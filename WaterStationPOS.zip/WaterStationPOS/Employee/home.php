<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Home</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/sweetalert2@11.js"></script>
</head>

<body>

    <header class="home-header">
        <div class="logo-container">
            <!--logo pic-->
            <img src="pic.png" alt="Water Station Logo" class="water-logo">
        </div>
        <nav class="user">
            <button class="btn-profile">Profile</button>
            <button class="btn-logout">Logout</button>
        </nav>
    </header>

    <main class="container">

        <section class="product-panel">
            <header class="product-header">
                <h2>Products</h2>
            </header>

            <div class="product-grid">
                <button class="product-btn">
                    <div class="product-name">Round Gallon Refill</div>
                    <div class="product-price">₱30.00</div>
                </button>

                <button class="product-btn">
                    <div class="product-name">Slim Gallon Refill</div>
                    <div class="product-price">₱30.00</div>
                </button>

                <button class="product-btn">
                    <div class="product-name">New Round Container</div>
                    <div class="product-price">₱150.00</div>
                </button>

                <button class="product-btn">
                    <div class="product-name">New Slim Container</div>
                    <div class="product-price">₱150.00</div>
                </button>

                <button class="product-btn">
                    <div class="product-name">PET Bottle (500ml)</div>
                    <div class="product-price">₱15.00</div>
                </button>
            </div>
        </section>


        <section class="checkout-panel">
            <header class="panel-header">
                <h2>Current Order</h2>
            </header>

            <div class="cart-container">
                <ul class="cart-list" id="active-cart">
                    <li class="cart-item">
                        <div class="item-qty">2x</div>
                        <div class="item-name">Round Gallon Refill</div>
                        <div class="item-subtotal">₱60.00</div>
                        <button class="remove-item-btn">X</button>
                    </li>
                </ul>
            </div>

            <div class="checkout-calculator">
                <div class="calc-row summary-row">
                    <div class="label">Total Amount:</div>
                    <div class="value total-display" id="order-total">₱60.00</div>
                </div>

                <div class="calc-row input-row">
                    <label for="cash-tendered" class="label">Cash Given:</label>
                    <input type="number" id="cash-tendered" class="payment-input" placeholder="0.00" min="0">
                </div>

                <div class="calc-row summary-row highlight">
                    <div class="label">Change:</div>
                    <div class="value change-display" id="order-change">₱0.00</div>
                </div>
            </div>

            <footer class="checkout-actions">
                <button class="action-btn clear-btn" id="btn-clear-cart">Clear</button>
                <button class="action-btn checkout-btn" id="btn-complete-sale">Checkout</button>
            </footer>
        </section>

    </main>

</body>

</html>