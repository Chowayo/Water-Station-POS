<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/sweetalert2@11.js"></script>
    <style>
        body {
            background-color: #B5D8FF;
        }
    </style>
</head>

<body>

    <div class="container d-flex justify-content-center align-items-center vh-100">

        <div class="card shadow-sm" style="width: 384px;">
            <div class="card-body p-4">

                <h3 class="card-title text-center mb-4 fw-bold">Employee Login</h3>

                <form id="loginForm">
                    <div class="mb-3">
                        <label for="username" class="form-label fw-semibold">Username</label>
                        <input type="text" class="form-control" id="username" placeholder="Enter your username" required>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label fw-semibold">Password</label>
                        <input type="password" class="form-control" id="password" placeholder="Enter your password" required>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">

                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="rememberMe">
                            <label class="form-check-label" for="rememberMe" style="font-size: 14px;">
                                Remember me
                            </label>
                        </div>

                        <a href="#" class="text-decoration-none" style="font-size: 14px;">Forgot password?</a>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg fw-semibold">Login</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>

    </script>

</body>

</html>