<?php include 'header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-delivered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
    }

    .status-invoiced {
        background-color: rgba(179, 136, 255, 0.1);
        color: #b388ff;
        border: 1px solid #b388ff;
    }

    .status-contracted {
        background-color: rgba(130, 170, 255, 0.1);
        color: #82aaff;
        border: 1px solid #82aaff;
    }

    .status-paid {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
    }

    .status-overdue {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .category-chip {
        display: inline-block;
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        white-space: nowrap;
    }

    .price-cell {
        color: #64FFDA;
        font-weight: 600;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Order Confirmations</h1>
                    <h6>Review incoming purchase orders and confirm or decline the order</h6>
                </div>
            </header>

            <!-- KPI Summary Cards  -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Awaiting Confirmation</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Order Confirmed'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Confirmed This Month</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php
                                //Counts Contract approved
                                $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Approved' OR status = 'Contract Approved'";
                                $query = $conn->query($sql);
                                $approved_month = $query->fetch_object();

                                if ($approved_month != "") {
                                    echo $approved_month->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Declined This Month</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Order Declined'";
                                $query = $conn->query($sql);
                                $currents_reject = $query->fetch_object();
                                if ($currents_reject != "") {
                                    echo $currents_reject->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Total PO Value</div>
                        <div class="dash-value">
                            <?php
                            //TOTAL PO (TOTAL value of anything in this current table)
                            $sql = "SELECT SUM(cost) AS total FROM stock_request WHERE deleted ='False' AND status = 'Contract Approved' OR status = 'Supplier Order Confirmed' OR status = 'Inventory Order Received' OR status = 'Finance Invoice Closed' OR status = 'Supplier Payment Received' OR status = 'Supplier Order Declined' OR status = 'Finance Return to Supplier' ORDER BY id DESC";
                            $query = $conn->query($sql);
                            if ($query && $row = $query->fetch_object()) {
                                if (empty($row->total)) {
                                    $pending_value = 0;
                                } else {
                                    $pending_value = $row->total;
                                }
                            } else {
                                $pending_value = 0;
                            }

                            echo '₱'.$pending_value;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Purchase Orders</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Incoming Orders</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="poStatusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Delivered">Delivered</option>
                                    <option value="Invoice Sent">Invoice Sent</option>
                                    <option value="Paid">Paid</option>
                                    <option value="Declined">Declined</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search PO" id="poSearcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var poTable = $('#po_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#poSearcher').on('keyup change clear', function() {
                                    poTable.search(this.value).draw();
                                });

                                $('#poStatusFilter').on('change', function() {
                                    poTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="po_list">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Request ID</th>
                                    <th>Category</th>
                                    <th>Payment Terms</th>
                                    <th>SLA</th>
                                    <th>Total Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->

                                <?php
                                    $sql = "SELECT * FROM stock_request WHERE deleted = 'False' AND status = 'Contract Approved' OR status = 'Supplier Order Confirmed' OR status = 'Inventory Order Received' OR status = 'Finance Invoice Closed' OR status = 'Supplier Payment Received' OR status = 'Supplier Order Declined' OR status = 'Finance Return to Supplier' ORDER BY id DESC";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo'
                                            <tr>
                                                <td>PO-'.$set->order_number.'</td>
                                                <td>REQ-'.$set->id.'</td>
                                                <td><span class="category-chip">'.ucfirst($set->category).'</span></td>
                                                <td>'.$set->payment_method.'</td>
                                                <td>'.$set->delivery_commitment.'</td>
                                                <td>₱'.$set->final_cost.'</td>';
                                        
                                        if($set->status == "Contract Approved"){
                                            echo'<td><span class="status-badge status-pending">Pending</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-po"
                                                        data-po="PO-'.$set->order_number.'"
                                                        data-req="REQ-'.$set->id.'"
                                                        data-buyer="'.$set->supplier_name.'"
                                                        data-category="'.ucfirst($set->category).'"
                                                        data-terms="'.$set->payment_method.'"
                                                        data-sla="'.$set->delivery_commitment.'"
                                                        data-contract-type="REMOVED"
                                                        data-cost="'.$set->final_cost.'"
                                                        data-number="'.$set->id.'"
                                                        data-product="'.$set->supplier_product_name.'">
                                                        <i class="bi bi-clipboard-check me-1"></i>Review
                                                    </button>
                                                </td>
                                            </tr>
                                        ';
                                        }
                                        else if ($set->status=="Supplier Order Confirmed"){
                                            echo'
                                                <td><span class="status-badge status-approved">Supplier Order Confirmed</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-deliver-po"
                                                        data-po="PO-'.$set->order_number.'"
                                                        data-req="REQ-'.$set->id.'"
                                                        data-cost="'.$set->final_cost.'"
                                                        data-terms="'.$set->payment_method.'"
                                                        data-number="'.$set->id.'"
                                                        data-date="'.$set->date_requested.'">
                                                        <i class="bi bi-truck me-1"></i>Deliver
                                                    </button>
                                                </td>
                                            ';
                                            
                                        }

                                        else if ($set->status=="Inventory Order Received"){
                                            echo'
                                                <td><span class="status-badge status-delivered">Inventory Order Received</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-invoice-po"
                                                        data-po="PO-'.$set->order_number.'"
                                                        data-req="REQ-'.$set->id.'"
                                                        data-cost="'.$set->final_cost.'"
                                                        data-terms="'.$set->payment_method.'"
                                                        data-number="'.$set->id.'"
                                                        data-date="'.$set->date_requested.'">
                                                        <i class="bi bi-receipt me-1"></i>Generate Invoice
                                                    </button>
                                                </td>
                                            ';
                                            
                                        }

                                        else if($set->status=="Finance Invoice Closed"){
                                            echo'
                                                <td><span class="status-badge status-invoiced">Invoice Sent</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-check-payment"
                                                        data-invoice="INV-'.$set->invoice_number.'"
                                                        data-po="PO-'.$set->order_number.'"
                                                        data-amount="'.$set->invoice_amount.'"
                                                        data-number="'.$set->id.'">
                                                        <i class="bi bi-cash-coin me-1"></i>Check Payment
                                                    </button>
                                                </td>
                                            ';
                                        }
        
                                        else if($set->status=="Supplier Payment Received"){
                                            echo'
                                                <td><span class="status-badge status-paid">Paid</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-check-payment" disabled>
                                                        <i class="bi bi-check-circle me-1"></i>Paid
                                                    </button>
                                                </td>
                                            ';
                                        }

                                        else if($set->status=="Supplier Order Declined"){
                                            echo'
                                                <td><span class="status-badge status-rejected">Declined</span></td>
                                                <td>
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-x-circle me-1"></i>Declined
                                                    </button>
                                                </td>
                                            
                                            ';
                                        }

                                        else if($set->status=="Finance Return to Supplier"){
                                            echo'
                                                <td><span class="status-badge status-rejected">Returned to Supplier</span></td>
                                                <td>
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-x-circle me-1"></i>Returned
                                                    </button>
                                                </td>
                                            ';
                                        }



                                                
                                    }

                                ?>

                                <!--
                                <tr>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>Gcash</td>
                                    <td>Ships within 3 business days</td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Confirmed</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-deliver-po"
                                            data-po="PO-1002"
                                            data-req="REQ-0002"
                                            data-cost="1200"
                                            data-terms="Gcash"
                                            data-items='[{"name":"Bottle Caps (Blue)","qty":500,"unit":"₱2.40"}]'>
                                            <i class="bi bi-truck me-1"></i>Deliver
                                        </button>
                                    </td>
                                    </tr>
                                <tr>
                                    <td>PO-0989</td>
                                    <td>REQ-0009</td>
                                    <td><span class="category-chip">Filters</span></td>
                                    <td>Bank Transfer</td>
                                    <td>Net 30</td>
                                    <td>₱15,750.00</td>
                                    <td><span class="status-badge status-invoiced">Invoice Sent</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-check-payment"
                                            data-invoice="INV-0989"
                                            data-po="PO-0989"
                                            data-amount="15750">
                                            <i class="bi bi-cash-coin me-1"></i>Check Payment
                                        </button>
                                    </td>
                                </tr>-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Review Purchase Order Modal  -->
            <div class="modal fade" id="reviewPoModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Purchase Order — <span id="poNumber">PO-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="poBuyer">Buyer</span>
                                <span class="category-chip" id="poCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="poReqId">—</span>
                            </div>

                            <div id="productName"></div>

                            <div class="req-detail-item">
                                <span>Payment Method</span>
                                <span id="poTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="poSla">—</span>
                            </div>
                            

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Total Order Value</span>
                                <span class="fw-bold fs-5" id="poTotalCost">₱0.00</span>
                            </div>
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Decline Reason</label>
                                    <textarea class="form-control" id="poDeclineReason" rows="2" placeholder="Required if declining this order" name="initial_supplier_note"></textarea>
                                    <input type="text" id="idNumber" name="id" hidden>
                                </div>

                                <div class="modal-footer flex-wrap">
                                    <button type="submit" name="contract_update" value="Supplier Order Declined" class="btn btn-remove rounded-pill px-4" id="btnDeclinePo">
                                        <i class="bi bi-x-lg me-1"></i>Decline Order
                                    </button>
                                    <button type="submit" name="contract_update" value="Supplier Order Confirmed" class="btn btn-confirm rounded-pill px-4" id="btnConfirmPo">
                                        <i class="bi bi-check-lg me-1"></i>Confirm Order
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Delivery Receipt Modal  -->
            <div class="modal fade" id="deliveryReceiptModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Delivery Receipt — <span id="drPoNumber">PO-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block">Receipt No.</span>
                                <span id="drReceiptNo">—</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="drReqId">—</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Date Issued</span>
                                <span id="drDateIssued">—</span>
                            </div>

                            <div id="drItemsList"></div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Total Order Value</span>
                                <span class="fw-bold fs-5" id="drTotalCost">₱0.00</span>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">
                                    Close
                                </button>
                                <form method="POST">
                                    <input type="text" name="id" id="idNumber_1" hidden>
                                    <button type="submit" name="supplier_deliver" value="Supplier Delivered" class="btn btn-confirm rounded-pill px-4" id="btnSubmitDelivery">
                                        <i class="bi bi-truck me-1"></i>Confirm Delivery
                                    </button>
                                </form>
                                
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Supplier Invoice Modal  -->
            <div class="modal fade" id="supplierInvoiceModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Supplier Invoice — <span id="invNumber">INV-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="small" style="color:#8892B0;">PO Reference</span>
                                <span id="invPoNumber">—</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="invReqId">—</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="small" style="color:#8892B0;">Date Issued</span>
                                <span id="invDateIssued">—</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Payment Terms</span>
                                <span id="invTerms">—</span>
                            </div>

                            <div id="invItemsList"></div>

                            <div class="req-detail-item">
                                <span>Subtotal</span>
                                <span id="invSubtotal">₱0.00</span>
                            </div>
                            <div class="req-detail-item">
                                <span>VAT (12%)</span>
                                <span id="invVat">₱0.00</span>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Total Amount Due</span>
                                <span class="fw-bold fs-5" id="invTotalCost">₱0.00</span>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">
                                    Close
                                </button>
                                <form method="POST">
                                    <input type="text" name="id" class="idNumber" hidden>
                                    <input type="number" id="invTotalCostInput" name="invoice_total" step="0.01" min="0" hidden>
                                    <button type="submit" name="invoice_submit" value="Supplier Invoice Sent" class="btn btn-confirm rounded-pill px-4">
                                        <i class="bi bi-send me-1"></i>Submit Invoice to Finance
                                    </button>
                                </form>
                                
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Payment Status Modal  -->
            <div class="modal fade" id="paymentStatusModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Payment Status — <span id="paymentInvoiceNo">INV-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="small" style="color:#8892B0;">PO Reference</span>
                                <span id="paymentPoNumber">—</span>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-2 mb-3">
                                <span class="fw-semibold">Amount Due</span>
                                <span class="fw-bold fs-5" id="paymentAmountDue">₱0.00</span>
                            </div>

                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" id="paymentReceivedCheck">
                                <label class="form-check-label" for="paymentReceivedCheck">
                                    We have received payment from Finance for this invoice
                                </label>
                            </div>

                        </div>

                        <div class="modal-footer flex-wrap">

                            <form method="POST">
                                <input type="text" name="id" class="idNumber" hidden>
                                <button type="submit" name="invoice_sent" value="Supplier Value Not Received" class="btn btn-remove rounded-pill px-4" id="btnPaymentNotReceived">
                                    <i class="bi bi-x-lg me-1"></i>Didn't Receive Payment
                                </button>
                                <button type="submit" name="invoice_sent" value="Finance Invoice Done" class="btn btn-confirm rounded-pill px-4" id="btnMarkPaid" disabled>
                                    <i class="bi bi-check-lg me-1"></i>Mark as Paid
                                </button>
                            </form>
                            
                        </div>

                    </div>
                </div>
            </div>

            <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                    // Add Request
                    if (isset($_POST['contract_update'])) {
                        $initial_supplier_note = $_POST['initial_supplier_note'];
                        if($initial_supplier_note==""){
                            $initial_supplier_note = "NO NOTES";
                        }
                        $id = $_POST['id'];
                        echo <<<HTML
                            <script>
                                console.log("{$initial_supplier_note}");
                                console.log("{$_POST['contract_update']}");
                                console.log("{$id}");
                            </script>
                        HTML;
                        
                        $sql = "UPDATE `stock_request` SET `status` = ?, initial_supplier_note = ? WHERE id = '" . $id . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ss", $_POST['contract_update'], $initial_supplier_note);
                        if ($stmt->execute()) {
                            echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Contract Updated!',
                                                    text: '',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#00E676',
                                                    heightAuto: false
                                                }).then((result) => {
                                                    if(result.isConfirmed) {
                                                        location.assign('orders.php');
                                                    }});
                                            })
                                            
                                        </script> 
                                    HTML;
                        }


                    }

                    if (isset($_POST['supplier_deliver'])) {
                        $id = $_POST['id'];                        
                        $sql = "UPDATE `stock_request` SET `status` = ? WHERE id = '" . $id . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $_POST['supplier_deliver']);
                        if ($stmt->execute()) {
                            echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Order Delivered!',
                                                    text: '',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#00E676',
                                                    heightAuto: false
                                                }).then((result) => {
                                                    if(result.isConfirmed) {
                                                        location.assign('orders.php');
                                                    }});
                                            })
                                        </script> 
                                    HTML;
                        }
                    }

                    if (isset($_POST['invoice_submit'])) {
                        $id = $_POST['id'];
                        $invoice_total =  $_POST['invoice_total'];
                        $invoice_number = rand(1,9999999999);
                        $sql = "UPDATE `stock_request` SET `status` = ?, `invoice_number` = ?, `invoice_amount` = ?   WHERE id = '" . $id . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ssd", $_POST['invoice_submit'], $invoice_number, $invoice_total);
                        if ($stmt->execute()) {
                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Invoice Sent!',
                                            text: 'Please wait for the notification of Invoice approval',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('orders.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                        }
                    }

                    if (isset($_POST['invoice_sent'])) {
                        $id = $_POST['id'];
                        $sql = "UPDATE `stock_request` SET `status` = ? WHERE id = '" . $id . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $_POST['invoice_sent']);
                        if ($stmt->execute()) {
                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Invoice Updated!',
                                            text: '',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('orders.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                        }
                    }

                }




            ?>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            var $activePoRow = null;

            $(document).on('click', '.btn-review-po', function() {
                $activePoRow = $(this).closest('tr');
                var $btn = $(this);

                $('#poNumber').text($btn.data('po'));
                $('#productName').text("Product: "+$btn.data('product'));
                $('#idNumber').val($btn.data('number'));
                $('#poBuyer').text($btn.data('buyer'));
                $('#poCategory').text($btn.data('category'));
                $('#poReqId').text($btn.data('req'));
                $('#poTerms').text($btn.data('terms') === 'COD' ? 'Cash on Delivery' : $btn.data('terms'));
                $('#poSla').text($btn.data('sla'));
                $('#poContractType').text($btn.data('contract-type'));
                $('#poTotalCost').text(formatPeso(parseFloat($btn.data('cost'))));
                $('#poDeclineReason').val('');

                var items = $btn.data('items') || [];
                var $list = $('#poItemsList').empty();
                items.forEach(function(item) {
                    $list.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + ' × ' + item.qty + '</span>' +
                        '<span>' + item.unit + '</span>' +
                        '</div>'
                    );
                });

                $('#reviewPoModal').modal('show');
            });

            $('#btnConfirmPo').click(function() {
                if (!$activePoRow) return;

                $activePoRow.find('td').eq(6)
                    .html('<span class="status-badge status-approved">Confirmed</span>');

                $activePoRow.find('.btn-review-po')
                    .removeClass('btn-review-po btn-confirm')
                    .addClass('btn-deliver-po btn-confirm')
                    .prop('disabled', false)
                    .html('<i class="bi bi-truck me-1"></i>Deliver');

                $('#reviewPoModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Order Confirmed',
                    text: $('#poNumber').text() + ' has been confirmed. Procurement will be notified.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            var $activeDeliveryRow = null;

            $(document).on('click', '.btn-deliver-po', function() {
                $activeDeliveryRow = $(this).closest('tr');
                var $btn = $(this);
                var poNumber = $btn.data('po');

                $('#drPoNumber').text(poNumber);
                $('#idNumber_1').val($btn.data('number'));
                $('#drReceiptNo').text('RCPT-' + poNumber.replace('PO-', ''));
                $('#drReqId').text($btn.data('req'));
                $('#drDateIssued').text($btn.data('date'));
                $('#drTotalCost').text(formatPeso(parseFloat($btn.data('cost')) || 0));

                var items = $btn.data('items') || [];
                var $list = $('#drItemsList').empty();
                items.forEach(function(item) {
                    $list.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + ' × ' + item.qty + '</span>' +
                        '<span>' + item.unit + '</span>' +
                        '</div>'
                    );
                });

                $('#deliveryReceiptModal').modal('show');
            });

            $('#btnSubmitDelivery').click(function() {
                if (!$activeDeliveryRow) return;

                $activeDeliveryRow.find('td').eq(6)
                    .html('<span class="status-badge status-delivered">Delivered</span>');

                $activeDeliveryRow.find('.btn-deliver-po')
                    .removeClass('btn-deliver-po')
                    .addClass('btn-invoice-po')
                    .prop('disabled', false)
                    .html('<i class="bi bi-receipt me-1"></i>Generate Invoice');

                $('#deliveryReceiptModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Delivery Confirmed',
                    text: $('#drPoNumber').text() + ' has been marked as delivered. A delivery receipt has been sent to the buyer.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            var $activeInvoiceRow = null;

            $(document).on('click', '.btn-invoice-po', function() {
                $activeInvoiceRow = $(this).closest('tr');
                var $btn = $(this);
                var poNumber = $btn.data('po');
                var subtotal = parseFloat($btn.data('cost')) || 0;
                var vat = subtotal * 0.12;
                var total = subtotal + vat;

                $('#invNumber').text('INV-' + poNumber.replace('PO-', ''));
                $('#invPoNumber').text(poNumber);
                $('#invReqId').text($btn.data('req'));
                $('#invDateIssued').text($btn.data('date'));
                $('.idNumber').val($btn.data('number'));
                $('#invTerms').text($btn.data('terms') === 'COD' ? 'Cash on Delivery' : $btn.data('terms'));
                $('#invSubtotal').text(formatPeso(subtotal));
                $('#invVat').text(formatPeso(vat));
                $('#invTotalCost').text(formatPeso(total));
                $('#invTotalCostInput').val(total);

                var items = $btn.data('items') || [];
                var $list = $('#invItemsList').empty();
                items.forEach(function(item) {
                    $list.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + ' × ' + item.qty + '</span>' +
                        '<span>' + item.unit + '</span>' +
                        '</div>'
                    );
                });

                $('#supplierInvoiceModal').modal('show');
            });

            $('#btnSubmitInvoice').click(function() {
                
            });

            // ---- Payment Status ----
            var $activePaymentRow = null;

            $(document).on('click', '.btn-check-payment', function() {
                $activePaymentRow = $(this).closest('tr');
                var $btn = $(this);

                var amountDisplay = $btn.data('amount');

                $('#paymentInvoiceNo').text($btn.data('invoice'));
                $('#paymentPoNumber').text($btn.data('po'));
                $('#paymentAmountDue').text(amountDisplay);
                $('#paymentReceivedCheck').prop('checked', false);
                $('#paymentReference').val('REF-' + Math.floor(100000 + Math.random() * 900000));
                $('#paymentNotes').val('');
                $('#btnMarkPaid').prop('disabled', true);
                $('.idNumber').val($btn.data('number'));

                $('#paymentStatusModal').modal('show');
            });

            $('#paymentReceivedCheck').on('change', function() {
                $('#btnMarkPaid').prop('disabled', !this.checked);
            });

            $('#btnMarkPaid').click(function() {
                if (!$activePaymentRow || !$('#paymentReceivedCheck').is(':checked')) return;

                var reference = $('#paymentReference').val();
                var invoiceNo = $('#paymentInvoiceNo').text();

                $activePaymentRow.find('td').eq(6)
                    .html('<span class="status-badge status-paid">Paid</span>');

                $activePaymentRow.find('.btn-check-payment')
                    .removeClass('btn-confirm btn-check-payment')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-check-circle me-1"></i>Paid');

                $('#paymentStatusModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Payment Confirmed',
                    text: invoiceNo + ' has been marked as paid (Ref: ' + reference + ').',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnPaymentNotReceived').click(function() {
                if (!$activePaymentRow) return;

                var notes = $('#paymentNotes').val().trim();
                if (!notes) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Notes Required',
                        text: 'Please add a note explaining that payment has not been received.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                var invoiceNo = $('#paymentInvoiceNo').text();

                $activePaymentRow.find('td').eq(6)
                    .html('<span class="status-badge status-overdue">Payment Overdue</span>');

                $activePaymentRow.find('.btn-check-payment')
                    .html('<i class="bi bi-cash-coin me-1"></i>Check Payment');

                $('#paymentStatusModal').modal('hide');

                Swal.fire({
                    icon: 'warning',
                    title: 'Payment Not Received',
                    text: invoiceNo + ' has been flagged as overdue. Finance has been notified.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 2000,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnDeclinePo').click(function() {
                if (!$activePoRow) return;

                var reason = $('#poDeclineReason').val().trim();
                if (!reason) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Reason Required',
                        text: 'Please provide a reason for declining this order.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                $activePoRow.find('td').eq(6)
                    .html('<span class="status-badge status-rejected">Declined</span>');

                $activePoRow.find('.btn-review-po')
                    .removeClass('btn-confirm')
                    .addClass('btn-remove')
                    .prop('disabled', true)
                    .html('<i class="bi bi-x-circle me-1"></i>Declined');

                $('#reviewPoModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Order Declined',
                    text: $('#poNumber').text() + ' has been declined. Procurement will be notified to renegotiate.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>