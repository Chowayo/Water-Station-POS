<style>
    .top-nav {
        background-color: #112240;
        border-bottom: 1px solid #233554;
    }

    .top-nav-brand-logo {
        width: 42px;
        height: 42px;
        object-fit: contain;
        border-radius: 50%;
        border: 2px solid #64FFDA;
        background-color: #0A192F;
    }

    .top-nav-brand-name {
        font-weight: 800;
        font-size: 14px;
        letter-spacing: 0.5px;
        color: #FFFFFF;
        white-space: nowrap;
    }

    .top-nav-links {
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .top-nav-link {
        color: #b09b88;
        font-weight: 700;
        font-size: 14px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 14px;
        border-radius: 8px;
        white-space: nowrap;
        transition: 0.2s;
    }

    .top-nav-link:hover,
    .top-nav-link.active {
        color: #64FFDA;
        background-color: rgba(100, 255, 218, 0.1);
    }

    .cart-btn {
        position: relative;
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #8892B0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .cart-btn:hover {
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .cart-badge {
        position: absolute;
        top: -4px;
        right: -4px;
        background-color: #FF5252;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        min-width: 18px;
        height: 18px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
    }

    .cart-offcanvas {
        background-color: #112240;
        border-left: 1px solid #233554;
        width: 380px;
        max-width: 90vw;
    }

    .cart-offcanvas .offcanvas-header {
        border-bottom: 1px solid #233554;
        padding: 18px 20px;
    }

    .cart-offcanvas .offcanvas-title {
        font-weight: 800;
        font-size: 18px;
        color: #FFFFFF;
    }

    .cart-offcanvas .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    .cart-offcanvas .offcanvas-body {
        padding: 20px;
        display: flex;
        flex-direction: column;
    }

    .cart-scroll {
        flex: 1;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .cart-scroll::-webkit-scrollbar {
        width: 6px;
    }

    .cart-scroll::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.35);
        border-radius: 10px;
    }

    .cart-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .cart-store-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 14px;
        padding: 14px;
    }

    .cart-store-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .cart-store-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .cart-store-logo {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        object-fit: cover;
        flex-shrink: 0;
        background-color: #112240;
    }

    .cart-store-name {
        font-weight: 700;
        font-size: 14px;
        color: #E6F1FF;
        margin: 0;
    }

    .cart-store-meta {
        font-size: 12px;
        color: #8892B0;
        margin: 0;
    }

    .cart-store-meta .cyan-text {
        font-weight: 600;
    }

    .cart-store-actions {
        display: flex;
        gap: 4px;
    }

    .cart-edit-btn,
    .cart-remove-btn {
        background: none;
        border: none;
        color: #8892B0;
        cursor: pointer;
        transition: 0.2s;
        padding: 4px 8px;
    }

    .cart-edit-btn:hover {
        color: #64FFDA;
    }

    .cart-remove-btn:hover {
        color: #FF5252;
    }

    /* CART SUMMARY BOX STYLES */
    .cart-summary-box {
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px;
        margin-top: 10px;
    }

    .cart-summary-lines p {
        color: #ccd6f6;
        font-size: 13px;
        margin: 0 0 6px 0;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .cart-summary-lines .qty-text {
        color: #64FFDA;
        font-weight: 700;
        margin-right: 6px;
    }

    .cart-summary-lines .more-text {
        color: #8892B0;
        font-style: italic;
        font-size: 12px;
        margin-top: 8px;
        margin-bottom: 0;
    }

    .cart-summary-total {
        color: #00e676;
        font-weight: 800;
        font-size: 15px;
        margin-top: 12px;
        margin-bottom: 12px;
        text-align: right;
    }

    .btn-show-all {
        width: 100%;
        background-color: transparent;
        border: 1px solid #64FFDA;
        color: #64FFDA;
        border-radius: 6px;
        padding: 8px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .btn-show-all:hover {
        background-color: rgba(100, 255, 218, 0.1);
        transform: translateY(-1px);
    }

    .cart-subtotal-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 14px 0 10px;
    }

    .cart-subtotal-label {
        font-size: 13px;
        color: #8892B0;
    }

    .cart-subtotal-value {
        font-weight: 800;
        font-size: 16px;
        color: #FFFFFF;
    }

    .cart-checkout-btn {
        width: 100%;
        background-color: #64FFDA;
        color: #0A192F;
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-weight: 800;
        transition: 0.2s;
    }

    .cart-checkout-btn:hover {
        background-color: #1de9b6;
        color: #0A192F;
    }

    .cart-empty {
        text-align: center;
        color: #8892B0;
        font-size: 13px;
        padding: 30px 10px;
    }

    /* MODAL STYLES */
    .cart-modal .modal-content {
        background-color: #0f172a;
        border: 1px solid #233554;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }

    .cart-modal .modal-header {
        background-color: transparent;
        border-bottom: 1px solid #233554;
        padding: 20px 24px 16px;
        align-items: flex-start;
        border-radius: 12px 12px 0 0;
    }

    .cart-modal .modal-title-wrap {
        display: flex;
        flex-direction: column;
    }

    .cart-modal .modal-title-main {
        color: #ffffff;
        font-weight: 800;
        font-size: 18px;
        margin-bottom: 4px;
        line-height: 1.2;
    }

    .cart-modal .modal-title-sub {
        color: #8892b0;
        font-size: 13px;
        margin: 0;
        font-weight: 400;
    }

    .cart-modal .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
        opacity: 0.5;
        margin-top: -5px;
    }

    .cart-modal .btn-close:hover {
        opacity: 1;
    }

    .cart-modal .modal-body {
        padding: 0;
    }

    .modal-item-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 24px;
        border-bottom: 1px solid #233554;
    }

    .modal-item-row:last-child {
        border-bottom: none;
    }

    .modal-item-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .modal-item-qty {
        background-color: rgba(100, 255, 218, 0.15);
        color: #64FFDA;
        font-weight: 700;
        font-size: 13px;
        padding: 4px 10px;
        border-radius: 6px;
        min-width: 34px;
        text-align: center;
    }

    .modal-item-name {
        color: #ffffff;
        font-weight: 600;
        font-size: 14px;
    }

    .modal-item-price {
        color: #e2e8f0;
        font-weight: 600;
        font-size: 14px;
    }

    .modal-footer-custom {
        padding: 20px 24px;
        background-color: transparent;
        border-top: 1px solid #233554;
        border-radius: 0 0 12px 12px;
    }

    .modal-subtotal-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }

    .modal-subtotal-label {
        color: #8892b0;
        font-size: 14px;
    }

    .modal-subtotal-value {
        color: #ffffff;
        font-weight: 800;
        font-size: 18px;
    }

    .btn-modal-checkout {
        width: 100%;
        background-color: #64ffda;
        color: #000000;
        border: none;
        border-radius: 10px;
        padding: 14px;
        font-weight: 800;
        font-size: 16px;
        transition: 0.2s;
        text-align: center;
        text-decoration: none;
        display: block;
    }

    .btn-modal-checkout:hover {
        background-color: #1de9b6;
        color: #000000;
    }

    /* Notification Styling */
    .notif-btn {
        position: relative;
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #64ffda;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .notif-btn:hover {
        background-color: rgba(100, 255, 218, 0.1);
    }

    .notif-btn svg {
        width: 20px;
        height: 20px;
    }

    .notif-badge {
        position: absolute;
        top: -2px;
        right: -2px;
        background-color: #ff4d4d;
        color: #ffffff;
        font-size: 10px;
        font-weight: 700;
        min-width: 16px;
        height: 16px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 3px;
        border: 2px solid #ffffff;
    }

    .notif-dropdown {
        width: 320px;
        max-width: 90vw;
        border-radius: 14px;
        border: 1px solid #233554;
        background-color: #112240;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.35);
        overflow: hidden;
    }

    .notif-scroll {
        max-height: 320px;
        overflow-y: auto;
    }

    .notif-scroll::-webkit-scrollbar {
        width: 6px;
    }

    .notif-scroll::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.25);
        border-radius: 10px;
    }

    .notif-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .notif-header {
        padding: 10px 16px;
        font-weight: 700;
        color: #ffffff;
        font-size: 14px;
        border-bottom: 1px solid #233554;
        background-color: #112240;
    }

    .notif-icon-btn {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        background-color: #0d1b2e;
        border: 1px solid #233554;
        color: #64ffda;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        cursor: pointer;
        transition: 0.2s;
    }

    .notif-icon-btn:hover {
        background-color: rgba(100, 255, 218, 0.1);
    }

    .notif-item {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px 16px;
        white-space: normal;
        border-bottom: 1px solid #233554;
        color: #ccd6f6;
    }

    .notif-item:hover {
        background-color: rgba(100, 255, 218, 0.06);
    }

    .notif-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-top: 6px;
        flex-shrink: 0;
    }

    .notif-dot-blue {
        background-color: #64ffda;
    }

    .profile-avatar-btn {
        height: 42px;
        margin: 0;
        padding: 0 16px;
        background-color: #0A192F;
        border: 2px solid #64FFDA;
        color: #64FFDA;
        border-radius: 25px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        font-weight: 600;
        font-size: 14px;
        white-space: nowrap;
        cursor: pointer;
        transition: 0.2s;
    }

    .profile-avatar-btn:hover {
        background-color: rgba(100, 255, 218, 0.1);
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .profile-avatar-btn i {
        font-size: 18px;
    }

    @media (max-width: 991.98px) {
        .top-nav-links {
            display: none;
        }
    }
</style>

<div class="top-nav d-flex justify-content-between align-items-center gap-3 px-4 py-2">

    <!-- Brand -->
    <div class="d-flex align-items-center gap-2">
        <a href="home.php" style="text-decoration: none;" class="d-flex align-items-center gap-2">
            <img src="../Images/logo.png" alt="Logo" class="top-nav-brand-logo">
            <span class="top-nav-brand-name"><span class="green-text">ECO</span> HYDRATE HUB</span>
        </a>
    </div>

    <div class="d-flex align-items-center gap-3">

        <?php

        $carts = [];

        //Loads the carts
        $sql = "SELECT * FROM orders WHERE cashier = 'USER ID:".$result->id."' AND deleted = 'False'";
        $query = $conn->query($sql);
        while ($set = $query->fetch_object()) {
            array_push($carts,
                [
                    'id' => $set->id,
                    'store_name' => 'Eco Hydrate - Dasmarinas', //Dummy
                    'store_logo' => '../Images/logo.png', //Permanent
                    'eta' => '5-20 mins', //Dummy
                    'delivery_fee' => 'Free', //Dummy
                    'subtotal' => $set->total_price,
                    'status' => $set->status,
                    'items' => [],
                    'allow_checkout'=>true
                ]
            );

            $lastIndex = array_key_last($carts);

            // Deconstruct the whole order_list to load 
            $order_string = $set->order_content;
            $orders = explode(',', $order_string);
            foreach ($orders as $value) {
                $input = $value;
                $pattern = '/^(\d+)x\s*(.*?)\s*₱([\d.]+)\s*VAT:([\d.]+)/u';
                //Inserts order informations to $carts[items] based on the value present in the order_list
                if (preg_match('/^(\d+)x\s*(.*?)\s*(\d+(?:\.\d+)?\s*(?:L|ML))\s*\((.*?)\)\s*₱([\d.]+)\s*VAT:([\d.]+)/ui', $input, $matches)) {
                    $carts[$lastIndex]['items'][] = [
                        'name'             => trim($matches[2]),
                        'measurement'      => $matches[3],
                        'category'         => $matches[4],
                        'qty'              => (int)$matches[1],
                        'price'            => (float)$matches[5],
                        'show_unavailable' => true,
                    ];
                }
            }

            $newItemIndex = 0;
        
            foreach ($carts[$lastIndex]['items'] as $item) {
                $name = $item['name'];
                $category = $item['category'];
                $qty = $item['qty'];
                $allow_checkout = true;
                $stat = $carts[$lastIndex]['status'];

                // Using prepared statements to prevent SQL injection and fixed syntax error
                $stmt = $conn->prepare("SELECT * FROM product WHERE product_name = ? AND category = ? AND deleted = 'False'");
                $stmt->bind_param("ss", $name, $category);
                $stmt->execute();
                $querys = $stmt->get_result();

                while ($val = $querys->fetch_object()) {
                    if($qty>$val->stock && $stat!="Submitted"){
                        $allow_checkout = false;
                        $carts[$lastIndex]['allow_checkout'] = false;
                        $carts[$lastIndex]['items'][$newItemIndex]['show_unavailable'] = false;
                    }
                }
                $newItemIndex +=1;
            }

            
        }

        $cart_grand_total = array_sum(array_column($carts, 'subtotal'));
        ?>

        <!-- Cart Button -->
        <button class="cart-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas" aria-label="View cart">
            <i class="bi bi-cart3"></i>
            <?php if (count($carts) > 0): ?>
                <span class="cart-badge"><?php echo count($carts); ?></span>
            <?php endif; ?>
        </button>

        <!-- Notification bell CUSTOMER -->
        <div class="dropdown">
            <button class="notif-btn" type="button" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
                <i class="bi bi-bell-fill"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end notif-dropdown p-0" aria-labelledby="notifDropdown">
                <div class="notif-header d-flex justify-content-between align-items-center">
                    <span>Notifications</span>
                    <span class="d-flex gap-2">
                        <form method="POST">
                            <button type="submit" name="read" class="notif-icon-btn" title="Mark all as read" aria-label="Mark all as read">
                                <i class="bi bi-check2-all"></i>
                            </button>
                        </form>
                        <form method="POST">
                            <button type="submit" name="deleter" class="notif-icon-btn" title="Clear all" aria-label="Clear all">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </form>
                    </span>
                </div>
                <div class="notif-scroll">
                    <?php
                    $customer_notif_id = isset($user->id) ? $user->id : 0;
                    $sql = "SELECT * FROM notification WHERE deleted = 'False' AND emp_id = '" . $customer_notif_id . "' AND role = '".$user->role."' ORDER BY id DESC";
                    $query = $conn->query($sql);
                    $notif_counter = 0;

                    if ($query) {
                        while ($notif_info = $query->fetch_object()) {
                            echo '
                                <form method="POST">
                                <button type="submit" name="single_read" value="' . $notif_info->id . '" class="dropdown-item notif-item">
                            ';

                            if ($notif_info->status == "Unread") {
                                echo '<span class="notif-dot notif-dot-blue"></span>';
                                $notif_counter += 1;
                            }

                            echo <<< HTML
                                        <div>
                                            <p class="mb-0 fw-semibold">{$notif_info->category}</p>
                                            <p class="mb-0 small text-muted">{$notif_info->message}</p>
                                            <p class="mb-0 small text-muted">{$notif_info->date}</p>
                                        </div>
                                    </button>
                                    </form>
                            HTML;
                        }
                    }

                    if ($notif_counter > 0) {
                        echo <<< HTML
                            <script>
                                $(document).ready(function() {
                                    $(".notif-btn").append('<span class="notif-badge">{$notif_counter}</span>'); 
                                })
                            </script>
                            HTML;
                    }

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $read_status = "read";
                        $delete_status = "True";

                        if (isset($_POST['read'])) {
                            $up_sql = "UPDATE `notification` SET `status` = ? WHERE emp_id = '" . $customer_notif_id . "' AND status = 'Unread'";
                            $stmt = $conn->prepare($up_sql);
                            if ($stmt) {
                                $stmt->bind_param("s", $read_status);
                                $stmt->execute();
                            }
                            echo '<script>location.assign(window.location.href);</script>';
                        }
                        if (isset($_POST['single_read'])) {
                            $up_sql = "UPDATE `notification` SET `status` = ? WHERE id = '" . $_POST['single_read'] . "'";
                            $stmt = $conn->prepare($up_sql);
                            if ($stmt) {
                                $stmt->bind_param("s", $read_status);
                                $stmt->execute();
                            }
                            echo '<script>location.assign(window.location.href);</script>';
                        }
                        if (isset($_POST['deleter'])) {
                            $up_sql = "UPDATE `notification` SET `deleted` = ? WHERE emp_id = '" . $customer_notif_id . "' AND deleted = 'False'";
                            $stmt = $conn->prepare($up_sql);
                            if ($stmt) {
                                $stmt->bind_param("s", $delete_status);
                                $stmt->execute();
                            }
                            echo '<script>location.assign(window.location.href);</script>';
                        }

                        if (isset($_POST['order_deleter'])) {
                            $up_sql = "UPDATE `orders` SET `deleted` = ? WHERE id = '" . $_POST['order_deleter'] . "' AND deleted = 'False'";
                            $stmt = $conn->prepare($up_sql);
                            if ($stmt) {
                                $stmt->bind_param("s", $delete_status);
                                $stmt->execute();
                            }
                            echo '<script>location.assign(window.location.href);</script>';
                        }

                    }
                    ?>
                </div>
                <hr class="dropdown-divider m-0" style="border-color: #233554;">
                <form method="POST"><button type="submit" name="read" class="dropdown-item text-center small fw-semibold py-2" style="color: #64ffda;">Mark All As Read</button></form>
            </div>
        </div>

        <!-- Profile button -->
        <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="#adminProfileModal" aria-label="Open profile">
            <span><?php echo isset($result->full_name) ? htmlspecialchars($result->full_name) : 'Customer'; ?></span> <i class="bi bi-person"></i>
        </button>

        <!-- Logout -->
        <a class="cart-btn" aria-label="Logout" title="Logout" id="logout">
            <i class="bi bi-box-arrow-right"></i>
        </a>

        <script>
            $(document).ready(function() {
                $("#logout").click(function(e) {
                    e.preventDefault();
                    Swal.fire({
                        showConfirmButton: false,
                        icon: "question",
                        title: "Do you want to Log out?",
                        background: '#112240',
                        color: '#CCD6F6',
                        html: `
                            <a href='../logout.php' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>`,
                        heightAuto: false
                    });
                });
            });
        </script>

    </div>
</div>

<!-- Cart offcanvas panel -->
<div class="offcanvas offcanvas-end cart-offcanvas" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="cartOffcanvasLabel">All carts</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="cart-scroll">
            <?php if (empty($carts)): ?>
                <div class="cart-empty">Your cart is empty.</div>
                <?php else: foreach ($carts as $cartIndex => $cart): ?>
                    <div class="cart-store-card">
                        <div class="cart-store-row">
                            <div class="cart-store-info">
                                <img src="<?php echo $cart['store_logo']; ?>" alt="" class="cart-store-logo">
                                <div>
                                    <p class="cart-store-name"><?php echo htmlspecialchars($cart['store_name']); ?></p>
                                    <p class="cart-store-meta"><?php echo htmlspecialchars($cart['eta']); ?> &bull; <span class="cyan-text"><?php echo htmlspecialchars($cart['delivery_fee']); ?></span></p>
                                </div>
                            </div>
                            <div class="cart-store-actions">

                                <button type="button" name="edit" class="cart-edit-btn" aria-label="Edit cart" title="Edit Cart">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                
                                <?php

                                    if( $cart['status']!="Submitted"){
                                        echo '
                                            <button type="button" name="delete" class="cart-remove-btn delete-btn" aria-label="Remove cart" title="Remove Cart" data-id="'. $cart['id'].'";">
                                                <i class="bi bi-trash3"></i>
                                            </button>
                                            
                                            ';
                                    }
                                    
                                ?>
                                


                            </div>
                        </div>

                        <!-- CART SUMMARY BOX -->
                        <div class="cart-summary-box">
                            <div class="cart-summary-lines">
                                <?php
                                $itemCount = count($cart['items']);
                                $displayCount = min(2, $itemCount);
                                for ($i = 0; $i < $displayCount; $i++):
                                    $item = $cart['items'][$i];
                                ?>

                                    <p><span class="qty-text"><?php echo $item['qty']; ?>x</span> <?php echo htmlspecialchars($item['name'])." ".htmlspecialchars($item['measurement'])." (".htmlspecialchars($item['category']).")"; ?></p>
                                <?php endfor; ?>

                                <?php if ($itemCount > 2): ?>
                                    <p class="more-text">...and <?php echo $itemCount - 2; ?> more item(s)</p>
                                <?php endif; ?>
                            </div>

                            <div class="cart-summary-total">Subtotal: &#8369;<?php echo number_format($cart['subtotal'], 2); ?></div>

                            <button type="button" class="btn-show-all" data-bs-toggle="modal" data-bs-target="#cartModal<?php echo $cartIndex; ?>">
                                Show All
                            </button>
                        </div>
                    </div>
            <?php endforeach;
            endif; ?>
        </div>
    </div>
</div>

<!-- MODALS FOR CART ITEMS -->
<?php if (!empty($carts)): foreach ($carts as $cartIndex => $cart): ?>
        <div class="modal fade cart-modal" id="cartModal<?php echo $cartIndex; ?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">

                    <div class="modal-header border-0 pb-3">
                        <div class="modal-title-wrap">
                            <h5 class="modal-title-main">All items</h5>
                            <p class="modal-title-sub"><?php echo htmlspecialchars($cart['store_name']); ?></p>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="modal-item-list">
                            <?php foreach ($cart['items'] as $item):?>
                                <div class="modal-item-row">
                                    <div class="modal-item-left">
                                        <span class="modal-item-qty">x<?php echo $item['qty']; ?></span>
                                        <span class="modal-item-name <?php if(!$item['show_unavailable']){echo "text-danger";}?> " ><?php echo htmlspecialchars($item['name'])." ".htmlspecialchars($item['measurement'])." (".htmlspecialchars($item['category']).")";  if(!$item['show_unavailable']){echo " (Out of Stock)";} ?></span>
                                    </div>
                                    <span class="modal-item-price">&#8369;<?php echo number_format($item['price'] * $item['qty'], 2); ?></span>
                                </div>
                            <?php  endforeach; ?>
                        </div>
                    </div>

                    <div class="modal-footer-custom">
                        <div class="modal-subtotal-row">
                            <span class="modal-subtotal-label">Subtotal</span>
                            <span class="modal-subtotal-value">&#8369;<?php echo number_format($cart['subtotal'], 2); ?></span>
                        </div>
                        <?php
                            if($cart['status']!="Submitted"){

                                if($cart['allow_checkout']){
                                    echo '
                                        <a href="checkout.php?id='.$cart['id'].'" class="btn-modal-checkout">
                                            Go to checkout
                                        </a>
                                    ';

                                }
                                
                                else{
                                    echo '
                                        <p class="alert alert-danger">
                                            A Product(s) From This Cart is Unavailable
                                        </p>
                                    ';
                                }
                            }else{
                                echo '
                                        <p class="alert alert-success">
                                            Order Submitted
                                        </p>
                                    ';

                            }

                            ?>
                    </div>

                </div>
            </div>
        </div>
<?php endforeach;
endif; ?>



<script>
    //Delete Order
    $(document).ready(function() {
        $(".delete-btn").click(function() {
            id = $(this).data('id');
            Swal.fire({
            title: 'Delete Cart?',
            icon: 'question',
            background: '#112240',
            color: '#CCD6F6',
            showCancelButton: true,
            showConfirmButton: false,
            cancelButtonColor: '#8892B0',
            html: '<form method="POST"><button type="submit" name="order_deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
            heightAuto: false
            })

        });
    });
</script>


<?php include __DIR__ . '/profile.php'; ?>