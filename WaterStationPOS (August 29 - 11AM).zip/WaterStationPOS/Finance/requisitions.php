<?php include __DIR__ . '/../components/header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-ordered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64ffda;
        border: 1px solid #64ffda;
    }

    /* Budget check indicators */
    .budget-ok {
        color: #00e676;
        font-weight: 700;
    }

    .budget-over {
        color: #ff5252;
        font-weight: 700;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Budget usage bar */
    .budget-bar-wrap {
        background-color: #0A192F;
        border-radius: 8px;
        height: 8px;
        overflow: hidden;
        margin-top: 6px;
    }

    .budget-bar-fill {
        height: 100%;
        border-radius: 8px;
    }

    .budget-bar-fill.ok {
        background-color: #00e676;
    }

    .budget-bar-fill.warn {
        background-color: #ffc107;
    }

    .budget-bar-fill.over {
        background-color: #ff5252;
    }

    .cost-centre-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 12px;
        padding: 14px 16px;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Request Approvals</h1>
                    <h6>Review requisitions against budget and approve or reject</h6>
                </div>
            </header>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Awaiting Review</div>
                        <div class="dash-value" style="color:#ffc107;">3</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved This Month</div>
                        <div class="dash-value" style="color:#00e676;">7</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Rejected This Month</div>
                        <div class="dash-value" style="color:#ff5252;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Value</div>
                        <div class="dash-value">₱6,850.00</div>
                    </div>
                </div>
            </div>

            <!-- Budget Overview -->
            <div class="section-header">Budgets (This Month)</div>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between">
                            <span class="fw-semibold">Supplies</span>
                            <span class="small" style="color:#8892B0;">₱6,900 / ₱10,000</span>
                        </div>
                        <div class="budget-bar-wrap">
                            <div class="budget-bar-fill ok" style="width: 69%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between">
                            <span class="fw-semibold">Maintenance</span>
                            <span class="small" style="color:#8892B0;">₱4,800 / ₱5,000</span>
                        </div>
                        <div class="budget-bar-wrap">
                            <div class="budget-bar-fill warn" style="width: 96%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between">
                            <span class="fw-semibold">Delivery</span>
                            <span class="small" style="color:#8892B0;">₱3,200 / ₱3,000</span>
                        </div>
                        <div class="budget-bar-wrap">
                            <div class="budget-bar-fill over" style="width: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Request Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="statusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Ordered">Ordered</option>
                                </select>
                                <select class="form-select" id="centreFilter" style="width: 170px;">
                                    <option value="">Category</option>
                                    <option value="Supplies">Supplies</option>
                                    <option value="Maintenance">Maintenance</option>
                                    <option value="Delivery">Delivery</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Request" id="searcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#request_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#statusFilter').on('change', function() {
                                    table.column(6).search(this.value).draw();
                                });

                                $('#centreFilter').on('change', function() {
                                    table.column(3).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="request_list">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Requested By</th>
                                    <th>Date Requested</th>
                                    <th>Category</th>
                                    <th>Items</th>
                                    <th>Est. Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>REQ-0001</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-22</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0001">3 items</button>
                                    </td>
                                    <td>₱2,450.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review"
                                            data-id="REQ-0001" data-centre="Supplies" data-budget="within">
                                            <i class="bi bi-clipboard-check me-1"></i>Review
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0002</td>
                                    <td>Maria Santos</td>
                                    <td>2026-08-24</td>
                                    <td>Maintenance</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0002">2 items</button>
                                    </td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Approved</span></td>
                                    <td>
                                        <button type="button" class="btn btn-confirm rounded-pill px-3" id="btnConfirmPo">
                                            <i class="bi bi-check-lg me-1 small"></i>
                                            </i>Approve
                                        </button>
                                        <button type="button" class="btn btn-remove rounded-pill px-3" id="btnDeclinePo">
                                            <i class="bi bi-x-lg me-1 small"></i>Reject
                                        </button>

                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0003</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-25</td>
                                    <td>Delivery</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0003">4 items</button>
                                    </td>
                                    <td>₱9,300.00</td>
                                    <td><span class="status-badge status-rejected">Rejected</span></td>
                                    <td>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-x-circle me-1"></i>Rejected
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0004</td>
                                    <td>Ana Reyes</td>
                                    <td>2026-08-27</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0004">1 item</button>
                                    </td>
                                    <td>₱850.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review"
                                            data-id="REQ-0004" data-centre="Supplies" data-budget="within">
                                            <i class="bi bi-clipboard-check me-1"></i>Review
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0005</td>
                                    <td>Maria Santos</td>
                                    <td>2026-08-27</td>
                                    <td>Delivery</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0005">2 items</button>
                                    </td>
                                    <td>₱3,600.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review"
                                            data-id="REQ-0005" data-centre="Delivery" data-budget="over">
                                            <i class="bi bi-clipboard-check me-1"></i>Review
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0006</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-19</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0006">3 items</button>
                                    </td>
                                    <td>₱4,150.00</td>
                                    <td><span class="status-badge status-ordered">Ordered</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-truck me-1"></i>Ordered
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Review Request Modal -->
            <div class="modal fade" id="reviewRequestModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Review Request — <span id="reviewReqId">REQ-0001</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="req-detail-item">
                                <span>5-Gallon Container x 20</span>
                                <span>₱1,700.00</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Screw Cap (Blue) x 200</span>
                                <span>₱500.00</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Chlorine Solution x 2</span>
                                <span>₱250.00</span>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Requested Total</span>
                                <span class="fw-bold fs-5">₱2,450.00</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                <span class="fw-semibold" style="color:#8892B0;">Budget</span>
                                <span id="reviewCentreLabel">Supplies — ₱10,000.00 / mo</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="fw-semibold" style="color:#8892B0;">Budget Status</span>
                                <span id="reviewBudgetStatus" class="budget-ok"><i class="bi bi-check-circle-fill me-1"></i>Within Budget</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Rejection / Reallocation Notes</label>
                                <textarea class="form-control" rows="2" placeholder="Required if rejecting or requesting reallocation"></textarea>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4">
                                    <i class="bi bi-x-lg me-1"></i>Reject
                                </button>
                                <button type="button" class="btn btn-confirm rounded-pill px-4">
                                    <i class="bi bi-check-lg me-1"></i>Approve
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Review Supplier Negotiation Modal -->
            <div class="modal fade" id="reviewSupplierNegotiationModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Review Supplier — <span id="reviewSupplierName">Supplier</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                <span class="fw-semibold" style="color:#8892B0;">Category</span>
                                <span id="reviewSupplierCategory" class="category-chip">Filters</span>
                            </div>

                            <div class="req-detail-item">
                                <span>Recommended By</span>
                                <span id="reviewSupplierRecommender">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Negotiated Payment Terms</span>
                                <span id="reviewSupplierTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="reviewSupplierSla">—</span>
                            </div>

                            <div class="mb-3 mt-3">
                                <label class="form-label small text-muted">Procurement Recommendation Notes</label>
                                <textarea class="form-control" id="reviewSupplierProcNotes" rows="2" disabled></textarea>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Est. Total Cost of Ownership</span>
                                <span class="fw-bold fs-5" id="reviewSupplierCost">₱0.00</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Finance Notes</label>
                                <textarea class="form-control" id="reviewSupplierFinanceNotes" rows="2" placeholder="Required if requesting revision"></textarea>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4" id="btnSupplierNeedsRevision">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>Needs Revision
                                </button>
                                <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnSupplierApprove">
                                    <i class="bi bi-check-lg me-1"></i>Approve
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            $('.btn-view').click(function() {
                $('#viewReqId').text($(this).data('id'));
                $('#viewRequestModal').modal('show');
            });

            $('.btn-review').click(function() {
                var id = $(this).data('id');
                var centre = $(this).data('centre');
                var budget = $(this).data('budget');

                $('#reviewReqId').text(id);
                $('#reviewCentreLabel').text(centre + ' — Monthly Budget');

                if (budget === 'over') {
                    $('#reviewBudgetStatus')
                        .removeClass('budget-ok')
                        .addClass('budget-over')
                        .html('<i class="bi bi-exclamation-triangle-fill me-1"></i>Over Budget');
                } else {
                    $('#reviewBudgetStatus')
                        .removeClass('budget-over')
                        .addClass('budget-ok')
                        .html('<i class="bi bi-check-circle-fill me-1"></i>Within Budget');
                }

                $('#reviewRequestModal').modal('show');
            });

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            $('.btn-review-supplier').click(function() {
                var $row = $(this).closest('tr');
                var $btn = $(this);

                $('#reviewSupplierName').text($btn.data('supplier'));
                $('#reviewSupplierCategory').text($btn.data('category'));
                $('#reviewSupplierRecommender').text($btn.data('recommender'));
                $('#reviewSupplierTerms').text($btn.data('terms'));
                $('#reviewSupplierSla').text($btn.data('sla'));
                $('#reviewSupplierProcNotes').val($btn.data('notes'));
                $('#reviewSupplierCost').text(formatPeso(parseFloat($btn.data('cost'))));
                $('#reviewSupplierFinanceNotes').val('');
                $('#reviewSupplierNegotiationModal').data('activeRow', $row);

                $('#reviewSupplierNegotiationModal').modal('show');
            });

            function setSupplierReviewStatus(label, statusClass) {
                var $row = $('#reviewSupplierNegotiationModal').data('activeRow');
                if (!$row) return;

                $row.find('td').eq(5).html('<span class="status-badge ' + statusClass + '">' + label + '</span>');

                var $actionCell = $row.find('td').eq(6);
                if (label === 'Approved') {
                    $actionCell.html('<button class="btn btn-edit btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-check-circle me-1"></i>Approved</button>');
                } else {
                    $actionCell.html('<button class="btn btn-confirm btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back</button>');
                }
            }

            $('#btnSupplierApprove').click(function() {
                setSupplierReviewStatus('Approved', 'status-approved');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Supplier Approved',
                    text: 'Procurement can proceed to finalize the contract.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnSupplierNeedsRevision').click(function() {
                setSupplierReviewStatus('Needs Revision', 'status-needs-revision');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Sent Back for Revision',
                    text: 'Procurement will be notified to renegotiate terms.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>