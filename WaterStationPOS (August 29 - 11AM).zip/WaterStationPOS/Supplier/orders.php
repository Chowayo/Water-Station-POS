<?php include __DIR__ . '/../components/header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-contracted {
        background-color: rgba(130, 170, 255, 0.1);
        color: #82aaff;
        border: 1px solid #82aaff;
    }

    .category-chip {
        display: inline-block;
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        white-space: nowrap;
    }

    .price-cell {
        color: #64FFDA;
        font-weight: 600;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Order Confirmations</h1>
                    <h6>Review incoming purchase orders and confirm or decline the order</h6>
                </div>
            </header>

            <!-- KPI Summary Cards  -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Awaiting Confirmation</div>
                        <div class="dash-value" style="color:#ffc107;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Confirmed This Month</div>
                        <div class="dash-value" style="color:#00e676;">4</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Declined This Month</div>
                        <div class="dash-value" style="color:#ff5252;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Total PO Value</div>
                        <div class="dash-value">₱6,200.00</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Purchase Orders</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Incoming Orders</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="poStatusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Confirmed">Confirmed</option>
                                    <option value="Declined">Declined</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search PO" id="poSearcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var poTable = $('#po_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#poSearcher').on('keyup change clear', function() {
                                    poTable.search(this.value).draw();
                                });

                                $('#poStatusFilter').on('change', function() {
                                    poTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="po_list">
                            <thead>
                                <tr>
                                    <th>PO Number</th>
                                    <th>Request ID</th>
                                    <th>Category</th>
                                    <th>Payment Terms</th>
                                    <th>SLA</th>
                                    <th>Total Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->
                                <tr>
                                    <td>PO-1007</td>
                                    <td>REQ-0007</td>
                                    <td><span class="category-chip">Chemicals</span></td>
                                    <td>Cash on Delivery</td>
                                    <td>Next-day delivery within Metro Manila</td>
                                    <td>₱2,900.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-po"
                                            data-po="PO-1007"
                                            data-req="REQ-0007"
                                            data-buyer="AquaPure Water Refilling Station"
                                            data-category="Chemicals"
                                            data-terms="COD"
                                            data-sla="Next-day delivery within Metro Manila"
                                            data-contract-type="One-time Purchase"
                                            data-cost="2900"
                                            data-items='[{"name":"Chlorine Solution","qty":10,"unit":"₱290.00"}]'>
                                            <i class="bi bi-clipboard-check me-1"></i>Review
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>Gcash</td>
                                    <td>Ships within 3 business days</td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Confirmed</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-check-circle me-1"></i>Confirmed
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>PO-1003</td>
                                    <td>REQ-0003</td>
                                    <td><span class="category-chip">Delivery</span></td>
                                    <td>Cash on Delivery</td>
                                    <td>5-7 days</td>
                                    <td>₱2,100.00</td>
                                    <td><span class="status-badge status-rejected">Declined</span></td>
                                    <td>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-x-circle me-1"></i>Declined
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Review Purchase Order Modal  -->
            <div class="modal fade" id="reviewPoModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Purchase Order — <span id="poNumber">PO-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="poBuyer">Buyer</span>
                                <span class="category-chip" id="poCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="poReqId">—</span>
                            </div>

                            <div id="poItemsList"></div>

                            <div class="req-detail-item">
                                <span>Payment Method</span>
                                <span id="poTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="poSla">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Contract Type</span>
                                <span id="poContractType">—</span>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Total Order Value</span>
                                <span class="fw-bold fs-5" id="poTotalCost">₱0.00</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Decline Reason</label>
                                <textarea class="form-control" id="poDeclineReason" rows="2" placeholder="Required if declining this order"></textarea>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4" id="btnDeclinePo">
                                    <i class="bi bi-x-lg me-1"></i>Decline Order
                                </button>
                                <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnConfirmPo">
                                    <i class="bi bi-check-lg me-1"></i>Confirm Order
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            var $activePoRow = null;

            $(document).on('click', '.btn-review-po', function() {
                $activePoRow = $(this).closest('tr');
                var $btn = $(this);

                $('#poNumber').text($btn.data('po'));
                $('#poBuyer').text($btn.data('buyer'));
                $('#poCategory').text($btn.data('category'));
                $('#poReqId').text($btn.data('req'));
                $('#poTerms').text($btn.data('terms') === 'COD' ? 'Cash on Delivery' : $btn.data('terms'));
                $('#poSla').text($btn.data('sla'));
                $('#poContractType').text($btn.data('contract-type'));
                $('#poTotalCost').text(formatPeso(parseFloat($btn.data('cost'))));
                $('#poDeclineReason').val('');

                var items = $btn.data('items') || [];
                var $list = $('#poItemsList').empty();
                items.forEach(function(item) {
                    $list.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + ' × ' + item.qty + '</span>' +
                        '<span>' + item.unit + '</span>' +
                        '</div>'
                    );
                });

                $('#reviewPoModal').modal('show');
            });

            $('#btnConfirmPo').click(function() {
                if (!$activePoRow) return;

                $activePoRow.find('td').eq(6)
                    .html('<span class="status-badge status-approved">Confirmed</span>');

                $activePoRow.find('.btn-review-po')
                    .removeClass('btn-confirm')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-check-circle me-1"></i>Confirmed');

                $('#reviewPoModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Order Confirmed',
                    text: $('#poNumber').text() + ' has been confirmed. Procurement will be notified.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnDeclinePo').click(function() {
                if (!$activePoRow) return;

                var reason = $('#poDeclineReason').val().trim();
                if (!reason) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Reason Required',
                        text: 'Please provide a reason for declining this order.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                $activePoRow.find('td').eq(6)
                    .html('<span class="status-badge status-rejected">Declined</span>');

                $activePoRow.find('.btn-review-po')
                    .removeClass('btn-confirm')
                    .addClass('btn-remove')
                    .prop('disabled', true)
                    .html('<i class="bi bi-x-circle me-1"></i>Declined');

                $('#reviewPoModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Order Declined',
                    text: $('#poNumber').text() + ' has been declined. Procurement will be notified to renegotiate.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>