<?php include __DIR__ . '/../components/header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-ordered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64ffda;
        border: 1px solid #64ffda;
    }

    .status-contracted {
        background-color: rgba(130, 170, 255, 0.1);
        color: #82aaff;
        border: 1px solid #82aaff;
    }

    /* Negotiate modal */
    .negotiate-section-label {
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.03em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 10px;
    }

    /* Budget check indicators */
    .budget-ok {
        color: #00e676;
        font-weight: 700;
    }

    .budget-over {
        color: #ff5252;
        font-weight: 700;
    }

    .req-item-row {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px;
        margin-bottom: 10px;
    }

    .req-item-remove {
        color: #ff5252;
        cursor: pointer;
        font-size: 18px;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* Request detail (view) list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    .category-chip {
        display: inline-block;
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        white-space: nowrap;
    }

    .price-cell {
        color: #64FFDA;
        font-weight: 600;
    }

    /* Recommend Supplier modal */
    .supplier-option-card {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px 16px;
        margin-bottom: 8px;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .supplier-option-card:hover {
        border-color: #64FFDA;
    }

    .supplier-option-card input[type="radio"]:checked~.supplier-option-info,
    .supplier-option-card:has(input[type="radio"]:checked) {
        border-color: #64FFDA;
        background-color: rgba(100, 255, 218, 0.06);
    }

    #recommendSupplierModal .text-muted {
        color: #8892B0 !important;
    }

    /* Category filter pills */
    .supplier-filter-chip {
        display: inline-block;
        background-color: transparent;
        color: #8892B0;
        border: 1px solid #233554;
        font-size: 12px;
        font-weight: 600;
        padding: 5px 14px;
        border-radius: 20px;
        white-space: nowrap;
        cursor: pointer;
        transition: all 0.15s ease;
        user-select: none;
    }

    .supplier-filter-chip:hover {
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .supplier-filter-chip.active {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border-color: #64FFDA;
    }

    .supplier-option-card.d-none {
        display: none !important;
    }

    .supplier-option-card .form-check-input {
        margin-top: 0;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Requests</h1>
                    <h6>Submit and track your restock requests — Finance reviews and approves separately</h6>
                </div>
            </header>

            <!-- KPI Summary Cards  -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Requests</div>
                        <div class="dash-value" style="color:#ffc107;">3</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved This Month</div>
                        <div class="dash-value" style="color:#00e676;">7</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Rejected</div>
                        <div class="dash-value" style="color:#ff5252;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Value</div>
                        <div class="dash-value">₱6,850.00</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Request Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="statusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Ordered">Ordered</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Request" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap" id="btnNewRequest">+ New Request</button>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#request_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#statusFilter').on('change', function() {
                                    table.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="request_list">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Requested By</th>
                                    <th>Date Requested</th>
                                    <th>Category</th>
                                    <th>Items</th>
                                    <th>Est. Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>REQ-0001</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-22</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0001">3 items</button>
                                    </td>
                                    <td>₱2,450.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-hourglass-split me-1"></i>Awaiting Finance
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0002</td>
                                    <td>Maria Santos</td>
                                    <td>2026-08-24</td>
                                    <td>Maintenance</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0002">2 items</button>
                                    </td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Approved</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-recommend-supplier" data-id="REQ-0002">
                                            <i class="bi bi-person-check me-1"></i>Recommend Supplier
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0007</td>
                                    <td>Ana Reyes</td>
                                    <td>2026-08-21</td>
                                    <td>Chemicals</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0007">2 items</button>
                                    </td>
                                    <td>₱1,850.00</td>
                                    <td><span class="status-badge status-approved">Supplier Approved</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-negotiate"
                                            data-id="REQ-0007"
                                            data-supplier="HydroChem Philippines"
                                            data-category="Chemicals"
                                            data-range="₱125.00 – ₱320.00">
                                            <i class="bi bi-chat-dots me-1"></i>Negotiate
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0003</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-25</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0003">4 items</button>
                                    </td>
                                    <td>₱9,300.00</td>
                                    <td><span class="status-badge status-rejected">Rejected</span></td>
                                    <td>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-x-circle me-1"></i>Rejected
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0004</td>
                                    <td>Ana Reyes</td>
                                    <td>2026-08-27</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0004">1 item</button>
                                    </td>
                                    <td>₱850.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-hourglass-split me-1"></i>Awaiting Finance
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0005</td>
                                    <td>Maria Santos</td>
                                    <td>2026-08-27</td>
                                    <td>Maintenance</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0005">2 items</button>
                                    </td>
                                    <td>₱3,600.00</td>
                                    <td><span class="status-badge status-pending">Pending</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-hourglass-split me-1"></i>Awaiting Finance
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>REQ-0006</td>
                                    <td>Juan Dela Cruz</td>
                                    <td>2026-08-19</td>
                                    <td>Supplies</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-id="REQ-0006">3 items</button>
                                    </td>
                                    <td>₱4,150.00</td>
                                    <td><span class="status-badge status-ordered">Ordered</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-truck me-1"></i>Ordered
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- New Request Modal -->
            <div class="modal fade" id="newRequestModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">New Purchase Request</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="newRequestForm">

                                <div class="row mb-3">
                                    <div class="col-md-6 mb-3 mb-md-0">
                                        <label class="form-label">Category</label>
                                        <select class="form-select" name="cost_centre" required>
                                            <option value="" disabled selected>Select category...</option>
                                            <option value="Supplies">Supplies</option>
                                            <option value="Maintenance">Maintenance</option>
                                            <option value="Delivery">Delivery</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Requested By</label>
                                        <input type="text" class="form-control" value="Juan Dela Cruz" disabled>
                                    </div>
                                </div>

                                <label class="form-label">Requested Items</label>

                                <div id="reqItemsContainer">
                                    <div class="req-item-row row g-2 align-items-end">
                                        <div class="col-5">
                                            <label class="form-label small mb-1">Item</label>
                                            <select class="form-select form-select-sm" name="item[]">
                                                <option value="" disabled selected>Select item...</option>
                                                <option value="5-Gallon Container" data-cost="85.00">5-Gallon Container</option>
                                                <option value="Screw Cap (Blue)" data-cost="2.50">5-Gallon Container</option>
                                                <option value="Sediment Filter Cartridge" data-cost="150.00">5-Gallon Container</option>
                                                <option value="Carbon Filter Cartridge" data-cost="180.00">5-Gallon Container</option>
                                                <option value="Chlorine Solution" data-cost="120.00">5-Gallon Container</option>
                                            </select>
                                        </div>
                                        <div class="col-3">
                                            <label class="form-label small mb-1">Qty</label>
                                            <input type="number" class="form-control form-control-sm req-qty" name="qty[]" placeholder="0" min="1">
                                        </div>
                                        <div class="col-3">
                                            <label class="form-label small mb-1">Est. Subtotal</label>
                                            <input type="text" class="form-control form-control-sm req-subtotal" value="₱0.00" disabled>
                                        </div>
                                        <div class="col-1 text-center">
                                            <i class="bi bi-x-circle req-item-remove" title="Remove item"></i>
                                        </div>
                                    </div>
                                </div>

                                <button type="button" class="btn btn-secondary btn-sm rounded-pill px-3 mb-3" id="btnAddItemRow">
                                    <i class="bi bi-plus-lg me-1"></i>Add Another Item
                                </button>

                                <div class="req-total-box d-flex justify-content-between align-items-center mb-3">
                                    <span class="fw-semibold">Estimated Total</span>
                                    <span class="fw-bold fs-5" id="reqEstTotal">₱0.00</span>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Notes (optional)</label>
                                    <textarea class="form-control" name="notes" rows="2" placeholder="e.g. Needed before end of month"></textarea>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-add rounded-pill px-4">Submit Request</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- View Request Modal  -->
            <div class="modal fade" id="viewRequestModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Request Details — <span id="viewReqId">REQ-0001</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <div class="req-detail-item">
                                <span>5-Gallon Container x 20</span>
                                <span>₱1,700.00</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Screw Cap (Blue) x 200</span>
                                <span>₱500.00</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Chlorine Solution x 2</span>
                                <span>₱250.00</span>
                            </div>
                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3">
                                <span class="fw-semibold">Total</span>
                                <span class="fw-bold fs-5">₱2,450.00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recommend Supplier Modal -->
            <div class="modal fade" id="recommendSupplierModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Recommend Supplier — <span id="recommendReqId">REQ-0001</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <p class="text-muted small mb-3">Select a supplier to recommend for this request. See Suppliers for full pricing and contact details.</p>

                            <div class="d-flex flex-wrap gap-2 mb-3" id="supplierCategoryFilters">
                                <span class="supplier-filter-chip active" data-category="all">All</span>
                                <span class="supplier-filter-chip" data-category="Containers">Containers</span>
                                <span class="supplier-filter-chip" data-category="Caps & Seals">Caps &amp; Seals</span>
                                <span class="supplier-filter-chip" data-category="Filters">Filters</span>
                                <span class="supplier-filter-chip" data-category="Chemicals">Chemicals</span>
                                <span class="supplier-filter-chip" data-category="Others">Others</span>
                            </div>

                            <div id="supplierOptionsList">

                                <label class="supplier-option-card" data-category="Containers">
                                    <span class="d-flex align-items-center gap-2">
                                        <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="AquaPure Distributors">
                                        <span>
                                            <span class="fw-semibold d-block">AquaPure Distributors</span>
                                            <span class="category-chip">Containers</span>
                                            <span class="text-muted small ms-1">COD</span>
                                        </span>
                                    </span>
                                    <span class="price-cell">₱12.50 - ₱90.00</span>
                                </label>

                                <label class="supplier-option-card" data-category="Caps & Seals">
                                    <span class="d-flex align-items-center gap-2">
                                        <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="ClearFlow Supply Co.">
                                        <span>
                                            <span class="fw-semibold d-block">ClearFlow Supply Co.</span>
                                            <span class="category-chip">Caps &amp; Seals</span>
                                            <span class="text-muted small ms-1">15 Days</span>
                                        </span>
                                    </span>
                                    <span class="price-cell">₱0.75 - ₱2.50</span>
                                </label>

                                <label class="supplier-option-card" data-category="Filters">
                                    <span class="d-flex align-items-center gap-2">
                                        <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="PureFilter Solutions">
                                        <span>
                                            <span class="fw-semibold d-block">PureFilter Solutions</span>
                                            <span class="category-chip">Filters</span>
                                            <span class="text-muted small ms-1">30 Days</span>
                                        </span>
                                    </span>
                                    <span class="price-cell">₱145.00 - ₱950.00</span>
                                </label>

                                <label class="supplier-option-card" data-category="Chemicals">
                                    <span class="d-flex align-items-center gap-2">
                                        <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="HydroChem Philippines">
                                        <span>
                                            <span class="fw-semibold d-block">HydroChem Philippines</span>
                                            <span class="category-chip">Chemicals</span>
                                            <span class="text-muted small ms-1">COD</span>
                                        </span>
                                    </span>
                                    <span class="price-cell">₱125.00 - ₱320.00</span>
                                </label>

                                <label class="supplier-option-card mb-0" data-category="Others">
                                    <span class="d-flex align-items-center gap-2">
                                        <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="Metro Labels & Print">
                                        <span>
                                            <span class="fw-semibold d-block">Metro Labels &amp; Print</span>
                                            <span class="category-chip">Others</span>
                                            <span class="text-muted small ms-1">15 Days</span>
                                        </span>
                                    </span>
                                    <span class="price-cell">₱0.90 - ₱220.00</span>
                                </label>

                                <p class="text-muted small mb-0 d-none" id="supplierNoResults">No suppliers found in this category.</p>

                            </div>

                            <div class="modal-footer px-0 pb-0 mt-3">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-add rounded-pill px-4" id="btnConfirmRecommend" disabled>Confirm Recommendation</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Negotiate Terms Modal -->
            <div class="modal fade" id="negotiateModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Negotiate Terms — <span id="negotiateReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="negotiateSupplierName">Supplier</span>
                                <span class="category-chip" id="negotiateCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Finance-Approved Range</span>
                                <span class="price-cell" id="negotiateApprovedRange">₱0.00 - ₱0.00</span>
                            </div>

                            <div class="negotiate-section-label">Negotiated Terms</div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Final Unit Price / Total Cost</label>
                                    <div class="input-group">
                                        <span class="input-group-text" style="background-color:#0A192F;border:1px solid #233554;color:#8892B0;">₱</span>
                                        <input type="number" class="form-control" id="negotiateFinalCost" placeholder="0.00" min="0" step="0.01">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Payment Method</label>
                                    <select class="form-select" id="negotiatePaymentTerms">
                                        <option value="">Select Payment Method</option>
                                        <option value="COD">Cash on Delivery</option>
                                        <option value="Gcash">Gcash</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">SLA / Delivery Commitment</label>
                                    <input type="text" class="form-control" id="negotiateSla" placeholder="e.g. Ships within 3 business days">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Contract Type</label>
                                    <select class="form-select" id="negotiateContractType">
                                        <option value="One-time">One-time Purchase</option>
                                        <option value="Framework">Framework / Standing Agreement</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row g-3 mb-3 d-none" id="negotiateValidUntilRow">
                                <div class="col-md-6">
                                    <label class="form-label">Valid Until</label>
                                    <input type="date" class="form-control" id="negotiateValidUntil">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Negotiation Notes</label>
                                <textarea class="form-control" id="negotiateNotes" rows="2" placeholder="e.g. 10% discount for orders over ₱5,000"></textarea>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Final Negotiated Cost</span>
                                <span class="fw-bold fs-5" id="negotiateFinalCostDisplay">₱0.00</span>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4" id="btnCancelNegotiation">
                                    <i class="bi bi-x-lg me-1"></i>Cancel Negotiation
                                </button>

                                <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnFinalizeContract">
                                    <i class="bi bi-check-lg me-1"></i>Finalize &amp; Create Contract
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- View Contract Modal -->
            <div class="modal fade" id="viewContractModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Contract — <span id="contractReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="contractSupplierName">Supplier</span>
                                <span class="category-chip" id="contractCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Contract Status</span>
                                <span class="status-badge status-contracted"><i class="bi bi-file-earmark-check me-1"></i>Active</span>
                            </div>

                            <div class="req-detail-item">
                                <span>Payment Method</span>
                                <span id="contractPaymentTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="contractSla">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Contract Type</span>
                                <span id="contractType">—</span>
                            </div>
                            <div class="req-detail-item" id="contractValidUntilRow">
                                <span>Valid Until</span>
                                <span id="contractValidUntil">—</span>
                            </div>

                            <div class="mb-3 mt-3">
                                <label class="form-label small text-muted">Negotiation Notes</label>
                                <textarea class="form-control" id="contractNotes" rows="2" disabled></textarea>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Final Negotiated Cost</span>
                                <span class="fw-bold fs-5" id="contractFinalCost">₱0.00</span>
                            </div>

                            <div class="modal-footer px-0 pb-0">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            $('#btnNewRequest').click(function() {
                $('#newRequestModal').modal('show');
            });

            $('.btn-view').click(function() {
                $('#viewReqId').text($(this).data('id'));
                $('#viewRequestModal').modal('show');
            });

            var $activeRecommendRow = null;

            $(document).on('click', '.btn-recommend-supplier', function() {
                $activeRecommendRow = $(this).closest('tr');

                $('#recommendReqId').text($(this).data('id'));
                $('input[name="recommendSupplierChoice"]').prop('checked', false);
                $('#btnConfirmRecommend').prop('disabled', true);

                $('#recommendSupplierModal').modal('show');
            });

            $('input[name="recommendSupplierChoice"]').on('change', function() {
                $('#btnConfirmRecommend').prop('disabled', false);
            });

            $(document).on('click', '.supplier-filter-chip', function() {
                var category = $(this).data('category');

                $('.supplier-filter-chip').removeClass('active');
                $(this).addClass('active');

                var $cards = $('#supplierOptionsList .supplier-option-card');
                var $visible;

                if (category === 'all') {
                    $cards.removeClass('d-none');
                    $visible = $cards;
                } else {
                    $cards.each(function() {
                        var match = $(this).data('category') === category;
                        $(this).toggleClass('d-none', !match);
                    });
                    $visible = $cards.filter('[data-category="' + category + '"]');
                }

                $('#supplierNoResults').toggleClass('d-none', $visible.length > 0);

                var $checked = $('input[name="recommendSupplierChoice"]:checked');
                if ($checked.length && $checked.closest('.supplier-option-card').hasClass('d-none')) {
                    $checked.prop('checked', false);
                    $('#btnConfirmRecommend').prop('disabled', true);
                }
            });

            // Reset filter state whenever the modal is opened
            $('#recommendSupplierModal').on('show.bs.modal', function() {
                $('.supplier-filter-chip').removeClass('active');
                $('.supplier-filter-chip[data-category="all"]').addClass('active');
                $('#supplierOptionsList .supplier-option-card').removeClass('d-none');
                $('#supplierNoResults').addClass('d-none');
            });

            $('#btnConfirmRecommend').click(function() {
                var supplierName = $('input[name="recommendSupplierChoice"]:checked').val();
                if (!$activeRecommendRow || !supplierName) return;

                // Recommendation submitted — now awaiting Finance's approval of the supplier
                $activeRecommendRow.find('td').eq(6)
                    .html('<span class="status-badge status-pending">Pending</span>');

                $activeRecommendRow.find('.btn-recommend-supplier')
                    .removeClass('btn-confirm')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-hourglass-split me-1"></i>Recommended: ' + supplierName);

                $('#recommendSupplierModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Supplier Recommended',
                    text: supplierName + ' has been recommended for this request. Awaiting Finance approval.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            var $activeNegotiateRow = null;

            // Negotiate enabled once Finance has approved the recommended supplier
            $(document).on('click', '.btn-negotiate', function() {
                $activeNegotiateRow = $(this).closest('tr');

                $('#negotiateReqId').text($(this).data('id'));
                $('#negotiateSupplierName').text($(this).data('supplier'));
                $('#negotiateCategory').text($(this).data('category'));
                $('#negotiateApprovedRange').text($(this).data('range'));

                // Reset form fields
                $('#negotiateFinalCost').val('');
                $('#negotiatePaymentTerms').val('');
                $('#negotiateSla').val('');
                $('#negotiateContractType').val('One-time');
                $('#negotiateValidUntilRow').addClass('d-none');
                $('#negotiateValidUntil').val('');
                $('#negotiateNotes').val('');
                $('#negotiateFinalCostDisplay').text('₱0.00');

                $('#negotiateModal').modal('show');
            });

            $('#negotiateContractType').on('change', function() {
                $('#negotiateValidUntilRow').toggleClass('d-none', $(this).val() !== 'Framework');
            });

            $('#negotiateFinalCost').on('input', function() {
                var val = parseFloat($(this).val()) || 0;
                $('#negotiateFinalCostDisplay').text('₱' + val.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }));
            });

            $('#btnCancelNegotiation').click(function() {
                $('#negotiateModal').modal('hide');

                Swal.fire({
                    icon: 'warning',
                    title: 'Negotiation Cancelled',
                    text: 'The approved supplier remains on record. You can restart negotiation later.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnFinalizeContract').click(function() {
                if (!$activeNegotiateRow) return;

                var finalCost = parseFloat($('#negotiateFinalCost').val()) || 0;
                var paymentTerms = $('#negotiatePaymentTerms').val();

                if (!finalCost || !paymentTerms) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Missing Information',
                        text: 'Please enter the final cost and payment terms before finalizing.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                var contractData = {
                    id: $('#negotiateReqId').text(),
                    supplier: $('#negotiateSupplierName').text(),
                    category: $('#negotiateCategory').text(),
                    finalCost: finalCost,
                    paymentTerms: paymentTerms,
                    sla: $('#negotiateSla').val() || '—',
                    contractType: $('#negotiateContractType').val() === 'Framework' ? 'Framework / Standing Agreement' : 'One-time Purchase',
                    validUntil: $('#negotiateValidUntil').val() || '',
                    notes: $('#negotiateNotes').val() || ''
                };

                $activeNegotiateRow.find('td').eq(6)
                    .html('<span class="status-badge status-contracted">Contracted</span>');

                $activeNegotiateRow.find('.btn-negotiate')
                    .removeClass('btn-negotiate btn-confirm')
                    .addClass('btn-edit btn-view-contract')
                    .prop('disabled', false)
                    .data('contract', contractData)
                    .html('<i class="bi bi-eye me-1"></i>View Contract');

                $('#negotiateModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Contract Created',
                    text: 'Final terms locked in with ' + $('#negotiateSupplierName').text() + '.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            // View Contract
            $(document).on('click', '.btn-view-contract', function() {
                var c = $(this).data('contract');
                if (!c) return;

                $('#contractReqId').text(c.id);
                $('#contractSupplierName').text(c.supplier);
                $('#contractCategory').text(c.category);
                $('#contractPaymentTerms').text(c.paymentTerms === 'COD' ? 'Cash on Delivery' : c.paymentTerms);
                $('#contractSla').text(c.sla);
                $('#contractType').text(c.contractType);
                $('#contractNotes').val(c.notes || 'No additional notes.');
                $('#contractFinalCost').text('₱' + c.finalCost.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }));

                if (c.validUntil) {
                    $('#contractValidUntilRow').show();
                    $('#contractValidUntil').text(c.validUntil);
                } else {
                    $('#contractValidUntilRow').hide();
                }

                $('#viewContractModal').modal('show');
            });


            // Add another item row
            $('#btnAddItemRow').click(function() {
                var row = $('.req-item-row').first().clone();
                row.find('select').val('');
                row.find('input').val('');
                row.find('.req-subtotal').val('₱0.00');
                $('#reqItemsContainer').append(row);
            });

            // Remove item row
            $(document).on('click', '.req-item-remove', function() {
                if ($('.req-item-row').length > 1) {
                    $(this).closest('.req-item-row').remove();
                    calcTotal();
                }
            });

            // Recalculate subtotal per row + running total
            $(document).on('change keyup', '.req-qty, select[name="item[]"]', function() {
                var row = $(this).closest('.req-item-row');
                var qty = parseFloat(row.find('.req-qty').val()) || 0;
                var cost = parseFloat(row.find('select[name="item[]"] option:selected').data('cost')) || 0;
                var subtotal = qty * cost;
                row.find('.req-subtotal').val('₱' + subtotal.toFixed(2));
                calcTotal();
            });

            function calcTotal() {
                var total = 0;
                $('.req-subtotal').each(function() {
                    total += parseFloat($(this).val().replace('₱', '')) || 0;
                });
                $('#reqEstTotal').text('₱' + total.toFixed(2));
            }

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>