<?php include __DIR__ . '/../components/header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    .category-chip {
        display: inline-block;
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        margin: 2px;
        white-space: nowrap;
    }

    /* View Pricing button */
    .btn-view-pricing {
        background: transparent;
        border: 1px solid #64FFDA;
        color: #64FFDA;
        transition: all 0.15s ease;
    }

    .btn-view-pricing:hover {
        background: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
    }

    .price-list-table th,
    .price-list-table td {
        vertical-align: middle;
    }

    .price-list-table thead th {
        background-color: #0A192F;
        color: #8892B0;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        border-bottom: 1px solid #233554 !important;
    }

    .price-list-table tbody td {
        border-color: #233554 !important;
    }

    .price-cell {
        color: #64FFDA;
        font-weight: 600;
    }

    .pricing-supplier-meta {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px 16px;
        margin-bottom: 16px;
    }

    .pricing-total-box {
        background-color: rgba(0, 230, 118, 0.08);
        border: 1px solid #00E676;
        border-radius: 10px;
        padding: 10px 16px;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Suppliers</h1>
                    <h6>Sourcing / RFQ — Manage supplier contacts</h6>
                </div>
            </header>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Total Suppliers</div>
                        <div class="dash-value">8</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Active</div>
                        <div class="dash-value" style="color:#00e676;">7</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Inactive</div>
                        <div class="dash-value" style="color:#ff5252;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Categories Covered</div>
                        <div class="dash-value">5</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Suppliers</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Supplier Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="categoryFilter" style="width: 180px;">
                                    <option value="">All Categories</option>
                                    <option value="Containers">Containers</option>
                                    <option value="Caps & Seals">Caps & Seals</option>
                                    <option value="Filters">Filters</option>
                                    <option value="Chemicals">Chemicals</option>
                                    <option value="Others">Others</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Supplier" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap" id="btnAddSupplier">+ Add Supplier</button>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#supplier_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#categoryFilter').on('change', function() {
                                    table.column(3).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="supplier_list">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Supplier Name</th>
                                    <th>Contact Person</th>
                                    <th>Category Supplied</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Payment Method</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>AquaPure Distributors</td>
                                    <td>Mark Villanueva</td>
                                    <td><span class="category-chip">Containers</span></td>
                                    <td>0917 123 4567</td>
                                    <td>sales@aquapure.ph</td>
                                    <td>COD</td>
                                    <td><span class="status-badge status-active">Active</span></td>
                                    <td>
                                        <button class="btn btn-view-pricing btn-sm rounded-pill px-3 me-1 btn-view-pricing-action" data-id="1">
                                            <i class="bi bi-tags me-1"></i>Pricing
                                        </button>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1 btn-edit-supplier"
                                            data-id="1" data-name="AquaPure Distributors" data-contact="Mark Villanueva"
                                            data-category="Containers" data-phone="0917 123 4567"
                                            data-email="sales@aquapure.ph" data-address="Unit 4, Imus, Cavite"
                                            data-method="COD" data-status="Active">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>ClearFlow Supply Co.</td>
                                    <td>Liza Ramos</td>
                                    <td><span class="category-chip">Caps & Seals</span></td>
                                    <td>0917 234 5678</td>
                                    <td>orders@clearflow.ph</td>
                                    <td>Gcash</td>
                                    <td><span class="status-badge status-active">Active</span></td>
                                    <td>
                                        <button class="btn btn-view-pricing btn-sm rounded-pill px-3 me-1 btn-view-pricing-action" data-id="2">
                                            <i class="bi bi-tags me-1"></i>Pricing
                                        </button>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1 btn-edit-supplier"
                                            data-id="2" data-name="ClearFlow Supply Co." data-contact="Liza Ramos"
                                            data-category="Caps & Seals" data-phone="0917 234 5678"
                                            data-email="orders@clearflow.ph" data-address="Dasmariñas, Cavite"
                                            data-method="Gcash" data-status="Active">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="2">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>PureFilter Solutions</td>
                                    <td>Rico Bautista</td>
                                    <td><span class="category-chip">Filters</span></td>
                                    <td>0918 345 6789</td>
                                    <td>rico@purefilter.ph</td>
                                    <td>Gcash</td>
                                    <td><span class="status-badge status-active">Active</span></td>
                                    <td>
                                        <button class="btn btn-view-pricing btn-sm rounded-pill px-3 me-1 btn-view-pricing-action" data-id="3">
                                            <i class="bi bi-tags me-1"></i>Pricing
                                        </button>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1 btn-edit-supplier"
                                            data-id="3" data-name="PureFilter Solutions" data-contact="Rico Bautista"
                                            data-category="Filters" data-phone="0918 345 6789"
                                            data-email="rico@purefilter.ph" data-address="Bacoor, Cavite"
                                            data-method="Gcash" data-status="Active">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="3">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>HydroChem Philippines</td>
                                    <td>Grace Fernandez</td>
                                    <td><span class="category-chip">Chemicals</span></td>
                                    <td>0919 456 7890</td>
                                    <td>grace@hydrochem.ph</td>
                                    <td>COD</td>
                                    <td><span class="status-badge status-inactive">Inactive</span></td>
                                    <td>
                                        <button class="btn btn-view-pricing btn-sm rounded-pill px-3 me-1 btn-view-pricing-action" data-id="4">
                                            <i class="bi bi-tags me-1"></i>Pricing
                                        </button>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1 btn-edit-supplier"
                                            data-id="4" data-name="HydroChem Philippines" data-contact="Grace Fernandez"
                                            data-category="Chemicals" data-phone="0919 456 7890"
                                            data-email="grace@hydrochem.ph" data-address="Las Piñas City"
                                            data-method="COD" data-status="Inactive">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="4">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Metro Labels & Print</td>
                                    <td>Jerome Aquino</td>
                                    <td><span class="category-chip">Others</span></td>
                                    <td>0920 567 8901</td>
                                    <td>jerome@metrolabels.ph</td>
                                    <td>Gcash</td>
                                    <td><span class="status-badge status-active">Active</span></td>
                                    <td>
                                        <button class="btn btn-view-pricing btn-sm rounded-pill px-3 me-1 btn-view-pricing-action" data-id="5">
                                            <i class="bi bi-tags me-1"></i>Pricing
                                        </button>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1 btn-edit-supplier"
                                            data-id="5" data-name="Metro Labels & Print" data-contact="Jerome Aquino"
                                            data-category="Others" data-phone="0920 567 8901"
                                            data-email="jerome@metrolabels.ph" data-address="Parañaque City"
                                            data-method="Gcash" data-status="Active">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="5">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add Supplier Modal -->
            <div class="modal fade" id="addSupplierModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Add New Supplier</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="addSupplierForm">

                                <div class="mb-3">
                                    <label class="form-label">Supplier Name</label>
                                    <input type="text" class="form-control" name="name" required placeholder="e.g. AquaPure Distributors">
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Contact Person</label>
                                        <input type="text" class="form-control" name="contact" required placeholder="e.g. Mark Villanueva">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Category Supplied</label>
                                        <select class="form-select" name="category" required>
                                            <option value="" disabled selected>Select category...</option>
                                            <option value="Containers">Containers</option>
                                            <option value="Caps & Seals">Caps & Seals</option>
                                            <option value="Filters">Filters</option>
                                            <option value="Chemicals">Chemicals</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Phone</label>
                                        <input type="text" class="form-control" name="phone" required placeholder="e.g. 0917 123 4567">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" name="email" placeholder="e.g. sales@supplier.ph">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Address</label>
                                    <input type="text" class="form-control" name="address" placeholder="e.g. Dasmariñas, Cavite">
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <label class="form-label">Payment Method</label>
                                        <select class="form-select" name="method" required>
                                            <option value="" disabled selected>Select payment...</option>
                                            <option value="COD">COD</option>
                                            <option value="Gcash">Gcash</option>
                                        </select>
                                    </div>

                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-add rounded-pill px-4">Add Supplier</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Supplier Modal -->
            <div class="modal fade" id="editSupplierModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Edit Supplier</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="editSupplierForm">

                                <input type="number" name="id" id="edit-supplier-id" hidden>

                                <div class="mb-3">
                                    <label class="form-label">Supplier Name</label>
                                    <input type="text" class="form-control" name="name" required id="edit-supplier-name">
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Contact Person</label>
                                        <input type="text" class="form-control" name="contact" required id="edit-supplier-contact">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Category Supplied</label>
                                        <select class="form-select" name="category" id="edit-supplier-category" required>
                                            <option value="Containers">Containers</option>
                                            <option value="Caps & Seals">Caps & Seals</option>
                                            <option value="Filters">Filters</option>
                                            <option value="Chemicals">Chemicals</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Phone</label>
                                        <input type="text" class="form-control" name="phone" required id="edit-supplier-phone">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" name="email" id="edit-supplier-email">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Address</label>
                                    <input type="text" class="form-control" name="address" id="edit-supplier-address">
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Payment method</label>
                                        <select class="form-select" name="method" id="edit-supplier-method" required>
                                            <option value="COD">COD</option>
                                            <option value="Gcash">Gcash</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Status</label>
                                        <select class="form-select" name="status" id="edit-supplier-status" required>
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-add rounded-pill px-4">Save Changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Supplier Products & Pricing Modal -->
            <div class="modal fade" id="supplierPricingModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Products &amp; Pricing — <span id="pricingSupplierName">Supplier</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="pricing-supplier-meta d-flex flex-wrap justify-content-between align-items-center">
                                <div>
                                    <div class="text-muted small">Category Supplied</div>
                                    <span class="category-chip" id="pricingSupplierCategory">Containers</span>
                                </div>
                                <div class="text-end">
                                    <div class="text-muted small">Quotation method</div>
                                    <div id="pricingSuppliermethod" class="fw-semibold">COD</div>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-dark table-hover align-middle price-list-table mb-3">
                                    <thead>
                                        <tr>
                                            <th class="text-start">Product</th>
                                            <th>Unit</th>
                                            <th>Unit Price</th>
                                            <th>Lead Time</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pricingProductsBody">
                                    </tbody>
                                </table>
                            </div>

                            <div class="pricing-total-box d-flex justify-content-between align-items-center">
                                <span class="fw-semibold">Avg. Unit Price Range</span>
                                <span class="fw-bold fs-6" id="pricingRange">₱0.00 - ₱0.00</span>
                            </div>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                        </div>

                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        function formatPeso(amount) {
            return '₱' + amount.toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }


        $(document).ready(function() {

            $('#btnAddSupplier').click(function() {
                $('#addSupplierModal').modal('show');
            });

            $('.btn-view-pricing-action').click(function() {
                var supplierId = $(this).data('id');
                var supplier = supplierPricing[supplierId];

                if (!supplier) return;

                $('#pricingSupplierName').text(supplier.name);
                $('#pricingSupplierCategory').text(supplier.category);
                $('#pricingSuppliermethod').text(supplier.method);

                var rowsHtml = '';
                var prices = [];

                supplier.products.forEach(function(p) {
                    prices.push(p.price);
                    rowsHtml += '<tr>' +
                        '<td class="text-start">' + p.name + '</td>' +
                        '<td>' + p.unit + '</td>' +
                        '<td class="price-cell">' + formatPeso(p.price) + '</td>' +
                        '<td>' + p.lead + '</td>' +
                        '</tr>';
                });

                $('#pricingProductsBody').html(rowsHtml);

                var minPrice = Math.min.apply(null, prices);
                var maxPrice = Math.max.apply(null, prices);
                $('#pricingRange').text(formatPeso(minPrice) + ' – ' + formatPeso(maxPrice));

                $('#supplierPricingModal').modal('show');
            });

            $('.btn-edit-supplier').click(function() {
                $('#edit-supplier-id').val($(this).data('id'));
                $('#edit-supplier-name').val($(this).data('name'));
                $('#edit-supplier-contact').val($(this).data('contact'));
                $('#edit-supplier-category').val($(this).data('category'));
                $('#edit-supplier-phone').val($(this).data('phone'));
                $('#edit-supplier-email').val($(this).data('email'));
                $('#edit-supplier-address').val($(this).data('address'));
                $('#edit-supplier-method').val($(this).data('method'));
                $('#edit-supplier-status').val($(this).data('status'));

                $('#editSupplierModal').modal('show');
            });

            $('.btn-remove').click(function() {
                Swal.fire({
                    title: 'Remove Supplier?',
                    text: "It will be removed from the supplier directory",
                    icon: 'warning',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<button class="btn btn-danger" onclick="Swal.close()">Confirm Delete</button>',
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>