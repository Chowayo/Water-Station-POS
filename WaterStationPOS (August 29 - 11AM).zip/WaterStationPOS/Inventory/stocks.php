<?php include __DIR__ . '/../components/header.php'; ?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Stock status badges */
    .status-instock {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-lowstock {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-outofstock {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Inventory Management</h1>
                    <h6>Track stock levels for containers, caps, filters, and supplies</h6>
                </div>
            </header>

            <!-- KPI Summary Cards (static placeholder numbers) -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Total Items</div>
                        <div class="dash-value">6</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Low Stock</div>
                        <div class="dash-value" style="color:#ffc107;">2</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Out of Stock</div>
                        <div class="dash-value" style="color:#ff5252;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Inventory Value</div>
                        <div class="dash-value">₱18,450.00</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Supply Items</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Stock Directory</h5>
                            <div class="d-flex flex-wrap gap-2">

                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Item" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap">+ Add New Item</button>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#inventory_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#categoryFilter').on('change', function() {
                                    table.column(1).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="inventory_list">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Category</th>
                                    <th>Item Name</th>
                                    <th>Current Stock</th>
                                    <th>Unit Cost</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->
                                <tr>
                                    <td>1</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>120</td>
                                    <td>₱85.00</td>
                                    <td><span class="status-badge status-instock">In Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>25</td>
                                    <td>₱2.50</td>
                                    <td><span class="status-badge status-lowstock">Low Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>0</td>
                                    <td>₱150.00</td>
                                    <td><span class="status-badge status-outofstock">Out of Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>18</td>
                                    <td>₱180.00</td>
                                    <td><span class="status-badge status-instock">In Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>8</td>
                                    <td>₱120.00</td>
                                    <td><span class="status-badge status-lowstock">Low Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>Containers</td>
                                    <td>5-Gallon Container</td>
                                    <td>40</td>
                                    <td>₱95.00</td>
                                    <td><span class="status-badge status-instock">In Stock</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">
                                            <i class="bi bi-pencil-square me-1"></i>Edit
                                        </button>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="1">
                                            <i class="bi bi-trash-fill me-1"></i>Remove
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add Item Modal -->
            <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Add New Supply Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="addInventoryForm">

                                <div class="mb-3">
                                    <label class="form-label">Item Name</label>
                                    <input type="text" class="form-control" name="name" required placeholder="e.g. 5-Gallon Container">
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Unit</label>
                                    <select class="form-select" name="unit" required>
                                        <option value="" disabled selected>Select a unit...</option>
                                        <option value="pcs">Pieces</option>
                                        <option value="box">Box</option>
                                        <option value="L">Liters</option>
                                        <option value="kg">Kilograms</option>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <label class="form-label">Current Stock</label>
                                        <input type="number" class="form-control" name="stock" required placeholder="e.g. 50">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit Cost</label>
                                    <input type="number" step="0.01" class="form-control" name="cost" required placeholder="e.g. 45.00">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-add rounded-pill px-4" id="addInventoryBtn">Add Item</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Item Modal -->
            <div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Edit Supply Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="editInventoryForm">

                                <input type="number" name="id" id="edit-id" hidden>

                                <div class="mb-3">
                                    <label class="form-label">Item Name</label>
                                    <input type="text" class="form-control" name="name" required id="edit-name">
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Unit</label>
                                    <select class="form-select" name="unit" id="edit-unit-select" required>
                                        <option value="pcs">Pieces</option>
                                        <option value="box">Box</option>
                                        <option value="L">Liters</option>
                                        <option value="kg">Kilograms</option>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-">
                                        <label class="form-label">Current Stock</label>
                                        <input type="number" class="form-control" name="stock" required id="edit-stock">
                                    </div>

                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit Cost</label>
                                    <input type="number" step="0.01" class="form-control" name="cost" required id="edit-cost">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-add rounded-pill px-4" id="editInventoryBtn">Save Changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            $('.btn-edit').click(function() {
                id = $(this).data('id');
                name = $(this).data('name');
                category = $(this).data('category');
                stock = $(this).data('stock');
                cost = $(this).data('cost');

                $("#edit-id").val(id);
                $("#edit-name").val(name);
                $("#edit-category-select").val(category);
                $("#edit-stock").val(stock);
                $("#edit-cost").val(cost);

                $('#editProductModal').modal('show');
            });

            $(".btn-add").click(function() {
                $('#addProductModal').modal('show');
            });

            $('.btn-remove').click(function() {
                Swal.fire({
                    title: 'Remove Item?',
                    text: "It will be deleted from inventory",
                    icon: 'warning',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<button class="btn btn-danger" onclick="Swal.close()">Confirm Delete</button>',
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>