<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eco Hydrate Hub POS</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #ffffff;
        }

        .app {
            background-color: #ffffff;
            height: 100vh;
            max-height: 100vh;
            overflow-x: hidden;
            overflow-y: hidden;
        }

        .left-menu {
            width: 220px;
            background-color: #ffffff;
            border-right-width: 2px;
            border-right-style: solid;
            border-right-color: #ffffff;
        }

        .avatar {
            width: 130px;
            height: 130px;
            border-width: 2px;
            border-style: solid;
            border-color: #9b51e0;
            border-radius: 50%;
            margin-top: 20px;
            margin-right: auto;
            margin-bottom: 20px;
            margin-left: auto;
            background-color: #ffffff;
        }

        .menu-link {
            color: black;
            font-weight: 700;
            text-align: center;
            margin-bottom: 15px;
            font-size: 15px;
        }

        .menu-link:hover {
            color: #68b86d;
        }

        .content {
            background-color: #ffffff;
        }

        .top-text h1 {
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0px;
        }

        .green-text {
            color: #68b86d;
        }

        .top-text h6 {
            font-weight: 600;
            font-size: 14px;
            margin-top: 5px;
        }

        .search-box {
            background-color: #aee0dd;
            padding-top: 15px;
            padding-right: 25px;
            padding-bottom: 15px;
            padding-left: 25px;
            border-radius: 30px;
            position: relative;
        }

        .search-tag {
            position: absolute;
            top: -12px;
            left: 30px;
            background-color: #ffffff;
            padding-top: 0px;
            padding-right: 10px;
            padding-bottom: 0px;
            padding-left: 10px;
            font-weight: bold;
            font-size: 14px;
        }

        .search-bar {
            background-color: #ffffff;
            display: flex;
            align-items: center;
            padding-top: 5px;
            padding-right: 15px;
            padding-bottom: 5px;
            padding-left: 15px;
        }

        .search-bar input {
            border-style: none;
            width: 100%;
            padding-left: 10px;
        }

        .item-card {
            background-color: #aee0dd;
            border-style: none;

            border-radius: 20px;
            height: 100%;
            width: 100%;
            font-weight: 700;
            color: black;
            transition-property: all;
            transition-duration: 0.2s;
            transition-timing-function: ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding-top: 15px;
            padding-right: 10px;
            padding-bottom: 15px;
            padding-left: 10px;
            text-align: center;
        }

        .item-card:hover {
            background-color: #92d1ce;
            transform: translateY(-2px);
        }

        .price {
            font-size: 14px;
            font-weight: 600;
            color: #444444;
            margin-bottom: 10px;
        }

        .qty-box {
            display: flex;
            justify-content: center;
            align-items: center;
            column-gap: 5px;
            row-gap: 5px;
            margin-bottom: 8px;
        }

        .btn-math {
            background-color: #ffffff;
            border-style: none;
            border-radius: 5px;
            width: 28px;
            height: 28px;
            font-weight: bold;
            color: black;
        }

        .btn-math:active {
            background-color: #e0e0e0;
        }

        .input-num {
            width: 40px;
            height: 28px;
            text-align: center;
            border-style: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .input-num::-webkit-outer-spin-button,
        .input-num::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin-top: 0px;
            margin-right: 0px;
            margin-bottom: 0px;
            margin-left: 0px;
        }

        .btn-add {
            background-color: #ffffff;
            color: #000000;
            border-style: none;
            border-radius: 10px;
            width: 100%;
            font-weight: bold;
            padding-top: 5px;
            padding-right: 0px;
            padding-bottom: 5px;
            padding-left: 0px;
            font-size: 14px;
            transition-property: background-color;
            transition-duration: 0.2s;
        }

        .btn-add:hover {
            background-color: #68b86d;
            color: #ffffff;
        }

        .right-panel {
            width: 280px;
            background-color: #aee0dd;
            border-radius: 30px;
            margin: 20px;
            padding: 20px;
        }

        .btn-order,
        .btn-pay {
            background-color: #ffffff;
            color: #000000;
            border-style: none;
            border-radius: 25px;
            font-weight: 700;
            width: 100%;
            padding-top: 8px;
            padding-right: 0px;
            padding-bottom: 8px;
            padding-left: 0px;
        }
    </style>
</head>

<body>

    <div class="container-fluid p-0 app d-flex">

        <aside class="left-menu d-flex flex-column py-4">
            <div class="avatar"></div>

            <nav class="nav flex-column mt-4">
                <a class="menu-link" href="#">POS</a>
                <a class="menu-link" href="#">Confirmation</a>
                <a class="menu-link" href="#">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto" href="#">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex content">

            <section class="flex-grow-1 d-flex flex-column p-4">

                <header class="top-text text-center mb-4">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Mineral Water Refill & POS management System</h6>
                </header>

                <div class="search-box mb-4 mt-2">
                    <div class="search-bar">
                        <span class="fs-5 text-secondary">🔍</span>
                        <input type="text" placeholder="Enter Product ID or bottle size">
                    </div>
                </div>

                <div class="row g-4 mt-1 flex-grow-1 align-content-start">

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱30.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-math">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-math">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱30.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-math">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-math">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱150.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-math">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-math">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱150.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-math">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-math">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱15.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-math">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-math">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            <aside class="right-panel d-flex flex-column shadow-sm">
                <button class="btn-order mb-3">ORDERS</button>

                <div class="flex-grow-1 overflow-auto cart-list">
                </div>

                <button class="btn-pay mt-auto shadow-sm">Checkout</button>
            </aside>

        </main>
    </div>

    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
</body>

</html>