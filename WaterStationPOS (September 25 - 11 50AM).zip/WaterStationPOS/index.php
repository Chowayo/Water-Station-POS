<?php
require('dbConn.php');

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory") {
    header('location: /Inventory/stocks.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier") {
    header('location: /Supplier/orders.php');
    exit;
}


// ---------- Careers: load open job postings (managed from Hr/jobposting.php) ----------
function lp_e($v)
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function lp_salary($min, $max)
{
    $f = fn($n) => '₱' . number_format((float)$n);
    if ($min !== null && $max !== null) return $f($min) . ' - ' . $f($max);
    if ($min !== null) return 'From ' . $f($min);
    if ($max !== null) return 'Up to ' . $f($max);
    return 'Salary not specified';
}

$open_jobs = [];
try {
    $res = $conn->query("SELECT * FROM job_postings WHERE status = 'Open' AND (deadline IS NULL OR deadline >= CURDATE()) ORDER BY id DESC");
    $open_jobs = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
} catch (Throwable $e) {
    error_log('landing careers load: ' . $e->getMessage());
    $open_jobs = [];
}
$use_carousel = count($open_jobs) > 3;

function lp_render_job_card($job, $delay = null)
{
    $smin = $job['salary_min'] !== null ? (float)$job['salary_min'] : null;
    $smax = $job['salary_max'] !== null ? (float)$job['salary_max'] : null;
    $json = lp_e(json_encode([
        'id'               => (int)$job['id'],
        'title'            => $job['title'],
        'department'       => $job['department'],
        'employment_type'  => $job['employment_type'],
        'location'         => !empty($job['location']) ? $job['location'] : 'Location not specified',
        'openings'         => (int)$job['openings'],
        'salary_text'      => lp_salary($smin, $smax),
        'deadline_text'    => !empty($job['deadline']) ? date('M d, Y', strtotime($job['deadline'])) : 'No deadline',
        'overview'         => $job['overview'],
        'responsibilities' => $job['responsibilities'],
        'qualifications'   => $job['qualifications'],
    ], JSON_UNESCAPED_UNICODE));
    ob_start(); ?>
    <article class="job-card<?= $delay !== null ? ' reveal' : '' ?>" <?= $delay !== null ? 'style="--reveal-delay: ' . $delay . 's"' : '' ?>>
        <div class="job-dept"><?= lp_e($job['department']) ?></div>
        <h3><?= lp_e($job['title']) ?></h3>
        <div class="job-meta">
            <span><i class="bi bi-geo-alt"></i> <?= lp_e(!empty($job['location']) ? $job['location'] : 'Location not specified') ?></span>
            <span><i class="bi bi-clock"></i> <?= lp_e($job['employment_type']) ?></span>
            <span><i class="bi bi-cash-stack"></i> <?= lp_e(lp_salary($smin, $smax)) ?></span>
            <?php if (!empty($job['deadline'])): ?>
                <span><i class="bi bi-calendar-event"></i> Apply by <?= lp_e(date('M d, Y', strtotime($job['deadline']))) ?></span>
            <?php endif; ?>
        </div>
        <p class="job-desc"><?= lp_e($job['overview']) ?></p>
        <button class="btn-apply-job" type="button" data-job="<?= $json ?>" onclick="openJobDetails(this)">
            <i class="bi bi-eye-fill me-2"></i>View Details
        </button>
    </article>
<?php
    return ob_get_clean();
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e1e1e">
    <title>Eco Hydrate Hub - Home & Careers</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>
        /* Careers carousel (used when there are more than 3 open postings) */
        .jobs-empty {
            text-align: center;
            color: #8892B0;
            padding: 2.5rem 1rem;
        }

        .jobs-empty i {
            display: block;
            font-size: 2.2rem;
            color: #64FFDA;
            margin-bottom: 0.6rem;
        }

        .job-carousel {
            position: relative;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 56px;
        }

        .job-carousel-track {
            --jc-gap: 24px;
            --jc-per-view: 3;
            display: flex;
            gap: var(--jc-gap);
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-behavior: smooth;
            scrollbar-width: none;
            padding: 6px 2px 10px;
        }

        .job-carousel-track::-webkit-scrollbar {
            display: none;
        }

        .job-carousel-track .job-card {
            flex: 0 0 calc((100% - (var(--jc-per-view) - 1) * var(--jc-gap)) / var(--jc-per-view));
            scroll-snap-align: start;
            box-sizing: border-box;
        }

        .jc-btn {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            border: 1px solid rgba(100, 255, 218, 0.35);
            background: #112240;
            color: #64FFDA;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: 0.2s;
            z-index: 2;
        }

        .jc-btn:hover:not(:disabled) {
            background: #64FFDA;
            color: #0A192F;
        }

        .jc-btn:disabled {
            opacity: 0.3;
            cursor: default;
        }

        .jc-prev {
            left: 0;
        }

        .jc-next {
            right: 0;
        }

        .jc-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 18px;
        }

        .jc-dot {
            width: 9px;
            height: 9px;
            padding: 0;
            border: none;
            border-radius: 999px;
            background: rgba(136, 146, 176, 0.45);
            cursor: pointer;
            transition: 0.2s;
        }

        .jc-dot.active {
            width: 26px;
            background: #64FFDA;
        }


        /* Job details modal + card preview */
        .job-card .job-desc {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 3;
            line-clamp: 3;
            overflow: hidden;
        }

        #jobDetailsOverlay .custom-modal {
            max-height: 88vh;
            overflow-y: auto;
        }

        .jd-dept {
            font-size: 0.8rem;
            color: #64FFDA;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .jd-title {
            color: #fff;
            font-size: 1.5rem;
            font-weight: 700;
            margin: 2px 0 12px;
        }

        .jd-meta {
            display: flex;
            flex-direction: column;
            gap: 6px;
            color: #8892B0;
            font-size: 0.9rem;
            margin-bottom: 6px;
        }

        .jd-meta i {
            color: #64FFDA;
            margin-right: 8px;
        }

        .jd-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64FFDA;
            margin: 18px 0 6px;
        }

        .jd-block {
            white-space: pre-line;
            overflow-wrap: break-word;
            word-break: break-word;
            color: #CCD6F6;
            font-size: 0.92rem;
            line-height: 1.55;
        }

        .jd-apply {
            margin-top: 24px;
            padding-top: 18px;
            border-top: 1px solid rgba(100, 255, 218, 0.12);
        }

        @media (max-width: 991px) {
            .job-carousel-track {
                --jc-per-view: 2;
            }
        }

        @media (max-width: 640px) {
            .job-carousel {
                padding: 0 4px;
            }

            .job-carousel-track {
                --jc-per-view: 1;
            }

            .jc-btn {
                display: none;
            }
        }
    </style>
</head>

<body class="landing-page">
    <main class="site-shell">
        <nav class="site-nav" aria-label="Main navigation">
            <a class="brand" href="#home" aria-label="Eco Hydrate Hub home">
                <img src="Images/logo.png" alt="Eco Hydrate Hub">
            </a>
            <button class="menu-toggle" type="button" aria-label="Toggle menu" aria-expanded="false">
                <i class="bi bi-list"></i>
            </button>
            <div class="nav-content">
                <div class="nav-links">
                    <a class="active" href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#products">Products</a>
                    <a href="#expertise">Expertise</a>
                    <a href="#contact">Contact</a>
                    <?php if ($open_jobs): ?><a href="#careers">Careers</a><?php endif; ?>

                </div>
                <a class="login-btn" href="login.php">Login</a>
            </div>
        </nav>

        <section class="hero-panel" id="home">
            <div class="hero-copy">
                <h1>Thirst<br>for more</h1>
                <p>Eco Hydrate Hub integrates smart monitoring with eco-friendly water distribution. Track consumption, manage station status, and ensure pure, safe drinking water through a single, real-time management platform.</p>
                <a class="start-btn" href="Customer/registration.php">Get Started</a>
            </div>

            <div class="brand-showcase">
                <div class="gallon-stage" aria-hidden="true">
                    <div class="gallon-glow"></div>
                    <img src="Images/Landing%20Page/gallon.png" alt="">
                </div>
                <p class="wordmark"><span>Eco</span> Hydrate</p>
            </div>
        </section>

        <section class="stats-bar" aria-label="Eco Hydrate Hub statistics">
            <div class="stat-item reveal" style="--reveal-delay: 0s">
                <i class="bi bi-person-heart" aria-hidden="true"></i>
                <p><strong>10,000+</strong><span>Happy Customers</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.1s">
                <i class="bi bi-shop-window" aria-hidden="true"></i>
                <p><strong>10</strong><span>Branches</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.2s">
                <i class="bi bi-truck" aria-hidden="true"></i>
                <p><strong>20,000+</strong><span>Total Services</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.3s">
                <i class="bi bi-people" aria-hidden="true"></i>
                <p><strong>100+</strong><span>Employees</span></p>
            </div>
        </section>

        <!-- ABOUT -->
        <section class="about-section" id="about" aria-labelledby="about-title">
            <div class="about-glow"></div>
            <div class="about-heading reveal">
                <h2 id="about-title">About Us</h2>
            </div>

            <div class="about-grid">
                <div class="about-column">
                    <div class="about-card reveal">
                        <span class="about-badge">Better Water. Better Living.</span>
                        <div class="about-panel">
                            <p>Welcome to Eco Hydrate Water Refilling Station, your trusted source of clean, safe, and affordable drinking water. We are committed to providing high-quality purified water that families, businesses, and communities can rely on every day.</p>
                            <p>Our water goes through a careful purification and filtration process to help ensure cleanliness, freshness, and quality. We maintain proper sanitation and regularly monitor our equipment to provide water that meets our quality standards.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.1s">
                        <span class="about-badge">What We Offer?</span>
                        <div class="about-panel">
                            <ul class="about-list">
                                <li>Purified Drinking Water</li>
                                <li>Water Delivery Service</li>
                                <li>Clean and Sanitized Containers</li>
                                <li>Bulk Water or Container Orders</li>
                                <li>Fast and Reliable Service</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="about-column">
                    <div class="about-card reveal">
                        <span class="about-badge">Our Mission</span>
                        <div class="about-panel">
                            <p>To provide safe, clean, and affordable drinking water while delivering friendly, reliable, and convenient service to every customer.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.1s">
                        <span class="about-badge">Our Vision</span>
                        <div class="about-panel">
                            <p>To become a trusted water refilling station in the community, known for quality water, excellent service, and customer satisfaction.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.2s">
                        <span class="about-badge">Our Commitment</span>
                        <div class="about-panel">
                            <p>Your health and satisfaction are important to us. We continuously strive to maintain cleanliness, quality, and dependable service so you can enjoy safe and refreshing drinking water every day.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="products-section" id="products" aria-labelledby="products-title">
            <div class="products-heading reveal">
                <h2 id="products-title">Our products</h2>
                <p>Eco Hydrate tackles the crisis of single-use plastic waste by offering communities a convenient, affordable way to access safe, multi-stage purified drinking water. Driven by a mission to make sustainable living effortless, Eco Hydrate allows customers to refill their existing containers at purchase, durable, reusable ones directly in-store. By replacing single-use plastic with a practical, zero-waste alternative, the store reduces localized pollution and cuts carbon emissions—empowering individuals to protect the planet, one refill at a time.</p>
            </div>
            <div class="product-grid">
                <article class="product-card featured reveal">
                    <div class="product-icon"><i class="bi bi-droplet-fill" aria-hidden="true"></i></div>
                    <h3>Refill</h3>
                    <p style="font-size: medium;"> Bring your own bottles or jugs and top up with fresh, multi-stage purified water for a fast, affordable, zero-waste fix.</p>
                    <a href="login.php">Order now</a>
                </article>
                <article class="product-card reveal" style="--reveal-delay: 0.1s">
                    <div class="product-icon"><i class="bi bi-journal-bookmark-fill" aria-hidden="true"></i></div>
                    <h3>Containers</h3>
                    <p style="font-size: medium;">Don't have a bottle? Pick from our durable,
                        BPA-free jugs and stainless steel flasks built for long-lasting, zero-waste hydration.</p>
                    <a href="login.php">Order now</a>
                </article>
            </div>
        </section>

        <!-- EXPERTISE -->
        <section class="expertise-section" id="expertise" aria-labelledby="expertise-title">
            <div class="expertise-heading reveal">
                <h2 id="expertise-title">OUR EXPERTISE</h2>
                <p>We provide clean, purified, and quality drinking water for your home, school, or business.</p>
            </div>

            <div class="expertise-content">
                <!-- Left Column Features -->
                <div class="expertise-column left">
                    <div class="expertise-card reveal reveal--left">
                        <div class="exp-icon"><i class="bi bi-droplet-fill"></i></div>
                        <div class="exp-text">
                            <h4>Custom Refills</h4>
                            <p>Fast, affordable refills for any container size—from personal flasks to 5-gallon home dispensers.</p>
                        </div>
                    </div>

                    <div class="expertise-card reveal reveal--left" style="margin-top: 1rem; --reveal-delay: 0.1s">
                        <div class="exp-icon"><i class="bi bi-truck"></i></div>
                        <div class="exp-text">
                            <h4>Bulk Delivery</h4>
                            <p>Scheduled refills and dispenser setups for homes, offices, and local events.</p>
                        </div>
                    </div>
                </div>

                <!-- Water 3D Drop -->
                <div class="expertise-center reveal reveal--scale">
                    <div class="water-drop-3d"></div>
                </div>

                <!-- Right Column Features -->
                <div class="expertise-column right">
                    <div class="expertise-card reveal reveal--right">
                        <div class="exp-icon"><i class="bi bi-ui-checks"></i></div>
                        <div class="exp-text">
                            <h4>Multi-Stage Purification</h4>
                            <p>Don't have a bottle? Pick from our durable, BPA-free jugs and stainless steel flasks built for long-lasting, zero-waste hydration.</p>
                        </div>
                    </div>

                    <div class="expertise-card reveal reveal--right" style="margin-top: 1rem; --reveal-delay: 0.1s">
                        <div class="exp-icon"><i class="bi bi-shield-fill-check"></i></div>
                        <div class="exp-text">
                            <h4>Sanitation Services</h4>
                            <p>Professional washing and UV-sterilizing for your bottles to ensure safe, highest hydration every time.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- CONTACT US -->
        <section class="contact-section" id="contact" aria-labelledby="contact-title">
            <div class="contact-heading reveal">
                <h2 id="contact-title">Contact Us</h2>
                <p>For inquiries, orders, and delivery requests, please contact us through the information provided.</p>
            </div>

            <div class="contact-grid">
                <!-- Left Column -->
                <div class="contact-left reveal reveal--left">
                    <h3 class="contact-brand-title"><span>Eco</span><br>Hydrate</h3>
                    <div class="contact-image-wrapper">
                        <img src="Images/Landing%20Page/gallon.png" alt="Eco Hydrate Gallon">
                    </div>
                </div>

                <!-- Right Column (Panel) -->
                <div class="contact-panel reveal reveal--right">
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-telephone-fill"></i></div>
                        <div class="contact-text">+63 9123 456 7895</div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-envelope-fill"></i></div>
                        <div class="contact-text">
                            <a href="mailto:EcoHydrate@gmail.com">EcoHydrate@gmail.com</a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-clock-fill"></i></div>
                        <div class="contact-text">[Opening Time] – [Closing Time]</div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-geo-alt-fill"></i></div>
                        <div class="contact-text">Amafel Building, Aguinaldo Highway, Dasmarinas, Cavite 4114</div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- CAREERS (only shown when there's at least one open posting) -->
    <?php if ($open_jobs): ?>
        <section class="careers-section" id="careers" aria-labelledby="careers-title">
            <div class="careers-heading reveal">
                <h2 id="careers-title">Join Our Team</h2>
                <p>Help us revolutionize eco-friendly water distribution. Discover open roles below and apply to become part of the growing Eco Hydrate Hub family.</p>
            </div>

            <?php if (!$use_carousel): ?>
                <div class="job-grid">
                    <?php foreach ($open_jobs as $i => $job): ?>
                        <?= lp_render_job_card($job, $i * 0.1) ?>
                    <?php endforeach; ?>
                </div>

            <?php else: ?>
                <div class="job-carousel reveal" id="jobCarousel">
                    <button type="button" class="jc-btn jc-prev" aria-label="Previous jobs"><i class="bi bi-chevron-left"></i></button>
                    <div class="job-carousel-track">
                        <?php foreach ($open_jobs as $job): ?>
                            <?= lp_render_job_card($job) ?>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="jc-btn jc-next" aria-label="Next jobs"><i class="bi bi-chevron-right"></i></button>
                    <div class="jc-dots" role="tablist" aria-label="Job pages"></div>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <!-- Job Details Modal -->
    <div id="jobDetailsOverlay" class="custom-overlay">
        <div class="custom-modal">
            <button class="btn-modal-close" onclick="closeJobDetails()">&times;</button>
            <div class="jd-dept" id="jdDept"></div>
            <h3 class="jd-title" id="jdTitle"></h3>
            <div class="jd-meta">
                <span><i class="bi bi-geo-alt"></i><span id="jdLocation"></span></span>
                <span><i class="bi bi-clock"></i><span id="jdType"></span></span>
                <span><i class="bi bi-cash-stack"></i><span id="jdSalary"></span></span>
                <span><i class="bi bi-people"></i><span id="jdOpenings"></span></span>
                <span><i class="bi bi-calendar-event"></i>Apply by: <span id="jdDeadline"></span></span>
            </div>

            <div class="jd-label">Overview</div>
            <div class="jd-block" id="jdOverview"></div>
            <div class="jd-label">Key Responsibilities</div>
            <div class="jd-block" id="jdResp"></div>
            <div class="jd-label">Qualifications &amp; Requirements</div>
            <div class="jd-block" id="jdQual"></div>

            <div class="jd-apply">
                <button type="button" class="btn-apply-job" id="jdApplyBtn">
                    <i class="bi bi-send-fill me-2"></i>Apply Now
                </button>
            </div>
        </div>
    </div>

    <!-- Job Application Modal -->
    <div id="applicationModalOverlay" class="custom-overlay">
        <div class="custom-modal">
            <button class="btn-modal-close" onclick="closeApplicationModal()">&times;</button>
            <h3 style="color: #fff; margin-top: 0; font-size: 1.5rem; font-weight: 700;">Apply for <span id="modalTargetJob" style="color: #64FFDA;">Role</span></h3>
            <p style="color: #8892B0; font-size: 0.9rem; margin-bottom: 1.5rem;">Take the next step in your career with Eco Hydrate Hub.</p>

            <div id="appSuccessMsg">
                <i class="bi bi-check-circle-fill me-2"></i> Application submitted successfully! We will review your profile shortly.
            </div>

            <div id="appErrorMsg" style="display:none; background: rgba(255,82,82,0.12); border: 1px solid rgba(255,82,82,0.35); color: #FF5252; border-radius: 10px; padding: 10px 14px; margin-bottom: 1rem; font-size: 0.9rem;"></div>

            <form id="jobAppForm" enctype="multipart/form-data">
                <input type="hidden" id="appliedJobId" name="job_id">

                <label class="form-label-custom">Full Name</label>
                <input type="text" name="full_name" class="form-input-custom" required maxlength="150" placeholder="Juan Dela Cruz">

                <label class="form-label-custom">Email Address</label>
                <input type="email" name="email" class="form-input-custom" required maxlength="150" placeholder="juan@example.com">

                <label class="form-label-custom">Contact Number</label>
                <input type="tel" name="contact_number" class="form-input-custom" required maxlength="20" placeholder="09XX XXX XXXX">

                <label class="form-label-custom">Cover Letter / Message (optional)</label>
                <textarea name="cover_note" class="form-input-custom" rows="3" maxlength="3000" placeholder="Tell us a bit about yourself..."></textarea>

                <label class="form-label-custom">Upload Resume (PDF/DOCX, max 5 MB)</label>
                <input type="file" name="resume" id="resumeInput" class="form-input-custom" accept=".pdf,.doc,.docx" required>

                <button type="submit" class="btn-submit-app" id="submitAppBtn">
                    Submit Application <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-top">
            <div class="footer-brand">
                <a class="footer-logo" href="#home">
                    <img src="Images/logo.png" alt="Eco Hydrate Hub">
                    <span><em>Eco</em> Hydrate</span>
                </a>
                <p>Smart, eco-friendly water refilling and delivery — bringing clean, purified water to homes and businesses while cutting down on single-use plastic waste.</p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                    <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                    <a href="#" aria-label="Messenger"><i class="bi bi-messenger"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#products">Products</a></li>
                    <li><a href="#expertise">Expertise</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <?php if ($open_jobs): ?><li><a href="#careers">Careers</a></li><?php endif; ?>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="Customer/registration.php">Get Started</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Contact</h4>
                <ul class="footer-contact">
                    <li><i class="bi bi-telephone-fill"></i><span>+63 9123 456 7895</span></li>
                    <li><i class="bi bi-envelope-fill"></i><span><a href="mailto:EcoHydrate@gmail.com" style="color:inherit;">EcoHydrate@gmail.com</a></span></li>
                    <li><i class="bi bi-geo-alt-fill"></i><span>Amafel Building, Aguinaldo Highway, Dasmariñas, Cavite 4114</span></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Eco Hydrate Hub. All rights reserved.</p>
            <div class="footer-legal">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
            </div>
        </div>
    </footer>

    <script>
        /* Scroll Reveal */
        (function() {
            if (window.CSS && CSS.supports && CSS.supports('animation-timeline: view()')) {
                return;
            }
            const revealEls = document.querySelectorAll('.reveal');
            if (!revealEls.length) return;
            const revealObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        revealObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.15,
                rootMargin: '0px 0px -10% 0px'
            });
            revealEls.forEach(el => revealObserver.observe(el));
        })();

        const toggle = document.querySelector('.menu-toggle');
        const nav = document.querySelector('.site-nav');
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('menu-open');
            toggle.setAttribute('aria-expanded', open);
        });

        window.addEventListener('scroll', () => {
            nav.classList.toggle('scrolled', window.scrollY > 8);
        });

        // Highlight the nav link
        const navLinks = document.querySelectorAll('.nav-links a');
        const sections = [...navLinks]
            .map(link => {
                if (!link.getAttribute('href').startsWith('#')) return null;
                return document.querySelector(link.getAttribute('href'));
            })
            .filter(Boolean);

        const spyObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                navLinks.forEach(link => {
                    if (link.getAttribute('href').startsWith('#')) {
                        link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
                    }
                });
            });
        }, {
            rootMargin: '-40% 0px -55% 0px',
            threshold: 0
        });

        sections.forEach(section => spyObserver.observe(section));


        /* Careers carousel */
        (function() {
            const root = document.getElementById('jobCarousel');
            if (!root) return;
            const track = root.querySelector('.job-carousel-track');
            const prev = root.querySelector('.jc-prev');
            const next = root.querySelector('.jc-next');
            const dotsWrap = root.querySelector('.jc-dots');
            let pages = 1;

            function buildDots() {
                pages = Math.max(1, Math.ceil((track.scrollWidth - 4) / track.clientWidth));
                dotsWrap.innerHTML = '';
                dotsWrap.style.display = pages > 1 ? '' : 'none';
                for (let i = 0; i < pages; i++) {
                    const d = document.createElement('button');
                    d.type = 'button';
                    d.className = 'jc-dot';
                    d.setAttribute('aria-label', 'Go to page ' + (i + 1));
                    d.addEventListener('click', () => track.scrollTo({
                        left: i * track.clientWidth,
                        behavior: 'smooth'
                    }));
                    dotsWrap.appendChild(d);
                }
                update();
            }

            function update() {
                const max = track.scrollWidth - track.clientWidth;
                prev.disabled = track.scrollLeft <= 2;
                next.disabled = track.scrollLeft >= max - 2;
                let page = Math.round(track.scrollLeft / track.clientWidth);
                if (track.scrollLeft >= max - 2) page = pages - 1;
                dotsWrap.querySelectorAll('.jc-dot').forEach((d, i) => d.classList.toggle('active', i === page));
            }

            prev.addEventListener('click', () => track.scrollBy({
                left: -track.clientWidth,
                behavior: 'smooth'
            }));
            next.addEventListener('click', () => track.scrollBy({
                left: track.clientWidth,
                behavior: 'smooth'
            }));
            track.addEventListener('scroll', update, {
                passive: true
            });
            window.addEventListener('resize', buildDots);
            buildDots();
        })();

        /* Job details modal */
        const detailsOverlay = document.getElementById('jobDetailsOverlay');
        const jdApplyBtn = document.getElementById('jdApplyBtn');
        let jdCurrentJob = {
            id: 0,
            title: ''
        };

        function openJobDetails(btn) {
            let job;
            try {
                job = JSON.parse(btn.dataset.job);
            } catch (e) {
                return;
            }
            const set = (id, v, fb) => document.getElementById(id).textContent = (v && String(v).trim()) ? v : fb;
            set('jdDept', job.department, '');
            set('jdTitle', job.title, '');
            set('jdLocation', job.location, '');
            set('jdType', job.employment_type, '');
            set('jdSalary', job.salary_text, '');
            set('jdOpenings', job.openings + (job.openings == 1 ? ' opening' : ' openings'), '');
            set('jdDeadline', job.deadline_text, '');
            set('jdOverview', job.overview, 'Not provided');
            set('jdResp', job.responsibilities, 'Not provided');
            set('jdQual', job.qualifications, 'Not provided');
            jdCurrentJob = {
                id: job.id,
                title: job.title
            };
            detailsOverlay.querySelector('.custom-modal').scrollTop = 0;
            detailsOverlay.classList.add('active');
        }

        function closeJobDetails() {
            detailsOverlay.classList.remove('active');
        }

        jdApplyBtn.addEventListener('click', function() {
            closeJobDetails();
            openApplicationModal(jdCurrentJob.id, jdCurrentJob.title);
        });

        detailsOverlay.addEventListener('click', function(e) {
            if (e.target === detailsOverlay) closeJobDetails();
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeJobDetails();
                closeApplicationModal();
            }
        });

        const overlay = document.getElementById('applicationModalOverlay');
        const appForm = document.getElementById('jobAppForm');
        const successMsg = document.getElementById('appSuccessMsg');
        const errorMsg = document.getElementById('appErrorMsg');
        const submitBtn = document.getElementById('submitAppBtn');
        const submitLabel = 'Submit Application <i class="bi bi-arrow-right ms-1"></i>';

        function openApplicationModal(jobId, jobTitle) {
            appForm.reset();
            appForm.style.display = 'block';
            successMsg.style.display = 'none';
            errorMsg.style.display = 'none';
            submitBtn.disabled = false;
            submitBtn.innerHTML = submitLabel;
            submitBtn.style.opacity = '1';

            document.getElementById('modalTargetJob').textContent = jobTitle;
            document.getElementById('appliedJobId').value = jobId;

            overlay.classList.add('active');
        }

        function closeApplicationModal() {
            overlay.classList.remove('active');
        }

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closeApplicationModal();
            }
        });

        function showAppError(msg) {
            errorMsg.textContent = msg;
            errorMsg.style.display = 'block';
            submitBtn.disabled = false;
            submitBtn.innerHTML = submitLabel;
            submitBtn.style.opacity = '1';
        }

        appForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            errorMsg.style.display = 'none';

            const resume = document.getElementById('resumeInput').files[0];
            if (resume && resume.size > 5 * 1024 * 1024) {
                showAppError('Resume must be 5 MB or smaller.');
                return;
            }

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Sending...';
            submitBtn.style.opacity = '0.7';

            try {
                const res = await fetch('Hr/submit_application.php', {
                    method: 'POST',
                    body: new FormData(appForm)
                });
                const data = await res.json();
                if (data.ok) {
                    appForm.style.display = 'none';
                    successMsg.style.display = 'block';
                } else {
                    showAppError(data.message || 'Could not submit your application.');
                }
            } catch (err) {
                showAppError('Network error. Please check your connection and try again.');
            }
        });
    </script>
</body>

</html>