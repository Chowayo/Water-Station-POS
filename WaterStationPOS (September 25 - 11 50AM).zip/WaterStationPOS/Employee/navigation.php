<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<style>
    .menu-link-icon {
        display: inline-block;
        width: 20px;
        margin-right: 10px;
        text-align: center;
        font-size: 15px;
    }

    .menu-group-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
        color: #4d5f82;
        text-transform: uppercase;
        padding: 0 16px;
        margin: 18px 0 6px;
    }

    .menu-group-label:first-child {
        margin-top: 0;
    }

    /* Desktop collapse/expand toggle */
    .sidebar-collapse-btn {
        background: transparent;
        border: none;
        color: #8892B0;
        font-size: 18px;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background 0.15s ease, color 0.15s ease;
        position: absolute;
        top: 12px;
        right: 12px;
        z-index: 5;
    }

    .sidebar-collapse-btn:hover {
        background: rgba(100, 255, 218, 0.08);
        color: #64FFDA;
    }

    #leftMenu {
        position: relative;
        transition: width 0.2s ease, padding 0.2s ease;
        overflow: hidden;
    }

    /* Fully closed: width collapses to 0, nothing inside is visible or reachable */
    #leftMenu.collapsed {
        width: 0 !important;
        min-width: 0 !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
        border-right: none !important;
        visibility: hidden;
    }

    /* Small floating button to reopen the sidebar once it's fully closed */
    .sidebar-open-btn {
        display: none;
        position: fixed;
        top: 16px;
        left: 16px;
        z-index: 1050;
        width: 38px;
        height: 38px;
        border-radius: 8px;
        background: #112240;
        border: 1px solid rgba(100, 255, 218, 0.25);
        color: #64FFDA;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.35);
    }

    .sidebar-open-btn.visible {
        display: flex;
    }
</style>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">

        <button type="button" class="sidebar-collapse-btn d-none d-lg-flex" id="sidebarCollapseBtn" aria-label="Collapse menu" title="Collapse menu">
            <i class="bi bi-chevron-double-left"></i>
        </button>

        <div class="sidebar-brand text-center px-3 mb-3">
            <img src="../Images/logo.png" alt="Logo" class="sidebar-brand-logo mb-2">
            <h6 class="sidebar-brand-name mb-0"><span class="green-text">ECO</span> HYDRATE HUB</h6>
        </div>

        <div class="px-3 mb-4">
            <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>
        </div>

        <?php
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>

        <?php
        echo <<<HTML
                <script>
                    $(document).ready(function() {


                        //Sets the visible access of pages when the role is Delivery
                        if("{$result->role}"=="Delivery"){
                            $("#POS").hide();
                            $("#CustomInfo").hide();
                        }

                        //Sets the visible access of pages when the role is Cashier
                        else if("{$result->role}"=="Delivery"){
                            //Empty since cashier can access every present page in the system
                        }
                    });
                </script>
            HTML;
        ?>


        <nav class="nav flex-column px-2">
            <hr class="mx-3 border-secondary mt-0">

            <div class="menu-group-label">Operations</div>
            <a class="menu-link <?php echo $current_page === 'home.php' ? 'active' : ''; ?>" href="home.php" id="POS"><i class="bi bi-shop menu-link-icon"></i><span class="menu-link-text">POS</span></a>
            <a class="menu-link <?php echo $current_page === 'confirmation.php' ? 'active' : ''; ?>" href="confirmation.php" id="OrderConfirm"><i class="bi bi-clipboard-check menu-link-icon"></i><span class="menu-link-text">Order Confirmation</span></a>
            <a class="menu-link <?php echo $current_page === 'customerInfo.php' ? 'active' : ''; ?>" href="customerInfo.php" id="CustomInfo"><i class="bi bi-people menu-link-icon"></i><span class="menu-link-text">Customer Information</span></a>

            <div class="menu-group-label">HR</div>
            <a class="menu-link <?php echo $current_page === 'leaveRequest.php' ? 'active' : ''; ?>" href="leaveRequest.php" id="LeaveReq"><i class="bi bi-calendar2-week menu-link-icon"></i><span class="menu-link-text">Leave Requests</span></a>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout"><i class="bi bi-box-arrow-right menu-link-icon"></i><span class="menu-link-text">Logout</span></a>
    </aside>

    <button type="button" class="sidebar-open-btn" id="sidebarOpenBtn" aria-label="Open menu" title="Open menu">
        <i class="bi bi-chevron-double-right"></i>
    </button>

    <?php include 'profile.php'; ?>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }

        // Desktop collapse/expand toggle
        (function() {
            var menu = document.getElementById('leftMenu');
            var collapseBtn = document.getElementById('sidebarCollapseBtn');
            var openBtn = document.getElementById('sidebarOpenBtn');
            if (!menu || !collapseBtn || !openBtn) return;

            function applyCollapsed(collapsed) {
                menu.classList.toggle('collapsed', collapsed);
                openBtn.classList.toggle('visible', collapsed);
            }

            // Restore saved state on load
            applyCollapsed(localStorage.getItem('sidebarCollapsed') === '1');

            collapseBtn.addEventListener('click', function() {
                applyCollapsed(true);
                localStorage.setItem('sidebarCollapsed', '1');
            });

            openBtn.addEventListener('click', function() {
                applyCollapsed(false);
                localStorage.setItem('sidebarCollapsed', '0');
            });
        })();
    </script>