<?php
$current_section = basename(dirname($_SERVER['SCRIPT_NAME']));

if ($current_section === 'Hr') {
    $nav_items = [
        'Overview' => [
            'dashboard.php' => ['label' => 'Dashboard', 'icon' => 'bi-speedometer2'],
        ],
        'Workforce' => [
            'employees.php'  => ['label' => 'Accounts',       'icon' => 'bi-people'],
            'attendance.php' => ['label' => 'Attendance',     'icon' => 'bi-calendar-check'],
            'leave.php'      => ['label' => 'Leave Requests', 'icon' => 'bi-calendar2-x'],
            'payroll.php'    => ['label' => 'Payroll',        'icon' => 'bi-cash-coin'],
        ],
        'Recruitment' => [
            'jobposting.php'      => ['label' => 'Job Posting',      'icon' => 'bi-briefcase'],
            'jobapplications.php' => ['label' => 'Job Applications', 'icon' => 'bi-person-lines-fill'],
        ],
    ];
    $sidebar_label   = 'HR DEPARTMENT';
} elseif ($current_section === 'Finance') {
    $nav_items = [
        'Overview' => [
            'dashboard.php' => ['label' => 'Dashboard', 'icon' => 'bi-speedometer2'],
        ],
        'Finance Records' => [
            'transactions.php' => ['label' => 'Transactions', 'icon' => 'bi-arrow-left-right'],
            'expenses.php'     => ['label' => 'Expenses',     'icon' => 'bi-receipt'],
            'reports.php'      => ['label' => 'Reports',      'icon' => 'bi-bar-chart-line'],
        ],
        'Procurement' => [
            'requisitions.php'      => ['label' => 'Requisitions',      'icon' => 'bi-bar-chart-line'],
            'supplier_approval.php'      => ['label' => 'Supplier Approval',      'icon' => 'bi-bar-chart-line'],
            'contract.php'  => ['label' => 'Contract', 'icon' => 'bi-clipboard-check'],
            'invoices.php'      => ['label' => 'Invoices',      'icon' => 'bi-bar-chart-line'],
        ],
    ];
    $sidebar_label   = 'FINANCE DEPARTMENT';
} elseif ($current_section === 'Inventory') {
    $nav_items = [
        'Stock & Procurement' => [
            'stocks.php'     => ['label' => 'Stocks',        'icon' => 'bi-box-seam'],
            'requisitions.php'  => ['label' => 'Purchase Requests', 'icon' => 'bi-clipboard-check'],
            'suppliers.php'  => ['label' => 'Suppliers', 'icon' => 'bi-clipboard-check'],
        ],
    ];
    $sidebar_label   = 'INVENTORY DEPARTMENT';
} elseif ($current_section === 'Supplier') {
    $nav_items = [
        'Orders' => [
            'orders.php'     => ['label' => 'Orders',        'icon' => 'bi-box-seam'],
        ],
    ];
    $sidebar_label   = 'SUPPLIERS';
} else {
    $nav_items = [
        'Overview' => [
            'dashboard.php' => ['label' => 'Dashboard', 'icon' => 'bi-speedometer2'],
        ],
        'Management' => [
            'employees.php' => ['label' => 'Employees', 'icon' => 'bi-people'],
            'hr.php'        => ['label' => 'HR',        'icon' => 'bi-person-badge'],
            'finance.php'   => ['label' => 'Finance',   'icon' => 'bi-cash-coin'],
            'products.php'  => ['label' => 'Products',  'icon' => 'bi-box-seam'],
        ],
    ];
    $sidebar_label  = 'ADMINISTRATOR';
}

$current_page = basename($_SERVER['PHP_SELF']);
?>

<style>
    .sidebar-brand-logo {
        width: 52px;
        height: 52px;
        object-fit: contain;
        border-radius: 50%;
        border: 2px solid #64FFDA;
        background-color: #0A192F;
    }

    .sidebar-brand-name {
        font-weight: 800;
        font-size: 14px;
        letter-spacing: 0.5px;
        color: #FFFFFF;
    }

    .menu-link-icon {
        display: inline-block;
        width: 20px;
        margin-right: 10px;
        text-align: center;
        font-size: 15px;
    }

    .menu-group-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
        color: #4d5f82;
        text-transform: uppercase;
        padding: 0 16px;
        margin: 18px 0 6px;
    }

    .menu-group-label:first-child {
        margin-top: 0;
    }

    /* Desktop collapse/expand toggle */
    .sidebar-collapse-btn {
        background: transparent;
        border: none;
        color: #8892B0;
        font-size: 18px;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background 0.15s ease, color 0.15s ease;
        position: absolute;
        top: 12px;
        right: 12px;
        z-index: 5;
    }

    .sidebar-collapse-btn:hover {
        background: rgba(100, 255, 218, 0.08);
        color: #64FFDA;
    }

    #leftMenu {
        position: relative;
        transition: width 0.2s ease, padding 0.2s ease;
        overflow: hidden;
    }

    /* Fully closed: width collapses to 0, nothing inside is visible or reachable */
    #leftMenu.collapsed {
        width: 0 !important;
        min-width: 0 !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
        border-right: none !important;
        visibility: hidden;
    }

    /* Small floating button to reopen the sidebar once it's fully closed */
    .sidebar-open-btn {
        display: none;
        position: fixed;
        top: 16px;
        left: 16px;
        z-index: 1050;
        width: 38px;
        height: 38px;
        border-radius: 8px;
        background: #112240;
        border: 1px solid rgba(100, 255, 218, 0.25);
        color: #64FFDA;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.35);
    }

    .sidebar-open-btn.visible {
        display: flex;
    }
</style>

<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">

        <button type="button" class="sidebar-collapse-btn d-none d-lg-flex" id="sidebarCollapseBtn" aria-label="Collapse menu" title="Collapse menu">
            <i class="bi bi-chevron-double-left"></i>
        </button>

        <div class="sidebar-brand text-center px-3 mb-3">
            <img src="../Images/logo.png" alt="Logo" class="sidebar-brand-logo mb-2">
            <h6 class="sidebar-brand-name mb-0"><span class="green-text">ECO</span> HYDRATE HUB</h6>
        </div>

        <div class="px-3 mb-3">
            <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;"><?php echo $sidebar_label; ?></p>
        </div>

        <nav class="nav flex-column px-2">

            <hr class="mx-3 border-secondary mt-0">

            <?php foreach ($nav_items as $group_label => $group_items): ?>
                <div class="menu-group-label"><?php echo $group_label; ?></div>
                <?php foreach ($group_items as $link => $item): ?>
                    <a class="menu-link <?php echo $current_page === $link ? 'active' : ''; ?>" href="<?php echo $link; ?>">
                        <i class="bi <?php echo $item['icon']; ?> menu-link-icon"></i><?php echo $item['label']; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">
            <i class="bi bi-box-arrow-right menu-link-icon"></i>Logout
        </a>
    </aside>

    <button type="button" class="sidebar-open-btn" id="sidebarOpenBtn" aria-label="Open menu" title="Open menu">
        <i class="bi bi-chevron-double-right"></i>
    </button>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function() {
            const link = document.querySelector('a[href$="logout.php"]');
            if (!link) return;

            function confirmLogout() {
                Swal.fire({
                    icon: 'question',
                    title: 'Log out?',
                    text: 'You will need to sign in again to continue.',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, log out',
                    cancelButtonText: 'Cancel',
                    background: '#112240',
                    color: '#CCD6F6',
                    confirmButtonColor: '#00E676',
                    cancelButtonColor: '#5c6b8a',
                    heightAuto: false
                }).then(function(result) {
                    if (result.isConfirmed) window.location.href = link.href;
                });
            }

            link.addEventListener('click', function(e) {
                e.preventDefault();
                if (typeof Swal !== 'undefined') {
                    confirmLogout();
                } else {
                    const sc = document.createElement('script');
                    sc.src = '../js/sweetalert2@11.js'; // adjust path if navigation.php is included from other folders
                    sc.onload = confirmLogout;
                    document.head.appendChild(sc);
                }
            });
        });

        // Desktop collapse/expand toggle
        (function() {
            var menu = document.getElementById('leftMenu');
            var collapseBtn = document.getElementById('sidebarCollapseBtn');
            var openBtn = document.getElementById('sidebarOpenBtn');
            if (!menu || !collapseBtn || !openBtn) return;

            function applyCollapsed(collapsed) {
                menu.classList.toggle('collapsed', collapsed);
                openBtn.classList.toggle('visible', collapsed);
            }

            // Restore saved state on load
            applyCollapsed(localStorage.getItem('sidebarCollapsed') === '1');

            collapseBtn.addEventListener('click', function() {
                applyCollapsed(true);
                localStorage.setItem('sidebarCollapsed', '1');
            });

            openBtn.addEventListener('click', function() {
                applyCollapsed(false);
                localStorage.setItem('sidebarCollapsed', '0');
            });
        })();
    </script>