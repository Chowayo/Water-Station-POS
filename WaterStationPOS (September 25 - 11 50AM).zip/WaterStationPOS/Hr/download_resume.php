<?php
// HR/Admin only: streams a stored resume. Files live in /uploads/resumes (not web-accessible).
require_once __DIR__ . '/../dbConn.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$role = $_SESSION['users']->role ?? null;
if (!in_array($role, ['HR', 'Admin'], true)) {
    http_response_code(403);
    exit('Forbidden');
}

$id = (int)($_GET['id'] ?? 0);
$row = null;
try {
    $stmt = $conn->prepare("SELECT resume_path, resume_original_name FROM job_applications WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
} catch (Throwable $e) {
    error_log('download_resume: ' . $e->getMessage());
}

$path = $row ? __DIR__ . '/../uploads/resumes/' . basename($row['resume_path']) : '';
if (!$row || !is_file($path)) {
    http_response_code(404);
    exit('Resume not found.');
}

$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$types = [
    'pdf'  => 'application/pdf',
    'doc'  => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
$inline = ($ext === 'pdf' && empty($_GET['dl']));
$filename = str_replace('"', '', $row['resume_original_name']);

header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
