<?php
// Public endpoint: receives the landing-page application form and saves it to job_applications.
ob_start();                       // swallow any stray output (warnings, whitespace from dbConn.php)
ini_set('display_errors', '0');   // errors go to the PHP error log, not into the JSON

function app_json($data, $code = 200)
{
    while (ob_get_level() > 0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

function app_fail($msg, $code = 422)
{
    app_json(['ok' => false, 'message' => $msg], $code);
}

try {
    require_once __DIR__ . '/../dbConn.php';
} catch (Throwable $e) {
    error_log('submit_application dbConn: ' . $e->getMessage());
    app_fail('Could not connect to the database.', 500);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    app_fail('Invalid request.', 405);
}

$job_id  = (int)($_POST['job_id'] ?? 0);
$name    = trim($_POST['full_name'] ?? '');
$email   = trim($_POST['email'] ?? '');
$phone   = trim($_POST['contact_number'] ?? '');
$note    = trim($_POST['cover_note'] ?? '');

if ($job_id <= 0)                                   app_fail('Please choose a job to apply for.');
if ($name === '' || strlen($name) > 150)         app_fail('Please enter your full name.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) app_fail('Please enter a valid email address.');
if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone))  app_fail('Please enter a valid contact number.');
if (strlen($note) > 3000)                        app_fail('Your message is too long (3,000 characters max).');

// ---- Resume validation ----
$file = $_FILES['resume'] ?? null;
if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) app_fail('Please upload your resume.');
if ($file['error'] !== UPLOAD_ERR_OK)                app_fail('Resume upload failed. Please try again.');
if ($file['size'] > 5 * 1024 * 1024)                 app_fail('Resume must be 5 MB or smaller.');

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = [
    'pdf'  => ['application/pdf'],
    'doc'  => ['application/msword', 'application/x-ole-storage', 'application/CDFV2', 'application/octet-stream'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
];
if (!isset($allowed[$ext])) app_fail('Resume must be a PDF, DOC or DOCX file.');

if (class_exists('finfo')) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    if (!in_array($finfo->file($file['tmp_name']), $allowed[$ext], true)) {
        app_fail('That file does not look like a valid ' . strtoupper($ext) . ' document.');
    }
} elseif ($ext === 'pdf' && file_get_contents($file['tmp_name'], false, null, 0, 4) !== '%PDF') {
    app_fail('That file does not look like a valid PDF.');
}

try {
    // Job must exist and still be open (title is taken from the DB, not from the browser)
    $stmt = $conn->prepare("SELECT id, title FROM job_postings WHERE id = ? AND status = 'Open' AND (deadline IS NULL OR deadline >= CURDATE())");
    $stmt->bind_param('i', $job_id);
    $stmt->execute();
    $job = $stmt->get_result()->fetch_assoc();
    if (!$job) app_fail('Sorry, this position is no longer accepting applications.');

    // One application per email per job
    $stmt = $conn->prepare("SELECT id FROM job_applications WHERE job_id = ? AND email = ? LIMIT 1");
    $stmt->bind_param('is', $job_id, $email);
    $stmt->execute();
    if ($stmt->get_result()->fetch_assoc()) app_fail('You have already applied for this position with that email.');

    // Save the file in a private folder (blocked from direct web access)
    $dir = __DIR__ . '/../uploads/resumes';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) app_fail('Server could not store your resume.', 500);
    if (!file_exists($dir . '/.htaccess')) {
        file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $stored)) app_fail('Server could not store your resume.', 500);

    $orig = substr(preg_replace('/[^\w.\- ]+/u', '_', basename($file['name'])), 0, 200);

    $conn->begin_transaction();
    $stmt = $conn->prepare("INSERT INTO job_applications (job_id, position_title, full_name, email, contact_number, cover_note, resume_path, resume_original_name) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param('isssssss', $job['id'], $job['title'], $name, $email, $phone, $note, $stored, $orig);
    $stmt->execute();

    // Keep the "applicants" counter on the HR Job Postings page in sync
    $stmt = $conn->prepare("UPDATE job_postings SET applicants = applicants + 1 WHERE id = ?");
    $stmt->bind_param('i', $job['id']);
    $stmt->execute();
    $conn->commit();

    app_json(['ok' => true]);
} catch (Throwable $e) {
    if (isset($conn)) {
        try {
            $conn->rollback();
        } catch (Throwable $x) {
        }
    }
    if (!empty($stored) && file_exists(($dir ?? '') . '/' . $stored)) @unlink($dir . '/' . $stored);
    error_log('submit_application: ' . $e->getMessage());
    app_fail('Something went wrong while saving your application. Please try again.', 500);
}
