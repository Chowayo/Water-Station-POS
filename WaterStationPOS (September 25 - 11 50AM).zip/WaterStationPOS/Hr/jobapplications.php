<?php
// Buffer so we can redirect after updating a stage (header.php may already have started the HTML)
ob_start();
include 'header.php';
require_once __DIR__ . '/../dbConn.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$stages = ['Pending', 'Shortlisted', 'Initial Interview', 'Final Interview', 'Hired', 'Rejected'];

function ja_e($v)
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function ja_slug($s)
{
    return strtolower(str_replace(' ', '-', $s));
}

function ja_initials($name)
{
    $parts = preg_split('/\s+/', trim($name));
    $i = mb_substr($parts[0] ?? '', 0, 1);
    if (count($parts) > 1) $i .= mb_substr(end($parts), 0, 1);
    return mb_strtoupper($i);
}

// ---------- Update application stage ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    $id     = (int)($_POST['app_id'] ?? 0);
    $status = $_POST['status'] ?? '';

    if ($id > 0 && in_array($status, $stages, true)) {
        try {
            $stmt = $conn->prepare("UPDATE job_applications SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $id);
            $stmt->execute();
            $_SESSION['app_flash'] = ['success', 'Application stage updated to ' . $status . '.'];
        } catch (Throwable $e) {
            error_log('jobapplications update: ' . $e->getMessage());
            $_SESSION['app_flash'] = ['danger', 'Could not update the application.'];
        }
    } else {
        $_SESSION['app_flash'] = ['danger', 'Invalid application or stage.'];
    }
    header('Location: jobapplications.php');
    exit;
}

$flash = $_SESSION['app_flash'] ?? null;
unset($_SESSION['app_flash']);

// ---------- Load applications ----------
$apps = [];
$load_error = false;
try {
    $res = $conn->query("SELECT * FROM job_applications ORDER BY created_at DESC, id DESC");
    $apps = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    error_log('jobapplications load: ' . $e->getMessage());
    $load_error = true;
}

$counts = array_fill_keys($stages, 0);
$positions = [];
foreach ($apps as $a) {
    if (isset($counts[$a['status']])) $counts[$a['status']]++;
    $positions[$a['position_title']] = true;
}
$positions = array_keys($positions);
sort($positions);
?>

<head>
    <title>Job Applications - HR Dashboard</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        :root {
            --bg: #0A192F;
            --card-bg: #112240;
            --card-bg-hover: #16294a;
            --border: rgba(100, 255, 218, 0.12);
            --text-main: #CCD6F6;
            --text-muted: #8892B0;
            --accent-green: #00E676;
            --accent-green-dark: #00A859;
            --accent-cyan: #64FFDA;
            --accent-amber: #FFC107;
            --accent-red: #FF5252;
            --accent-blue: #64B5F6;
            --accent-purple: #B388FF;
        }

        .top-text h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0;
        }

        .top-text p {
            color: var(--text-muted);
            margin: 4px 0 0;
            font-size: 0.9rem;
        }

        /* ===== Summary chips ===== */
        .summary-chip {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 14px;
            height: 100%;
        }

        .summary-chip .chip-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 1.1rem;
        }

        .chip-icon-total {
            background-color: rgba(100, 255, 218, 0.12);
            color: var(--accent-cyan);
        }

        .chip-icon-pending {
            background-color: rgba(255, 193, 7, 0.12);
            color: var(--accent-amber);
        }

        .chip-icon-shortlisted {
            background-color: rgba(0, 230, 118, 0.12);
            color: var(--accent-green);
        }

        .chip-icon-rejected {
            background-color: rgba(255, 82, 82, 0.12);
            color: var(--accent-red);
        }

        .chip-icon-initial-interview {
            background-color: rgba(100, 181, 246, 0.12);
            color: var(--accent-blue);
        }

        .chip-icon-final-interview {
            background-color: rgba(179, 136, 255, 0.12);
            color: var(--accent-purple);
        }

        .summary-chip .chip-value {
            font-size: 1.3rem;
            font-weight: 800;
            color: #FFFFFF;
            line-height: 1.1;
        }

        .summary-chip .chip-label {
            font-size: 0.78rem;
            color: var(--text-muted);
        }

        .manage-box {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
        }

        .section-header {
            font-size: 0.95rem;
            font-weight: 700;
            color: #FFFFFF;
            margin-bottom: 12px;
        }

        /*  Filters  */
        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .filter-bar .form-select,
        .filter-bar .form-control {
            background-color: #0A192F;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .filter-bar .form-select:focus,
        .filter-bar .form-control:focus {
            background-color: #0A192F;
            border-color: var(--accent-cyan);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.15);
        }

        .filter-bar .form-control::placeholder {
            color: var(--text-muted);
        }

        .search-box-wrap {
            position: relative;
            display: inline-block;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            pointer-events: none;
            font-size: 14px;
        }

        .search-box-wrap input.table-search-input {
            padding-left: 34px;
            min-width: 220px;
        }

        /*  Table  */
        .applicant-name {
            display: flex;
            align-items: center;
            gap: 10px;
            text-align: left;
        }

        .applicant-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-cyan) 0%, var(--accent-green-dark) 100%);
            color: #06210F;
            font-weight: 700;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .applicant-info .name {
            font-weight: 700;
            color: #FFFFFF;
            font-size: 0.9rem;
        }

        .applicant-info .email {
            font-size: 0.78rem;
            color: var(--text-muted);
        }

        .status-pill {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 999px;
            white-space: nowrap;
        }

        .status-pending {
            background-color: rgba(255, 193, 7, 0.12);
            color: var(--accent-amber);
            border: 1px solid rgba(255, 193, 7, 0.35);
        }

        .status-shortlisted {
            background-color: rgba(100, 255, 218, 0.12);
            color: var(--accent-cyan);
            border: 1px solid rgba(100, 255, 218, 0.35);
        }

        .status-initial-interview {
            background-color: rgba(100, 181, 246, 0.12);
            color: var(--accent-blue);
            border: 1px solid rgba(100, 181, 246, 0.35);
        }

        .status-final-interview {
            background-color: rgba(179, 136, 255, 0.12);
            color: var(--accent-purple);
            border: 1px solid rgba(179, 136, 255, 0.35);
        }

        .status-hired {
            background-color: rgba(0, 230, 118, 0.12);
            color: var(--accent-green);
            border: 1px solid rgba(0, 230, 118, 0.35);
        }

        .status-rejected {
            background-color: rgba(255, 82, 82, 0.12);
            color: var(--accent-red);
            border: 1px solid rgba(255, 82, 82, 0.35);
        }

        .btn-view-app {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
            font-size: 0.78rem;
            padding: 5px 12px;
            border-radius: 8px;
        }

        .btn-view-app:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
        }

        .btn-resume {
            background: transparent;
            border: 1px solid rgba(100, 255, 218, 0.3);
            color: var(--accent-cyan);
            font-size: 0.78rem;
            padding: 5px 12px;
            border-radius: 8px;
        }

        .btn-resume:hover {
            background-color: rgba(100, 255, 218, 0.1);
            color: var(--accent-cyan);
        }

        table.dataTable thead th {
            color: var(--text-muted);
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            border-bottom: 1px solid var(--border) !important;
        }

        table.table-dark {
            --bs-table-bg: transparent;
        }

        table.table-dark td,
        table.table-dark th {
            border-color: var(--border);
            vertical-align: middle;
        }

        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: var(--card-bg);
            z-index: 1;
        }

        .dataTables_wrapper {
            color: var(--text-main);
        }

        .dataTables_wrapper .dataTables_info {
            color: var(--text-muted);
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: var(--text-main) !important;
            border: 1px solid var(--border) !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: var(--accent-cyan) !important;
            color: var(--accent-cyan) !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--accent-cyan) !important;
            border-color: var(--accent-cyan) !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }

        /*  Modal  */
        .modal-content {
            background-color: var(--card-bg);
            color: var(--text-main);
            border: 1px solid var(--border);
            border-radius: 16px;
        }

        .modal-header,
        .modal-footer {
            border-color: var(--border);
        }

        .modal-title {
            font-weight: 700;
            color: #FFFFFF;
        }

        .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }

        .detail-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--text-muted);
            margin-bottom: 2px;
        }

        .detail-value {
            font-size: 0.92rem;
            color: var(--text-main);
            margin-bottom: 14px;
        }

        .btn-cancel {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .btn-cancel:hover {
            color: var(--text-main);
            border-color: var(--accent-red);
        }

        .btn-approve {
            background: linear-gradient(135deg, var(--accent-green) 0%, var(--accent-green-dark) 100%);
            border: none;
            color: #06210F;
            font-weight: 700;
        }

        .btn-approve:hover {
            filter: brightness(1.08);
            color: #06210F;
        }

        .btn-reject-outline {
            background: transparent;
            border: 1px solid rgba(255, 82, 82, 0.4);
            color: var(--accent-red);
            font-weight: 600;
        }

        .btn-reject-outline:hover {
            background-color: rgba(255, 82, 82, 0.1);
            color: var(--accent-red);
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <h1><i class="bi bi-people-fill me-2"></i>Job Applications</h1>
                    <p>Review candidates who applied for open positions</p>
                </div>
            </header>

            <?php if ($flash): ?>
                <script>
                    (function() {
                        const flash = <?= json_encode($flash, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
                        const ok = flash[0] === 'success';

                        function showFlash() {
                            Swal.fire({
                                icon: ok ? 'success' : 'error',
                                title: ok ? 'Success!' : 'Oops...',
                                text: flash[1],
                                background: '#112240',
                                color: '#CCD6F6',
                                confirmButtonColor: '#00E676',
                                confirmButtonText: 'Okay',
                                heightAuto: false, // <-- add this
                                timer: ok ? 2000 : undefined,
                                timerProgressBar: ok
                            });
                        }
                        if (typeof Swal !== 'undefined') {
                            showFlash();
                        } else {
                            const sc = document.createElement('script');
                            sc.src = '../js/sweetalert2@11.js';
                            sc.onload = showFlash;
                            document.head.appendChild(sc);
                        }
                    })();
                </script>
            <?php endif; ?>

            <?php if ($load_error): ?>
                <div class="alert alert-warning">Could not load applications. Create the <code>job_applications</code> table first (see <code>job_applications.sql</code>).</div>
            <?php endif; ?>

            <!-- Summary chips -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-lg-3">
                    <div class="summary-chip">
                        <div class="chip-icon chip-icon-total"><i class="bi bi-people"></i></div>
                        <div>
                            <div class="chip-value"><?= count($apps) ?></div>
                            <div class="chip-label">Total Applicants</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="summary-chip">
                        <div class="chip-icon chip-icon-pending"><i class="bi bi-hourglass-split"></i></div>
                        <div>
                            <div class="chip-value"><?= (int)$counts['Pending'] ?></div>
                            <div class="chip-label">Pending Review</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="summary-chip">
                        <div class="chip-icon chip-icon-initial-interview"><i class="bi bi-people"></i></div>
                        <div>
                            <div class="chip-value"><?= (int)$counts['Initial Interview'] ?></div>
                            <div class="chip-label">Initial Interview</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="summary-chip">
                        <div class="chip-icon chip-icon-final-interview"><i class="bi bi-calendar2-check"></i></div>
                        <div>
                            <div class="chip-value"><?= (int)$counts['Final Interview'] ?></div>
                            <div class="chip-label">Final Interview</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Applications Table -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-file-earmark-person me-2"></i>All Applications</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3 filter-bar">
                            <div class="search-box-wrap">
                                <i class="bi bi-search"></i>
                                <input type="text" class="form-control table-search-input" placeholder="Search applicant" id="searcher">
                            </div>
                            <div class="d-flex gap-2">
                                <select class="form-select" id="positionFilter" style="max-width: 190px;">
                                    <option value="" selected>All Positions</option>
                                    <?php foreach ($positions as $pos): ?>
                                        <option value="<?= ja_e($pos) ?>"><?= ja_e($pos) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <select class="form-select" id="statusFilter" style="max-width: 180px;">
                                    <option value="" selected>All Status</option>
                                    <?php foreach ($stages as $st): ?>
                                        <option value="<?= ja_e($st) ?>"><?= ja_e($st) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#applications_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    order: [
                                        [3, 'desc']
                                    ],
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });
                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                function exact(v) {
                                    return v ? '^' + $.fn.dataTable.util.escapeRegex(v) + '$' : '';
                                }
                                $('#positionFilter').on('change', function() {
                                    table.column(1).search(exact(this.value), true, false).draw();
                                });
                                $('#statusFilter').on('change', function() {
                                    table.column(5).search(exact(this.value), true, false).draw();
                                });
                            });
                        </script>
                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="applications_list">
                            <thead>
                                <tr>
                                    <th>Applicant</th>
                                    <th>Position Applied For</th>
                                    <th>Contact Number</th>
                                    <th>Date Applied</th>
                                    <th>Resume</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($apps as $a):
                                    $ts = strtotime($a['created_at']);
                                    $payload = [
                                        'id'          => (int)$a['id'],
                                        'full_name'   => $a['full_name'],
                                        'email'       => $a['email'],
                                        'position'    => $a['position_title'],
                                        'contact'     => $a['contact_number'],
                                        'date'        => date('M j, Y g:i A', $ts),
                                        'status'      => $a['status'],
                                        'cover_note'  => $a['cover_note'],
                                        'resume_name' => $a['resume_original_name'],
                                    ];
                                    $json = ja_e(json_encode($payload, JSON_UNESCAPED_UNICODE));
                                ?>
                                    <tr>
                                        <td>
                                            <div class="applicant-name">
                                                <div class="applicant-avatar"><?= ja_e(ja_initials($a['full_name'])) ?></div>
                                                <div class="applicant-info">
                                                    <div class="name"><?= ja_e($a['full_name']) ?></div>
                                                    <div class="email"><?= ja_e($a['email']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= ja_e($a['position_title']) ?></td>
                                        <td><?= ja_e($a['contact_number']) ?></td>
                                        <td data-order="<?= (int)$ts ?>"><?= ja_e(date('M j, Y', $ts)) ?></td>
                                        <td><a href="download_resume.php?id=<?= (int)$a['id'] ?>" target="_blank" rel="noopener" class="btn btn-resume"><i class="bi bi-file-earmark-text me-1"></i>View</a></td>
                                        <td><span class="status-pill status-<?= ja_e(ja_slug($a['status'])) ?>"><?= ja_e($a['status']) ?></span></td>
                                        <td>
                                            <button type="button" class="btn btn-view-app" data-bs-toggle="modal" data-bs-target="#viewApplicantModal" data-app="<?= $json ?>">View Details</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <!-- View Applicant Modal  -->
    <div class="modal fade" id="viewApplicantModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-vcard me-2"></i>Applicant Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="appStatusForm" method="POST" action="jobapplications.php">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="app_id" id="vAppId" value="0">
                    </form>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-label">Full Name</div>
                            <div class="detail-value" id="vName">—</div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Position Applied For</div>
                            <div class="detail-value" id="vPosition">—</div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Email Address</div>
                            <div class="detail-value" id="vEmail">—</div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Contact Number</div>
                            <div class="detail-value" id="vContact">—</div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-label">Date Applied</div>
                            <div class="detail-value" id="vDate">—</div>
                        </div>
                        <div class="col-md-6">
                            <label class="detail-label" for="applicantStatusSelect">Application Stage</label>
                            <select class="form-select form-select-sm" id="applicantStatusSelect" name="status" form="appStatusForm" style="background-color:#0A192F; border: 1px solid var(--border); color: var(--text-main);">
                                <?php foreach ($stages as $st): ?>
                                    <option value="<?= ja_e($st) ?>"><?= ja_e($st) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <div class="detail-label">Cover Letter / Notes</div>
                            <div class="detail-value" id="vNote" style="white-space: pre-line;">—</div>
                        </div>
                        <div class="col-12">
                            <div class="detail-label">Resume</div>
                            <div class="detail-value">
                                <a href="#" id="vResume" target="_blank" rel="noopener" class="btn btn-resume"><i class="bi bi-file-earmark-arrow-down me-1"></i>Download Resume</a>
                                <span id="vResumeName" style="margin-left:8px; font-size:0.8rem; color: var(--text-muted);"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-reject-outline" id="btnRejectApp"><i class="bi bi-x-lg me-1"></i>Reject Applicant</button>
                    <button type="submit" form="appStatusForm" class="btn btn-approve"><i class="bi bi-check-lg me-1"></i>Update Stage</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function() {
            const modal = document.getElementById('viewApplicantModal');
            const select = document.getElementById('applicantStatusSelect');
            const form = document.getElementById('appStatusForm');

            // textContent only, so nothing an applicant typed can inject HTML
            modal.addEventListener('show.bs.modal', function(ev) {
                let app = null;
                try {
                    app = JSON.parse(ev.relatedTarget.dataset.app);
                } catch (e) {}
                if (!app) return;
                const set = (id, v, fb) => document.getElementById(id).textContent = (v && String(v).trim()) ? v : fb;
                document.getElementById('vAppId').value = app.id;
                set('vName', app.full_name, '—');
                set('vPosition', app.position, '—');
                set('vEmail', app.email, '—');
                set('vContact', app.contact, '—');
                set('vDate', app.date, '—');
                set('vNote', app.cover_note, 'No message provided.');
                set('vResumeName', app.resume_name, '');
                document.getElementById('vResume').href = 'download_resume.php?id=' + app.id + '&dl=1';
                select.value = app.status;
            });

            document.getElementById('btnRejectApp').addEventListener('click', function() {
                select.value = 'Rejected';
                form.submit();
            });
        })();
    </script>

</body>

</html>