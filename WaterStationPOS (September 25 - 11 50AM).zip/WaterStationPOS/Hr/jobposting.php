<?php
// Buffer so we can redirect after saving (header.php may already have started the HTML)
ob_start();
include 'header.php';
require_once __DIR__ . '/../dbConn.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$departments = ['Human Resources', 'Operations', 'Logistics', 'Finance', 'IT'];
$emp_types   = ['Full-time', 'Part-time', 'Contract', 'Internship'];
$statuses    = ['Draft', 'Open', 'Closed'];

function jp_e($v)
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function jp_salary($min, $max)
{
    $f = fn($n) => '₱' . number_format((float)$n);
    if ($min !== null && $max !== null) return $f($min) . ' - ' . $f($max);
    if ($min !== null) return 'From ' . $f($min);
    if ($max !== null) return 'Up to ' . $f($max);
    return 'Salary not specified';
}

function jp_num_or_null($v)
{
    $v = trim((string)$v);
    return ($v === '' || !is_numeric($v)) ? null : (float)$v;
}

// ---------- Save (add / edit) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_job') {
    $id              = (int)($_POST['job_id'] ?? 0);
    $title           = trim($_POST['title'] ?? '');
    $department      = $_POST['department'] ?? '';
    $employment_type = $_POST['employment_type'] ?? '';
    $location        = trim($_POST['location'] ?? '');
    $openings        = max(1, (int)($_POST['openings'] ?? 1));
    $salary_min      = jp_num_or_null($_POST['salary_min'] ?? '');
    $salary_max      = jp_num_or_null($_POST['salary_max'] ?? '');
    $deadline        = trim($_POST['deadline'] ?? '');
    $deadline        = ($deadline !== '' && strtotime($deadline)) ? date('Y-m-d', strtotime($deadline)) : null;
    $overview        = trim($_POST['overview'] ?? '');
    $responsibilities = trim($_POST['responsibilities'] ?? '');
    $qualifications  = trim($_POST['qualifications'] ?? '');
    $status          = in_array($_POST['status'] ?? '', $statuses, true) ? $_POST['status'] : 'Draft';

    $error = '';
    if ($title === '') {
        $error = 'Job title is required.';
    } elseif (!in_array($department, $departments, true)) {
        $error = 'Please select a department.';
    } elseif (!in_array($employment_type, $emp_types, true)) {
        $error = 'Please select an employment type.';
    } elseif ($salary_min !== null && $salary_max !== null && $salary_min > $salary_max) {
        $error = 'Minimum salary cannot be higher than maximum salary.';
    }

    if ($error === '') {
        try {
            if ($id > 0) {
                $sql = "UPDATE job_postings SET title=?, department=?, employment_type=?, location=?, openings=?, salary_min=?, salary_max=?, deadline=?, overview=?, responsibilities=?, qualifications=?, status=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssiddsssssi", $title, $department, $employment_type, $location, $openings, $salary_min, $salary_max, $deadline, $overview, $responsibilities, $qualifications, $status, $id);
                $stmt->execute();
                $_SESSION['job_flash'] = ['success', 'Job posting updated.'];
            } else {
                $created_by = isset($_SESSION['users']->id) ? (int)$_SESSION['users']->id : null;
                $sql = "INSERT INTO job_postings (title, department, employment_type, location, openings, salary_min, salary_max, deadline, overview, responsibilities, qualifications, status, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssiddsssssi", $title, $department, $employment_type, $location, $openings, $salary_min, $salary_max, $deadline, $overview, $responsibilities, $qualifications, $status, $created_by);
                $stmt->execute();
                $_SESSION['job_flash'] = ['success', 'Job posting added.'];
            }
        } catch (Throwable $e) {
            error_log('jobposting save: ' . $e->getMessage());
            $_SESSION['job_flash'] = ['danger', 'Could not save the job posting. Make sure the job_postings table exists.'];
        }
    } else {
        $_SESSION['job_flash'] = ['danger', $error];
    }

    header('Location: jobposting.php');
    exit;
}

$flash = $_SESSION['job_flash'] ?? null;
unset($_SESSION['job_flash']);

// ---------- Load postings ----------
$jobs = [];
$load_error = false;
try {
    $res = $conn->query("SELECT * FROM job_postings ORDER BY id DESC");
    $jobs = $res->fetch_all(MYSQLI_ASSOC);
} catch (Throwable $e) {
    error_log('jobposting load: ' . $e->getMessage());
    $load_error = true;
}
?>

<head>
    <title>Job Postings - HR Dashboard</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        :root {
            --bg: #0A192F;
            --card-bg: #112240;
            --card-bg-hover: #16294a;
            --border: rgba(100, 255, 218, 0.12);
            --text-main: #CCD6F6;
            --text-muted: #8892B0;
            --accent-green: #00E676;
            --accent-green-dark: #00A859;
            --accent-cyan: #64FFDA;
            --accent-amber: #FFC107;
            --accent-red: #FF5252;
        }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
        }

        .top-text h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0;
        }

        .top-text p {
            color: var(--text-muted);
            margin: 4px 0 0;
            font-size: 0.9rem;
        }

        .btn-add-job {
            background: linear-gradient(135deg, var(--accent-green) 0%, var(--accent-green-dark) 100%);
            border: none;
            color: #06210F;
            font-weight: 700;
            padding: 10px 20px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }

        .btn-add-job:hover {
            filter: brightness(1.08);
            color: #06210F;
            transform: translateY(-1px);
        }

        /* Filters  */
        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .filter-bar .form-select,
        .filter-bar .form-control {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .filter-bar .form-select:focus,
        .filter-bar .form-control:focus {
            background-color: var(--card-bg);
            border-color: var(--accent-cyan);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.15);
        }

        .filter-bar .form-control::placeholder {
            color: var(--text-muted);
        }

        .search-box-wrap {
            position: relative;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
            pointer-events: none;
        }

        .search-box-wrap input {
            padding-left: 34px;
            min-width: 220px;
        }

        /* Job Card  */
        .job-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            height: 100%;
            display: flex;
            flex-direction: column;
            transition: 0.2s ease;
        }

        .job-card:hover {
            background-color: var(--card-bg-hover);
            border-color: rgba(100, 255, 218, 0.35);
            transform: translateY(-2px);
        }

        .job-card-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 10px;
        }

        .job-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0 0 2px;
        }

        .job-dept {
            font-size: 0.8rem;
            color: var(--accent-cyan);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .status-pill {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 999px;
            white-space: nowrap;
        }

        .status-open {
            background-color: rgba(0, 230, 118, 0.12);
            color: var(--accent-green);
            border: 1px solid rgba(0, 230, 118, 0.35);
        }

        .status-draft {
            background-color: rgba(255, 193, 7, 0.12);
            color: var(--accent-amber);
            border: 1px solid rgba(255, 193, 7, 0.35);
        }

        .status-closed {
            background-color: rgba(255, 82, 82, 0.12);
            color: var(--accent-red);
            border: 1px solid rgba(255, 82, 82, 0.35);
        }

        .job-meta {
            display: flex;
            flex-direction: column;
            gap: 6px;
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .job-meta span i {
            width: 16px;
            color: var(--accent-cyan);
            margin-right: 6px;
        }

        .job-desc-preview {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 16px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
            flex-grow: 1;
        }

        .job-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid var(--border);
            padding-top: 12px;
            margin-top: auto;
        }

        .applicants-count {
            font-size: 0.8rem;
            color: var(--text-muted);
        }

        .applicants-count strong {
            color: var(--text-main);
        }

        .job-card-actions .btn {
            font-size: 0.78rem;
            padding: 5px 12px;
            border-radius: 8px;
        }

        .btn-view {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .btn-view:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
        }

        .btn-edit {
            background: transparent;
            border: 1px solid rgba(255, 193, 7, 0.4);
            color: var(--accent-amber);
        }

        .btn-edit:hover {
            background-color: rgba(255, 193, 7, 0.1);
            color: var(--accent-amber);
        }

        /* ===== Modal ===== */
        .modal-content {
            background-color: var(--card-bg);
            color: var(--text-main);
            border: 1px solid var(--border);
            border-radius: 16px;
        }

        .modal-header {
            border-bottom: 1px solid var(--border);
        }

        .modal-footer {
            border-top: 1px solid var(--border);
        }

        .modal-title {
            font-weight: 700;
            color: #FFFFFF;
        }

        .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }

        .form-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 6px;
        }

        .form-control,
        .form-select {
            background-color: #0A192F;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .form-control:focus,
        .form-select:focus {
            background-color: #0A192F;
            border-color: var(--accent-cyan);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.15);
        }

        .form-control::placeholder {
            color: #52618a;
        }

        .section-divider {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--accent-cyan);
            margin: 4px 0 12px;
            padding-top: 8px;
            border-top: 1px solid var(--border);
        }

        .section-divider:first-child {
            border-top: none;
            padding-top: 0;
        }

        .btn-cancel {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .btn-cancel:hover {
            color: var(--text-main);
            border-color: var(--accent-red);
        }

        .btn-save {
            background: linear-gradient(135deg, var(--accent-green) 0%, var(--accent-green-dark) 100%);
            border: none;
            color: #06210F;
            font-weight: 700;
        }

        .btn-save:hover {
            filter: brightness(1.08);
            color: #06210F;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 2.5rem;
            color: var(--accent-cyan);
            margin-bottom: 12px;
            display: block;
        }

        .job-desc-preview {
            -webkit-line-clamp: 3;
            line-clamp: 3;
        }

        .job-detail-block {
            white-space: pre-line;
            color: var(--text-main);
            font-size: 0.9rem;
        }

        .job-detail-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--accent-cyan);
            margin: 16px 0 6px;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <h1><i class="bi bi-briefcase-fill me-2"></i>Job Postings</h1>
                    <p>Create and manage open positions for the company</p>
                </div>
                <button type="button" class="btn btn-add-job" data-bs-toggle="modal" data-bs-target="#addJobModal">
                    <i class="bi bi-plus-lg"></i> Add Job Posting
                </button>
            </header>

            <?php if ($flash): ?>
                <script>
                    (function() {
                        const flash = <?= json_encode($flash, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
                        const ok = flash[0] === 'success';

                        function showFlash() {
                            Swal.fire({
                                icon: ok ? 'success' : 'error',
                                title: ok ? 'Success!' : 'Oops...',
                                text: flash[1],
                                background: '#112240',
                                color: '#CCD6F6',
                                confirmButtonColor: '#00E676',
                                confirmButtonText: 'Okay',
                                timer: ok ? 2000 : undefined,
                                timerProgressBar: ok
                            });
                        }
                        if (typeof Swal !== 'undefined') {
                            showFlash();
                        } else {
                            const s = document.createElement('script');
                            s.src = '../js/sweetalert2@11.js';
                            s.onload = showFlash;
                            document.head.appendChild(s);
                        }
                    })();
                </script>
            <?php endif; ?>

            <?php if ($load_error): ?>
                <div class="alert alert-warning">Could not load job postings. Create the <code>job_postings</code> table first.</div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="filter-bar mb-4">
                <div class="search-box-wrap">
                    <i class="bi bi-search"></i>
                    <input type="text" id="jobSearch" class="form-control" placeholder="Search job title...">
                </div>
                <select id="deptFilter" class="form-select" style="max-width: 180px;">
                    <option value="" selected>All Departments</option>
                    <?php foreach ($departments as $d): ?>
                        <option value="<?= jp_e($d) ?>"><?= jp_e($d) ?></option>
                    <?php endforeach; ?>
                </select>
                <select id="statusFilter" class="form-select" style="max-width: 160px;">
                    <option value="" selected>All Status</option>
                    <?php foreach ($statuses as $s): ?>
                        <option value="<?= jp_e($s) ?>"><?= jp_e($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Job Cards Grid -->
            <div class="row g-4" id="jobGrid">
                <?php foreach ($jobs as $job):
                    $smin = $job['salary_min'] !== null ? (float)$job['salary_min'] : null;
                    $smax = $job['salary_max'] !== null ? (float)$job['salary_max'] : null;
                    $payload = [
                        'id'               => (int)$job['id'],
                        'title'            => $job['title'],
                        'department'       => $job['department'],
                        'employment_type'  => $job['employment_type'],
                        'location'         => $job['location'],
                        'openings'         => (int)$job['openings'],
                        'salary_min'       => $smin,
                        'salary_max'       => $smax,
                        'salary_text'      => jp_salary($smin, $smax),
                        'deadline'         => $job['deadline'],
                        'deadline_text'    => $job['deadline'] ? date('M d, Y', strtotime($job['deadline'])) : 'No deadline',
                        'overview'         => $job['overview'],
                        'responsibilities' => $job['responsibilities'],
                        'qualifications'   => $job['qualifications'],
                        'status'           => $job['status'],
                        'applicants'       => (int)$job['applicants'],
                    ];
                    $json = jp_e(json_encode($payload, JSON_UNESCAPED_UNICODE));
                ?>
                    <div class="col-md-6 col-lg-4 job-col"
                        data-title="<?= jp_e(strtolower($job['title'])) ?>"
                        data-dept="<?= jp_e($job['department']) ?>"
                        data-status="<?= jp_e($job['status']) ?>">
                        <div class="job-card">
                            <div class="job-card-top">
                                <div>
                                    <div class="job-dept"><?= jp_e($job['department']) ?></div>
                                    <h3 class="job-title"><?= jp_e($job['title']) ?></h3>
                                </div>
                                <span class="status-pill status-<?= jp_e(strtolower($job['status'])) ?>"><?= jp_e($job['status']) ?></span>
                            </div>
                            <div class="job-meta">
                                <span><i class="bi bi-geo-alt"></i><?= jp_e(!empty($job['location']) ? $job['location'] : 'Location not specified') ?></span>
                                <span><i class="bi bi-clock"></i><?= jp_e($job['employment_type']) ?></span>
                                <span><i class="bi bi-cash-stack"></i><?= jp_e(jp_salary($smin, $smax)) ?></span>
                            </div>
                            <p class="job-desc-preview"><?= jp_e($job['overview']) ?></p>
                            <div class="job-card-footer">
                                <div class="applicants-count"><strong><?= (int)$job['applicants'] ?></strong> applicants</div>
                                <div class="job-card-actions d-flex gap-2">
                                    <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal" data-job="<?= $json ?>">View</button>
                                    <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal" data-job="<?= $json ?>">Edit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="noResults" class="empty-state" style="<?= $jobs ? 'display:none;' : '' ?>">
                <i class="bi bi-briefcase"></i>
                <span id="noResultsText"><?= $jobs ? 'No job postings match your filters.' : 'No job postings yet. Click "Add Job Posting" to create one.' ?></span>
            </div>

        </section>
    </main>

    <!-- Add / Edit Job Modal -->
    <div class="modal fade" id="addJobModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-briefcase-fill me-2"></i><span id="jobModalTitle">Add Job Posting</span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="jobPostingForm" method="POST" action="jobposting.php">
                        <input type="hidden" name="action" value="save_job">
                        <input type="hidden" name="job_id" value="0">

                        <div class="section-divider">Job Details</div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-8">
                                <label class="form-label">Job Title</label>
                                <input type="text" name="title" class="form-control" placeholder="e.g. HR Assistant" maxlength="150" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Department</label>
                                <select name="department" class="form-select" required>
                                    <option value="" selected disabled>Select department</option>
                                    <?php foreach ($departments as $d): ?>
                                        <option value="<?= jp_e($d) ?>"><?= jp_e($d) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Employment Type</label>
                                <select name="employment_type" class="form-select" required>
                                    <option value="" selected disabled>Select type</option>
                                    <?php foreach ($emp_types as $t): ?>
                                        <option value="<?= jp_e($t) ?>"><?= jp_e($t) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Location</label>
                                <input type="text" name="location" class="form-control" placeholder="e.g. Head Office" maxlength="150">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">No. of Openings</label>
                                <input type="number" name="openings" class="form-control" min="1" value="1" placeholder="1">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Salary Range (Min)</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color:#0A192F; border-color: var(--border); color: var(--text-muted);">₱</span>
                                    <input type="number" name="salary_min" class="form-control" min="0" step="0.01" placeholder="15000">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Salary Range (Max)</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color:#0A192F; border-color: var(--border); color: var(--text-muted);">₱</span>
                                    <input type="number" name="salary_max" class="form-control" min="0" step="0.01" placeholder="20000">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Application Deadline</label>
                                <input type="date" name="deadline" class="form-control">
                            </div>
                        </div>

                        <div class="section-divider">Job Description</div>
                        <div class="mb-3">
                            <label class="form-label">Overview</label>
                            <textarea name="overview" class="form-control" rows="3" placeholder="Briefly describe the role and its purpose..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Key Responsibilities</label>
                            <textarea name="responsibilities" class="form-control" rows="4" placeholder="List the main duties and responsibilities..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Qualifications &amp; Requirements</label>
                            <textarea name="qualifications" class="form-control" rows="4" placeholder="List required education, skills, and experience..."></textarea>
                        </div>

                        <div class="section-divider">Posting Settings</div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Status</label>
                                <select name="status" class="form-select">
                                    <?php foreach ($statuses as $s): ?>
                                        <option value="<?= jp_e($s) ?>"><?= jp_e($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" form="jobPostingForm" class="btn btn-save"><i class="bi bi-check-lg me-1"></i>Save Job Posting</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Job Modal -->
    <div class="modal fade" id="viewJobModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-eye-fill me-2"></i>Job Posting Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex justify-content-between align-items-start gap-3 mb-2">
                        <div>
                            <div class="job-dept" id="vDept"></div>
                            <h3 class="job-title" id="vTitle"></h3>
                        </div>
                        <span class="status-pill" id="vStatus"></span>
                    </div>
                    <div class="job-meta">
                        <span><i class="bi bi-geo-alt"></i><span id="vLocation"></span></span>
                        <span><i class="bi bi-clock"></i><span id="vType"></span></span>
                        <span><i class="bi bi-cash-stack"></i><span id="vSalary"></span></span>
                        <span><i class="bi bi-people"></i><span id="vOpenings"></span></span>
                        <span><i class="bi bi-calendar-event"></i>Deadline: <span id="vDeadline"></span></span>
                    </div>
                    <div class="job-detail-label">Overview</div>
                    <div class="job-detail-block" id="vOverview"></div>
                    <div class="job-detail-label">Key Responsibilities</div>
                    <div class="job-detail-block" id="vResp"></div>
                    <div class="job-detail-label">Qualifications &amp; Requirements</div>
                    <div class="job-detail-block" id="vQual"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function() {
            const addModal = document.getElementById('addJobModal');
            const viewModal = document.getElementById('viewJobModal');
            const form = document.getElementById('jobPostingForm');

            function readJob(btn) {
                try {
                    return btn && btn.dataset.job ? JSON.parse(btn.dataset.job) : null;
                } catch (e) {
                    return null;
                }
            }

            // Add vs Edit: same modal, filled when opened from an Edit button
            addModal.addEventListener('show.bs.modal', function(ev) {
                const job = readJob(ev.relatedTarget);
                form.reset();
                form.elements['job_id'].value = job ? job.id : 0;
                document.getElementById('jobModalTitle').textContent = job ? 'Edit Job Posting' : 'Add Job Posting';
                if (!job) return;
                form.elements['title'].value = job.title || '';
                form.elements['department'].value = job.department || '';
                form.elements['employment_type'].value = job.employment_type || '';
                form.elements['location'].value = job.location || '';
                form.elements['openings'].value = job.openings || 1;
                form.elements['salary_min'].value = job.salary_min ?? '';
                form.elements['salary_max'].value = job.salary_max ?? '';
                form.elements['deadline'].value = job.deadline || '';
                form.elements['overview'].value = job.overview || '';
                form.elements['responsibilities'].value = job.responsibilities || '';
                form.elements['qualifications'].value = job.qualifications || '';
                form.elements['status'].value = job.status || 'Draft';
            });

            // View modal (textContent only, so nothing typed into a posting can inject HTML)
            viewModal.addEventListener('show.bs.modal', function(ev) {
                const job = readJob(ev.relatedTarget);
                if (!job) return;
                const set = (id, v, fallback) => document.getElementById(id).textContent = (v && String(v).trim()) ? v : fallback;
                set('vDept', job.department, '');
                set('vTitle', job.title, '');
                set('vLocation', job.location, 'Location not specified');
                set('vType', job.employment_type, '');
                set('vSalary', job.salary_text, '');
                set('vOpenings', job.openings + (job.openings == 1 ? ' opening' : ' openings') + ' · ' + job.applicants + ' applicants', '');
                set('vDeadline', job.deadline_text, '');
                set('vOverview', job.overview, 'Not provided');
                set('vResp', job.responsibilities, 'Not provided');
                set('vQual', job.qualifications, 'Not provided');
                const pill = document.getElementById('vStatus');
                pill.textContent = job.status;
                pill.className = 'status-pill status-' + String(job.status).toLowerCase();
            });

            // Filters
            const search = document.getElementById('jobSearch');
            const dept = document.getElementById('deptFilter');
            const status = document.getElementById('statusFilter');
            const cols = document.querySelectorAll('.job-col');
            const empty = document.getElementById('noResults');
            const emptyText = document.getElementById('noResultsText');

            function applyFilters() {
                const q = search.value.trim().toLowerCase();
                let shown = 0;
                cols.forEach(function(c) {
                    const ok = (!q || c.dataset.title.includes(q)) &&
                        (!dept.value || c.dataset.dept === dept.value) &&
                        (!status.value || c.dataset.status === status.value);
                    c.style.display = ok ? '' : 'none';
                    if (ok) shown++;
                });
                if (cols.length) {
                    empty.style.display = shown ? 'none' : '';
                    emptyText.textContent = 'No job postings match your filters.';
                }
            }
            search.addEventListener('input', applyFilters);
            dept.addEventListener('change', applyFilters);
            status.addEventListener('change', applyFilters);
        })();
    </script>

</body>

</html>