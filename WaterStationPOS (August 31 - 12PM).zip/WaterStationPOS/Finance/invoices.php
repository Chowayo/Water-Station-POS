<?php

include "header.php";

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    #invoice_match_list thead th,
    #invoice_match_list.dataTable thead th {
        text-align: center !important;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-hold {
        background-color: rgba(255, 145, 0, 0.1);
        color: #ff9100;
        border: 1px solid #ff9100;
    }

    .status-paid {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
    }

    .status-closed {
        background-color: rgba(136, 146, 176, 0.12);
        color: #8892B0;
        border: 1px solid #8892B0;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* 3-way match comparison */
    .match-column-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
        height: 100%;
    }

    .match-column-label {
        font-size: 11px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .match-column-card .req-detail-item {
        padding: 6px 0;
        font-size: 0.9rem;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Invoice &amp; 3-Way Match</h1>
                    <h6>Match supplier invoices against the Purchase Order and Goods Receipt before releasing payment</h6>
                </div>
            </header>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Match</div>
                        <div class="dash-value" style="color:#ffc107;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Matched This Month</div>
                        <div class="dash-value" style="color:#00e676;">5</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Mismatched</div>
                        <div class="dash-value" style="color:#ff9100;">1</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Invoice Value</div>
                        <div class="dash-value">₱2,900.00</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Supplier Invoices</div>
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Awaiting 3-Way Match</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="invoiceStatusFilter" style="width: 190px;">
                                    <option value="">All Status</option>
                                    <option value="Pending Match">Pending Match</option>
                                    <option value="Matched">Matched</option>
                                    <option value="Paid">Paid</option>
                                    <option value="Closed">Closed</option>
                                    <option value="Returned to Supplier">Returned to Supplier</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Invoice" id="invoiceSearcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var invoiceTable = $('#invoice_match_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#invoiceSearcher').on('keyup change clear', function() {
                                    invoiceTable.search(this.value).draw();
                                });

                                $('#invoiceStatusFilter').on('change', function() {
                                    invoiceTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="invoice_match_list">
                            <thead>
                                <tr>
                                    <th>Invoice No.</th>
                                    <th>PO Number</th>
                                    <th>Request ID</th>
                                    <th>Supplier</th>
                                    <th>Category</th>
                                    <th>Invoice Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->
                                <tr>
                                    <td>INV-1007</td>
                                    <td>PO-1007</td>
                                    <td>REQ-0007</td>
                                    <td>HydroChem Philippines</td>
                                    <td><span class="category-chip">Chemicals</span></td>
                                    <td>₱2,900.00</td>
                                    <td><span class="status-badge status-pending">Pending Match</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-match"
                                            data-invoice="INV-1007"
                                            data-po="PO-1007"
                                            data-req="REQ-0007"
                                            data-supplier="HydroChem Philippines"
                                            data-category="Chemicals"
                                            data-po-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'
                                            data-grn-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'
                                            data-inv-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'>
                                            <i class="bi bi-search me-1"></i>Review Match
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>INV-1002</td>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td>BlueCap Packaging Solutions</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Matched</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-process-payment"
                                            data-invoice="INV-1002"
                                            data-supplier="BlueCap Packaging Solutions"
                                            data-amount="₱1,200.00">
                                            <i class="bi bi-cash-coin me-1"></i>Process Payment
                                        </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>INV-0995</td>
                                    <td>PO-0995</td>
                                    <td>REQ-0004</td>
                                    <td>AquaTech Solutions</td>
                                    <td><span class="category-chip">Equipment</span></td>
                                    <td>₱8,400.00</td>
                                    <td><span class="status-badge status-paid">Paid</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-close-done">
                                            <i class="bi bi-check-lg me-1"></i>Done
                                        </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>INV-0989</td>
                                    <td>PO-0989</td>
                                    <td>REQ-0009</td>
                                    <td>HydroChem Philippines</td>
                                    <td><span class="category-chip">Filters</span></td>
                                    <td>₱15,750.00</td>
                                    <td><span class="status-badge status-rejected">Returned to Supplier</span></td>
                                    <td>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-x-circle me-1"></i>Returned
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>INV-0975</td>
                                    <td>PO-0975</td>
                                    <td>REQ-0005</td>
                                    <td>BlueCap Packaging Solutions</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>₱3,480.00</td>
                                    <td><span class="status-badge status-closed">Closed</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-check-circle me-1"></i>Closed
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 3-Way Match Review Modal -->
            <div class="modal fade" id="reviewMatchModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">3-Way Match — <span id="matchInvoiceNo">INV-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <div>
                                    <span class="fw-semibold d-block" id="matchSupplier">Supplier</span>
                                    <span class="category-chip" id="matchCategory">Category</span>
                                </div>
                                <div class="text-end">
                                    <div class="small" style="color:#8892B0;">PO Reference</div>
                                    <span id="matchPoNumber">—</span>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="matchReqId">—</span>
                            </div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-file-earmark-text"></i>Purchase Order</div>
                                        <div id="matchPoItems"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-box-seam"></i>Goods Receipt</div>
                                        <div id="matchGrnItems"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-receipt"></i>Supplier Invoice</div>
                                        <div id="matchInvItems"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Finance Notes</label>
                                <textarea class="form-control" id="matchFinanceNotes" rows="2" placeholder="Required if holding or returning this invoice"></textarea>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4" id="btnMatchReturn">
                                    <i class="bi bi-x-lg me-1"></i>Return to Supplier
                                </button>
                                <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnMatchApprove">
                                    <i class="bi bi-check-lg me-1"></i>Approve for Payment
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Process Payment Modal -->
            <div class="modal fade" id="processPaymentModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Process Payment — <span id="paymentInvoiceNo">INV-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="req-total-box mb-3">
                                <div class="req-detail-item">
                                    <span>Supplier</span>
                                    <span class="fw-semibold" id="paymentSupplier">—</span>
                                </div>
                                <div class="req-detail-item">
                                    <span>Invoice Amount</span>
                                    <span class="fw-semibold" id="paymentAmount">—</span>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Payment Method</label>
                                <select class="form-select" id="paymentMethod">
                                    <option value="Cash">Cash</option>
                                    <option value="GCash">GCash</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Reference No.</label>
                                <input type="text" class="form-control" id="paymentReference" placeholder="Bank ref, cheque no., or GCash ref no.">
                            </div>

                            <div class="mb-1">
                                <label class="form-label">Notes (optional)</label>
                                <textarea class="form-control" id="paymentNotes" rows="2" placeholder="Additional notes for this payment"></textarea>
                            </div>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnConfirmPayment">
                                <i class="bi bi-check-lg me-1"></i>Confirm Payment
                            </button>
                        </div>

                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            function renderMatchColumn(elId, items) {
                var $col = $(elId).empty();
                items.forEach(function(item) {
                    $col.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + ' x' + item.qty + '</span>' +
                        '<span>' + formatPeso(item.price) + '</span>' +
                        '</div>'
                    );
                });
            }

            var $activeMatchRow = null;

            $(document).on('click', '.btn-review-match', function() {
                $activeMatchRow = $(this).closest('tr');
                var $btn = $(this);

                var poItems = $btn.data('po-items') || [];
                var grnItems = $btn.data('grn-items') || [];
                var invItems = $btn.data('inv-items') || [];

                $('#matchInvoiceNo').text($btn.data('invoice'));
                $('#matchSupplier').text($btn.data('supplier'));
                $('#matchCategory').text($btn.data('category'));
                $('#matchPoNumber').text($btn.data('po'));
                $('#matchReqId').text($btn.data('req'));
                $('#matchFinanceNotes').val('');

                renderMatchColumn('#matchPoItems', poItems);
                renderMatchColumn('#matchGrnItems', grnItems);
                renderMatchColumn('#matchInvItems', invItems);

                $('#reviewMatchModal').modal('show');
            });

            function setInvoiceStatus(label, statusClass, icon, buttonClass) {
                if (!$activeMatchRow) return;

                $activeMatchRow.find('td').eq(6)
                    .html('<span class="status-badge ' + statusClass + '">' + label + '</span>');

                $activeMatchRow.find('.btn-review-match')
                    .removeClass('btn-review-match btn-confirm')
                    .addClass(buttonClass)
                    .prop('disabled', true)
                    .html('<i class="bi ' + icon + ' me-1"></i>' + label);
            }

            $('#btnMatchApprove').click(function() {
                if (!$activeMatchRow) return;

                var invoiceNo = $('#matchInvoiceNo').text();
                var supplier = $('#matchSupplier').text();
                var amount = $activeMatchRow.find('td').eq(5).text();

                $activeMatchRow.find('td').eq(6)
                    .html('<span class="status-badge status-approved">Matched</span>');

                $activeMatchRow.find('.btn-review-match')
                    .removeClass('btn-review-match btn-confirm')
                    .addClass('btn-confirm btn-process-payment')
                    .attr('data-invoice', invoiceNo)
                    .attr('data-supplier', supplier)
                    .attr('data-amount', amount)
                    .html('<i class="bi bi-cash-coin me-1"></i>Process Payment');

                $('#reviewMatchModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Invoice Matched',
                    text: invoiceNo + ' passed the 3-way match and is cleared for payment.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            // ---- Payment ----
            var $activePaymentRow = null;

            $(document).on('click', '.btn-process-payment', function() {
                $activePaymentRow = $(this).closest('tr');
                var $btn = $(this);

                $('#paymentInvoiceNo').text($btn.data('invoice'));
                $('#paymentSupplier').text($btn.data('supplier'));
                $('#paymentAmount').text($btn.data('amount'));
                $('#paymentMethod').val('Cash');
                $('#paymentReference').val('');
                $('#paymentNotes').val('');

                $('#processPaymentModal').modal('show');
            });

            $('#btnConfirmPayment').click(function() {
                if (!$activePaymentRow) return;

                if (!$('#paymentReference').val().trim()) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Reference Required',
                        text: 'Please enter a payment reference number before confirming.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                var invoiceNo = $('#paymentInvoiceNo').text();
                var supplier = $('#paymentSupplier').text();

                $activePaymentRow.find('td').eq(6)
                    .html('<span class="status-badge status-paid">Paid</span>');

                $activePaymentRow.find('.btn-process-payment')
                    .removeClass('btn-process-payment')
                    .addClass('btn-confirm btn-close-done')
                    .html('<i class="bi bi-check-lg me-1"></i>Done');

                $('#processPaymentModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Payment Confirmed',
                    text: invoiceNo + ' has been paid via ' + $('#paymentMethod').val() + '. Payment advice sent to ' + supplier + '.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 2200,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $(document).on('click', '.btn-close-done', function() {
                $(this).closest('tr').find('td').eq(6)
                    .html('<span class="status-badge status-closed">Closed</span>');

                $(this)
                    .removeClass('btn-confirm btn-close-done')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-check-circle me-1"></i>Closed');
            });

            $('#btnMatchReturn').click(function() {
                if (!$('#matchFinanceNotes').val().trim()) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Note Required',
                        text: 'Please explain why this invoice is being returned to the supplier.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                setInvoiceStatus('Returned to Supplier', 'status-rejected', 'bi-x-circle', 'btn-remove');
                $('#reviewMatchModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Invoice Returned',
                    text: $('#matchInvoiceNo').text() + ' has been returned to the supplier for correction.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>