<?php

include "header.php";

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    #supplier_review_list thead th,
    #supplier_review_list.dataTable thead th {
        text-align: center !important;
    }

    #supplier_review_list thead th:before,
    #supplier_review_list thead th:after,
    #supplier_review_list thead th .dt-column-order {
        display: none !important;
        content: none !important;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-ordered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64ffda;
        border: 1px solid #64ffda;
    }

    .status-needs-revision {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    /* Budget check indicators */
    .budget-ok {
        color: #00e676;
        font-weight: 700;
    }

    .budget-over {
        color: #ff5252;
        font-weight: 700;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Budget usage bar */
    .budget-bar-wrap {
        background-color: #0A192F;
        border-radius: 8px;
        height: 8px;
        overflow: hidden;
        margin-top: 6px;
    }

    .budget-bar-fill {
        height: 100%;
        border-radius: 8px;
    }

    .budget-bar-fill.ok {
        background-color: #00e676;
    }

    .budget-bar-fill.warn {
        background-color: #ffc107;
    }

    .budget-bar-fill.over {
        background-color: #ff5252;
    }

    .cost-centre-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 12px;
        padding: 14px 16px;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Supplier Recommendation Review</h1>
                    <h6>Review payment terms and total cost, then approve or send back for revision</h6>
                </div>
            </header>


            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Awaiting Review</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Pending'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved This Month</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Supplier Approved'";
                            $query = $conn->query($sql);
                            $approved_month = $query->fetch_object();

                            if ($approved_month != "") {
                                echo $approved_month->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Rejected This Month</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Need Revision' ";
                            $query = $conn->query($sql);
                            $reject_month = $query->fetch_object();

                            if ($reject_month != "") {
                                echo $reject_month->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Value</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT SUM(cost) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Pending'";
                            $query = $conn->query($sql);
                            $pending_value = $query->fetch_object();

                            // Safely format the total, defaulting to 0 if total is NULL
                            $total = $pending_value->total ?? 0;

                            echo "₱" . number_format($total, 2);
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Budget Overview -->
            <div class="section-header">Budgets (This Month)</div>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Supplies</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Supplies'";
                                $query = $conn->query($sql);
                                $supplies_total = $query->fetch_object();

                                if ($supplies_total != "") {
                                    echo "₱" . $supplies_total->total . "/ ₱20,000";
                                    $supplies_percent = ($supplies_total->total / 20000) * 100;
                                } else {
                                    echo "₱0.00 / ₱20,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill ok" style="width: <?php echo $supplies_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Maintenance</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Maintenance'";
                                $query = $conn->query($sql);
                                $maintenance_total = $query->fetch_object();

                                if ($maintenance_total != "") {
                                    echo "₱" . $maintenance_total->total . "/ ₱10,000";
                                    $maintenance_percent = ($maintenance_total->total / 10000) * 100;
                                } else {
                                    echo "₱0.00 / ₱10,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill warn" style="width: <?php echo $maintenance_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Transportation/Fuel</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Transport/Fuel'";
                                $query = $conn->query($sql);
                                $transport_total = $query->fetch_object();

                                if ($transport_total != "") {
                                    echo "₱" . $transport_total->total . "/ ₱5,000";
                                    $transport_percent = ($transport_total->total / 5000) * 100;
                                } else {
                                    echo "₱0.00 / ₱5,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill over" style="width: <?php echo $transport_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Supplier Recommendations Pending Review</div>
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Awaiting Finance Sign-off</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="supplierStatusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending Review">Pending Review</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Needs Revision">Needs Revision</option>
                                </select>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var supplierTable = $('#supplier_review_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: false,
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#supplierStatusFilter').on('change', function() {
                                    supplierTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="supplier_review_list">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Recommended Supplier</th>
                                    <th>Category</th>
                                    <th>Recommended By</th>
                                    <th>Est. Total Cost</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM stock_request WHERE deleted = 'False' AND status != 'Pending' AND status != 'Approved' AND status != 'Rejected' AND status != 'Negotiation Approved' AND status != 'Cancelled Negotiation' AND status != 'Ordered' AND status != 'Supplier Approved' ORDER BY id DESC";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                            <tr>
                                                <td>REQ-' . $set->id . '</td>
                                                <td>' . $set->supplier_name . '</td>
                                                <td><span class="category-chip">' . ucfirst($set->category) . '</span></td>
                                                <td>' . $set->recommended_by . '</td>
                                                <td>₱' . $set->cost . '</td>';
                                    if ($set->status == "Supplier Pending") {
                                        echo '<td><span class="status-badge status-pending">' . $set->status . '</span></td>';
                                        echo '
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-supplier"
                                                        data-number="' . $set->id . '"
                                                        data-id="REQ-' . $set->id . '"
                                                        data-supplier="' . $set->supplier_name . '"
                                                        data-category="' . ucfirst($set->category) . '"
                                                        data-recommender="' . $set->recommended_by . '"
                                                        data-cost="' . $set->cost . '">
                                                        <i class="bi bi-clipboard-check me-1"></i>Review
                                                    </button>
                                                </td>';
                                    } else if ($set->status == "Supplier Approve") {
                                        echo '<td><span class="status-badge status-approved">ICON HERE ' . $set->status . '</span></td>';
                                        echo '<td><span class="status-badge status-approved">ICON HERE ' . $set->status . '</span></td>';
                                    }
                                    if ($set->status == "Need Revision") {
                                        echo '<td><span class="status-badge status-rejected">ICON HERE ' . $set->status . '</span></td>';
                                        echo '<td><span class="status-badge status-rejected">ICON HERE ' . $set->status . '</span></td>';
                                    }
                                    echo '
                                            </tr>

                                            <div class="modal fade" id="reviewSupplierNegotiationModal-' . $set->id . '" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content shadow-lg">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Review Supplier — <span id="reviewSupplierName">Supplier</span></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">
                                                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                                                <span class="fw-semibold" style="color:#8892B0;">Category</span>
                                                                <span id="reviewSupplierCategory" class="category-chip">' . ucfirst($set->category) . '</span>
                                                            </div>

                                                            <div class="req-detail-item">
                                                                <span>Recommended By</span>
                                                                <span id="reviewSupplierRecommender">' . $set->recommended_by . '</span>
                                                            </div>

                                                            <div class="req-detail-item">
                                                                <span>Supplier Name</span>
                                                                <span id="reviewSupplierRecommender">' . $set->supplier_name . '</span>
                                                            </div>

                                                            <div class="req-detail-item">
                                                                <span>Supplier Price Range</span>
                                                                <span id="reviewSupplierRecommender">' . $set->supplier_price . '</span>
                                                            </div>

                                                            
                                                            <div class="mb-3 mt-3">
                                                                <label class="form-label small">Procurement Recommendation Notes (Initial Notes)</label>
                                                                <textarea class="form-control" id="reviewSupplierProcNotes" rows="2" disabled>' . $set->note . '</textarea>
                                                            </div>

                                                            <form method="POST">

                                                                <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                                                    <span class="fw-semibold">Est. Total Cost of Ownership</span>
                                                                    <span class="fw-bold fs-5" id="reviewSupplierCost">₱' . $set->cost . '</span>
                                                                </div>

                                                                <div class="mb-3">
                                                                    <label class="form-label">Finance Approval/Revision Notes</label>
                                                                    <textarea class="form-control" id="reviewSupplierFinanceNotes" rows="2" name="review_note" placeholder="Required if requesting revision"></textarea>
                                                                </div>
                                                
                                                                <div class="modal-footer flex-wrap">
                                                                    <button type="submit" name="supplier_review" value="Need Revision" class="btn btn-remove rounded-pill px-4" id="btnSupplierNeedsRevision">
                                                                        <i class="bi bi-arrow-counterclockwise me-1"></i>Needs Revision
                                                                    </button>
                                                                    
                                                                    <input type="text" value="' . $set->id . '" name="id" hidden>';
                                    $approved = True;
                                    $sqls = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Supplies'";
                                    $querys = $conn->query($sqls);
                                    $supplies_total = $querys->fetch_object();
                                    if ($supplies_total != "") {
                                        if (($supplies_total->total + $set->cost) > 20000) {
                                            $approved = False;
                                        }
                                    } else {
                                        if ((0 + $set->cost) > 20000) {
                                            $approved = False;
                                        }
                                    }
                                    if ($approved) {
                                        echo '                   <button type="submit" name="supplier_review" value="Supplier Approved" class="btn btn-confirm rounded-pill px-4" id="btnSupplierApprove">
                                                                        <i class="bi bi-check-lg me-1"></i>Approve
                                                                    </button>';
                                    }
                                    echo '                   </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ';
                                }

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                    // Add Inventory Item
                                    if (isset($_POST['supplier_review'])) {
                                        $review_note = trim($_POST['review_note']);
                                        $id = trim($_POST['id']);
                                        if ($review_note == "") {
                                            $review_note = $_POST['review'] . " With no Note";
                                        }

                                        $sql = "UPDATE `stock_request` SET `status` = ?, `last_note` = ? WHERE id = '" . $id . "'";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("ss",  $_POST['supplier_review'], $review_note);

                                        if ($stmt->execute()) {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'success',
                                                                title: 'Supplier Request Updated!',
                                                                text: 'The new supplier request has been Updated.',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                confirmButtonColor: '#00E676',
                                                                heightAuto: false
                                                            }).then((result) => {
                                                                if(result.isConfirmed) {
                                                                    location.assign('supplier_approval.php');
                                                                }});
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    }
                                }


                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            $('.btn-review-supplier').click(function() {
                var $row = $(this).closest('tr');
                var $btn = $(this);

                //$('#reviewSupplierName').text($btn.data('supplier'));
                //$('#reviewSupplierCategory').text($btn.data('category'));
                //$('#reviewSupplierRecommender').text($btn.data('recommender'));
                //$('#reviewSupplierTerms').text($btn.data('terms'));
                //$('#reviewSupplierSla').text($btn.data('sla'));
                //$('#reviewSupplierProcNotes').val($btn.data('notes'));
                //$('#reviewSupplierCost').text(formatPeso(parseFloat($btn.data('cost'))));
                //$('#reviewSupplierFinanceNotes').val('');

                $('#reviewSupplierNegotiationModal').data('activeRow', $row);

                $('#reviewSupplierNegotiationModal-' + $(this).data('number')).modal('show');
            });

            function setSupplierReviewStatus(label, statusClass) {
                var $row = $('#reviewSupplierNegotiationModal').data('activeRow');
                if (!$row) return;

                $row.find('td').eq(6).html('<span class="status-badge ' + statusClass + '">' + label + '</span>');

                var $actionCell = $row.find('td').eq(7);
                if (label === 'Approved') {
                    $actionCell.html('<button class="btn btn-edit btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-check-circle me-1"></i>Approved</button>');
                } else {
                    $actionCell.html('<button class="btn btn-confirm btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back</button>');
                }
            }

            $('#btnSupplierApprove').click(function() {
                setSupplierReviewStatus('Approved', 'status-approved');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Supplier Approved',
                    text: 'Procurement can proceed to finalize the contract.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnSupplierNeedsRevision').click(function() {
                setSupplierReviewStatus('Needs Revision', 'status-needs-revision');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Sent Back for Revision',
                    text: 'Procurement will be notified to renegotiate terms.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>