<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
    
<head>
    <title>Transactions</title>


    <style>
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Transactions</h1>
                    <h6>Full record of income and expenses</h6>
                </div>
            </header>

            <!-- Summary Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Total_Income.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Income (This Month)</div>
                        <div class="dash-value green-text">
                            <?php
                            $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                            $query = $conn->query($sql);
                            $income = $query->fetch_object();

                            if ($income != "") {
                                echo "₱" . $income->total;
                            } else {
                                echo "₱0.00";
                            }
                            ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Total_expenses.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Expenses (This Month)</div>
                        <div class="dash-value" style="color: #FF5252;">
                            <?php
                            $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Payroll", "Invoice");
                            $expenses_total = 0;

                            //Gets total of expenses
                            foreach ($expenses_category as $category) {

                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                                $query = $conn->query($sql);
                                $expense = $query->fetch_object();

                                //Adds total to array
                                $expenses_total += $expense->total;
                            }

                            if ($expenses_total != "") {
                                echo "₱" . $expenses_total;
                            } else {
                                echo "₱0.00";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Net_Cash.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Net Cash Flow</div>
                        <div class="dash-value cyan-text">
                            <?php

                            if ($income->total == "") {
                                if ($expense->total != "") {
                                    echo "-₱" . $expense->total;
                                } else {
                                    echo "₱0.00";
                                }
                            } else if ($expense->total == "") {
                                if ($income != "") {
                                    echo "₱" . $income->total;
                                } else {
                                    echo "₱0.00";
                                }
                            } else {
                                echo "₱" . ($income->total - $expenses_total);
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Transaction Ledger -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-journal-text me-2"></i>Transaction Ledger</div>
                    <div class="manage-box shadow-sm">

                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <ul class="txn-filter-tabs" id="txnFilterTabs">
                                <li><button type="button" class="nav-link active" data-filter="all"><i class="bi bi-list-ul me-1"></i>All</button></li>
                                <li><button type="button" class="nav-link" data-filter="Income"><i class="bi bi-arrow-down-circle me-1"></i>Income</button></li>
                                <li><button type="button" class="nav-link" data-filter="Expense"><i class="bi bi-arrow-up-circle me-1"></i>Expense</button></li>
                            </ul>

                            <div class="d-flex flex-wrap gap-2">
                                <select id="category" class="form-select form-select-sm" style="width: auto;">
                                    <option value="all">All Categories</option>
                                    <option value="Sales">Sales</option>
                                    <option value="Payroll">Payroll</option>
                                    <option value="Utilities">Utilities</option>
                                    <option value="Marketing">Marketing</option>
                                    <option value="Supplies">Supplies</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search transaction" id="searcher">
                                </div>
                            </div>
                        </div>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="txn_list">
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Type</th>
                                    <th>Payment Method</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM transactions";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {

                                    if ($set->type == "Income") {
                                        echo '<tr data-type="Income">';
                                    } else {
                                        echo '<tr data-type="Expense">';
                                    }

                                    echo '
                                                <td class="cyan-text fw-bold">' . $set->id . '</td>
                                                <td>' . $set->date . '</td>
                                                <td>' . $set->time . '</td>
                                                <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">' . $set->description . '</td>
                                                <td data-category="' . $set->category . '">' . $set->category . '</td>
                                            ';

                                    //Type
                                    if ($set->type == "Income") {
                                        echo '<td><span class="txn-type-badge txn-type-income" data-filter="Income">Income</span></td>';
                                    } else {
                                        echo '<td><span class="txn-type-badge txn-type-expense" data-filter="Expense">Expense</span></td>';
                                    }

                                    //Payment method
                                    if ($set->payment_method == "Gcash") {
                                        echo '<td><span class="badge bg-warning"><i class="bi bi-credit-card me-1"></i>GCash</span></td>';
                                    } else if ($set->payment_method == "Cash") {
                                        echo '<td><span class="badge bg-success"><i class="bi bi-credit-card me-1"></i>Cash</span></td>';
                                    } else if ($set->payment_method == "Bank Transfer") {
                                        echo '<td><span class="badge bg-cod">Bank Transfer</span></td>';
                                    }

                                    if ($set->type == "Income") {
                                        echo '<td style="color: #2ad410;" class="green-text fw-bold">+₱' . $set->amount . '</td>';
                                    } else {
                                        echo '<td style="color: #FF5252;" class="fw-bold">-₱' . $set->amount . '</td>';
                                    }

                                    echo '
                                                </tr>
                                            ';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            var table = $('#txn_list').DataTable({
                paging: true,
                pageLength: 8,
                lengthChange: false,
                searching: true,
                ordering: false,
                dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
            });

            $('#searcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });

            var activeTypeFilter = 'all';
            var activeCategoryFilter = 'all';

            $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
                if (settings.nTable.id !== 'txn_list') return true;

                var row = table.row(dataIndex).node();

                if (activeTypeFilter !== 'all' && $(row).data('type') !== activeTypeFilter) {
                    return false;
                }

                if (activeCategoryFilter !== 'all') {
                    var matchCat = $(row).find('td[data-category]').filter(function() {
                        return $(this).data('category') === activeCategoryFilter;
                    }).length > 0;

                    if (!matchCat) return false;
                }

                return true;
            });

            $('#txnFilterTabs .nav-link').on('click', function() {
                $('#txnFilterTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                activeTypeFilter = $(this).data('filter');
                table.draw();
            });

            //Selection searcher
            $('#category').on('change', function() {
                activeCategoryFilter = $(this).val();
                table.draw();
            });

        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Finance Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>