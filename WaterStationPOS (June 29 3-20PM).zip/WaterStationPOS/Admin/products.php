<?php

include 'header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<link rel="stylesheet" href="styles.css">
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <aside class="left-menu d-flex flex-column py-4">

            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-3">
                <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;">ADMINISTRATOR</p>
            </div>

            <nav class="nav flex-column px-2">
                <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal">Profile</a>
                <?php
                include 'profile.php';
                ?>

                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="dashboard.php">Dashboard</a>
                <a class="menu-link" href="employees.php">Employees</a>
                <a class="menu-link active" href="products.php">Products</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">

            <section class="p-4 flex-grow-1">

                <header class="top-text mb-5 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Products Management</h6>
                    </div>
                </header>

                <div class="row">
                    <div class="col-12">
                        <div class="section-header">All Products</div>
                        <div class="manage-box shadow-sm">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="mb-0 pt-1">Product Directory</h5>
                                <button class="btn btn-add px-4 rounded-pill">+ Add New Product</button>
                            </div>
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>

                                    <tr>
                                        <th>Image</th>
                                        <th>Id</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //Loading employee list
                                    $sql = "SELECT * FROM product";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo "
                                            <tr>
                                                <td>
                                                    <img src='../images/$set->image' alt='Round Gallon' style='width: 50px; height: 50px; object-fit: contain; background: #ffffff; border-radius: 8px; padding: 2px;'>
                                                </td>
                                                <td>$set->id</td>
                                                <td>$set->product_name</td>
                                                <td>$set->category</td>
                                                <td>₱$set->price</td>
                                                <td>
                                                    <button class='btn btn-edit btn-sm rounded-pill px-3 me-1'
                                                            data-image='{$set->image}'
                                                            data-id='{$set->id}' 
                                                            data-name='{$set->product_name}'
                                                            data-category='{$set->category}'
                                                            data-price='{$set->price}'>
                                                        Edit
                                                        </button>
                                                    <button class='btn btn-remove btn-sm rounded-pill px-3' data-id='{$set->id}'>Remove</button>
                                                </td>
                                            ";
                                    }

                                    echo <<<HTML
                                                <script>
                                                    $('.btn-remove').click(function() {
                                                        //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                                        id = $(this).data('id');

                                                        Swal.fire({
                                                            title: 'Remove Product?',
                                                            text: "It will be deleted in the database",
                                                            icon: 'warning',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showCancelButton: true,
                                                            showConfirmButton: false,
                                                            cancelButtonColor: '#8892B0',
                                                            html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
                                                            heightAuto: false
                                                        });
                                                    });
                                                </script>
                                                HTML;

                                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                        //Remove Account
                                        if (isset($_POST['deleter'])) {
                                            $sql = "DELETE FROM product WHERE id = " . $_POST['deleter'];
                                            if ($conn->query($sql) === TRUE) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Product Removed!',
                                                                            text: 'The product has been removed.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676'
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('products.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        }

                                        if (isset($_POST['adder'])) {
                                            echo <<<HTML
                                                    <script>
                                                        console.log("LINKED/Adder");
                                                    </script>
                                                HTML;

                                            $name = $_POST['name'];
                                            $price = $_POST['price'];
                                            $category = $_POST['category'];
                                            $image = $_POST['image'];


                                            echo <<<HTML
                                                        <script>
                                                            console.log("{$name}", "{$price}", "{$category}", "{$image}");
                                                        </script>
                                                    HTML;



                                            if ($name && $price && $category && $image) {
                                                //Product name and category repetition checker
                                                $sql = "SELECT product_name, category FROM product";
                                                $query = $conn->query($sql);
                                                $product_checked = True;
                                                while ($set = $query->fetch_object()) {
                                                    if ($set->product_name == $name && $set->category == $category) {
                                                        $product_checked = False;
                                                        break;
                                                    }
                                                }

                                                //Number prevents "-" and "e"
                                                $number_checked = True;
                                                if (strpbrk($price, 'e-') !== false) {
                                                    $number_checked = False;
                                                }


                                                if ($number_checked) {
                                                    if ($product_checked) {
                                                        //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                        $sql = "INSERT INTO `product` (`image`, `product_name`, `category`, `price`) VALUES (?, ?, ?, ?)";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("sssd", $image, $name, $category, $price);
                                                        if ($stmt->execute()) {
                                                            echo <<<HTML
                                                                            <script>
                                                                                $(document).ready(function() {
                                                                                    Swal.fire({
                                                                                        icon: 'success',
                                                                                        title: 'Product Added!',
                                                                                        text: 'The new product has been registered.',
                                                                                        background: '#112240',
                                                                                        color: '#CCD6F6',
                                                                                        confirmButtonColor: '#00E676'
                                                                                    }).then((result) => {
                                                                                        if(result.isConfirmed) {
                                                                                            location.assign('products.php');
                                                                                        }});
                                                                                })
                                                                                
                                                                            </script> 
                                                                        HTML;
                                                        }
                                                    } else {
                                                        //Product repeated
                                                        echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Product Already Exists!',
                                                                            text: 'Enter a new product and category',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000'
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                $('#addProductModal').modal('show');
                                                                            }});
                                                                    })
                                                                    </script> 
                                                            HTML;
                                                    }
                                                } else {
                                                    //Number not verified
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Invalid Price!',
                                                                            text: 'Enter a new price',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000'
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                $('#addProductModal').modal('show');
                                                                            }});
                                                                    })
                                                                    </script> 
                                                            HTML;
                                                }
                                            }
                                        }

                                        if (isset($_POST['editer'])) {
                                            $id =  $_POST['id'];
                                            $name = $_POST['name'];
                                            $price = $_POST['price'];
                                            $category = $_POST['category'];

                                            if ($name && $price && $category) {
                                                $sql = "SELECT product_name, category FROM product WHERE id != " . $id;
                                                $query = $conn->query($sql);
                                                $product_checked = True;
                                                while ($set = $query->fetch_object()) {
                                                    if ($set->product_name == $name && $set->category == $category) {
                                                        $product_checked = False;
                                                        break;
                                                    }
                                                }

                                                //Number prevents "-" and "e"
                                                $number_checked = True;
                                                if (strpbrk($price, 'e-') !== false) {
                                                    $number_checked = False;
                                                }


                                                if ($number_checked) {
                                                    if ($product_checked) {
                                                        //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                        if ($_POST['image'] != "") {
                                                            //UPDATE WITH PHOTO
                                                            $image = $_POST['image'];
                                                            $sql = "UPDATE `product` SET `image` = ?, `product_name` = ?, `category` = ?, `price` = ? WHERE id = '" . $id . "'";
                                                            $stmt = $conn->prepare($sql);
                                                            $stmt->bind_param("sssd", $image, $name, $category, $price);
                                                        } else {
                                                            //UPLOAD WITHOUT PHOTO
                                                            $sql = "UPDATE `product` SET `product_name` = ?, `category` = ?, `price` = ? WHERE id = '" . $id . "'";
                                                            $stmt = $conn->prepare($sql);
                                                            $stmt->bind_param("ssd", $name, $category, $price);
                                                        }

                                                        if ($stmt->execute()) {
                                                            echo <<<HTML
                                                                            <script>
                                                                                $(document).ready(function() {
                                                                                    Swal.fire({
                                                                                        icon: 'success',
                                                                                        title: 'Product Added!',
                                                                                        text: 'The new product has been registered.',
                                                                                        background: '#112240',
                                                                                        color: '#CCD6F6',
                                                                                        confirmButtonColor: '#00E676',

                                                                                        heightAuto: false
                                                                                    }).then((result) => {
                                                                                        if(result.isConfirmed) {
                                                                                            location.assign('products.php');
                                                                                        }});
                                                                                })
                                                                                
                                                                            </script> 
                                                                        HTML;
                                                        }
                                                    } else {
                                                        //Product repeated
                                                        echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Product Already Exists!',
                                                                            text: 'Enter a new product and category',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000',

                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('products.php');
                                                                            }});
                                                                    })
                                                                    </script> 
                                                            HTML;
                                                    }
                                                } else {
                                                    //Invalid Price
                                                    echo <<<HTML
                                                            <script>
                                                                $(document).ready(function() {
                                                                    Swal.fire({
                                                                        icon: 'error',
                                                                        title: 'Invalid Price!',
                                                                        text: 'Enter a new price',
                                                                        background: '#112240',
                                                                        color: '#CCD6F6',
                                                                        confirmButtonColor: '#e60000',

                                                                        heightAuto: false
                                                                    }).then((result) => {
                                                                        if(result.isConfirmed) {
                                                                            location.assign('products.php');
                                                                        }});
                                                                })
                                                                </script> 
                                                        HTML;
                                                }
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content shadow-lg">

                            <div class="modal-header">
                                <h5 class="modal-title">Add New Product</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body p-4">
                                <form id="addProductForm" method="POST">

                                    <div class="mb-3">
                                        <label class="form-label">Product Name</label>
                                        <input type="text" class="form-control" name="name" required placeholder="e.g. 10L Gallon">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Price</label>
                                        <input type="number" class="form-control" name="price" required placeholder="e.g. 100">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Category</label>
                                        <select class="form-select" name="category" required>
                                            <option value="" disabled selected>Select a category...</option>
                                            <option value="Refill">Refill</option>
                                            <option value="New Container">New Container</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Product Image</label>
                                        <input type="file" class="form-control" name="image" id="productImage" accept="image/*" required>
                                    </div>

                                    <div class="mb-2 text-center d-none" id="imagePreviewContainer">
                                        <img id="imagePreview" src="" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="addProductBtn">Add Product</button>
                                    </div>

                                </form>
                            </div>



                        </div>
                    </div>
                </div>



                <div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content shadow-lg">

                            <div class="modal-header">
                                <h5 class="modal-title">Edit Product</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body p-4">
                                <form id="addProductForm" method="POST">

                                    <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                                    <input type="number" name="id" id="edit-id" hidden>

                                    <div class="mb-3">
                                        <label class="form-label">Product Name</label>
                                        <input type="text" class="form-control" name="name" required placeholder="e.g. 10L Gallon" id="edit-name">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Price</label>
                                        <input type="number" class="form-control" name="price" required placeholder="e.g. 100" id="edit-price">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Category</label>
                                        <select class="form-select" name="category">
                                            <option value="" id="edit-category" selected></option>
                                            <option value="Refill">Refill</option>
                                            <option value="New Container">New Container</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Product Image</label>
                                        <input type="file" name="image" class="form-control" id="productImageEdit" accept="image/*">
                                    </div>

                                    <div class="mb-2 text-center" id="imagePreviewContainerEdit">
                                        <img id="imagePreviewEdit" value="" class="edit-image" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="editProductBtn">Edit Product</button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>
    <script>
        $(document).ready(function() {

            $('.btn-edit').click(function() {

                //Used to pre-load the edit section since it's not connected to PHP
                id = $(this).data('id');
                image = $(this).data('image');
                name = $(this).data('name');
                category = $(this).data('category');
                price = $(this).data('price');

                //Resets the value of file if cancelled
                $("#productImageEdit").val("");

                $("#edit-id").val(id);
                $("#imagePreviewEdit").attr("src", "../Images/" + image);
                $("#edit-name").val(name);
                $("#edit-category").text(category);
                $("#edit-category").attr("value", category);
                $("#edit-price").val(price);

            });



            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",

                    heightAuto: false

                });
            });



            $(".btn-add").click(function() {
                $('#addProductModal').modal('show');
                //Dito ko nalang nilagay toh since nag r-reset din naman sya before pa mag open yung modal
                $('#imagePreviewContainer').addClass('d-none');
                $('#imagePreview').attr('src', '');
            });

            $(".btn-edit").click(function() {
                $('#editProductModal').modal('show');
            });

        });

        // Image Preview Logic for Add Product Modal
        $('#productImage').change(function(e) {
            let reader = new FileReader();

            // When the file is read, put it in the image tag and show the container
            reader.onload = function(e) {
                $('#imagePreview').attr('src', e.target.result);
                $('#imagePreviewContainer').removeClass('d-none');
            }

            // Read the file the user selected
            if (this.files[0]) {
                reader.readAsDataURL(this.files[0]);
            }
        });

        $('#productImageEdit').change(function(e) {
            let reader = new FileReader();

            // When the file is read, put it in the image tag and show the container
            reader.onload = function(e) {
                $('#imagePreviewEdit').attr('src', e.target.result);
                //$('#imagePreviewContainer').removeClass('d-none');
            }

            // Read the file the user selected
            if (this.files[0]) {
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>