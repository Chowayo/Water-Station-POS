<?php

include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-4">

                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

            </div>

            <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#profileModal">Profile</a>
            <?php
            include 'profile.php';
            ?>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link active" href="home.php">POS</a>
                <a class="menu-link" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <!-- MAIN POS CONTENT -->
        <main class="flex-grow-1 d-flex content">
            <section class="flex-grow-1 d-flex flex-column p-4">

                <header class="top-text text-center mb-4">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Mineral Water Refill & POS management System</h6>
                </header>

                <div class="row g-4 mt-1 flex-grow-1 align-content-start product-container">
                    <!-- Product 1 -->

                    <?php
                    $sql = "SELECT * FROM product";
                    $query = $conn->query($sql);
                    while ($set = $query->fetch_object()) {
                        echo '<div class="col-4">
                                    <div class="item-card">
                                        <div class="info">
                                            <div class="product-image">
                                                <img src="../Images/' . $set->image . '" class="product-img">
                                            </div>
                                            <div>' . $set->product_name . ' ' . $set->category . '</div>
                                            <div class="price">₱' . $set->price . '</div>
                                        </div>
                                        <div class="actions">
                                            <button class="btn-add" id="' . $set->id . '-submit">Add</button>
                                        </div>
                                    </div>
                                </div>';
                        echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            //clear button
                                            total = 0; //Total amount
                                            $("#clear").click(function() {
                                                if($("#{$set->id}-submit").css("background-color")==="rgb(40, 167, 69)"){
                                                    $("#{$set->id}-submit").css("background-color", "#007BFF");
                                                }
                                                if($("#{$set->id}-submit").prop("disabled")===true){
                                                    $("#{$set->id}-submit").attr("disabled", false);
                                                }
                                                if($("#{$set->id}-submit").text()==="Added"){
                                                    $("#{$set->id}-submit").text("Add");
                                                }
                                                //Wipes all of the side div inside of order_queue
                                                $(".order_queue").empty();
                                                $("#sub-total").empty();
                                                $("#bill-list").empty();
                                                total = 0; //Total resets
                                                $("#total-amount").text("₱"+total+".00");
                                                $("#grand-total").text("₱"+total+".00");
                                                $("#checkout").attr("hidden", true);   


                                            });

                                            $("#{$set->id}-submit").click(function() {
                                                $("#checkout").attr("hidden", false);
                                                $("#{$set->id}-submit").css("background-color", "#28a745");
                                                $("#{$set->id}-submit").attr("disabled", true);
                                                $("#{$set->id}-submit").text("Added");

                                                //Generates sub-total
                                                $("#sub-total").prepend(`<p id="{$set->id}-sub"></p>`);

                                                //Receipt editor
                                                $("#bill-list").prepend(`
                                                    <div class="receipt-grid" id="{$set->id}-bill">
                                                        <p id="{$set->id}-quantity"></p>
                                                        <p id="{$set->id}-product_name"></p>
                                                        <p id="{$set->id}-price" class="price"></p>
                                                    </div>
                                                `);

                                                $(".order_queue").prepend(`
                                                    <div class="overflow-auto cart-list pe-2" id="{$set->id}-whole">
                                                        <div class="cart-item">
                                                            <div class="item-details">
                                                                <div class="cart-name">{$set->product_name} {$set->category}</div>
                                                                <div class="cart-calc" id="{$set->id}-calc">1 x ₱{$set->price}</div>
                                                                <div class="qty-box">
                                                                    <button class="btn-qty" id="{$set->id}-minus">-</button>
                                                                    <input type="number" class="input-num" value="1" min="1" max="20" id="{$set->id}-value" disabled>
                                                                    <button class="btn-qty" id="{$set->id}-add">+</button>
                                                                </div>
                                                            </div>
                                                            <div class="item-actions">
                                                                <div class="cart-line-total" id="{$set->id}-total">₱{$set->price}</div>
                                                                <button class="btn-remove" id="{$set->id}-remove">X</button>
                                                            </div>
                                                            
                                                        </div>
                                                    
                                                    
                                                    <script>
                                                        
                                                        total += {$set->price};
                                                        $("#total-amount").text("₱"+total+".00");
                                                        $("#grand-total").text("₱"+total+".00");
                                                        $("#{$set->id}-sub").text("₱"+{$set->price}+".00");

                                                        $("#{$set->id}-quantity").text(1+"x");
                                                        $("#{$set->id}-product_name").text("{$set->product_name}");
                                                        $("#{$set->id}-price").text("₱{$set->price}");                                                        

                                                        $("#{$set->id}-add").click(function() {
                                                            if( $("#{$set->id}-value").val()<=19){
                                                                $("#{$set->id}-value").val(function(index, value) {
                                                                    return (parseInt(value) || 0) + 1;
                                                                });
                                                            }else{
                                                                $("#{$set->id}-value").val(20);
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                            total += {$set->price};
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-sub").text("₱"+(quantity*{$set->price})+".00");

                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });

                                                        $("#{$set->id}-minus").click(function() {
                                                            if( $("#{$set->id}-value").val()>1){
                                                                $("#{$set->id}-value").val($("#{$set->id}-value").val()-1);
                                                            }else{
                                                                $("#{$set->id}-value").val(1);
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                            total -= {$set->price};
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-sub").text("₱"+(quantity*{$set->price})+".00");

                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });


                                                        $("#{$set->id}-remove").click(function() {
                                                            $("#{$set->id}-submit").css("background-color", "#007BFF");
                                                            $("#{$set->id}-submit").attr("disabled", false);
                                                            $("#{$set->id}-submit").text("Add");
                                                            total -= ($("#{$set->id}-value").val()*{$set->price});
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-whole").remove();
                                                            $("#{$set->id}-sub").remove();
                                                            $("#{$set->id}-bill").remove();

                                                            if ($(".order_queue").children().length === 0) {
                                                                $("#checkout").attr("hidden", true);
                                                            }
                                                        });
                                                    <\/script>
                                                    </div>
                                                `)
                                            });
                                        })
                                        
                                    </script>
                                    HTML;
                    }

                    ?>
                </div>
            </section>

            <!-- RIGHT CART PANEL -->
            <aside class="right-panel d-flex flex-column shadow-sm">

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <button class="btn-order flex-grow-1 m-0">ORDERS</button>
                    <button class="btn-clear ms-2" id="clear">Clear</button>
                </div>

                <!-- Dito binabato lahat ng additions na product -->
                <div class="order_queue flex-grow-1 overflow-auto">


                </div>



                <div class="totals-box mt-5">
                    <div class="total-row">
                        <p>Subtotal:</p>
                    </div>
                    <div id="sub-total" style="font-weight: 700; color: #003366; font-size: 14px;">
                    </div>
                    <hr class="my-2 border-secondary">
                    <div class="total-row grand-total">
                        <span>Total</span>
                        <span id="total-amount">₱0.00</span>
                    </div>
                </div>

                <button type="button" class="btn-pay mt-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#checkoutCustomerModal" id="checkout" hidden>Checkout</button>
            </aside>
        </main>
    </div>

    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">

        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-body p-4">


                    <div class="receipt-paper" id="printableReceipt">

                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>1</strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>
                                <?php
                                date_default_timezone_set('Asia/Manila');
                                echo "Time:" . date("h:iA"); ?>
                            </p>
                            <p>
                                <?php
                                echo "Cashier:" . $result->first_name;
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <p>Name: Luz Cantos</p>
                        <p>Phone: 0912 345 6789</p>
                        <p>Address: Trece Martires</p>
                        <p>Payment Method: Cash </p>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>

                        <!--Dito naka lagay yung mga custom part ng receipt-->
                        <div id="bill-list">

                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p id="grand-total"></p>
                        </div>


                    </div>

                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()">Print Receipt</button>
                </div>

            </div>
        </div>
    </div>

    <!-- CUSTOMER CHECKOUT -->
    <div class="modal fade" id="checkoutCustomerModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content custom-modal-content">

                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-navy">Checkout Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <div class="row g-4">

                        <!-- Search & Table -->
                        <div class="col-md-6 d-flex flex-column gap-3">

                            <div class="input-group mb-3 custom-search-group">
                                <input type="text" class="form-control custom-search-input" placeholder="Search Customer...">
                            </div>

                            <div class="customer-table-area flex-grow-1 border rounded p-3 bg-white">
                                <div class="table-responsive">
                                    <table class="table table-sm table-borderless text-center align-middle mb-0 customer-table">
                                        <thead class="text-navy border-bottom" style="font-size: 0.9rem;">
                                            <tr>
                                                <th>Full Name</th>
                                                <th>Contact</th>
                                                <th>Address</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-muted" style="font-size: 0.85rem;">
                                            <tr>
                                                <td>Luz Cantos</td>
                                                <td>09123456789</td>
                                                <td class="truncate-text" title="123 Block 4, Lot 5, Phase 2, Very Long Subdivision Name, Barangay 1">
                                                    123 Block 4, Lot 5, Phase 2, Trece Martires City
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Customer Inputs -->
                        <div class="col-md-6 d-flex flex-column gap-3 justify-content-center">

                            <input type="text" class="form-control custom-input text-center" placeholder="Full Name">
                            <input type="text" class="form-control custom-input text-center" placeholder="Contact Number">
                            <input type="text" class="form-control custom-input text-center" placeholder="Address">

                            <select class="form-select custom-input">
                                <option value="" disabled selected>Order Type</option>
                                <option value="pickup">Pick Up</option>
                                <option value="delivery">Delivery</option>
                            </select>

                            <select class="form-select custom-input">
                                <option value="" disabled selected>Payment Method</option>
                                <option value="cash">Cash</option>
                                <option value="gcash">GCash</option>
                            </select>

                            <div class="d-flex justify-content-center gap-3 mt-3">
                                <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>

                                <button type="button" class="btn btn-primary rounded-pill px-5 fw-bold" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#receiptModal">Submit</button>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    title: "Do you want to Log out?",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    html: "<a href='../logout.php' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>