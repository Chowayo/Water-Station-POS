<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Confirmation</title>


    <link rel="stylesheet" href="styles.css">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-4">

                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

            </div>

            <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#profileModal">Profile</a>
            <?php
                include 'profile.php';
            ?>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="home.php">POS</a>
                <a class="menu-link active" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">
            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Delivery & Order Confirmation</h6>
                    </div>
                </header>

                <div class="box mt-2">
                    <div class="d-flex justify-content-between mb-3 align-items-center">
                        <h5 class="mb-0 fw-bold">Active Deliveries</h5>

                        <div class="input-group w-25">
                            <input type="text" class="form-control" placeholder="Search Order ID">
                            <button class="btn btn-primary fw-bold px-3" type="button">Search</button>
                        </div>
                    </div>

                    <table class="table table-hover text-center mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer Name</th>
                                <th>Produt Name</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Payment</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Row 1: Pending Order -->
                            <tr>
                                <td class="cyan-text fw-bold">1</td>
                                <td><strong class="d-block">Maybelle Dellamas</strong></td>
                                <td>Round Gallon Refill</td>
                                <td>3</td>
                                <td class="green-text fw-bold fs-5">₱ 90.00</td>
                                <td><span class="badge bg-cod">COD</span></td>
                                <td>
                                    <button class="btn btn-closed btn-sm rounded-pill px-3">Closed</button>
                                </td>
                            </tr>

                            <tr>
                                <td class="cyan-text fw-bold">2</td>
                                <td><strong class="d-block">Luz Cantos</strong></td>
                                <td>New Slim Container</td>
                                <td>1</td>
                                <td class="green-text fw-bold fs-5">₱ 150.00</td>
                                <td><span class="badge bg-paid">GCash</span></td>
                                <td>
                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 confirm-btn">Confirm Delivery</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </section>
        </main>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $(document).ready(function() {
            //Confirming Delivery
            $(".confirm-btn").click(function() {
                Swal.fire({
                    title: 'Confirm Delivery?',
                    text: "Has the customer received the water and settled the payment?",
                    icon: 'success',
                    background: '#FFFFFF',
                    color: '#2D3748',
                    showCancelButton: true,
                    confirmButtonColor: '#00A859',
                    cancelButtonColor: '#718096',
                    confirmButtonText: 'Yes, Confirm!',
                    heightAuto: false
                })
            });

            //Logout
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>
</body>

</html>