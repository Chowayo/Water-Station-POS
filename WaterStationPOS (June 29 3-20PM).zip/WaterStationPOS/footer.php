<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        .pos-footer {
            background-color: rgba(255, 255, 255, 0.65);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 32px 0 rgba(0, 84, 166, 0.2);
        }

        .pos-footer {
            position: relative;
        }

        .pos-footer::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, #0457d3, #eaebc6);
            opacity: 0.9;
        }
    </style>
</head>

<body>
    <footer class="pos-footer bg-white border-top mt-auto">
        <div class="container-fluid">
            <div class="row align-items-center py-2">
                <div class="col-12 col-md-6 text-center text-md-start">
                    <div class="fw-semibold">Eco Hydrate Hub POS</div>
                    <div class="text-secondary small">Mineral Water Refill & POS management System</div>
                </div>

                <div class="col-12 col-md-6 text-center text-md-end mt-2 mt-md-0">
                    <div class="text-secondary small" style="line-height: 1.2;">
                        <div class="d-flex align-items-center justify-content-md-end justify-content-center gap-2">
                            <span>✉︎</span>
                            <span>ecohydratehub@gmail.com</span>
                        </div>
                        <div class="d-flex align-items-center justify-content-md-end justify-content-center gap-2">
                            <span>🕻</span>
                            <span>+63 912 345 6789</span>
                        </div>
                        <div class="d-flex align-items-center justify-content-md-end justify-content-center gap-2">
                            <span>☎︎</span>
                            <span>(46) 1234 567</span>
                        </div>
                        <div class="mt-0 mb-0 text-center text-md-end">© <span id="year"></span> 2026 All rights reserved.</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script>
    </script>
</body>

</html>