<?php
include 'header.php';

$sql = "SELECT * FROM customers WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<style>
    body {
        background: #0a192f !important;
        display: block !important;
        overflow-y: auto !important;
        padding: 0 !important;
        min-height: 100vh;
        font-family: "Poppins", sans-serif;
    }

    .content {
        min-height: 100vh;
    }

    /* TOP TEXT */
    .top-text h1 {
        font-weight: 800;
        color: #ffffff;
        margin-bottom: 0;
    }

    .first-title-text {
        color: #00e676;
    }

    .top-text h6 {
        font-weight: 600;
        color: #8892b0;
        margin-top: 5px;
    }

    /* SEARCH BAR */
    .box {
        background-color: #112240;
        border-radius: 15px;
        border: 1px solid #233554;
    }

    .search-icon-wrap {
        position: relative;
        flex: 1;
    }

    .search-icon-inside {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #8892b0;
    }

    .search-icon-wrap input {
        padding-left: 38px !important;
        background-color: #0d1b2e !important;
        border: 1px solid #233554 !important;
        color: #ccd6f6 !important;
        border-radius: 8px;
    }

    .search-icon-wrap input:focus {
        background-color: #0a192f !important;
        border-color: #00e676 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .btn-filter {
        background-color: #0d1b2e;
        border: 1px solid #233554;
        color: #ccd6f6;
        font-weight: 600;
        border-radius: 8px;
        padding: 0.4rem 1.1rem;
        transition: 0.2s;
    }

    .btn-filter:hover,
    .btn-filter.active {
        background-color: rgba(100, 255, 218, 0.15);
        border-color: #64ffda;
        color: #64ffda;
    }

    /* PRODUCT CARDS */
    .item-card {
        background-color: #112240;
        border: 2px solid #233554;
        border-radius: 20px;
        height: 100%;
        width: 100%;
        font-weight: 700;
        color: #ccd6f6;
        transition: all 0.2s ease;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding: 15px 10px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .item-card:hover {
        border-color: #00e676;
        transform: translateY(-3px);
        box-shadow: 0 8px 15px rgba(0, 230, 118, 0.12);
    }

    .product-image {
        display: flex;
        justify-content: center;
        margin-bottom: 10px;
    }

    .product-img {
        width: 180px;
        height: 180px;
        object-fit: contain;
    }

    .price {
        font-size: 16px;
        font-weight: 800;
        color: #00e676;
        margin-bottom: 4px;
    }

    .stock-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }

    .stock-badge.stock-ok {
        background-color: rgba(0, 230, 118, 0.12);
        color: #00e676;
        border: 1px solid rgba(0, 230, 118, 0.35);
    }

    .stock-badge.stock-medium {
        background-color: rgba(255, 193, 7, 0.15);
        color: #ffc107;
        border: 1px solid rgba(255, 193, 7, 0.4);
    }

    .stock-badge.stock-low {
        background-color: rgba(220, 53, 69, 0.15);
        color: #ff6b6b;
        border: 1px solid rgba(220, 53, 69, 0.4);
    }

    .btn-add {
        background-color: #007bff;
        color: #ffffff;
        border: none;
        border-radius: 10px;
        width: 100%;
        font-weight: bold;
        padding: 8px 0;
        font-size: 14px;
        transition: 0.2s;
        margin-top: 10px;
    }

    .btn-add:hover {
        background-color: #28a745;
    }

    /* RIGHT CART PANEL */
    .right-panel {
        width: 280px;
        min-width: 280px;
        flex-shrink: 0;
        background-color: #112240;
        border: 2px solid #233554;
        border-radius: 30px;
        margin: 20px;
        padding: 20px;
        box-shadow: -2px 0px 10px rgba(0, 0, 0, 0.15);
        max-height: calc(100vh - 40px);
    }

    .btn-order {
        background-color: transparent;
        color: #64ffda;
        border: 2px solid #64ffda;
        border-radius: 25px;
        font-weight: 800;
        width: 100%;
        padding: 8px 0;
        margin-bottom: 15px;
    }

    .btn-pay {
        background-color: #00e676;
        color: #0a192f;
        border: none;
        border-radius: 25px;
        font-weight: 700;
        width: 100%;
        padding: 10px 0;
        font-size: 16px;
        transition: 0.2s;
    }

    .btn-pay:hover {
        background-color: #00c96c;
    }

    .btn-clear {
        background-color: #ff4d4d;
        color: #ffffff;
        border: none;
        border-radius: 25px;
        font-weight: 700;
        padding: 8px 15px;
        font-size: 12px;
    }

    .cart-item {
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 10px;
        margin-bottom: 10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .cart-name {
        font-weight: 700;
        color: #ccd6f6;
        font-size: 14px;
    }

    .cart-calc {
        color: #8892b0;
        font-size: 12px;
        font-weight: 600;
    }

    .item-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .cart-line-total {
        font-weight: 800;
        color: #00e676;
        font-size: 14px;
    }

    .btn-remove {
        background-color: rgba(255, 77, 77, 0.15);
        color: #ff4d4d;
        border: none;
        border-radius: 5px;
        width: 25px;
        height: 25px;
        font-weight: bold;
        font-size: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: 0.2s;
    }

    .btn-remove:hover {
        background-color: rgba(255, 77, 77, 0.3);
    }

    /* Quantity Box */
    .qty-box {
        display: flex;
        justify-content: center;
        align-items: center;
        column-gap: 5px;
        margin-bottom: 8px;
    }

    .btn-qty {
        background-color: #1c2b45;
        border: none;
        border-radius: 5px;
        width: 28px;
        height: 28px;
        font-weight: bold;
        color: #64ffda;
        transition: 0.2s;
    }

    .btn-qty:hover {
        background-color: #24395c;
    }

    .input-num {
        width: 40px;
        height: 28px;
        text-align: center;
        border: 1px solid #233554;
        border-radius: 5px;
        font-weight: bold;
        color: #ccd6f6;
        background-color: #0d1b2e;
    }

    .input-num::-webkit-outer-spin-button,
    .input-num::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Cart Totals */
    .totals-box {
        background-color: #0d1b2e;
        border: 2px solid #233554;
        border-radius: 15px;
        padding: 15px;
        margin-top: 10px;
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        font-weight: 700;
        color: #ccd6f6;
        font-size: 14px;
    }

    .grand-total {
        font-size: 18px;
        font-weight: 800;
        color: #00e676;
    }

    #order_queue::-webkit-scrollbar {
        width: 6px;
    }

    #order_queue::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.25);
        border-radius: 10px;
    }
</style>

<div class="content d-flex flex-column flex-grow-1">
    <?php include 'topbar.php'; ?>

    <div class="d-flex flex-grow-1 pos-content-row">
        <section class="flex-grow-1 p-4">

            <div class="top-text mb-4">
                <h1>Welcome, <span class="first-title-text">
                    <?php                    
                        for($i=-1; $i>(strlen($result->full_name)*-1); $i--){
                            if($result->full_name[$i]==" "){
                                break;
                            }
                        }

                        echo substr($result->full_name, $i);
                    ?>
                </span></h1>
                <h6>What's your order for today?</h6>
            </div>
            <div class="box shadow p-2">
                <div class="d-flex gap-2" id="productTypeTabs">
                    <div class="table-search-input search-icon-wrap">
                        <i class="bi bi-search search-icon-inside"></i>
                        <input type="text" class="form-control w-25" placeholder="Search product..." id="searcher">

                        
                    </div>
                    <button class="btn btn-filter ms-auto nav-link active" data-product="all">All</button>
                    <button class="btn btn-filter nav-link" data-product="refill">Refill</button>
                    <button class="btn btn-filter nav-link" data-product="newBottle">Container</button>
                </div>
            </div>


            <style>
                .product-panel {
                    display: none;
                }

                .product-panel.active {
                    display: block;
                }

                .product-container::-webkit-scrollbar {
                    display: none;
                }
            </style>


            <?php
            $global_counter = 0;
            function product_loader($conn, $category, &$counter)
            {
                if ($category == "All") {
                    $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False'";
                } else if ($category == "NewContainer") {
                    $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False' AND category = 'New Container'";
                } else {
                    $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False' AND category = '" . $category . "'";
                }
                $query = $conn->query($sql);
                $counter = 0;
                while ($set = $query->fetch_object()) {
                    $counter += 1;

                    // Color-code the stock badge by how low the quantity is
                    if ($set->stock <= 5) {
                        $stock_class = 'stock-low';
                    } elseif ($set->stock <= 15) {
                        $stock_class = 'stock-medium';
                    } else {
                        $stock_class = 'stock-ok';
                    }

                    echo '<div class="col-6 col-md-4" id="product_card-'.$counter.'-'.$category.'">
                                    <div class="item-card">
                                        <div class="info">
                                            <div class="product-image">
                                                <img src="../Images/' . $set->image . '" class="product-img">
                                            </div>
                                            <div>' . $set->product_name . ' ' . $set->measurement . $set->unit . ' ' . $set->category . '</div>
                                            <p hidden id="name-'.$counter.'-'.$category.'">'.$set->product_name.' '.$set->category.'</p>
                                            <div class="price">₱' . $set->price . '</div>
                                            <div class="mb-2"><span class="stock-badge ' . $stock_class . '">Stock: ' . $set->stock . '</span></div>
                                        </div>
                                        <div class="actions">
                                            <button class="btn-add ' . $set->id . '-' . $category . '-submit" id=""> <i class="bi bi-cart-plus"></i> Add</button>
                                        </div>
                                    </div>
                                </div>';

                    echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        //clear button
                                        total = 0; //Total amount
                                        $("#clear").click(function() {
                                            if($(".{$set->id}-{$category}-submit").css("background-color")==="rgb(40, 167, 69)"){
                                                $(".{$set->id}-{$category}-submit").css("background-color", "#007BFF");
                                            }
                                            if($(".{$set->id}-{$category}-submit").prop("disabled")===true){
                                                $(".{$set->id}-{$category}-submit").attr("disabled", false);
                                            }
                                            if($(".{$set->id}-{$category}-submit").text()==="Added"){
                                                $(".{$set->id}-{$category}-submit").html("<i class='bi bi-cart-plus'></i> Add");
                                            }
                                            //Wipes all of the side div inside of order_queue
                                            $("#order_queue").empty();
                                            $("#bill-list").empty();
                                            total = 0; //Total resets
                                            $("#total-amount").text("₱"+total+".00");
                                            $("#grand-total").text("₱"+total+".00");
                                            $("#checkout").attr("hidden", true);
                                            $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm d-none");
                                        });


                                        $(".{$set->id}-{$category}-submit").click(function() {
                                            $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm");
                                            $("#checkout").attr("hidden", false);
                                            $(".{$set->id}-{$category}-submit").css("background-color", "#28a745");
                                            $(".{$set->id}-{$category}-submit").attr("disabled", true);
                                            $(".{$set->id}-{$category}-submit").text("Added");

                                            //Disables the same product from other categories
                                            categories = ["All", "Refill", "NewContainer"];
                                            for (const category of categories) {
                                                if ($(".{$set->id}-"+category+"-submit").prop("disabled") === false) {
                                                    $(".{$set->id}-"+category+"-submit").css("background-color", "#28a745");
                                                    $(".{$set->id}-"+category+"-submit").attr("disabled", true);
                                                    $(".{$set->id}-"+category+"-submit").text("Added");
                                                }
                                            }

                                            //Receipt editor
                                            $("#bill-list").prepend(`
                                                <div class="receipt-grid" id="{$set->id}-bill">
                                                    <p id="{$set->id}-quantity"></p>
                                                    <p id="{$set->id}-product_name"></p>
                                                    <p id="{$set->id}-price" class="price"></p>
                                                </div>
                                            `);

                                            $("#order_queue").prepend(`
                                                <div class="overflow-auto cart-list pe-2" id="{$set->id}-whole">
                                                    <div class="cart-item"> 
                                                        <div class="item-details">
                                                            <input type="text" name="product_name-{$counter}" value="{$set->product_name}" hidden>
                                                            <input type="text" name="product_category-{$counter}" value="{$set->category}" hidden>
                                                            <input type="text" name="product_unit-{$counter}" value="{$set->unit}" hidden>
                                                            <input type="number" name="product_measurement-{$counter}" value="{$set->measurement}" hidden>
                                                            <input type="number" name="product_tax-{$counter}" value="{$set->tax_percentage}" hidden>
                                                            <input type="number" name="product_quantity-{$counter}" value="1" id="{$set->id}-totalQuantity" hidden>
                                                            <input type="number" name="total_price-{$counter}" value="{$set->price}" id="{$set->id}-totalPrice" hidden>

                                                            <div class="cart-name">{$set->product_name} {$set->category}</div>
                                                            <div class="cart-calc" id="{$set->id}-calc">1 x ₱{$set->price}</div>
                                                            <div class="qty-box">
                                                                <button type="button" class="btn-qty" id="{$set->id}-minus">-</button>
                                                                <input type="number" class="input-num" min="1" max="20" id="{$set->id}-value" value="1" disabled>
                                                                <button type="button" class="btn-qty" id="{$set->id}-add">+</button>
                                                            </div>
                                                        </div>
                                                        <div class="item-actions">
                                                            <div class="cart-line-total" id="{$set->id}-total">₱{$set->price}</div>
                                                            <button type="button" class="btn-remove" id="{$set->id}-remove"><i class="bi bi-x-lg"></i></button>
                                                        </div>
                                                        
                                                    </div>
                                                    <script>
                                                        total += {$set->price};
                                                        $("#total-amount").text("₱"+total+".00");
                                                        $("#grand-total").text("₱"+total+".00");
                                                        $("#{$set->id}-quantity").text(1+"x");
                                                        $("#{$set->id}-product_name").text("{$set->product_name}");
                                                        $("#{$set->id}-price").text("₱{$set->price}");                                                        

                                                        $("#{$set->id}-add").click(function() {
                                                            if( $("#{$set->id}-value").val()<=({$set->stock}-1)){
                                                                total += {$set->price};
                                                                $("#{$set->id}-value").val(function(index, value) {
                                                                    return (parseInt(value) || 0) + 1;
                                                                });
                                                            }else{
                                                                $("#{$set->id}-value").val({$set->stock});
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                            
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                            $("#{$set->id}-totalQuantity").val(quantity);

                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });

                                                        $("#{$set->id}-minus").click(function() {
                                                            if( $("#{$set->id}-value").val()>1){
                                                                total -= {$set->price};
                                                                $("#{$set->id}-value").val($("#{$set->id}-value").val()-1);
                                                            }else{
                                                                $("#{$set->id}-value").val(1);
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                            
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                            $("#{$set->id}-totalQuantity").val(quantity);
                                                            
                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });

                                                        $("#{$set->id}-remove").click(function() {
                                                            $(".{$set->id}-{$category}-submit").css("background-color", "#007BFF");
                                                            $(".{$set->id}-{$category}-submit").attr("disabled", false);
                                                            $(".{$set->id}-{$category}-submit").html("<i class='bi bi-cart-plus'></i> Add");

                                                            total -= ($("#{$set->id}-value").val()*{$set->price});
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-whole").remove();
                                                            $("#{$set->id}-sub").remove();
                                                            $("#{$set->id}-bill").remove();

                                                            for (const category of categories) {
                                                                if ($(".{$set->id}-"+category+"-submit").prop("disabled") === true) {
                                                                    $(".{$set->id}-"+category+"-submit").css("background-color", "#007BFF");
                                                                    
                                                                    $(".{$set->id}-"+category+"-submit").html("<i class='bi bi-cart-plus'></i> Add");
                                                                }
                                                            }

                                                            if ($("#order_queue").children().length === 0) {
                                                                $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm d-none");
                                                            }
                                                        });
                                                    <\/script>
                                                </div>
                                            `)
                                        });
                                        
                                    })
                                </script>
                            HTML;
                }
            }
            ?>


            <div id="panel-refill" class="product-panel product-container">
                <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                    <h4 class="mt-4 mb-3" style="color: #ffffff; font-weight: 700;">Refill</h4>
                    <hr style="border-color: #233554;">
                    <?php
                    product_loader($conn, "Refill", $global_counter);
                    ?>

                </div>
            </div>

            <div id="panel-newBottle" class="product-panel product-container">
                <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                    <h4 class="mt-4 mb-3" style="color: #ffffff; font-weight: 700;">New Container</h4>
                    <hr style="border-color: #233554;">
                    <?php
                    product_loader($conn, "NewContainer", $global_counter);
                    ?>
                </div>
            </div>

            <div id="panel-all" class="product-panel active product-container">
                <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                    <h4 class="mt-4 mb-3" style="color: #ffffff; font-weight: 700;">All Products</h4>
                    <hr style="border-color: #233554;">
                    <?php
                    product_loader($conn, "All", $global_counter);
                    ?>
                    <script>
                        //Searching Function
                        $(document).ready(function() {
                            categories = ["All", "Refill", "NewContainer"];
                            $("#searcher").on("input", function() {
                                for (const category of categories) {
                                    for(i=1; i<(<?php echo $global_counter ?>+1); i++){
                                        if ($("#name-"+i+"-"+category).text().toLowerCase().includes($("#searcher").val().trim().toLowerCase())) {
                                            $("#product_card-" + i +"-"+category).attr("hidden", false);
                                        }else{
                                            $("#product_card-" + i +"-"+category).attr("hidden", true);
                                        }
                                    }
                                }
                            });
                        });
                    </script> 
                </div>
            </div>
        </section>

        <!-- RIGHT CART PANEL -->
        <aside class="right-panel d-flex flex-column shadow-sm d-none" id="side_orders">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <button class="btn-order flex-grow-1 m-0"><i class="bi bi-receipt me-1"></i>Orders</button>
                <button class="btn-clear ms-2" id="clear"><i class="bi bi-arrow-counterclockwise me-1"></i>Clear</button>
            </div>
            <!-- SAVE POINT-->
            <!-- Dito binabato lahat ng additions na product -->
            <div class="order_queue flex-grow-1 overflow-auto">
                <form method="POST">
                    <div id="order_queue">

                    </div>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                        //Remove Account
                        if (isset($_POST['checkout'])) {
                            $customer_name = $result->full_name;
                            $order_type = "Delivery";
                            $payment_amount = 0;
                            $payment_method = "Pending";

                            if ($customer_name && $order_type && $payment_method) {

                                //if pickup is chosen
                                $status = "Not Received";
                                $customer_contact = $result->contact;
                                $customer_address = "NO INFO";
                                $cashier = "USER ID:".$result->id;

                                $grand_total = 0.00;
                                $total_tax = 0.00;

                                //Date and time Information
                                date_default_timezone_set('Asia/Manila');
                                $time = date("h:iA");
                                $date = date('Y/m/d');

                                // NOTE: eto yung bagong lister ng orders na gagawin
                                $order_content = "";

                                for ($i = 1; $i <= $global_counter; $i++) {
                                    if (isset($_POST['product_name-' . $i])) {

                                        //Variables to be submitted
                                        $product_name = $_POST['product_name-' . $i];
                                        $product_categoty = $_POST['product_category-' . $i];
                                        $product_quantity = $_POST['product_quantity-' . $i];
                                        $product_tax = $_POST['product_tax-' . $i];
                                        $product_measurement = $_POST['product_measurement-' . $i];
                                        $product_unit = $_POST['product_unit-' . $i];


                                        //Total Price
                                        $total_price = $_POST['total_price-' . $i];
                                        $grand_total += $total_price;

                                        //Total Tax
                                        $product_tax = $product_tax / 100;
                                        $tax_value = ($total_price * $product_tax);
                                        $total_tax += $tax_value;

                                        //Order content will replace order name para maging 1 row lang per order
                                        $order_content .= "" . $product_quantity . "x " . $product_name . " " . $product_measurement . $product_unit . "(" . $product_categoty . ")₱" . $total_price . " VAT:" . $product_tax . ",";

                                        //Used for receipt printing only
                                        $receipt = "" . $product_quantity . "x " . $product_name . " " . $product_measurement . $product_unit . "(" . $product_categoty . ")";

                                        //Deducts stock value based on quantity
                                        $sql = "UPDATE `product` SET `stock` = `stock` - ? WHERE product_name = '" . $product_name . "' AND category = '" . $product_categoty . "'";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("i", $product_quantity);
                                        if ($stmt->execute()) {}
                                    }
                                }

                                //Removes the last , for propper loading in receipt
                                $order_content = substr_replace($order_content, '', -1);

                                //Upload Data
                                $sql = "INSERT INTO `orders` (`customer_name`, `customer_contact`, `customer_address`, `order_content`, `total_price`, `total_vat`, `payment_amount`, `order_type`, `payment_method`, `status`, `time`, `date`, `cashier`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("ssssdddssssss", $customer_name, $customer_contact, $customer_address, $order_content, $grand_total, $total_tax, $payment_amount, $order_type, $payment_method, $status, $time, $date, $cashier);
                                if ($stmt->execute()) {
                                    //Receipt loader after process
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Added to Cart',
                                                        text: 'Checkout cart to confirm order',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#00E676',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('home.php');
                                                        }});
                                                })
                                            </script> 
                                        HTML;
                                }
                            }
                        }
                    }
                    ?>
                    <!-- DITO NATAPOS YUNG FORM-->
            </div>
            <div class="totals-box mt-5">
                <hr class="my-2 border-secondary">
                <div class="total-row grand-total">
                    <span>Total</span>
                    <span id="total-amount">₱0.00</span>
                </div>
            </div>

            <button type="submit" name="checkout" class="btn-pay mt-3 shadow-sm" id="checkout" hidden><i class="bi bi-bag-check"></i> Add to Cart</button>
            </form>
        </aside>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Product type tab switching
        $('#productTypeTabs .nav-link').on('click', function() {
            $('#productTypeTabs .nav-link').removeClass('active');
            $(this).addClass('active');

            var product = $(this).data('product');

            $('.product-panel').removeClass('active');
            $('#panel-' + product).addClass('active');
        });
    });
</script>

