<!DOCTYPE html>
<html lang="en">
<?php
require(__DIR__ . '/../dbConn.php');


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}


?>


<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>



<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //Add Account
    if (isset($_POST['adder'])) {

        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $confirmPass = $_POST['confirmPassword'];
        $contact = $_POST['contact'];

        //Note: May possible issue to kapag sa login na kapag same ng email sa employees/HR/Admin/Finance/Customer
        if ($full_name && $email && $pass && $contact) {
            $sql = "SELECT email FROM customers WHERE deleted = 'False'";
            $query = $conn->query($sql);
            $email_checked = True;
            while ($set = $query->fetch_object()) {
                if ($set->email == $email) {
                    $email_checked = False;
                    break;
                }
            }
            if ($email_checked) {
                if (strlen($pass) >= 8 && $confirmPass == $pass) {
                    $pass = password_hash($pass, PASSWORD_DEFAULT); //ENCRYPTS PASSOWRD BEFORE THROWING IT TO DATABASE
                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                    $sql = "INSERT INTO `customers` (`full_name`, `email`, `contact`, `password`) VALUES (?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssss", $full_name, $email, $contact, $pass);
                    if ($stmt->execute()) {
                        //New Employee Notification
                        /*$role_list = array("Admin", "HR");
                            foreach ($role_list as $roles){
                                if($roles=="Admin"){
                                    $sql = "SELECT * FROM admin";
                                }
                                elseif($roles=="HR"){
                                    $sql = "SELECT * FROM employees WHERE role = '".$roles."' AND deleted = 'False'";
                                }
                                $query = $conn->query($sql);
                                while($emp_info = $query->fetch_object()) {
                                    $notif_id = $emp_info->id;
                                    $notif_role = $emp_info->role;
                                    $notif_category = "New Employee Added";
                                    $notif_message = "New ".$role." employee has been added";

                                    if($roles=="HR"){
                                        if($role!="HR"){
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            $stmt->execute();
                                        }
                                    }
                                    elseif($roles=="Admin"){
                                        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                        $stmt->execute();
                                    }
                                    
                                    

                                }
                            }*/
                        echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Account Created!',
                                                text: 'You can now login to your account',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('../login.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                    }
                } else {
                    echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Invalid Password!',
                                            text: 'Password must be atleast 8 characters long And it must match with confirm password',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#e60000',
                                            heightAuto: false
                                        });
                                    })
                                </script>
                            HTML;
                }
            } else {
                echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Email Already in use!',
                                    text: 'Enter a new email',
                                    background: '#112240',
                                    color: '#CCD6F6',
                                    confirmButtonColor: '#e60000',
                                    heightAuto: false
                                });
                            })
                        </script> 
                    HTML;
            }
        }
    }
}
?>

<body>

    <div class="auth-card">

        <img src="../Images/logo.png" alt="Eco Hydrate Hub" class="auth-logo">

        <div class="auth-title"><b>Welcome!</b></div>
        <div class="auth-subtitle">Join the Eco Hydrate Community</div>

        <form action="#" method="POST">

            <div class="auth-field">
                <label for="full_name" class="auth-label">Full Name</label>
                <input type="text" id="full_name" name="full_name" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="email" class="auth-label">Email</label>
                <input type="email" id="email" name="email" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="contact" class="auth-label">Contact</label>
                <input type="text" id="contact" name="contact" class="auth-input" minlength="11" maxlength="11" required>
            </div>

            <div class="auth-field">
                <label for="password" class="auth-label">Password</label>
                <input type="password" id="password" name="password" class="auth-input">
                <div class="auth-hint">At least 8 characters</div>
            </div>

            <div class="auth-field">
                <label for="confirmPassword" class="auth-label">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" class="auth-input" required>
            </div>

            <button type="submit" class="btn-create-account" name="adder">Create account</button>

            <div class="auth-footer">
                Already have an account? <a href="../login.php">Login</a>
            </div>

        </form>

    </div>

</body>

</html>