
<?php
require(__DIR__ . '/../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../login.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}


$user = $_SESSION['users'];

?>


<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>

    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

