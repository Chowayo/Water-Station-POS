<!DOCTYPE html>
<html lang="en">

<?php
require('dbConn.php');


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}

?>


<script>
    //Ensures that arrows are not usable to accessed while logged in
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/sweetalert2@11.js"></script>

</head>

<?php
//This will generate daily attendance list 
//Gets the date of the highest value id and compares it to the Current date and if it detects that it doesn't match it will genereta new attendance row based on the day
$sql = "SELECT date FROM attendance ORDER BY id DESC LIMIT 1";
$query = $conn->query($sql);
$time = $query->fetch_object();

date_default_timezone_set('Asia/Manila');
$current_time = date('H:i:s');

//If attendance is empty then uses the date yesterday to generate new attendance and the loop will start itself again
if ($time) {
    $yesterday = $time->date;
} else {
    $yesterday = date('Y-m-d', strtotime('yesterday'));
}

if ($yesterday < date('Y-m-d')) {
    $sql = "SELECT * FROM employees WHERE deleted = 'False'";
    $query = $conn->query($sql);
    while ($set = $query->fetch_object()) {
        $name = $set->first_name . " " . $set->last_name;
        $id = $set->id;
        $role = $set->role;
        $time_in = "00:00:00";
        $time_out = "00:00:00";
        $status = 'Absent';

        if (strtotime($current_time) > strtotime("07:00:00")) {
            //Clocks in all of the employee before the shift starts allowing them to login again
            $clocked = "in";
            $sql = "UPDATE `employees` SET `clocked` = ? WHERE `id` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $clocked, $id);
            if ($stmt->execute()) {
            }
        }

        //Generates the actual rows of attendance
        $sql = "INSERT INTO `attendance` (`employee_name`, `employee_id`, `role`, `init_in`, `last_out`, `status`) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sissss", $name, $id, $role, $time_in, $time_out, $status);
        if ($stmt->execute()) {
        }
    }
}

//Payroll Generator
//This will only run if it detects that it's the first day of the current month
if (date('d') === '01') {
    $month_num = (int)date('m');
    $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    $month_year = $months[$month_num - 1] . " " . date('Y');
    $sql = "SELECT * FROM payroll WHERE month_year ='" . $month_year . "'";
    $query = $conn->query($sql);
    $one_run = $query->fetch_object();

    if (!$one_run) {
        $sql = "SELECT * FROM employees WHERE role !='HR'";
        $query = $conn->query($sql);
        while ($set = $query->fetch_object()) {
            $name = $set->last_name;
            $id = $set->id;
            $role = $set->role;
            $daily = 0;

            $month_num = (int)date('m');
            $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            $month_year = $months[$month_num - 1] . " " . date('Y');

            if ($role == "Cashier") {
                $daily = 500.00;
            } else if ($role == "Delivery") {
                $daily = 600.00;
            }

            $sql = "INSERT INTO `payroll` (`employee_id`, `employee_name`, `employee_role`, `max_day_pay`, `month_year`) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issds", $id, $name, $role, $daily, $month_year);
            if ($stmt->execute()) {
            }
        }

        //Payroll Notification
        $sql = "SELECT * FROM employees WHERE role = 'HR' AND deleted = 'False'";
        $query = $conn->query($sql);
        while ($emp_info = $query->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;

            $notif_category = "Payroll Due";
            $notif_message = "Employees wages from last month are ready to be given";

            //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '" . $notif_message . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if (!$check) {
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {
                }
            }
        }
    }
}

//Absent but no leave Notification
if ($current_time > "10:00:00") {
    $sql = "SELECT * FROM attendance WHERE status = 'Absent' AND date = CURDATE() and role != 'HR'";
    $query = $conn->query($sql);
    while ($absents = $query->fetch_object()) {
        $absent_with_leave = FALSE;
        $sql = "SELECT * FROM leave_request WHERE status = 'Approved' AND start_date <= CURDATE() AND employee_id = " . $absents->employee_id;
        $querys = $conn->query($sql);
        while ($leave_list = $querys->fetch_object()) {
            // Set start date to today and end date to next Monday
            $startDate = new DateTime($leave_list->start_date);
            $endDate   = new DateTime($leave_list->end_date);
            while ($startDate <= $endDate) {
                if ($startDate->format('Y-m-d') == $absents->date) {
                    //Employee is on a leave
                    $absent_with_leave = TRUE;
                }
                $startDate->modify('+1 day');
            }
        }
        if (!$absent_with_leave) {
            //Absent but no leave Notification
            $sql = "SELECT * FROM employees WHERE role = 'HR'";
            $notif_query = $conn->query($sql);
            while ($emp_info = $notif_query->fetch_object()) {
                $notif_id = $emp_info->id;
                $notif_role = $emp_info->role;
                $notif_category = "Absent Employee";
                $notif_message = "Employee " . $absents->employee_id . " is absent today";

                //No repeation ON THE SAME DAY checker
                $sql = "SELECT * FROM notification WHERE message = '" . $notif_message . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                $checker_query = $conn->query($sql);
                $check = $checker_query->fetch_object();

                if (!$check) {
                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                    if ($stmt->execute()) {
                    }
                }
            }
        }
    }
}

//Absent for the last 3 days without leave
if ($current_time > "10:00:00") {
    $absent_list = [];
    for ($i = 0; $i < 3; $i++) {
        $past_days = date('Y-m-d', strtotime('today - ' . $i . ' day'));

        $sql = "SELECT * FROM attendance WHERE status = 'Absent' AND date = '" . $past_days . "' and role != 'HR'";
        $query = $conn->query($sql);
        while ($absents = $query->fetch_object()) {
            $absent_with_leave = FALSE;
            $sql = "SELECT * FROM leave_request WHERE status = 'Approved' AND start_date <= '" . $past_days . "' AND employee_id = " . $absents->employee_id;
            $querys = $conn->query($sql);
            while ($leave_list = $querys->fetch_object()) {
                // Set start date to today and end date to next Monday
                $startDate = new DateTime($leave_list->start_date);
                $endDate   = new DateTime($leave_list->end_date);
                while ($startDate <= $endDate) {
                    if ($startDate->format('Y-m-d') == $absents->date) {
                        //Employee is on a leave
                        $absent_with_leave = TRUE;
                    }
                    $startDate->modify('+1 day');
                }
            }
            if (!$absent_with_leave) {
                $absent_list[] = $absents->employee_name;
            }
        }

        //Counting absent count in the past 3 days
        $absent_complete_list = array_unique($absent_list);
        foreach ($absent_complete_list as $emp_name) {
            $count = count(array_keys($absent_list, $emp_name));
            if ($count == 3) {
                //Absent with no leave for 3 consecutive days Notification
                $role_list = array("Admin", "HR");
                foreach ($role_list as $role) {
                    if ($role == "Admin") {
                        $sql = "SELECT * FROM admin";
                    } elseif ($role == "HR") {
                        $sql = "SELECT * FROM employees WHERE role = '" . $role . "' AND deleted = 'False'";
                    }

                    $query = $conn->query($sql);
                    while ($emp_info = $query->fetch_object()) {
                        $notif_id = $emp_info->id;
                        $notif_role = $emp_info->role;
                        $notif_category = "Absent Employee in the Last 3 days";
                        $notif_message = "Employee " . $emp_name . " has been absent for 3 condecutive days";

                        //No repeation ON THE SAME DAY checker
                        $sql = "SELECT * FROM notification WHERE message = '" . $notif_message . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                        $checker_querys = $conn->query($sql);
                        $check = $checker_querys->fetch_object();

                        if (!$check) {
                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                            if ($stmt->execute()) {
                            }
                        }
                    }
                }
            }
        }
    }
}

?>

<body>
    <style>
        html,
        body {
            height: 100%;
        }

        body {
            background:
                radial-gradient(circle at 18% 15%, rgba(130, 210, 255, 0.28), transparent 42%),
                radial-gradient(circle at 88% 88%, rgba(46, 154, 204, 0.16), transparent 45%),
                linear-gradient(135deg, #0a192f 0%, #0a192f 38%, #0a192f 68%, #0a192f 100%);
            overflow: hidden;
        }

        .page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .page>.site-nav {
            background: #1e1e1e;
        }

        .login-area {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .pos-footer {
            flex: 0 0 auto;
        }


        .login-book {
            display: flex;
            width: 1080px;
            max-width: 100%;
            border-radius: 28px;
            overflow: hidden;
            box-shadow: 0 30px 70px rgba(0, 20, 50, 0.35);
            background-color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.4);
        }

        .book-left {
            flex: 1;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 65px 50px;
            background-color: #ffffff;
            overflow: hidden;
        }

        .book-left .brand-logo {
            width: 130px;
            height: 130px;
            object-fit: contain;
            border-radius: 50%;
            border: 3px solid #64B5F6;
            background-color: #ffffff;
            margin-bottom: 26px;
            position: relative;
            z-index: 1;
        }

        .book-left h2 {
            font-family: Georgia, 'Times New Roman', serif;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #003366;
            text-align: center;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }

        .book-left .brand-accent {
            color: #28a745;
        }

        .book-left p.tagline {
            color: #64748B;
            text-align: center;
            font-size: 15px;
            max-width: 300px;
            margin: 0;
            position: relative;
            z-index: 1;
        }

        .book-divider {
            width: 2px;
            background: linear-gradient(to bottom, transparent 0%, rgba(0, 51, 102, 0.15) 50%, transparent 100%);
        }

        .book-right {
            flex: 1;
            background-color: #cfe9fb;
            padding: 65px 56px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .book-right h1 {
            font-family: Georgia, 'Times New Roman', serif;
            font-weight: 700;
            font-size: 34px;
            color: #0d2b4e;
            text-align: center;
            margin-bottom: 34px;
        }

        .book-right .form-label {
            font-weight: 600;
            color: #0d2b4e;
            margin-bottom: 6px;
        }

        .book-right .form-control {
            border-radius: 10px;
            border: none;
            padding: 14px 18px;
            font-size: 16px;
            background-color: #ffffff;
        }

        .book-right .form-control:focus {
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.25);
        }

        .book-right .form-check-label {
            color: #0d2b4e;
            font-size: 14px;
        }

        .btn-book-login {
            background-color: #00e676;
            border: none;
            color: #ffffff;
            font-weight: 700;
            letter-spacing: 1px;
            padding: 16px;
            font-size: 16px;
            border-radius: 10px;
            transition: 0.2s;
        }

        .btn-book-login:hover {
            background-color: #28a745;
            color: #ffffff;
        }

        .signup-text {
            font-size: 14px;
            color: #0d2b4e;
        }

        .signup-link {
            color: #0d6efd;
            font-weight: 600;
            text-decoration: none;
        }

        .signup-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 767.98px) {
            .login-book {
                flex-direction: column;
                border-radius: 20px;
            }

            .book-divider {
                width: 100%;
                height: 2px;
                background: linear-gradient(to right, transparent 0%, rgba(0, 51, 102, 0.15) 50%, transparent 100%);
            }

            .book-left {
                padding: 35px 30px 25px;
            }

            .book-left .brand-logo {
                width: 85px;
                height: 85px;
            }

            .book-right {
                padding: 30px 30px 35px;
            }
        }
    </style>

    <div class="page">
        <div class="login-area">
            <div class="login-book">

                <!-- LEFT SIDE -->
                <div class="book-left">
                    <img src="Images/logo.png" alt="Logo" class="brand-logo">
                    <h2><span class="brand-accent">ECO</span> HYDRATE HUB</h2>
                    <p class="tagline">Mineral Water Refill & <br>
                        POS Management System</p>
                </div>

                <div class="book-divider"></div>

                <!-- RIGHT SIDE LOGIN -->
                <div class="book-right">
                    <h1>Login</h1>

                    <form id="loginForm" form method="POST" class="form-group">
                        <div class="mb-3">
                            <label for="username" class="form-label">Email</label>
                            <input type="email" class="form-control" id="username" placeholder="✉︎ example@email.com" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="🔒︎ Your Password" name="password" required>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="rememberMe" name="remember">
                                <label class="form-check-label" for="rememberMe">Remember me</label>
                            </div>

                            <button type="button" class="text-decoration-none small bg-transparent border-0 p-0 fw-semibold" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal" style="color: #0d6efd;">Forgot password?</button>
                        </div>

                        <div class="d-grid">
                            <button type="submit" name="login" class="btn btn-book-login btn-lg">LOGIN</button>
                        </div>

                        <p class="signup-text text-center mt-3 mb-0">
                            Don't have an account yet? <a href="Customer/registration.php" class="signup-link">Sign up here</a>
                        </p>

                    </form>
                </div>

            </div>
        </div>



        <?php
        include 'forgotpass.php';
        ?>


        <?php
        //Login Logic
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $forgot_email = "DUMMY";
            if (isset($_POST['login'])) {
                $email = $_POST['email'];
                $password = $_POST['password'];

                $sql = "SELECT * FROM employees WHERE email = '$email' AND deleted = 'False'";
                $query = $conn->query($sql);
                $result = $query->fetch_object();

                if ($email && $password) {
                    if ($result == NULL) { //Starts Admin login
                        //No Account with the same email for employess:
                        $sql = "SELECT * FROM admin WHERE email = '$email'";
                        $query = $conn->query($sql);
                        $result = $query->fetch_object();
                        if ($result == NULL) {
                            //Customer Login Logic

                            $sql = "SELECT * FROM customers WHERE email = '$email' AND deleted = 'False'";
                            $query = $conn->query($sql);
                            $result = $query->fetch_object();

                            if (!$result) {
                                //Email does not exist in the 3 tables
                                echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Email!'});
                                    </script>";
                            } else {
                                if (password_verify($password, $result->password)) {
                                    $_SESSION['users'] = $result;
                                    echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Login Success!',
                                                    color: '#000000',
                                                    showConfirmButton: false,
                                                });
                                                setTimeout(function() {
                                                    if("{$result->role}"=="Customer"){
                                                        location.assign('Customer/home.php');
                                                    }
                                                }, 900);
                                            });
                                        </script> 
                                    HTML;
                                } else {
                                    //Wrong Customer Password
                                    echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                                    </script>";
                                }
                            }
                        } else {
                            if (password_verify($password, $result->password)) {
                                $_SESSION['users'] = $result;
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Login Success!',
                                                color: '#000000',
                                                showConfirmButton: false,
                                            });
                                            setTimeout(function() {
                                                if("{$result->role}"=="Admin"){
                                                    location.assign('Admin/dashboard.php');
                                                }
                                            }, 900);
                                        });
                                    </script> 
                                    HTML;
                            } else {
                                //Wrong password
                                echo "<script>
                                    Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                                </script>";
                            }
                        }
                        //Employee login logic
                    } else {
                        if (password_verify($password, $result->password)) {
                            if ($result->status == "Active") {
                                //Checks if the user has already clocked-out
                                if ($result->clocked == "in") {
                                    $sql = "SELECT * FROM attendance WHERE employee_id = " . $result->id . " AND date = CURDATE()";
                                    $query = $conn->query($sql);
                                    $check = $query->fetch_object();
                                    $last_entry_time = "21:00:00";
                                    //Hindi na pwedeng mag log in after 10AM kapag and status mo pa is ABSENT
                                    if ($current_time <= $last_entry_time || $check->status != "Absent" || $check->role == "HR") {
                                        $_SESSION['users'] = $result;
                                        //Attendance Logic
                                        if ($result->role != "HR") {
                                            if ($check->status == "Absent") {
                                                date_default_timezone_set('Asia/Manila');
                                                $time_in = date('H:i:s');
                                                $employee_id = $result->id;
                                                $scheduled_time = "08:00:00";

                                                //Status Checker
                                                if ($time_in > $scheduled_time) {
                                                    $status = "Late";

                                                    //Late HR Notification
                                                    $sql = "SELECT * FROM employees WHERE role = 'HR' AND deleted = 'False'";
                                                    $query = $conn->query($sql);
                                                    while ($emp_info = $query->fetch_object()) {
                                                        $notif_id = $emp_info->id;
                                                        $notif_role = $emp_info->role;
                                                        $notif_category = "Employee Late";
                                                        $notif_message = "Employee #" . $result->id . " is late for today";

                                                        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                        if ($stmt->execute()) {
                                                        }
                                                    }
                                                } else {
                                                    $status = "On Time";
                                                }

                                                $sql = "UPDATE `attendance` SET `init_in` = ?, `status` = ? WHERE `employee_id` = ? AND date = CURDATE()";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("ssi", $time_in, $status, $employee_id);
                                                if ($stmt->execute()) {
                                                }
                                            }

                                            //Notification
                                            $sql = "SELECT * FROM employees WHERE role = 'HR'";
                                            $query = $conn->query($sql);
                                            while ($emp_info = $query->fetch_object()) {
                                                $notif_id = $emp_info->id;
                                                $notif_role = $emp_info->role;
                                                $notif_category = "Employee Logged In";
                                                $notif_message = "Employee #" . $result->id . " has logged in their account ";

                                                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                if ($stmt->execute()) {
                                                }
                                            }
                                        }

                                        //Re-route to different dashboards 
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: 'Login Success!',
                                                            color: '#000000',
                                                            showConfirmButton: false,
                                                        });
                                                        setTimeout(function() {
                                                            if("{$result->role}"=="Delivery"){
                                                                location.assign('Employee/confirmation.php');
                                                            }
                                                            else if("{$result->role}"=="Cashier"){
                                                                location.assign('Employee/home.php');
                                                            }
                                                            else if("{$result->role}"=="HR"){
                                                                location.assign('Hr/dashboard.php');
                                                            }
                                                            else if("{$result->role}"=="Financer"){
                                                                location.assign('Finance/dashboard.php');
                                                            }
                                                        }, 900);
                                                    });
                                                </script> 
                                                HTML;
                                    } else {
                                        //DI NA PWEDENG MAG LOGIN KASI LATE
                                        echo "<script>
                                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Time Passed Grace Period!'});
                                        </script>";
                                    }
                                } else {
                                    //Already clocked out
                                    echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Employee Already clocked out for the day!'});
                                    </script>";
                                }
                            } else {
                                //Offline Account
                                echo "<script>
                                    Swal.fire({icon: 'error',title: 'Login Error..',text: 'Deactivated Account!'});
                                </script>";
                            }
                        } else {
                            //Wrong password
                            echo "<script>
                                Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                            </script>";
                        }
                    }
                } else {
                    echo "<script>
                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Empty Input Fields'});
                        </script>";
                }
            }

            if (isset($_POST['forgot'])) {
                $forgot_email = $_POST['forgot_email'];

                //Checks if the email exist in the system
                if (ucfirst(substr($forgot_email, 0, 5)) == "Admin") {
                    $sql = "SELECT email FROM admin";
                } else {
                    $sql = "SELECT email FROM employees";
                }
                $query = $conn->query($sql);
                $email_checked = False;
                while ($set = $query->fetch_object()) {
                    if ($set->email == $forgot_email) {
                        $email_checked = True;
                        break;
                    }
                }

                if ($email_checked) {
                    echo <<<HTML
                    <script>
                        $(document).ready(function() {
                            //Load the reset pass
                            $('#hiddenResetEmail').val('{$forgot_email}');
                            $('#changePassModal').modal('show');
                        });
                    
                    </script>
                    HTML;
                } else {
                    echo <<<HTML
                            <script>
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Invalid Email',
                                    text: 'Please enter your work email',
                                    confirmButtonColor: '#0d6efd',
                                    confirmButtonText: 'Okay',
                                    background: '#FFFFFF',
                                    color: '#1A202C'
                                });
                            </script>
                        HTML;
                }
            }

            if (isset($_POST['change'])) {

                $new_pass = $_POST['new_password'];
                $confirm_pass = $_POST['confirm_password'];
                $forgot_email = $_POST['hidden_email'];

                if ($new_pass && $confirm_pass) {
                    if (strlen($new_pass) >= 8) {
                        //Confirm pass and new pass mathes
                        if ($new_pass == $confirm_pass && $forgot_email != "DUMMY") {
                            //New pass must not match current pass
                            if (ucfirst(substr($forgot_email, 0, 5)) == "Admin") {
                                $sql = "SELECT password FROM admin WHERE email = '" . $forgot_email . "'";
                            } else {
                                $sql = "SELECT password FROM employees WHERE email = '" . $forgot_email . "'";
                            }
                            $query = $conn->query($sql);
                            $result = $query->fetch_object();
                            if (!password_verify($new_pass, $result->password)) {
                                $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process
                                if (ucfirst(substr($forgot_email, 0, 5)) == "Admin") {
                                    $sql = "UPDATE `admin` SET `password` = ? WHERE email = '" . $forgot_email . "'";
                                } else {
                                    $sql = "UPDATE `employees` SET `password` = ? WHERE email = '" . $forgot_email . "'";
                                }
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("s", $password);
                                if ($stmt->execute()) {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: 'Password Updated!',
                                                            text: 'Account password has been updated!.',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#00E676',
                                                            heightAuto: false
                                                        });
                                                    })
                                                </script> 
                                                HTML;
                                }
                            } else {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Password Re-used!',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                showConfirmButton: false,
                                                html:`
                                                    <p>New password must not match with current password!</p>
                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                            })
                                        })
                                    </script> 
                                HTML;
                            }
                        } else {
                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Password Unmatched!',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            showConfirmButton: false,
                                            html:`
                                                <p>New password must match with confirm password!</p>
                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                        })
                                    })
                                </script> 
                            HTML;
                        }
                    } else {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',  
                                            title: 'Invalid New Password!',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            showConfirmButton: false,
                                            html:`
                                                <p>New password must be atleast 8 characters long</p>
                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                        })
                                    });
                                </script> 
                            HTML;
                    }
                }
            }
        }
        ?>

        <?php
        include 'changepass.php';
        ?>

    </div>




    <script>
        const toggle = document.querySelector('.menu-toggle');
        const nav = document.querySelector('.site-nav');
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('menu-open');
            toggle.setAttribute('aria-expanded', open);
        });

        $(document).ready(function() {

            $("#sendResetBtn").click(function() {
                let userEmail = $("#resetEmail").val();

                if (userEmail === "") {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Email Required',
                        text: 'Please enter your email address first.',
                        confirmButtonColor: '#0d6efd',
                        confirmButtonText: 'Okay',
                        background: '#FFFFFF',
                        color: '#1A202C'
                    });
                    return; // Stop here if empty
                }

                $("#hiddenResetEmail").val(userEmail);

                // Hide the Forgot Password
                $("#forgotPasswordModal").modal('hide');

                setTimeout(function() {
                    $("#changePassModal").modal('show');
                }, 500);
            });

        });
    </script>



</body>

</html>