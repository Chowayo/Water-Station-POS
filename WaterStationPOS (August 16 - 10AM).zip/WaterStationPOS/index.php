<?php ?>
<!doctype html>
<html lang="en">


<?php
require('dbConn.php');


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e1e1e">
    <title>Eco Hydrate Hub</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
</head>

<body class="landing-page">
    <main class="site-shell">
        <nav class="site-nav" aria-label="Main navigation">
            <a class="brand" href="#home" aria-label="Eco Hydrate Hub home">
                <img src="Images/logo.png" alt="Eco Hydrate Hub">
            </a>
            <button class="menu-toggle" type="button" aria-label="Toggle menu" aria-expanded="false">
                <i class="bi bi-list"></i>
            </button>
            <div class="nav-content">
                <div class="nav-links">
                    <a class="active" href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#products">Products</a>
                    <a href="#expertise">Expertise</a>
                    <a href="#contact">Contact</a>
                </div>
                <a class="login-btn" href="login.php">Login</a>
            </div>
        </nav>

        <section class="hero-panel" id="home">
            <div class="hero-copy">
                <h1>Thirst<br>for more</h1>
                <p>Eco Hydrate Hub integrates smart monitoring with eco-friendly water distribution. Track consumption, manage station status, and ensure pure, safe drinking water through a single, real-time management platform.</p>
                <a class="start-btn" href="Customer/registration.php">Get Started</a>
            </div>

            <div class="brand-showcase">
                <div class="gallon-stage" aria-hidden="true">
                    <div class="gallon-glow"></div>
                    <img src="Images/Landing%20Page/gallon.png" alt="">
                </div>
                <p class="wordmark"><span>Eco</span> Hydrate</p>
            </div>
        </section>

        <section class="stats-bar" aria-label="Eco Hydrate Hub statistics">
            <div class="stat-item">
                <i class="bi bi-person-heart" aria-hidden="true"></i>
                <p><strong>10,000+</strong><span>Happy Customers</span></p>
            </div>
            <div class="stat-item">
                <i class="bi bi-shop-window" aria-hidden="true"></i>
                <p><strong>10</strong><span>Branches</span></p>
            </div>
            <div class="stat-item">
                <i class="bi bi-truck" aria-hidden="true"></i>
                <p><strong>20,000+</strong><span>Total Services</span></p>
            </div>
            <div class="stat-item">
                <i class="bi bi-people" aria-hidden="true"></i>
                <p><strong>100+</strong><span>Employees</span></p>
            </div>
        </section>

        <section class="products-section" id="products" aria-labelledby="products-title">
            <div class="products-heading">
                <h2 id="products-title">Our products</h2>
                <p>Eco Hydrate tackles the crisis of single-use plastic waste by offering communities a convenient, affordable way to access safe, multi-stage purified drinking water. Driven by a mission to make sustainable living effortless, Eco Hydrate allows customers to refill their existing containers at purchase, durable, reusable ones directly in-store. By replacing single-use plastic with a practical, zero-waste alternative, the store reduces localized pollution and cuts carbon emissions—empowering individuals to protect the planet, one refill at a time.</p>
            </div>
            <div class="product-grid">
                <article class="product-card featured">
                    <div class="product-icon"><i class="bi bi-droplet-fill" aria-hidden="true"></i></div>
                    <h3>Refill</h3>
                    <p style="font-size: medium;"> Bring your own bottles or jugs and top up with fresh, multi-stage purified water for a fast, affordable, zero-waste fix.</p>
                    <a href="index.php">Order now</a>
                </article>
                <article class="product-card">
                    <div class="product-icon"><i class="bi bi-journal-bookmark-fill" aria-hidden="true"></i></div>
                    <h3>Containers</h3>
                    <p style="font-size: medium;">Don't have a bottle? Pick from our durable,
                        BPA-free jugs and stainless steel flasks built for long-lasting, zero-waste hydration.</p>
                    <a href="index.php">Order now</a>
                </article>
            </div>
        </section>
    </main>

    <script>
        const toggle = document.querySelector('.menu-toggle');
        const nav = document.querySelector('.site-nav');
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('menu-open');
            toggle.setAttribute('aria-expanded', open);
        });

        window.addEventListener('scroll', () => {
            nav.classList.toggle('scrolled', window.scrollY > 8);
        });

        // Highlight the nav link for whichever section is currently in view
        const navLinks = document.querySelectorAll('.nav-links a');
        const sections = [...navLinks]
            .map(link => document.querySelector(link.getAttribute('href')))
            .filter(Boolean);

        const spyObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                navLinks.forEach(link => {
                    link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
                });
            });
        }, {
            rootMargin: '-40% 0px -55% 0px', // section counts as "current" once its top crosses the upper-middle of the viewport
            threshold: 0
        });

        sections.forEach(section => spyObserver.observe(section));
    </script>
</body>

</html>