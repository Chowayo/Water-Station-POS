<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<style>
    .menu-link-icon {
        display: inline-block;
        width: 20px;
        margin-right: 10px;
        text-align: center;
        font-size: 15px;
    }

    .menu-group-label {
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
        color: #4d5f82;
        text-transform: uppercase;
        padding: 0 16px;
        margin: 18px 0 6px;
    }

    .menu-group-label:first-child {
        margin-top: 0;
    }
</style>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">

        <div class="sidebar-brand text-center px-3 mb-3">
            <img src="../Images/logo.png" alt="Logo" class="sidebar-brand-logo mb-2">
            <h6 class="sidebar-brand-name mb-0"><span class="green-text">ECO</span> HYDRATE HUB</h6>
        </div>

        <div class="px-3 mb-4">
            <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>
        </div>

        <?php
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>

        <?php
        echo <<<HTML
                <script>
                    $(document).ready(function() {


                        //Sets the visible access of pages when the role is Delivery
                        if("{$result->role}"=="Delivery"){
                            $("#POS").hide();
                            $("#CustomInfo").hide();
                        }

                        //Sets the visible access of pages when the role is Cashier
                        else if("{$result->role}"=="Delivery"){
                            //Empty since cashier can access every present page in the system
                        }
                    });
                </script>
            HTML;
        ?>


        <nav class="nav flex-column px-2">
            <hr class="mx-3 border-secondary mt-0">

            <div class="menu-group-label">Operations</div>
            <a class="menu-link <?php echo $current_page === 'home.php' ? 'active' : ''; ?>" href="home.php" id="POS"><i class="bi bi-shop menu-link-icon"></i>POS</a>
            <a class="menu-link <?php echo $current_page === 'confirmation.php' ? 'active' : ''; ?>" href="confirmation.php" id="OrderConfirm"><i class="bi bi-clipboard-check menu-link-icon"></i>Order Confirmation</a>
            <a class="menu-link <?php echo $current_page === 'customerInfo.php' ? 'active' : ''; ?>" href="customerInfo.php" id="CustomInfo"><i class="bi bi-people menu-link-icon"></i>Customer Information</a>

            <div class="menu-group-label">HR</div>
            <a class="menu-link <?php echo $current_page === 'leaveRequest.php' ? 'active' : ''; ?>" href="leaveRequest.php" id="LeaveReq"><i class="bi bi-calendar2-week menu-link-icon"></i>Leave Requests</a>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout"><i class="bi bi-box-arrow-right menu-link-icon"></i>Logout</a>
    </aside>

    <?php include 'profile.php'; ?>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }
    </script>