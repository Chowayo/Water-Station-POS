<?php
    require 'dbConn.php';

    $user = $_SESSION['users'];

    //clock out time logic
    if($user->role=="Delivery" || $user->role=="Cashier" || $user->role=="Financer"){
        date_default_timezone_set('Asia/Manila'); 
        $time_out = date('H:i:s');
        $employee_id = $user->id;
        
        $sql = "SELECT * FROM attendance WHERE employee_id = " . $employee_id . " AND date = CURDATE()";
        $query = $conn->query($sql);
        $set = $query->fetch_object();

        //Sets the clock_out time
        if($set->last_out=="00:00:00"){
            $sql = "UPDATE `attendance` SET `last_out` = ? WHERE `employee_id` = ? AND date = CURDATE()";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $time_out, $employee_id);
            if ($stmt->execute()) {}
        }

        //Per minute rate
        $month_num = (int)date('m');
        $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        $month_year = $months[$month_num-1]." ".date('Y');
        $sql = "SELECT * FROM payroll WHERE employee_id = " . $employee_id . " AND month_year = '".$month_year."'";
        $query = $conn->query($sql);
        $check = $query->fetch_object();

        $daily = $check->max_day_pay;
        $hour_pay = $daily/9;
        $minute_pay = $hour_pay/60;

        //This is the pay before any type of deduction
        $daily_pay = $check->max_day_pay;


        //Late pay deduction logic
        $time_in = new DateTime($set->init_in);
        $scheduled_time = new DateTime("08:15:00");

        //This will check if the time in is pasts the grace period
        if($time_in>$scheduled_time){

            //Gets the time difference between time_in and grace time 
            $interval_minutes = $scheduled_time->diff($time_in);
            $minute_difference = $interval_minutes->i; 

            //Calculates the deduction amount based on minute difference in time_in
            $late_deduction = $minute_pay*$minute_difference;
            $daily_pay = $daily_pay - $late_deduction;
            
        }


        //Not completed shift deduction logic
        $time_out = new DateTime($set->last_out);
        $scheduled_time = new DateTime("17:00:00");

        //This will check if the time in is NOT past the the shift end
        if($time_out<$scheduled_time){
            //Gets the time difference between time_in and out time 
            $interval_minutes = $time_out->diff($scheduled_time);
            $minute_difference = $interval_minutes->i; 

            //Calculates the deduction amount based on minute difference in time_out
            $early_out_deduction = $minute_pay*$minute_difference;
            $daily_pay = $daily_pay - $early_out_deduction;
        }


        //Updating the payroll row of the employee

        //Gets all of the value before updating them to the latest
        $sql = "SELECT * FROM payroll WHERE employee_id = " . $employee_id . " AND month_year = '".$month_year."'";
        $query = $conn->query($sql);
        $before = $query->fetch_object();

        //Latest value Gross Pay
        $updated_gross = $daily_pay + $before->gross_pay;

        //Latest tax deductions based on new overall gross pay(WILL ONLY REFLECT ON NET)
        $sss = $updated_gross * 0.02;
        $phil_health = $updated_gross * 0.025;
        $pag_ibig = $updated_gross * 0.05;

        //Latest version net Pay 
        $net_pay = $updated_gross - ($sss+$phil_health+$pag_ibig);

        //Last update of date
        $latest_date = date('Y-m-d');


        //Updates the current gross_pay
        $sql = "UPDATE `payroll` SET `gross_pay` = ?, `sss` = ?, `phil_health` = ?, `pag_ibig` = ?, net_pay = ?, `last_updated` = ? WHERE `employee_id` = ? AND `month_year` = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("dddddsss", $updated_gross, $sss, $phil_health, $pag_ibig, $net_pay, $latest_date, $employee_id, $month_year);
        if ($stmt->execute()) {}

        //Clocks out the user that logged out
        //$clocked = "out";
        //$sql = "UPDATE `employees` SET `clocked` = ? WHERE `id` = ?";
        //$stmt = $conn->prepare($sql);
        //$stmt->bind_param("ss", $clocked, $employee_id);
        //if ($stmt->execute()) {}

        //Notification
        $sql = "SELECT * FROM employees WHERE role = 'HR'";
        $query = $conn->query($sql);
        while ($emp_info = $query->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;
            $notif_category = "Employee Logged Out";
            $notif_message = "Employee #" . $employee_id . " has logged out of their account ";

            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {}
        }
    
    }


    session_destroy();
    header('location: login.php');
