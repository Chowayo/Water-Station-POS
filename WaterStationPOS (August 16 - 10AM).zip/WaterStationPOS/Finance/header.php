<!DOCTYPE html>
<html lang="en">

<?php
require(__DIR__ . '/../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../login.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if ($_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}



date_default_timezone_set('Asia/Manila');
$cur_time = new DateTime(date('G:i:s'));
$scheduled_time = new DateTime("16:45:00");

if($cur_time>$scheduled_time){
    //Settlement Notification
    $sql = "SELECT * FROM employees WHERE role = 'Financer' AND deleted = 'False'";
    $query = $conn->query($sql);
    while ($emp_info = $query->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        //Getting TODAY'S settlement
        $sql = "SELECT * FROM settlement_records WHERE date = CURDATE()";
        $query = $conn->query($sql);
        $settlement = $query->fetch_object();
        if($settlement!=NULL){
            $notif_category = "Settlement For Today";
            $notif_message = "Todays system cash is ₱".$settlement->system_cash." and the physical cash is ₱".$settlement->physical_cash;

            //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }

        }
        
    }

    //Net Profit Notification
    $sql = "SELECT * FROM employees WHERE role = 'Financer' AND deleted = 'False'";
    $query = $conn->query($sql);
    while ($emp_info = $query->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        //Getting TODAY'S settlement
        $sql = "SELECT SUM(amount) as expenses FROM transactions WHERE date = CURDATE() AND type = 'Expense'";
        $query = $conn->query($sql);
        $expense = $query->fetch_object();

        $sql = "SELECT SUM(amount) as incomes FROM transactions WHERE date = CURDATE() AND type = 'Income'";
        $query = $conn->query($sql);
        $income = $query->fetch_object();

        $net  = ($income->incomes-$expense->expenses);

        $notif_category = "Net Money For Today";
        $notif_message = "Todays net money is ₱".$net;


        //No repeation ON THE SAME DAY checker
        $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
        $checker_query = $conn->query($sql);
        $check = $checker_query->fetch_object();

        if(!$check){
            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {}
        }
    }

}


//Installment Due TODAY notification
$sql = "SELECT * FROM bills WHERE due_date = CURDATE() AND status = 'Unpaid'";
$query = $conn->query($sql);
while ($bill_due = $query->fetch_object()) {
    $role_list = array("Admin", "Financer");
    foreach ($role_list as $role){
        if($role=="Admin"){
        $sql = "SELECT * FROM admin";
        }
        elseif($role=="Financer"){
        $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False'";
        }

        $querys = $conn->query($sql);
        while ($emp_info = $querys->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;
            $notif_category = "Bill Due Today";
            $notif_message = "Bill #".$bill_due->id." is due today";

           //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }
        }
    }
}


//Installment Due TODAY notification
$sql = "SELECT * FROM bills WHERE due_date < CURDATE() AND status = 'Unpaid'";
$query = $conn->query($sql);
while ($bill_due = $query->fetch_object()) {
    $role_list = array("Admin", "Financer");
    foreach ($role_list as $role){
        if($role=="Admin"){
        $sql = "SELECT * FROM admin";
        }
        elseif($role=="Financer"){
        $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False'";
        }

        $querys = $conn->query($sql);
        while ($emp_info = $querys->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;
            $notif_category = "Bill Passed Due Date";

            $current_date = new DateTime(date('Y-m-d')); 
            $due_date = new DateTime($bill_due->due_date); 

            // Calculate the difference
            $interval = $current_date->diff($due_date);
            $notif_message = "Bill #".$bill_due->id." has been due for ".$interval->days." day(s)";

            //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }
        }
    }
}



$user = $_SESSION['users'];

?>

<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>