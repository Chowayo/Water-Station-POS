<?php

include  'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Employees - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        .search-box-wrap {
            position: relative;
            display: inline-block;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
            font-size: 14px;
        }

        .search-box-wrap input.table-search-input {
            padding-left: 34px;
        }

        /* ===== Scrollable table container ===== */
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <!-- MAIN DASHBOARD CONTENT -->
    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-5 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h1>Employee & Staff Management</h1>
                    </div>
                </div>
            </header>

            <div class="row">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-person-badge me-2"></i>Employee Management</div>
                    <div class="box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1"><i class="bi bi-list-ul me-2"></i>All Employees</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="search-box-wrap">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap"><i class="bi bi-person-plus me-1"></i>Add Employee</button>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#employee_list').DataTable({
                                    paging: true, // Enable pagination
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true, // Enable search functionality
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw(); //Sets the input box as the new search bar
                                });


                            });
                        </script>
                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="employee_list">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //Loading employee list
                                $sql = "SELECT * FROM employees WHERE role !='HR' AND deleted = 'False'";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo "
                                            <tr>
                                            <td>$set->id</td>
                                            <td>$set->first_name $set->last_name </td>
                                            <td>$set->role</td>
                                            <td>$set->email</td>
                                            ";

                                    if ($set->status == "Active") {
                                        echo "<td><span class='status-badge status-active'>$set->status</span></td>";
                                    } else {
                                        echo "<td><span class='status-badge status-inactive'>$set->status</span></td>";
                                    }
                                    //Micheal: yung data-id is nag s-save ng specific points sa loop para ma-seperate sila 
                                    echo "
                                                    <td>
                                                        <button class='btn btn-edit btn-sm rounded-pill px-3 me-1' 
                                                            data-id='{$set->id}' 
                                                            data-fname='{$set->first_name}' 
                                                            data-lname='{$set->last_name}'
                                                            data-role='{$set->role}'
                                                            data-email='{$set->email}'
                                                            data-status='{$set->status}'>
                                                        <i class='bi bi-pencil-square me-1'></i>Edit
                                                        </button>
                                                        <button class='btn btn-remove btn-sm rounded-pill px-3' 
                                                                data-id='{$set->id}'>
                                                            <i class='bi bi-trash me-1'></i>Remove
                                                        </button>
                                                    </td>
                                                    </tr>
                                                    ";
                                }

                                //Sweet Alert pop-up
                                echo <<<HTML
                                    <script>
                                        $('.btn-remove').click(function() {
                                            //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id/email sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                            id = $(this).data('id');

                                            Swal.fire({
                                                title: 'Remove Employee?',
                                                text: 'They will be deleted from the database.',
                                                icon: 'warning',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                showCancelButton: true,
                                                showConfirmButton: false,
                                                cancelButtonColor: '#8892B0',
                                                html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
                                                heightAuto: false
                                            });
                                        });
                                    </script>
                                HTML;

                                // ADD,REMOVE,EDIT Employee data
                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                    //Remove Account
                                    if (isset($_POST['deleter'])) {
                                        $sql = "UPDATE `employees` SET `deleted` = 'True' WHERE id = " . $_POST['deleter'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Employee Deleted!',
                                                                    text: 'The employee has been removed.',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00E676',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('employees.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }

                                    //Add Account
                                    if (isset($_POST['adder'])) {

                                        $fname = $_POST['fname'];
                                        $lname = $_POST['lname'];
                                        $email = $_POST['email'];
                                        $role = $_POST['role'];
                                        $pass = $_POST['password'];

                                        if ($fname && $lname && $email && $role && $pass) {
                                            $sql = "SELECT email FROM employees";
                                            $query = $conn->query($sql);
                                            $email_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->email == $email) {
                                                    $email_checked = False;
                                                    break;
                                                }
                                            }
                                            if ($email_checked) {
                                                if (strlen($pass) >= 8) {
                                                    $pass = password_hash($pass, PASSWORD_DEFAULT); //ENCRYPTS PASSOWRD BEFORE THROWING IT TO DATABASE
                                                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                    $sql = "INSERT INTO `employees` (`first_name`, `last_name`, `email`, `role`, `password`) VALUES (?, ?, ?, ?, ?)";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("sssss", $fname, $lname, $email, $role, $pass);
                                                    if ($stmt->execute()) {

                                                        //New Employee Notification
                                                        $role_list = array("Admin", "HR");
                                                        foreach ($role_list as $roles) {
                                                            if ($roles == "Admin") {
                                                                $sql = "SELECT * FROM admin";
                                                            } elseif ($roles == "HR") {
                                                                $sql = "SELECT * FROM employees WHERE role = '" . $roles . "' AND deleted = 'False'";
                                                            }
                                                            $query = $conn->query($sql);
                                                            while ($emp_info = $query->fetch_object()) {
                                                                $notif_id = $emp_info->id;
                                                                $notif_role = $emp_info->role;
                                                                $notif_category = "New Employee Added";
                                                                $notif_message = "New " . $role . " employee has been added";

                                                                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                                                $stmt = $conn->prepare($sql);
                                                                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                                $stmt->execute();
                                                            }
                                                        }
                                                        echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Employee Added!',
                                                                                text: 'The new employee has been registered.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',
                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('employees.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                                    }
                                                } else {
                                                    echo <<<HTML
                                                                <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Password!',
                                                                    text: 'Password must be atleast 8 characters long',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script>
                                                            HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Email Already in use!',
                                                                    text: 'Enter a new email',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                            }
                                        }
                                    }


                                    if (isset($_POST['editer'])) {

                                        $id = $_POST['id'];
                                        $fname = $_POST['fname'];
                                        $lname = $_POST['lname'];
                                        $email = $_POST['email'];
                                        $role = $_POST['role'];
                                        $status = $_POST['status'];
                                        $pass = isset($_POST['pass']) ? 1 : 0; //1 check, 0 unchecked

                                        if ($id && $fname && $lname && $email && $role && $status) {
                                            $sql = "SELECT email FROM employees WHERE id !=" . $id; //Para di nya check yung sarili nya yung iba lang na email
                                            $query = $conn->query($sql);
                                            $email_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->email == $email) {
                                                    $email_checked = False;
                                                    break;
                                                }
                                            }
                                            if ($email_checked) {
                                                if ($pass == 1) {
                                                    //Reset password process
                                                    $default = "12345678"; //Password after reset
                                                    $password = password_hash($default, PASSWORD_DEFAULT); //Encryp process
                                                    $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ?, `password` = ? WHERE id = '" . $id . "'";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("ssssss", $fname, $lname, $email, $role, $status, $password);
                                                } else {
                                                    //Not reset
                                                    $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ? WHERE id = '" . $id . "'";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("sssss", $fname, $lname, $email, $role, $status);
                                                }

                                                if ($stmt->execute()) {
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Employee Edited!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Email Already in use!',
                                                                            text: 'Enter a new email',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                            HTML;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role" required>
                                <option value="" disabled selected>Select a role...</option>
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery">Delivery Driver</option>
                                <option value="Financer">Financer</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Temporary Password</label>
                            <input type="password" class="form-control" name="password" value="12345678" required placeholder="Enter a default password">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn"><i class="bi bi-check2-circle me-1"></i>Save Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">

                        <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos" id="edit-fname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos" id="edit-lname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com" id="edit-email">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role">
                                <option id="edit-role" selected></option>
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery">Delivery Driver</option>
                                <option value="Financer">Financer</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option id="edit-status" selected></option>
                                <option value="Active">Active</option>
                                <option value="Offline">Offline</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Reset Password</label>
                            <input type="checkbox" name="pass">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn"><i class="bi bi-check2-circle me-1"></i>Update Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('.btn-edit').click(function() {

            //Used to pre-load the edit section since it's not connected to PHP
            id = $(this).data('id');
            fname = $(this).data('fname');
            lname = $(this).data('lname');
            email = $(this).data('email');
            role = $(this).data('role');
            status = $(this).data('status');

            $("#edit-id").val(id);
            $("#edit-fname").val(fname);
            $("#edit-lname").val(lname);
            $("#edit-email").val(email);
            $("#edit-role").text(role);
            $("#edit-status").text(status);
        });

        $(document).ready(function() {

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'><i class='bi bi-box-arrow-right me-1'></i>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'><i class='bi bi-x-lg me-1'></i>Cancel</button>",
                    heightAuto: false
                });
            });


            $(".btn-edit").click(function() {
                $('#editEmployeeModal').modal('show');
            });

            $(".btn-add").click(function() {
                $('#addEmployeeModal').modal('show');
            });




        });
    </script>