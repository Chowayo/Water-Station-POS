<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

// Date filter for this page: falls back to today if missing/invalid
$filter_date = (isset($_GET['filter_date']) && DateTime::createFromFormat('Y-m-d', $_GET['filter_date']) !== false)
    ? $_GET['filter_date']
    : date('Y-m-d');
?>

<head>
    <title>Attendance - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">

    <style>
        .status-badge-attendance {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            display: inline-block;
        }

        .status-ontime {
            background-color: rgba(0, 230, 118, 0.1);
            color: #00E676;
            border: 1px solid #00E676;
        }

        .status-present {
            background-color: rgba(100, 255, 218, 0.1);
            color: #64FFDA;
            border: 1px solid #64FFDA;
        }

        .status-late {
            background-color: rgba(255, 193, 7, 0.1);
            color: #FFC107;
            border: 1px solid #FFC107;
        }

        .status-absent {
            background-color: rgba(255, 82, 82, 0.1);
            color: #FF5252;
            border: 1px solid #FF5252;
        }

        .search-box-wrap {
            position: relative;
            display: inline-block;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
            font-size: 14px;
        }

        .search-box-wrap input.table-search-input {
            padding-left: 34px;
        }

        /* ===== Scrollable table container ===== */
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h1>Attendance Management</h1>
                    </div>
                </div>
            </header>

            <!-- Summary Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Attendance Management/Attendance.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Employees Scheduled Today</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM employees WHERE status = 'Active' AND deleted = 'False' AND role != 'HR'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Attendance Management/Employees_clocked_in.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Employees Clocked In</div>
                        <div class="dash-value cyan-text">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status != 'Absent' AND date = '" . $conn->real_escape_string($filter_date) . "'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Attendance Management/Absentees.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Absentees</div>
                        <div class="dash-value" style="color: #FF5252;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status = 'Absent' AND date = '" . $conn->real_escape_string($filter_date) . "'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-header"><i class="bi bi-clock-history me-2"></i>Attendance Tracking Overview</div>

            <!-- Daily Attendance Log -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1"><i class="bi bi-list-check me-2"></i>Daily Attendance Log <span class="small fw-normal" style="color: #8892B0;">(<?php echo date('M d, Y', strtotime($filter_date)); ?>)</span></h5>

                            <div class="d-flex flex-wrap gap-2 align-items-center">
                                <form method="GET" class="d-flex gap-2 align-items-center mb-0">
                                    <input type="date" name="filter_date" class="form-control" value="<?php echo htmlspecialchars($filter_date); ?>" onchange="this.form.submit()" style="max-width: 180px;">
                                    <?php if ($filter_date !== date('Y-m-d')): ?>
                                        <a href="attendance.php" class="btn btn-sm btn-outline-light rounded-pill px-3"><i class="bi bi-arrow-counterclockwise me-1"></i>Today</a>
                                    <?php endif; ?>
                                </form>

                                <div class="search-box-wrap">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                                </div>
                            </div>
                        </div>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="attendance_list">
                            <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Employee ID</th>
                                    <th>Role</th>
                                    <th>Initial Login Time</th>
                                    <th>Last Log Out Time</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //Loader of todays attendance
                                $sql = "SELECT * FROM attendance WHERE date = '" . $conn->real_escape_string($filter_date) . "' AND role != 'HR'";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                                    <tr>
                                                        <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                        <td><strong class="d-block">' . $set->employee_id . '</strong></td>
                                                        <td>' . $set->role . '</td>
                                                        <td>' . $set->init_in . '</td>
                                                        <td>' . $set->last_out . '</td>
                                                        ';
                                    //<td><span class="status-badge-attendance status-ontime">On Time</span></td>
                                    if ($set->status == "On Time") {
                                        echo '<td><span class="status-badge-attendance status-ontime">On Time</span></td>';
                                    } else if ($set->status == "Late") {
                                        echo '<td><span class="status-badge-attendance status-late">Late</span></td>';
                                    } else if ($set->status == "Absent") {
                                        echo '<td><span class="status-badge-attendance status-absent">Absent</span></td>';
                                    }
                                    echo '       
                                                        <td><strong class="d-block">' . $set->date . '</strong></td>
                                                    </tr>         
                                                ';
                                }


                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            var table = $('#attendance_list').DataTable({
                paging: true,
                pageLength: 8,
                lengthChange: false,
                searching: true,
                ordering: false,
                dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
            });

            $('#searcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of HR Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'><i class='bi bi-box-arrow-right me-1'></i>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'><i class='bi bi-x-lg me-1'></i>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>