<?php
include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Leave Requests - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        .leave-filter-tabs {
            display: flex;
            gap: 8px;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .leave-filter-tabs .nav-link {
            background-color: #0A192F;
            border: 1px solid #233554;
            color: #8892B0;
            font-weight: 600;
            font-size: 13px;
            padding: 6px 16px;
            border-radius: 20px;
            cursor: pointer;
            transition: 0.2s;
        }

        .leave-filter-tabs .nav-link:hover {
            border-color: #64FFDA;
            color: #CCD6F6;
        }

        .leave-filter-tabs .nav-link.active {
            background-color: rgba(100, 255, 218, 0.12);
            border-color: #64FFDA;
            color: #64FFDA;
        }

        .search-box-wrap {
            position: relative;
            display: inline-block;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
            font-size: 14px;
        }

        .search-box-wrap input.table-search-input {
            padding-left: 34px;
        }

        /* ===== Scrollable table container ===== */
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h1>Leave Requests Management</h1>
                    </div>
                </div>
            </header>

            <!-- Summary cards stats -->
            <div class="row g-4 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Leave Request Management/Total_Requests.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Requests</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM leave_request";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Leave Request Management/pending.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Pending</div>
                        <div class="dash-value" style="color: #FFC107;">
                            <?php
                            $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Pending'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Leave Request Management/approve.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Approved</div>
                        <div class="dash-value green-text" style="color: #45f500;">
                            <?php
                            $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Approved'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Leave Request Management/rejected.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Rejected</div>
                        <div class="dash-value" style="color: #FF5252;">
                            <?php
                            $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Rejected'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- All leave requests -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-journal-text me-2"></i>All Leave Requests</div>
                    <div class="manage-box shadow-sm">

                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <ul class="leave-filter-tabs" id="leaveFilterTabs">
                                <li><button type="button" class="nav-link active" data-filter="all">All</button></li>
                                <li><button type="button" class="nav-link" data-filter="Pending">Pending</button></li>
                                <li><button type="button" class="nav-link" data-filter="Approved">Approved</button></li>
                                <li><button type="button" class="nav-link" data-filter="Rejected">Rejected</button></li>
                            </ul>
                            <div class="search-box-wrap">
                                <i class="bi bi-search"></i>
                                <input type="text" class="form-control table-search-input" placeholder="Search employee" id="searcher">
                            </div>
                        </div>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="leave_list">
                            <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Employee Role</th>
                                    <th>Leave Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Reason</th>
                                    <th>Date Submitted</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM leave_request";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                                <tr data-status="' . $set->status . '">
                                                    <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                    <td><strong class="d-block">' . $set->employee_role . '</strong></td>
                                                    <td>' . $set->leave_type . '</td>
                                                    <td>' . $set->start_date . '</td>
                                                    <td>' . $set->end_date . '</td>
                                                    <td><button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3 view-reason-btn" data-reason="' . htmlspecialchars($set->reason, ENT_QUOTES) . '" data-bs-toggle="modal" data-bs-target="#viewReasonModal"><i class="bi bi-eye me-1"></i>View</button></td>
                                                    <td>' . $set->submission_date . '</td>';

                                    if ($set->status == "Pending") {
                                        echo '
                                                    <td><span class="badge" style="background-color: rgba(255, 193, 7, 0.15); color: #a17c00; border: 1px solid rgba(255, 193, 7, 0.4);">Pending</span></td>
                                                    
                                                    <td>
                                                        <div class="d-flex gap-2 justify-content-center">
                                                            <form method="POST" class="m-0"><button type="submit" name="approve" value="' . $set->id . '" class="btn btn-confirm btn-sm rounded-pill px-3"><i class="bi bi-check2 me-1"></i>Approve</button></form>
                                                            <form method="POST" class="m-0"><button type="submit" name="reject" value="' . $set->id . '" class="btn btn-delete btn-sm rounded-pill px-3"><i class="bi bi-x-lg me-1"></i>Reject</button></form>
                                                        </div>
                                                    </td>';
                                    } else if ($set->status == "Approved") {
                                        echo '
                                                <td><span class="badge" style="background-color: rgba(40, 167, 69, 0.1); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.3);">Approved</span></td>
                                                <td>
                                                    <button class="btn btn-closed btn-sm rounded-pill px-3" disabled><i class="bi bi-check2-circle me-1"></i>Already Approved</button>
                                                </td>';
                                    } else if ($set->status == "Rejected") {
                                        echo '<td><span class="badge" style="background-color: rgba(220, 53, 69, 0.1); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.3);">Rejected</span></td>
                                                    <td>
                                                        <button class="btn btn-closed btn-sm rounded-pill px-3" disabled><i class="bi bi-x-circle me-1"></i>Already Rejected</button>
                                                    </td>';
                                    }

                                    echo '</tr>';
                                }


                                //Refect and Approve process

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                    //Remove Account
                                    if (isset($_POST['approve'])) {
                                        $sql = "UPDATE `leave_request` SET `status` = 'Approved' WHERE id = " . $_POST['approve'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Leave Request Approve!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('leave.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;

                                            //Notification
                                            $sql = "SELECT * FROM leave_Request WHERE id = " . $_POST['approve'];
                                            $query = $conn->query($sql);
                                            $emp_info = $query->fetch_object();

                                            $notif_id = $emp_info->employee_id;
                                            $notif_role = $emp_info->employee_role;
                                            $notif_category = "Leave Request Approved";
                                            $notif_message = "Your leave Rquest has been approved by Human Resource";

                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            if ($stmt->execute()) {
                                            }
                                        }
                                    }

                                    if (isset($_POST['reject'])) {
                                        $sql = "UPDATE `leave_request` SET `status` = 'Rejected' WHERE id = " . $_POST['reject'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Leave Request Rejected!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('leave.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;

                                            //Notification
                                            $sql = "SELECT * FROM leave_Request WHERE id = " . $_POST['reject'];
                                            $query = $conn->query($sql);
                                            $emp_info = $query->fetch_object();

                                            $notif_id = $emp_info->employee_id;
                                            $notif_role = $emp_info->employee_role;
                                            $notif_category = "Leave Request Rejected";
                                            $notif_message = "Your leave Rquest has been rejected by Human Resource";

                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            if ($stmt->execute()) {
                                            }
                                        }
                                    }
                                }
                                ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <!-- View Reason Modal  -->
    <div class="modal fade" id="viewReasonModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-chat-left-text me-2"></i>Leave Reason</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0" id="viewReasonText" style="word-break: break-word; overflow-wrap: break-word;"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-auto" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var table = $('#leave_list').DataTable({
                paging: true,
                pageLength: 8,
                lengthChange: false,
                searching: true,
                ordering: false,
                dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
            });

            $('#searcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });

            var activeFilter = 'all';

            $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
                if (settings.nTable.id !== 'leave_list') return true;
                if (activeFilter === 'all') return true;
                var row = table.row(dataIndex).node();
                return $(row).data('status') === activeFilter;
            });

            $('#leaveFilterTabs .nav-link').on('click', function() {
                $('#leaveFilterTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                activeFilter = $(this).data('filter');
                table.draw();
            });

            $('#viewReasonModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                $('#viewReasonText').text(button.data('reason'));
            });
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of HR Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'><i class='bi bi-box-arrow-right me-1'></i>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'><i class='bi bi-x-lg me-1'></i>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>