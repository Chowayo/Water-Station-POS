<?php
include 'header.php';
?>

<head>
    <title>Job Postings - HR Dashboard</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        :root {
            --bg: #0A192F;
            --card-bg: #112240;
            --card-bg-hover: #16294a;
            --border: rgba(100, 255, 218, 0.12);
            --text-main: #CCD6F6;
            --text-muted: #8892B0;
            --accent-green: #00E676;
            --accent-green-dark: #00A859;
            --accent-cyan: #64FFDA;
            --accent-amber: #FFC107;
            --accent-red: #FF5252;
        }

        body {
            background-color: var(--bg);
            color: var(--text-main);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
        }

        .top-text h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0;
        }

        .top-text p {
            color: var(--text-muted);
            margin: 4px 0 0;
            font-size: 0.9rem;
        }

        .btn-add-job {
            background: linear-gradient(135deg, var(--accent-green) 0%, var(--accent-green-dark) 100%);
            border: none;
            color: #06210F;
            font-weight: 700;
            padding: 10px 20px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
        }

        .btn-add-job:hover {
            filter: brightness(1.08);
            color: #06210F;
            transform: translateY(-1px);
        }

        /* Filters  */
        .filter-bar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .filter-bar .form-select,
        .filter-bar .form-control {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .filter-bar .form-select:focus,
        .filter-bar .form-control:focus {
            background-color: var(--card-bg);
            border-color: var(--accent-cyan);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.15);
        }

        .filter-bar .form-control::placeholder {
            color: var(--text-muted);
        }

        .search-box-wrap {
            position: relative;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 14px;
            pointer-events: none;
        }

        .search-box-wrap input {
            padding-left: 34px;
            min-width: 220px;
        }

        /* Job Card  */
        .job-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            height: 100%;
            display: flex;
            flex-direction: column;
            transition: 0.2s ease;
        }

        .job-card:hover {
            background-color: var(--card-bg-hover);
            border-color: rgba(100, 255, 218, 0.35);
            transform: translateY(-2px);
        }

        .job-card-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 10px;
        }

        .job-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #FFFFFF;
            margin: 0 0 2px;
        }

        .job-dept {
            font-size: 0.8rem;
            color: var(--accent-cyan);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .status-pill {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 999px;
            white-space: nowrap;
        }

        .status-open {
            background-color: rgba(0, 230, 118, 0.12);
            color: var(--accent-green);
            border: 1px solid rgba(0, 230, 118, 0.35);
        }

        .status-draft {
            background-color: rgba(255, 193, 7, 0.12);
            color: var(--accent-amber);
            border: 1px solid rgba(255, 193, 7, 0.35);
        }

        .status-closed {
            background-color: rgba(255, 82, 82, 0.12);
            color: var(--accent-red);
            border: 1px solid rgba(255, 82, 82, 0.35);
        }

        .job-meta {
            display: flex;
            flex-direction: column;
            gap: 6px;
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 14px;
        }

        .job-meta span i {
            width: 16px;
            color: var(--accent-cyan);
            margin-right: 6px;
        }

        .job-desc-preview {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 16px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
            flex-grow: 1;
        }

        .job-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-top: 1px solid var(--border);
            padding-top: 12px;
            margin-top: auto;
        }

        .applicants-count {
            font-size: 0.8rem;
            color: var(--text-muted);
        }

        .applicants-count strong {
            color: var(--text-main);
        }

        .job-card-actions .btn {
            font-size: 0.78rem;
            padding: 5px 12px;
            border-radius: 8px;
        }

        .btn-view {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .btn-view:hover {
            border-color: var(--accent-cyan);
            color: var(--accent-cyan);
        }

        .btn-edit {
            background: transparent;
            border: 1px solid rgba(255, 193, 7, 0.4);
            color: var(--accent-amber);
        }

        .btn-edit:hover {
            background-color: rgba(255, 193, 7, 0.1);
            color: var(--accent-amber);
        }

        /* ===== Modal ===== */
        .modal-content {
            background-color: var(--card-bg);
            color: var(--text-main);
            border: 1px solid var(--border);
            border-radius: 16px;
        }

        .modal-header {
            border-bottom: 1px solid var(--border);
        }

        .modal-footer {
            border-top: 1px solid var(--border);
        }

        .modal-title {
            font-weight: 700;
            color: #FFFFFF;
        }

        .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }

        .form-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-muted);
            margin-bottom: 6px;
        }

        .form-control,
        .form-select {
            background-color: #0A192F;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .form-control:focus,
        .form-select:focus {
            background-color: #0A192F;
            border-color: var(--accent-cyan);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(100, 255, 218, 0.15);
        }

        .form-control::placeholder {
            color: #52618a;
        }

        .section-divider {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--accent-cyan);
            margin: 4px 0 12px;
            padding-top: 8px;
            border-top: 1px solid var(--border);
        }

        .section-divider:first-child {
            border-top: none;
            padding-top: 0;
        }

        .btn-cancel {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text-main);
        }

        .btn-cancel:hover {
            color: var(--text-main);
            border-color: var(--accent-red);
        }

        .btn-save {
            background: linear-gradient(135deg, var(--accent-green) 0%, var(--accent-green-dark) 100%);
            border: none;
            color: #06210F;
            font-weight: 700;
        }

        .btn-save:hover {
            filter: brightness(1.08);
            color: #06210F;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--text-muted);
        }

        .empty-state i {
            font-size: 2.5rem;
            color: var(--accent-cyan);
            margin-bottom: 12px;
            display: block;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <h1><i class="bi bi-briefcase-fill me-2"></i>Job Postings</h1>
                    <p>Create and manage open positions for the company</p>
                </div>
                <button type="button" class="btn btn-add-job" data-bs-toggle="modal" data-bs-target="#addJobModal">
                    <i class="bi bi-plus-lg"></i> Add Job Posting
                </button>
            </header>

            <!-- Filters -->
            <div class="filter-bar mb-4">
                <div class="search-box-wrap">
                    <i class="bi bi-search"></i>
                    <input type="text" class="form-control" placeholder="Search job title...">
                </div>
                <select class="form-select" style="max-width: 180px;">
                    <option selected>All Departments</option>
                    <option>Human Resources</option>
                    <option>Operations</option>
                    <option>Logistics</option>
                    <option>Finance</option>
                    <option>IT</option>
                </select>
                <select class="form-select" style="max-width: 160px;">
                    <option selected>All Status</option>
                    <option>Open</option>
                    <option>Draft</option>
                    <option>Closed</option>
                </select>
            </div>

            <!-- Job Cards Grid -->
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-6 col-lg-4">
                    <div class="job-card">
                        <div class="job-card-top">
                            <div>
                                <div class="job-dept">Operations</div>
                                <h3 class="job-title">Delivery Rider</h3>
                            </div>
                            <span class="status-pill status-open">Open</span>
                        </div>
                        <div class="job-meta">
                            <span><i class="bi bi-geo-alt"></i>Dasmariñas, Cavite</span>
                            <span><i class="bi bi-clock"></i>Full-time</span>
                            <span><i class="bi bi-cash-stack"></i>₱15,000 - ₱18,000</span>
                        </div>
                        <p class="job-desc-preview">Responsible for timely delivery of water containers to residential and commercial customers within the assigned area.</p>
                        <div class="job-card-footer">
                            <div class="applicants-count"><strong>8</strong> applicants</div>
                            <div class="job-card-actions d-flex gap-2">
                                <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal">View</button>
                                <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal">Edit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-6 col-lg-4">
                    <div class="job-card">
                        <div class="job-card-top">
                            <div>
                                <div class="job-dept">Human Resources</div>
                                <h3 class="job-title">HR Assistant</h3>
                            </div>
                            <span class="status-pill status-open">Open</span>
                        </div>
                        <div class="job-meta">
                            <span><i class="bi bi-geo-alt"></i>Head Office</span>
                            <span><i class="bi bi-clock"></i>Full-time</span>
                            <span><i class="bi bi-cash-stack"></i>₱18,000 - ₱22,000</span>
                        </div>
                        <p class="job-desc-preview">Support day-to-day HR operations including recruitment coordination, employee records, and attendance monitoring.</p>
                        <div class="job-card-footer">
                            <div class="applicants-count"><strong>14</strong> applicants</div>
                            <div class="job-card-actions d-flex gap-2">
                                <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal">View</button>
                                <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal">Edit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-6 col-lg-4">
                    <div class="job-card">
                        <div class="job-card-top">
                            <div>
                                <div class="job-dept">Finance</div>
                                <h3 class="job-title">Accounting Clerk</h3>
                            </div>
                            <span class="status-pill status-draft">Draft</span>
                        </div>
                        <div class="job-meta">
                            <span><i class="bi bi-geo-alt"></i>Head Office</span>
                            <span><i class="bi bi-clock"></i>Full-time</span>
                            <span><i class="bi bi-cash-stack"></i>₱17,000 - ₱20,000</span>
                        </div>
                        <p class="job-desc-preview">Handle daily transaction recording, invoice processing, and assist with monthly financial reports.</p>
                        <div class="job-card-footer">
                            <div class="applicants-count"><strong>0</strong> applicants</div>
                            <div class="job-card-actions d-flex gap-2">
                                <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal">View</button>
                                <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal">Edit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 4 -->
                <div class="col-md-6 col-lg-4">
                    <div class="job-card">
                        <div class="job-card-top">
                            <div>
                                <div class="job-dept">Logistics</div>
                                <h3 class="job-title">Warehouse Staff</h3>
                            </div>
                            <span class="status-pill status-open">Open</span>
                        </div>
                        <div class="job-meta">
                            <span><i class="bi bi-geo-alt"></i>Main Warehouse</span>
                            <span><i class="bi bi-clock"></i>Full-time</span>
                            <span><i class="bi bi-cash-stack"></i>₱14,000 - ₱16,000</span>
                        </div>
                        <p class="job-desc-preview">Assist with inventory handling, loading and unloading of stock, and warehouse organization.</p>
                        <div class="job-card-footer">
                            <div class="applicants-count"><strong>5</strong> applicants</div>
                            <div class="job-card-actions d-flex gap-2">
                                <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal">View</button>
                                <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal">Edit</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card 5 -->
                <div class="col-md-6 col-lg-4">
                    <div class="job-card">
                        <div class="job-card-top">
                            <div>
                                <div class="job-dept">IT</div>
                                <h3 class="job-title">IT Support Specialist</h3>
                            </div>
                            <span class="status-pill status-closed">Closed</span>
                        </div>
                        <div class="job-meta">
                            <span><i class="bi bi-geo-alt"></i>Head Office</span>
                            <span><i class="bi bi-clock"></i>Full-time</span>
                            <span><i class="bi bi-cash-stack"></i>₱20,000 - ₱25,000</span>
                        </div>
                        <p class="job-desc-preview">Maintain company systems, troubleshoot hardware/software issues, and support POS terminals across branches.</p>
                        <div class="job-card-footer">
                            <div class="applicants-count"><strong>21</strong> applicants</div>
                            <div class="job-card-actions d-flex gap-2">
                                <button type="button" class="btn btn-view" data-bs-toggle="modal" data-bs-target="#viewJobModal">View</button>
                                <button type="button" class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#addJobModal">Edit</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </section>
    </main>

    <!-- Add / Edit Job Modal -->
    <div class="modal fade" id="addJobModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-briefcase-fill me-2"></i>Add Job Posting</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="jobPostingForm">

                        <div class="section-divider">Job Details</div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-8">
                                <label class="form-label">Job Title</label>
                                <input type="text" class="form-control" placeholder="e.g. HR Assistant">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Department</label>
                                <select class="form-select">
                                    <option selected disabled>Select department</option>
                                    <option>Human Resources</option>
                                    <option>Operations</option>
                                    <option>Logistics</option>
                                    <option>Finance</option>
                                    <option>IT</option>
                                </select>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Employment Type</label>
                                <select class="form-select">
                                    <option selected disabled>Select type</option>
                                    <option>Full-time</option>
                                    <option>Part-time</option>
                                    <option>Contract</option>
                                    <option>Internship</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Location</label>
                                <input type="text" class="form-control" placeholder="e.g. Head Office">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">No. of Openings</label>
                                <input type="number" class="form-control" min="1" placeholder="1">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Salary Range (Min)</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color:#0A192F; border-color: var(--border); color: var(--text-muted);">₱</span>
                                    <input type="number" class="form-control" placeholder="15000">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Salary Range (Max)</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color:#0A192F; border-color: var(--border); color: var(--text-muted);">₱</span>
                                    <input type="number" class="form-control" placeholder="20000">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Application Deadline</label>
                                <input type="date" class="form-control">
                            </div>
                        </div>

                        <div class="section-divider">Job Description</div>
                        <div class="mb-3">
                            <label class="form-label">Overview</label>
                            <textarea class="form-control" rows="3" placeholder="Briefly describe the role and its purpose..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Key Responsibilities</label>
                            <textarea class="form-control" rows="4" placeholder="List the main duties and responsibilities..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Qualifications & Requirements</label>
                            <textarea class="form-control" rows="4" placeholder="List required education, skills, and experience..."></textarea>
                        </div>

                        <div class="section-divider">Posting Settings</div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Status</label>
                                <select class="form-select">
                                    <option selected>Draft</option>
                                    <option>Open</option>
                                    <option>Closed</option>
                                </select>
                            </div>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-save"><i class="bi bi-check-lg me-1"></i>Save Job Posting</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Job Modal -->
    <div class="modal fade" id="viewJobModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-eye-fill me-2"></i>Job Posting Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted mb-0">Job details </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

</body>

</html>