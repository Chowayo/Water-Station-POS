<?php
include 'header.php';
$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>HR Dashboard - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <!--<link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">-->

    <style>
        /* ===== Modern KPI cards ===== */
        .dash-card-modern {
            text-align: left;
        }

        .kpi-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            background-color: transparent;
        }

        .kpi-icon svg {
            width: 20px;
            height: 20px;
        }

        .kpi-icon-green,
        .kpi-icon-cyan,
        .kpi-icon-amber {
            background-color: transparent;
        }

        .trend-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 12px;
            font-weight: 700;
            margin-top: 6px;
        }

        .trend-badge svg {
            width: 12px;
            height: 12px;
        }

        .kpi-icon-img {
            width: 12px;
            height: 12px;
            object-fit: contain;
            vertical-align: middle;
            flex-shrink: 0;
        }

        .kpi-icon .kpi-icon-img {
            width: 40px;
            height: 40px;
        }

        .trend-up {
            color: #00E676;
        }

        .trend-down {
            color: #FF5252;
        }

        .trend-down svg {
            transform: scaleY(-1);
        }

        .sparkline {
            width: 100%;
            height: 30px;
            margin-top: 10px;
            display: block;
        }

        /* ===== Chart card / bar chart ===== */
        .chart-card {
            padding: 25px;
        }

        .bar-chart {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 12px;
            height: 160px;
            margin-top: 10px;
        }

        .bar-col {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-end;
            height: 100%;
        }

        .bar {
            width: 60%;
            max-width: 34px;
            background: linear-gradient(180deg, #64FFDA 0%, #00A3A3 100%);
            border-radius: 8px 8px 0 0;
            transition: 0.2s;
        }

        .bar-col:hover .bar {
            filter: brightness(1.2);
        }

        .bar-value {
            font-size: 11px;
            color: #8892B0;
            margin-bottom: 4px;
            font-weight: 700;
        }

        .bar-label {
            font-size: 12px;
            color: #8892B0;
            margin-top: 8px;
            font-weight: 600;
        }

        /* ===== Donut chart (CSS conic-gradient, no library needed) ===== */
        .donut-wrap {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            height: 100%;
        }

        .donut {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .donut-center {
            width: 92px;
            height: 92px;
            border-radius: 50%;
            background-color: #112240;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .donut-center .value {
            font-size: 20px;
            font-weight: 800;
            color: #FFFFFF;
        }

        .donut-center .label {
            font-size: 11px;
            color: #8892B0;
        }

        .donut-legend {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .donut-legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #CCD6F6;
        }

        .donut-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        @media (max-width: 767.98px) {
            .donut-wrap {
                flex-direction: column;
                gap: 16px;
            }

            .bar-chart {
                height: 130px;
            }
        }

        .search-box-wrap {
            position: relative;
            display: inline-block;
        }

        .search-box-wrap .bi-search {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
            font-size: 14px;
        }

        .search-box-wrap input.table-search-input {
            padding-left: 34px;
        }

        /* ===== Scrollable table container ===== */
        .table-scroll-wrap {
            max-height: 400px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h1>HR Dashboard</h1>
                    </div>
                </div>
            </header>

            <div class="row g-4 mb-4 justify-content-center">

                <div class="col-md-4">
                    <div class="dash-card dash-card-modern">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="dash-title">Total Employees</div>
                                <div class="dash-value green-text">
                                    <?php
                                    $sql = "SELECT COUNT(id) AS total FROM employees WHERE deleted = 'False' AND role!='HR'";
                                    $query = $conn->query($sql);
                                    $set = $query->fetch_object();
                                    echo $set->total;
                                    ?></div>
                                <div class="trend-badge trend-up">
                                    <?php
                                    $sql = "SELECT COUNT(id) AS total FROM employees WHERE status = 'Active' AND deleted = 'False' AND role!='HR'";
                                    $query = $conn->query($sql);
                                    $act = $query->fetch_object();

                                    $active = (int)$act->total;
                                    $total_active = (int)$set->total;
                                    $inactive = $total_active - $active;

                                    echo "Active: " . $active . " Inactive: " . $inactive;


                                    ?>

                                </div>
                            </div>
                            <div class="kpi-icon kpi-icon-green">
                                <img src="../Images/employee.png" class="kpi-icon-img">
                            </div>
                        </div>
                        <svg class="sparkline" viewBox="0 0 100 30" preserveAspectRatio="none">
                            <polyline points="0,25 15,21 30,23 45,14 60,17 75,9 100,6" fill="none" stroke="#00E676" stroke-width="2" />
                        </svg>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card dash-card-modern">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="dash-title">Pending Leave Requests Today</div>
                                <div class="dash-value">
                                    <?php
                                    $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Pending' AND submission_date = CURDATE()";
                                    $query = $conn->query($sql);
                                    $set = $query->fetch_object();
                                    echo $set->total;

                                    ?>
                                </div>
                                <div class="trend-badge trend-down">

                                    <?php
                                    date_default_timezone_set('Asia/Manila');
                                    $yesterday_date = strtotime('yesterday');
                                    $yesterday_date = date('Y-m-d', $yesterday_date);
                                    $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Pending' AND DATE(submission_date) = '" . $yesterday_date . "'";
                                    $query = $conn->query($sql);
                                    $last = $query->fetch_object();

                                    $today = (int)$set->total;
                                    $yesterday = (int)$last->total;

                                    if ($today != 0 && $yesterday != 0 && $today < $yesterday) {
                                        $less_percentage = (($yesterday / $today) * 100) - 100;
                                        echo $less_percentage . "% More than yesterday";
                                    } else if ($today != 0 && $yesterday != 0 && $today > $yesterday) {
                                        $less_percentage = (($yesterday / $today) * 100) - 100;
                                        echo $less_percentage . "% Less than yesterday";
                                    } else if ($today != 0 && $yesterday != 0 && $today == $yesterday) {
                                        echo "Same amount as yesterday";
                                    }

                                    //echo $less_percentage;
                                    ?>

                                </div>
                            </div>
                            <div class="kpi-icon kpi-icon-amber">
                                <img src="../Images/leave.png" class="kpi-icon-img">
                            </div>
                        </div>
                        <svg class="sparkline" viewBox="0 0 100 30" preserveAspectRatio="none">
                            <polyline points="0,8 15,14 30,10 45,18 60,15 75,22 100,20" fill="none" stroke="#FFC107" stroke-width="2" />
                        </svg>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card dash-card-modern">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="dash-title">Present Today</div>
                                <div class="dash-value cyan-text">
                                    <?php
                                    $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status != 'Absent' AND date = CURDATE() ";
                                    $query = $conn->query($sql);
                                    $set = $query->fetch_object();
                                    echo $set->total;
                                    ?>
                                </div>
                                <div class="trend-badge trend-up">
                                    <?php
                                    $sql = "SELECT COUNT(id) AS total FROM employees WHERE status = 'Active'";
                                    $query = $conn->query($sql);
                                    $employees = $query->fetch_object();
                                    $total_present = ($set->total / $employees->total) * 100;
                                    echo $total_present . "% Attendance";
                                    ?>
                                </div>
                            </div>
                            <div class="kpi-icon kpi-icon-cyan">
                                <img src="../Images/attendances.png" class="kpi-icon-img">
                            </div>
                        </div>
                        <svg class="sparkline" viewBox="0 0 100 30" preserveAspectRatio="none">
                            <polyline points="0,20 15,18 30,12 45,15 60,10 75,13 100,7" fill="none" stroke="#64FFDA" stroke-width="2" />
                        </svg>
                    </div>
                </div>

            </div>

            <!-- Leave Requests Overview: bar chart + status breakdown -->
            <div class="row g-4 mb-4">
                <div class="col-lg-7">
                    <div class="section-header"><i class="bi bi-bar-chart-line me-2"></i>Leave Requests Overview</div>
                    <div class="manage-box shadow-sm chart-card h-100">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h5 class="mb-0"><i class="bi bi-calendar3 me-2"></i>Monthly Leave Requests</h5>
                            <span class="small" style="color: #8892B0;">Last 6 months, Maximum of 25 Requests</span>
                        </div>
                        <div class="bar-chart">
                            <?php
                            $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                            $current_month_num = date('m');
                            $current_month_num = (int)$current_month_num;
                            $current_year = date('Y');
                            for ($i = 0; $i < 6; $i++) {
                                if ($current_month_num < 10) {
                                    $year_month_search = $current_year . "-0" . $current_month_num;
                                } else if ($current_month_num >= 10) {
                                    $year_month_search = $current_year . "-" . $current_month_num;
                                }
                                $leave_count = 0;
                                $current_month_num -= 1;
                                $sql = "SELECT * FROM leave_request";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    $year_month_look = substr($set->submission_date, 0, -3);

                                    if ($year_month_search == $year_month_look) {
                                        $leave_count += 1;

                                        if ($current_month_num < 0) {
                                            $current_month_num = 11;
                                        }
                                    }
                                }

                                echo <<<HTML
                                        <div class="bar-col">
                                            <div class="bar-value">{$leave_count}</div>
                                            <div class="bar" id="bar-{$current_month_num}" ></div>
                                            <div class="bar-label">{$months[$current_month_num]} {$current_year}</div>
                                        </div>
                                        <script>
                                            $(document).ready(function() {
                                                leave_count = {$leave_count};
                                                leave_percentage = (leave_count / 25)*100;
                                                leave_percentage_text = leave_percentage+"%";
                                                $("#bar-{$current_month_num}").css({"height": leave_percentage_text});
                                                console.log(leave_percentage_text);
                                            })
                                        </script>
                                    HTML;
                            }

                            ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="section-header"><i class="bi bi-pie-chart me-2"></i>Status Breakdown</div>
                    <div class="manage-box shadow-sm chart-card h-100">
                        <div class="donut-wrap">
                            <?php
                            //Donut logic

                            //Pending Count
                            $sql = "SELECT COUNT(status) AS pending FROM leave_request WHERE status = 'Pending'";
                            $query = $conn->query($sql);
                            $pending = $query->fetch_object();


                            //Approved Count
                            $sql = "SELECT COUNT(status) AS approve FROM leave_request WHERE status = 'Approved'";
                            $query = $conn->query($sql);
                            $approve = $query->fetch_object();

                            //Rejected Count
                            $sql = "SELECT COUNT(status) AS reject FROM leave_request WHERE status = 'Rejected'";
                            $query = $conn->query($sql);
                            $reject = $query->fetch_object();



                            echo <<<HTML
                                        <script>

                                            let total = (parseInt("{$pending->pending}")+parseInt("{$reject->reject}")+parseInt("{$approve->approve}"));

                                            //Rising Percentage Calculation
                                            
                                            approved_per = (parseInt("{$approve->approve}")/total)*100;
                                            pending_per = ((parseInt("{$pending->pending}")/total)*100) + approved_per;
                                            rejected_per = ((parseInt("{$reject->reject}")/total)*100) + pending_per;
                                            
                                            $(document).ready(function() {

                                                //Used for the bar
                                                $("#donut").css("background", "conic-gradient( #00E676 0% "+approved_per+"%, #FFC107 "+approved_per+"% "+pending_per+"%, #FF5252 "+pending_per+"% "+rejected_per+"%)")

                                                //Total
                                                $("#total").text(total);

                                                //Value on the side of the donut
                                                $("#approved").text("Approved: ("+((parseInt("{$approve->approve}")/total)*100).toFixed(2)+"%)");
                                                $("#pending").text("Pending: ("+((parseInt("{$pending->pending}")/total)*100).toFixed(2)+"%)");
                                                $("#rejected").text("Rejected: ("+((parseInt("{$reject->reject}")/total)*100).toFixed(2)+"%)");


                                            });
                                        </script>
                                    HTML;

                            ?>
                            <div class="donut" id="donut">
                                <div class="donut-center">
                                    <div class="value" id="total"></div>
                                    <div class="label">Total</div>
                                </div>
                            </div>
                            <div class="donut-legend">
                                <div class="donut-legend-item">
                                    <span class="donut-dot" style="background-color: #00E676;"></span>
                                    <div id="approved"></div>
                                </div>
                                <div class="donut-legend-item">
                                    <span class="donut-dot" style="background-color: #FFC107;"></span>
                                    <div id="pending"></div>
                                </div>
                                <div class="donut-legend-item">
                                    <span class="donut-dot" style="background-color: #FF5252;"></span>
                                    <div id="rejected"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Leave Requests -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-clock-history me-2"></i>Recent Leave Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
                            <h5 class="mb-0 pt-1"><i class="bi bi-inbox me-2"></i>Latest Submissions</h5>
                            <div class="search-box-wrap">
                                <i class="bi bi-search"></i>
                                <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#leave_list').DataTable({
                                    paging: true,
                                    pageLength: 3,
                                    lengthChange: false,
                                    searching: true,
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="leave_list">
                            <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Leave Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Reason</th>
                                    <th>Date Submitted</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM leave_request";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                                <tr data-status="' . $set->status . '">
                                                    <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                    <td>' . $set->leave_type . '</td>
                                                    <td>' . $set->start_date . '</td>
                                                    <td>' . $set->end_date . '</td>
                                                    <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">' . $set->reason . '</td>
                                                    <td>' . $set->submission_date . '</td>';

                                    if ($set->status == "Pending") {
                                        echo '
                                                    <td><span class="badge" style="background-color: rgba(255, 193, 7, 0.15); color: #a17c00; border: 1px solid rgba(255, 193, 7, 0.4);">Pending</span></td>
                                                    
                                                    <td>
                                                        <div class="d-flex justify-content-center gap-2">
                                                            <form method="POST" class="m-0"><button type="submit" name="approve" value="' . $set->id . '" class="btn btn-confirm btn-sm rounded-pill px-3">Approve</button></form>
                                                            <form method="POST" class="m-0"><button type="submit" name="reject" value="' . $set->id . '" class="btn btn-delete btn-sm rounded-pill px-3">Reject</button></form>
                                                        </div>
                                                    </td>';
                                    } else if ($set->status == "Approved") {
                                        echo '
                                                <td><span class="badge" style="background-color: rgba(40, 167, 69, 0.1); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.3);"> Approved</span></td>
                                                <td>
                                                    <button class="btn btn-closed btn-sm rounded-pill px-3" disabled>Already Approved</button>
                                                </td>';
                                    } else if ($set->status == "Rejected") {
                                        echo '<td><span class="badge" style="background-color: rgba(220, 53, 69, 0.1); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.3);">Rejected</span></td>
                                                    <td>
                                                        <button class="btn btn-closed btn-sm rounded-pill px-3" disabled>Already Rejected</button>
                                                    </td>';
                                    }

                                    echo '</tr>';
                                }


                                //Refect and Approve process

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                    //Remove Account
                                    if (isset($_POST['approve'])) {
                                        $sql = "UPDATE `leave_request` SET `status` = 'Approved' WHERE id = " . $_POST['approve'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Leave Request Approve!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('leave.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }

                                    if (isset($_POST['reject'])) {
                                        $sql = "UPDATE `leave_request` SET `status` = 'Rejected' WHERE id = " . $_POST['reject'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Leave Request Rejected!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('leave.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of HR Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'><i class='bi bi-box-arrow-right me-1'></i>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'><i class='bi bi-x-lg me-1'></i>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>