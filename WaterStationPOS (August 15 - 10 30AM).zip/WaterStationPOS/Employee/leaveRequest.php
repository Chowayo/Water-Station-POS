<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<head>
    <title>Leave Requests - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include 'navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include 'topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-center align-items-center gap-3">
                <div class="text-center">
                    <h1>Leave Requests</h1>
                </div>
            </header>

            <div class="box mt-2">
                <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                    <h5 class="mb-0 pt-1">My Leave Requests</h5>
                    <div class="d-flex flex-wrap gap-2">
                        <div class="table-search-input search-icon-wrap">
                            <i class="bi bi-search search-icon-inside"></i>
                            <input type="text" class="form-control" placeholder="Search requests" id="searcher">
                        </div>
                        <button type="button" class="btn btn-add w-auto px-4 rounded-pill text-nowrap" data-bs-toggle="modal" data-bs-target="#leaveRequestModal"><i class="bi bi-calendar-plus me-1"></i>Request Leave</button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-dark table-hover text-center mb-0 align-middle" id="leave_list">
                        <thead>
                            <tr>
                                <th>Leave Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Reason</th>
                                <th>Status</th>
                                <th>Date Submitted</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Placeholder rows -->
                            <?php
                            //Loading leave request list
                            $sql = "SELECT * FROM leave_request WHERE employee_id = " . $result->id;
                            $query = $conn->query($sql);
                            while ($set = $query->fetch_object()) {
                                echo '
                                        <tr>
                                            <td>' . $set->leave_type . '</td>
                                            <td>' . $set->start_date . '</td>
                                            <td>' . $set->end_date . '</td>
                                            <td><button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3 view-reason-btn" data-reason="' . htmlspecialchars($set->reason, ENT_QUOTES) . '" data-bs-toggle="modal" data-bs-target="#viewReasonModal"><i class="bi bi-eye"></i> View</button></td>';

                                if ($set->status == "Pending") {
                                    echo '<td><span class="badge" style="background-color: rgba(255, 193, 7, 0.15); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.4);"><i class="bi bi-hourglass-split me-1"></i>Pending</span></td>';
                                } else if ($set->status == "Approved") {
                                    echo '<td><span class="badge" style="background-color: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35);"><i class="bi bi-check-circle me-1"></i>Approved</span></td>';
                                } else if ($set->status == "Rejected") {
                                    echo '<td><span class="badge" style="background-color: rgba(220, 53, 69, 0.15); color: #ff6b6b; border: 1px solid rgba(220, 53, 69, 0.4);"><i class="bi bi-x-circle me-1"></i>Rejected</span></td>';
                                }

                                echo '
                                            <td>' . $set->submission_date . '</td>
                                        </tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </main>

    <!-- Request Leave Modal -->
    <div class="modal fade" id="leaveRequestModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-calendar-plus me-2"></i>Request Leave</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form id="leaveRequestForm" method="POST">
                        <div class="mb-3">
                            <label for="leaveType" class="form-label"><i class="bi bi-tag me-1"></i>Leave Type</label>
                            <select class="form-select" id="leaveType" name="leave_type" required>
                                <option value="" selected disabled>Select leave type</option>
                                <option value="Sick leave">Sick Leave</option>
                                <option value="Vacation leave">Vacation Leave</option>
                                <option value="Emergency leave">Emergency Leave</option>
                                <option value="Maternity paternity_leave">Maternity / Paternity Leave</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-6">
                                <label for="leaveStart" class="form-label"><i class="bi bi-calendar-event me-1"></i>Start Date</label>
                                <input type="date" class="form-control" id="leaveStart" name="start" required>
                            </div>
                            <div class="col-6">
                                <label for="leaveEnd" class="form-label"><i class="bi bi-calendar-event me-1"></i>End Date</label>
                                <input type="date" class="form-control" id="leaveEnd" name="end" required>
                            </div>
                        </div>

                        <div class="mb-1">
                            <label for="leaveReason" class="form-label"><i class="bi bi-chat-left-text me-1"></i>Reason</label>
                            <textarea class="form-control" id="leaveReason" rows="3" placeholder="describe the reason for your leave" name="reason" required></textarea>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" name="adder" form="leaveRequestForm" class="btn btn-add w-auto px-4"><i class="bi bi-check-circle me-1"></i>Submit Request</button>
                        </div>
                    </form>

                    <?php

                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        //Add customer
                        if (isset($_POST['adder'])) {
                            //Gotten from input
                            $leave_type = $_POST['leave_type'];
                            $start = $_POST['start'];
                            $end = $_POST['end'];
                            $reason = $_POST['reason'];

                            //Automated
                            $employee_name = $result->last_name;
                            $employee_id = $result->id;
                            $employee_role = $result->role;
                            $status = "Pending";
                            date_default_timezone_set('Asia/Manila');
                            $submission = date('Y-m-d');


                            if ($leave_type && $start && $end && $reason) {
                                //Verifies if the starting time is in the past or present or future (CAN"T ADD LEAVE A THE SAME DAY TODAY)
                                $today = strtotime('today');
                                if (strtotime($start) > $today) {

                                    //Makes it so that the end of leave can only last maximum of 1 year after the start of leave
                                    $maximum_start_date = strtotime($start . '+1 year');
                                    $maximum_date = strtotime('today +1 year');
                                    if (strtotime($end) <= $maximum_start_date && strtotime($start) < $maximum_date) {
                                        //Makes sure than start is before end
                                        if (strtotime($start) < strtotime($end)) {
                                            $sql = "INSERT INTO `leave_request` (`employee_name`, `employee_role`,  `employee_id`, `leave_type`, `start_date`, `end_date`, `reason`, `status`, `submission_date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("ssissssss", $employee_name, $employee_role, $employee_id, $leave_type, $start, $end, $reason, $status, $submission);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Leave Request Submitted!',
                                                                    text: 'Please keep tabs on this request',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#34ff01',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('leaveRequest.php');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;

                                                //Notification
                                                $sql = "SELECT * FROM employees WHERE role = 'HR'";
                                                $query = $conn->query($sql);
                                                while ($emp_info = $query->fetch_object()) {
                                                    $notif_id = $emp_info->id;
                                                    $notif_role = $emp_info->role;
                                                    $notif_category = "Leave Request Submitted";
                                                    $notif_message = "Employee " . $result->last_name . " has submitted a leave request";

                                                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP())";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                    if ($stmt->execute()) {
                                                    }
                                                }
                                            }
                                        } else {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Date!',
                                                                    text: 'Make sure that the starting date is sooner than the end date',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#leaveRequestModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Date!',
                                                            text: 'The maximum starting date is only 1 year from now and the maximum end date is only 1 year ahead of the starting date',
                                                            background: '#FFFFFF',
                                                            color: '#2D3748',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        }).then((result) => {
                                                            if(result.isConfirmed) {
                                                                $('#leaveRequestModal').modal('show');
                                                            }});
                                                    })
                                                    </script> 
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Date!',
                                                            text: 'The starting date must not be the same day as today or set in the dates before today',
                                                            background: '#FFFFFF',
                                                            color: '#2D3748',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        }).then((result) => {
                                                            if(result.isConfirmed) {
                                                                $('#leaveRequestModal').modal('show');
                                                            }});
                                                    })
                                                    </script> 
                                            HTML;
                                }
                            }
                        }
                    }


                    ?>
                </div>



            </div>
        </div>
    </div>

    <!-- View Reason Modal (shared, populated per-row via JS) -->
    <div class="modal fade" id="viewReasonModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-chat-square-text me-2"></i>Leave Reason</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0" id="viewReasonText" style="word-break: break-word; overflow-wrap: break-word;"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-auto" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var table = $('#leave_list').DataTable({
                paging: false,
                searching: true,
                dom: 't'
            });

            $('#searcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });

            // Populate the View Reason modal from whichever row's button triggered it
            $('#viewReasonModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                $('#viewReasonText').text(button.data('reason'));
            });
        });

        //Logout
        $("#logout").click(function(e) {
            e.preventDefault();
            let logoutUrl = $(this).attr('href');

            Swal.fire({
                showConfirmButton: false,
                icon: "question",
                background: '#FFFFFF',
                color: '#2D3748',
                title: "Log out of POS?",
                html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                heightAuto: false
            });
        });
    </script>

</body>