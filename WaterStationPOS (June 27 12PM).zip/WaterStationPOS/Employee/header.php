<!DOCTYPE html>
<html lang="en">

<?php
require('../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../index.php');
}

if (isset($_SESSION['users']) && ucfirst(substr($_SESSION['users']->email, 0, 5)) == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

$user = $_SESSION['users'];

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery-3.6.0.min.js"></script>
</head>


<body>
    <script>
        window.addEventListener('pageshow', function(events) {
            if (events.persisted) {
                window.location.reload();
            }
        });
    </script>