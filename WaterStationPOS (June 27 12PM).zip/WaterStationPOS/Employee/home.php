<?php

include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eco Hydrate Hub POS</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>

    <link rel="stylesheet" href="styles.css">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <!-- Employee Details (Styled as text to fit the dark theme) -->
            <div class="px-3 mb-4">
                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE DETAILS</p>
                <div class="employee-text">ID: <?php echo isset($result) ? $result->id : 'EMP-001'; ?></div>
                <div class="employee-text">Email: <?php echo isset($result) ? $result->email : 'user@hydrate.com'; ?></div>
                <div class="employee-text">Name: <?php echo isset($result) ? $result->first_name . " " . $result->last_name : 'Jane Doe'; ?></div>
            </div>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link active" href="home.php">POS</a>
                <a class="menu-link" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <!-- MAIN POS CONTENT -->
        <main class="flex-grow-1 d-flex content">
            <section class="flex-grow-1 d-flex flex-column p-4">

                <header class="top-text text-center mb-4">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Mineral Water Refill & POS management System</h6>
                </header>

                <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                    <!-- Product 1 -->
                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/20L.png" alt="20L Slimline" class="product-img">
                                </div>
                                <div>20L Slimline Gallon with Faucet</div>
                                <div class="price">₱35.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <!-- Product 2 -->
                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/10L.png" alt="10L Slim Gallon" class="product-img">
                                </div>
                                <div>10L Slim Gallon with Faucet</div>
                                <div class="price">₱15.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <!-- Product 3 -->
                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/18.9L.png" alt="18.9L Round Gallon" class="product-img">
                                </div>
                                <div>18.9L Round Gallon</div>
                                <div class="price">₱35.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- RIGHT CART PANEL -->
            <aside class="right-panel d-flex flex-column shadow-sm">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <button class="btn-order flex-grow-1 m-0">ORDERS</button>
                    <button class="btn-clear ms-2">Clear</button>
                </div>

                <div class="flex-grow-1 overflow-auto cart-list pe-2">
                    <div class="cart-item">
                        <div class="item-details">
                            <div class="cart-name">Round Gallon Refill</div>
                            <div class="cart-calc">2 x ₱30.00</div>
                        </div>
                        <div class="item-actions">
                            <div class="cart-line-total">₱60.00</div>
                            <button class="btn-remove">X</button>
                        </div>
                    </div>
                </div>

                <div class="totals-box">
                    <div class="total-row">
                        <span>Subtotal</span>
                        <span>₱60.00</span>
                    </div>
                    <hr class="my-2 border-secondary">
                    <div class="total-row grand-total">
                        <span>Total</span>
                        <span>₱60.00</span>
                    </div>
                </div>

                <button type="button" class="btn-pay mt-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#receiptModal">Checkout</button>
            </aside>
        </main>
    </div>

    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">

        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-body p-4">


                    <div class="receipt-paper" id="printableReceipt">

                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>1</strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>Time: <?php echo date('h:i A'); ?></p>
                            <p>Cashier: Luz Cantos</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <p>Name: Luz Cantos</p>
                        <p>Phone: 0912 345 6789</p>
                        <p>Address: Trece Martires</p>
                        <p>Payment Method: Cash </p>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>

                        <div class="receipt-grid">
                            <div>3x</div>
                            <div>Round Refill</div>
                            <div class="price">90.00</div>
                        </div>

                        <div class="receipt-grid">
                            <div>1x</div>
                            <div>New Container</div>
                            <div class="price">150.00</div>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱250.00</p>
                        </div>


                    </div>

                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()">Print Receipt</button>
                </div>

            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    title: "Do you want to Log out?",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    html: "<a href='../logout.php' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>

    <?php
    include '../footer.php';
    ?>
</body>

</html>