<?php

include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Information</title>

    <link rel="stylesheet" href="styles.css">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <nav class="nav flex-column mt-4 px-2">
                <p class="text-center fw-bold text-muted small mb-4">EMPLOYEE POS</p>

                <a class="menu-link" href="home.php">POS</a>
                <a class="menu-link" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link active" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="flex-grow-1 d-flex flex-column content overflow-auto">
            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Customer Information Directory</h6>
                    </div>
                </header>

                <div class="box mt-2">
                    <div class="d-flex justify-content-between mb-3 align-items-center">
                        <h5 class="mb-0 fw-bold">Registered Customers</h5>

                        <div class="d-flex gap-2">
                            <input type="text" class="form-control" placeholder="Search customer..." style="width: 250px;">
                            <button type="button" class="btn btn-add rounded-pill px-4" data-toggle="modal" id="openAddCustomerBtn" data-target="#addCustomerModal">Add Customer</button>
                        </div>
                    </div>

                    <table class="table table-hover text-center mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Contact Number</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="fw-bold">Maybelle Dellamas</td>
                                <td>0912 345 6789</td>
                                <td>GMA Cavite Blk 1 Lot 2</td>
                                <td>
                                    <button class="btn btn-edit btn-sm rounded-pill px-4">Edit</button>
                                </td>
                            </tr>

                            <tr>
                                <td class="fw-bold">Luz Cantos</td>
                                <td>0998 765 4321</td>
                                <td>Trece Martires Blk 2 Lot 2</td>
                                <td>
                                    <button class="btn btn-edit btn-sm rounded-pill px-4">Edit</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </section>
        </main>
    </div>

    <!-- ADD CUSTOMER MODAL -->
    <div class="modal fade" id="addCustomerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addCustomerForm">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" required placeholder="e.g. 09123456789">
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Complete Address</label>
                            <textarea class="form-control" name="address" rows="3" required placeholder="House No., Street, Barangay, City..."></textarea>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-add rounded-pill px-4" id="saveCustomerBtn">Save Customer</button>
                </div>

            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {

            $("#saveCustomerBtn").click(function() {

                //Close
                $('#addCustomerModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Customer Saved!',
                    text: 'The new customer has been added.',
                    background: '#FFFFFF',
                    color: '#2D3748',
                    confirmButtonColor: '#00A859',
                    heightAuto: false
                });

                // Reset the form
                $('#addCustomerForm')[0].reset();
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });

        });

        document.getElementById('openAddCustomerBtn').addEventListener('click', function(e) {
            e.preventDefault();
            var modalEl = document.getElementById('addCustomerModal');
            if (!modalEl) return;

            if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
                console.error('Bootstrap is not loaded. Include bootstrap.bundle.min.js');
                return;
            }

            var myModal = bootstrap.Modal.getOrCreateInstance(modalEl);
            myModal.show();
        });
    </script>
    <?php
    include '../footer.php';
    ?>
</body>

</html>