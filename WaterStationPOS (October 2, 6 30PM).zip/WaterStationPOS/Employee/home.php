<?php

include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

echo <<<HTML
        <script>
            $(document).ready(function() {
                 //Sends the Delivery back if it tries to access pages that it does not have persmission to access
                if("{$result->role}"=="Delivery"){
                    location.assign('confirmation.php');
                }

                //Sends the Cashier back if it tries to access pages that it does not have persmission to access
                else if("{$result->role}"=="Delivery"){
                    //Empty since cashier can access every present page in the system
                }
            });
        </script>
    HTML;

?>

<link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <?php
        include 'navigation.php';
        ?>

        <main class="flex-grow-1 d-flex flex-column content">

            <?php include 'topbar.php'; ?>

            <div class="d-flex flex-grow-1 pos-content-row" style="min-height: 0;">
                <section class="flex-grow-1 d-flex flex-column p-4">

                    <header class="pos-head">
                        <div class="pos-title">
                            <div class="pos-title-icon">
                                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2.5C12 2.5 5 10.2 5 15a7 7 0 0 0 14 0c0-4.8-7-12.5-7-12.5Z" fill="#fff"/><path d="M8.5 15.2a3.5 3.5 0 0 0 3.2 3.3" stroke="#1e88e5" stroke-width="1.8" stroke-linecap="round"/></svg>
                            </div>
                            <div>
                                <h1>Point of Sale</h1>
                                <small>Walk-in counter &bull; Refills &amp; containers</small>
                            </div>
                        </div>
                        <div class="pos-chip"><i class="bi bi-person-badge"></i><div><div class="lbl">Cashier</div><div class="val"><?php echo htmlspecialchars($result->first_name); ?></div></div></div>
                        <div class="pos-chip"><i class="bi bi-calendar3"></i><div><div class="lbl">Date</div><div class="val" id="posDate">--</div></div></div>
                        <div class="pos-chip"><i class="bi bi-clock"></i><div><div class="lbl">Time</div><div class="val" id="posClock">--:--</div></div></div>
                        <button type="button" class="btn-order btn-pending-top"><i class="bi bi-clipboard-check me-1"></i>Pending Orders</button>
                    </header>

                    <div class="pos-toolbar" id="productTypeTabs">
                        <div class="table-search-input search-icon-wrap">
                            <i class="bi bi-search search-icon-inside"></i>
                            <input type="text" class="form-control" placeholder="Search product..." id="searcher">
                        </div>
                        <button class="btn btn-filter ms-auto nav-link active" data-product="all"><i class="bi bi-grid-fill"></i>All</button>
                        <button class="btn btn-filter nav-link" data-product="refill"><i class="bi bi-droplet-fill"></i>Refill</button>
                        <button class="btn btn-filter nav-link" data-product="newBottle"><i class="bi bi-box-seam-fill"></i>Container</button>
                    </div>

                    <style>
                        .product-panel {
                            display: none;
                        }

                        .product-panel.active {
                            display: block;
                        }

                        .product-container::-webkit-scrollbar {
                            display: none;
                        }
                    </style>

                    <?php
                    function product_loader($conn, $category)
                    {

                        if ($category == "All") {
                            $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False'";
                        } else if ($category == "NewContainer") {
                            $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False' AND category = 'New Container'";
                        } else {
                            $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False' AND category = '" . $category . "'";
                        }
                        $query = $conn->query($sql);
                        $counter = 0;
                        while ($set = $query->fetch_object()) {
                            $counter += 1;

                            // Color-code the stock badge by how low the quantity is
                            if ($set->stock <= 5) {
                                $stock_class = 'stock-low';
                            } elseif ($set->stock <= 15) {
                                $stock_class = 'stock-medium';
                            } else {
                                $stock_class = 'stock-ok';
                            }

                            echo '<div class="col-6 col-md-4" id="product_card-'.$counter.'-'.$category.'">
                                    <div class="item-card">
                                        <div class="info">
                                            <div class="product-image">
                                                <img src="../Images/' . $set->image . '" class="product-img">
                                            </div>
                                            <div>' . $set->product_name . ' ' . $set->measurement . $set->unit . ' ' . $set->category . '</div>
                                            <p hidden id="name-'.$counter.'-'.$category.'">'.$set->product_name.' '.$set->category.'</p>
                                            <div class="price">₱' . $set->price . '</div>
                                            <div class="mb-2"><span class="stock-badge ' . $stock_class . '">Stock: ' . $set->stock . '</span></div>
                                        </div>
                                        <div class="actions">
                                            <button class="btn-add ' . $set->id . '-' . $category . '-submit" id=""> <i class="bi bi-cart-plus"></i> Add</button>
                                        </div>
                                    </div>
                                </div>';

                            echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            //clear button
                                            total = 0; //Total amount
                                            $("#clear").click(function() {
                                                if($(".{$set->id}-{$category}-submit").css("background-color")==="rgb(40, 167, 69)"){
                                                    $(".{$set->id}-{$category}-submit").css("background-color", "#007BFF");
                                                }
                                                if($(".{$set->id}-{$category}-submit").prop("disabled")===true){
                                                    $(".{$set->id}-{$category}-submit").attr("disabled", false);
                                                }
                                                if($(".{$set->id}-{$category}-submit").text()==="Added"){
                                                    $(".{$set->id}-{$category}-submit").html("<i class='bi bi-cart-plus'></i> Add");
                                                }
                                                //Wipes all of the side div inside of order_queue
                                                $("#order_queue").empty();
                                                $("#bill-list").empty();
                                                total = 0; //Total resets
                                                $("#total-amount").text("₱"+total+".00");
                                                $("#grand-total").text("₱"+total+".00");
                                                $("#checkout").attr("hidden", true);
                                                $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm");
                                            });


                                            $(".{$set->id}-{$category}-submit").click(function() {
                                                $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm");
                                                $("#checkout").attr("hidden", false);
                                                $(".{$set->id}-{$category}-submit").css("background-color", "#28a745");
                                                $(".{$set->id}-{$category}-submit").attr("disabled", true);
                                                $(".{$set->id}-{$category}-submit").text("Added");

                                                //Disables the same product from other categories
                                                categories = ["All", "Refill", "NewContainer"];
                                                for (const category of categories) {
                                                    if ($(".{$set->id}-"+category+"-submit").prop("disabled") === false) {
                                                        $(".{$set->id}-"+category+"-submit").css("background-color", "#28a745");
                                                        $(".{$set->id}-"+category+"-submit").attr("disabled", true);
                                                        $(".{$set->id}-"+category+"-submit").text("Added");
                                                    }
                                                }

                                                //Receipt editor
                                                $("#bill-list").prepend(`
                                                    <div class="receipt-grid" id="{$set->id}-bill">
                                                        <p id="{$set->id}-quantity"></p>
                                                        <p id="{$set->id}-product_name"></p>
                                                        <p id="{$set->id}-price" class="price"></p>
                                                    </div>
                                                `);

                                                $("#order_queue").prepend(`
                                                    <div class="overflow-auto cart-list pe-2" id="{$set->id}-whole">
                                                        <div class="cart-item"> 
                                                            <div class="item-details">
                                                                <input type="text" name="product_name-{$counter}" value="{$set->product_name}" hidden>
                                                                <input type="text" name="product_category-{$counter}" value="{$set->category}" hidden>
                                                                <input type="text" name="product_unit-{$counter}" value="{$set->unit}" hidden>
                                                                <input type="number" name="product_measurement-{$counter}" value="{$set->measurement}" hidden>
                                                                <input type="number" name="product_tax-{$counter}" value="{$set->tax_percentage}" hidden>
                                                                <input type="number" name="product_quantity-{$counter}" value="1" id="{$set->id}-totalQuantity" hidden>
                                                                <input type="number" name="total_price-{$counter}" value="{$set->price}" id="{$set->id}-totalPrice" hidden>

                                                                <div class="cart-name">{$set->product_name} {$set->category}</div>
                                                                <div class="cart-calc" id="{$set->id}-calc">1 x ₱{$set->price}</div>
                                                                <div class="qty-box">
                                                                    <button type="button" class="btn-qty" id="{$set->id}-minus">-</button>
                                                                    <input type="number" class="input-num" min="1" max="20" id="{$set->id}-value" value="1" disabled>
                                                                    <button type="button" class="btn-qty" id="{$set->id}-add">+</button>
                                                                </div>
                                                            </div>
                                                            <div class="item-actions">
                                                                <div class="cart-line-total" id="{$set->id}-total">₱{$set->price}</div>
                                                                <p class="text-danger text-center" id="{$set->id}-remove"><i class="bi bi-x-lg"></i></p>
                                                            </div>
                                                            
                                                        </div>
                                                        <script>
                                                            total += {$set->price};
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-quantity").text(1+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱{$set->price}");                                                        

                                                            $("#{$set->id}-add").click(function() {
                                                                if( $("#{$set->id}-value").val()<=({$set->stock}-1)){
                                                                    total += {$set->price};
                                                                    $("#{$set->id}-value").val(function(index, value) {
                                                                        return (parseInt(value) || 0) + 1;
                                                                    });
                                                                }else{
                                                                    $("#{$set->id}-value").val({$set->stock});
                                                                }
                                                                quantity = $("#{$set->id}-value").val();
                                                                $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                                $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                                
                                                                $("#total-amount").text("₱"+total+".00");
                                                                $("#grand-total").text("₱"+total+".00");
                                                                $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                                $("#{$set->id}-totalQuantity").val(quantity);

                                                                //Receipt
                                                                $("#{$set->id}-quantity").text(quantity+"x");
                                                                $("#{$set->id}-product_name").text("{$set->product_name}");
                                                                $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                            });

                                                            $("#{$set->id}-minus").click(function() {
                                                                if( $("#{$set->id}-value").val()>1){
                                                                    total -= {$set->price};
                                                                    $("#{$set->id}-value").val($("#{$set->id}-value").val()-1);
                                                                }else{
                                                                    $("#{$set->id}-value").val(1);
                                                                }
                                                                quantity = $("#{$set->id}-value").val();
                                                                $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                                $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                
                                                                $("#total-amount").text("₱"+total+".00");
                                                                $("#grand-total").text("₱"+total+".00");
                                                                $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                                $("#{$set->id}-totalQuantity").val(quantity);
                                                                
                                                                //Receipt
                                                                $("#{$set->id}-quantity").text(quantity+"x");
                                                                $("#{$set->id}-product_name").text("{$set->product_name}");
                                                                $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                            });

                                                            $("#{$set->id}-remove").click(function() {
                                                                $(".{$set->id}-{$category}-submit").css("background-color", "#007BFF");
                                                                $(".{$set->id}-{$category}-submit").attr("disabled", false);
                                                                $(".{$set->id}-{$category}-submit").html("<i class='bi bi-cart-plus'></i> Add");

                                                                total -= ($("#{$set->id}-value").val()*{$set->price});
                                                                $("#total-amount").text("₱"+total+".00");
                                                                $("#grand-total").text("₱"+total+".00");
                                                                $("#{$set->id}-whole").remove();
                                                                $("#{$set->id}-sub").remove();
                                                                $("#{$set->id}-bill").remove();

                                                                for (const category of categories) {
                                                                    if ($(".{$set->id}-"+category+"-submit").prop("disabled") === true) {
                                                                        console.log(".{$set->id}-"+category+"-submit");
                                                                        $(".{$set->id}-"+category+"-submit").css("background-color", "#007BFF");
                                                                        $(".{$set->id}-"+category+"-submit").attr("disabled", false);
                                                                        $(".{$set->id}-"+category+"-submit").html("<i class='bi bi-cart-plus'></i> Add");
                                                                    }
                                                                }

                                                                if ($("#order_queue").children().length === 0) {
                                                                    $("#side_orders").attr("class", "right-panel d-flex flex-column shadow-sm");
                                                                }
                                                            });
                                                        <\/script>
                                                    </div>
                                                `)
                                            });
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                    ?>

                    <div id="panel-all" class="product-panel active product-container">
                        <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                            <h3>All Products</h3>
                            <hr>
                            <?php
                            product_loader($conn, "All");
                            ?>
                            <script>
                                //Searching Function
                                $(document).ready(function() {
                                    categories = ["All", "Refill", "NewContainer"];
                                    $("#searcher").on("input", function() {
                                        for (const category of categories) {
                                            for(i=1; i<(<?php echo $counter ?>+1); i++){
                                                if ($("#name-"+i+"-"+category).text().toLowerCase().includes($("#searcher").val().trim().toLowerCase())) {
                                                    $("#product_card-" + i +"-"+category).attr("hidden", false);
                                                }else{
                                                    $("#product_card-" + i +"-"+category).attr("hidden", true);
                                                }
                                            }
                                        }
                                    });
                                });
                            </script> 
                        </div>
                    </div>

                    <div id="panel-refill" class="product-panel product-container">
                        <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                            <h3>Refill</h3>
                            <hr>
                            <?php
                            product_loader($conn, "Refill");
                            ?>
                        </div>
                    </div>

                    <div id="panel-newBottle" class="product-panel product-container">
                        <div class="row g-4 mt-1 flex-grow-1 align-content-start">
                            <h3>New Bottle</h3>
                            <hr>
                            <?php
                            product_loader($conn, "NewContainer");
                            ?>
                        </div>
                    </div>
                </section>

                <!-- RIGHT CART PANEL -->
                <aside class="right-panel d-flex flex-column shadow-sm" id="side_orders" hidden>

                    <div class="ticket-head">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <div class="t-title"><i class="bi bi-receipt-cutoff me-2"></i>Current Order</div>
                                <div class="t-sub"><span id="cartCount">0</span> item(s) &bull; Walk-in</div>
                            </div>
                            <button class="btn-clear ms-2" id="clear" title="Clear order"><i class="bi bi-arrow-counterclockwise me-1"></i>Clear</button>
                        </div>
                    </div>
                    <!-- SAVE POINT-->
                    <!-- Dito binabato lahat ng additions na product -->
                    <div class="order_queue flex-grow-1 overflow-auto" style="padding: 12px 14px 0;">
                        <div class="cart-empty show" id="cartEmpty">
                            <svg viewBox="0 0 64 64" fill="none" aria-hidden="true"><path d="M32 6S13 27 13 40a19 19 0 0 0 38 0C51 27 32 6 32 6Z" stroke="#6fe3ff" stroke-width="3" stroke-linejoin="round" fill="rgba(41,197,246,.12)"/><path d="M22 41a10 10 0 0 0 9 9" stroke="#6fe3ff" stroke-width="3" stroke-linecap="round"/></svg>
                            <p>No items yet</p>
                            <small>Tap <b>Add</b> on a product to start an order</small>
                        </div>
                        <form method="POST">
                            <div id="order_queue">

                            </div>
                            <div class="modal fade" id="checkoutCustomerModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content custom-modal-content">

                                        <div class="modal-header border-0 pb-0">
                                            <h5 class="modal-title fw-bold text-navy"><i class="bi bi-cart-check me-2"></i>Checkout Details</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>

                                        <div class="modal-body p-4">
                                            <div class="row g-4">

                                                <!-- Search & Table -->
                                                <script>
                                                    $(document).ready(function() {
                                                        var table = $('#customer_list').DataTable({
                                                            paging: false, // Enable pagination
                                                            searching: true, // Enable search functionality
                                                            dom: 't' //Removes the built in search from datatables
                                                        });

                                                        $('#searcher').on('keyup change clear', function() {
                                                            table.search(this.value).draw(); //Sets the input box as the new search bar
                                                        });

                                                        $(".btn-order").click(function() {
                                                            location.assign('confirmation.php');
                                                        });


                                                        $(".btn-pay").click(function() {
                                                            total_value = parseFloat($("#total-amount").text().slice(1));
                                                        });

                                                        $("#payment_amount").change(function() {
                                                            if (total_value <= $("#payment_amount").val()) {
                                                                $('#confirmCheckoutBtn').prop('disabled', false);

                                                            } else if (total_value > $("#payment_amount").val()) {
                                                                $('#confirmCheckoutBtn').prop('disabled', true);
                                                            }
                                                        });

                                                        //Online payment (PayMongo) doesn't need a cash amount - exact total is charged
                                                        $("#payment_method_select").change(function() {
                                                            if ($(this).val() === "Gcash") {
                                                                $("#cashFields").addClass("d-none");
                                                                $("#nameFields").removeClass("d-none");
                                                                $("#payment_amount").prop('required', false);
                                                                $("#onlineNote").removeClass("d-none");
                                                                $('#confirmCheckoutBtn').prop('disabled', false);
                                                            } else {
                                                                $("#cashFields").removeClass("d-none");
                                                                $("#nameFields").addClass("d-none");
                                                                $("#customer_name_input").val("");
                                                                $("#payment_amount").prop('required', true);
                                                                $("#onlineNote").addClass("d-none");
                                                                $("#payment_amount").trigger('change');
                                                            }
                                                        });
                                                    });
                                                </script>

                                                <!-- Customer Inputs -->
                                                <div class="d-flex flex-column gap-3 justify-content-center">
                                                    <div class="checkout-total"><div class="lbl">Amount Due</div><div class="amt" id="checkoutAmount">₱0.00</div></div>
                                                    <!-- Customer name is only asked for online (PayMongo) payments; Cash sales are recorded as Walk-in Customer -->
                                                    <div id="nameFields" class="d-flex flex-column gap-3 d-none">
                                                        <label class="form-label"><i class="bi bi-person-vcard me-1"></i>Customer Name <span class="text-muted small">(optional)</span></label>
                                                        <input type="text" class="form-control custom-input text-center" name="customer_name" id="customer_name_input" placeholder="Customer Full Name">
                                                    </div>
                                                    <label class="form-label"><i class="bi bi-envelope me-1"></i>Customer Email <span class="text-muted small">(optional, for e-receipt)</span></label>
                                                    <input type="email" class="form-control custom-input text-center" name="customer_email" placeholder="customer@email.com">


                                                    <label class="form-label"><i class="bi bi-credit-card me-1"></i>Payment Method</label>
                                                    <select class="form-select custom-input" name="payment_method" id="payment_method_select" required>
                                                        <option value="Cash">Cash</option>
                                                        <option value="Gcash">PayMongo (GCash / Maya / Card / QR Ph)</option>
                                                    </select>

                                                    <div id="cashFields" class="d-flex flex-column gap-3">
                                                        <label class="form-label"><i class="bi bi-cash-stack me-1"></i></i>Payment Amount (₱)</label>
                                                        <input type="number" class="form-control custom-input text-center" name="customer_payment" placeholder="Customer Payment Amount" id="payment_amount" required>
                                                        <div class="quick-cash" id="quickCash">
                                                            <button type="button" data-amt="exact">Exact</button>
                                                            <button type="button" data-amt="50">₱50</button>
                                                            <button type="button" data-amt="100">₱100</button>
                                                            <button type="button" data-amt="200">₱200</button>
                                                            <button type="button" data-amt="500">₱500</button>
                                                            <button type="button" data-amt="1000">₱1000</button>
                                                        </div>
                                                        <div class="change-due" id="changeDue"><span class="lbl">Change</span><span class="amt" id="changeAmt">₱0.00</span></div>
                                                    </div>
                                                    <p id="onlineNote" class="text-center small text-muted mb-0 d-none">You will be taken to PayMongo to pay the exact total. The sale is only recorded once payment is confirmed.</p>

                                                    <div class="d-flex justify-content-center gap-3 mt-3">
                                                        <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                                                        <button type="submit" name="checkout" id="confirmCheckoutBtn" class="btn btn-primary rounded-pill px-5 fw-bold"><i class="bi bi-check-circle me-1"></i>Confirm Checkout</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <?php
                            require_once __DIR__ . '/../paymongo.php';
                            require_once __DIR__ . '/../mailer/includes/payment_emails.php';

                            //Coming back from PayMongo: only finish the sale if PayMongo says it was paid
                            $paymongoReturn = false;
                            if (isset($_GET['pm_token'])) {
                                $pm_token = $_GET['pm_token'];
                                $pending = $_SESSION['pm_pending'][$pm_token] ?? null;
                                $pm_msg = null;

                                if (!$pending) {
                                    $pm_msg = ['info', 'Payment link expired', 'This payment was already processed or has expired.'];
                                } elseif (isset($_GET['pm_cancel'])) {
                                    unset($_SESSION['pm_pending'][$pm_token]);
                                    $pm_msg = ['warning', 'Payment cancelled', 'No sale was recorded. The cart is still here.'];
                                } elseif (paymongoIsPaid($pending['session_id'])) {
                                    unset($_SESSION['pm_pending'][$pm_token]); //one-time use so a refresh can't duplicate the sale
                                    $_POST = $pending['post'];
                                    $_POST['checkout'] = '1';
                                    $_POST['customer_payment'] = $pending['amount'];
                                    $paymongoReturn = true;
                                } else {
                                    $pm_msg = ['error', 'Payment not confirmed', 'PayMongo has not confirmed this payment yet. Refresh this page in a moment.'];
                                }

                                if ($pm_msg) {
                                    $pm_msg_js = json_encode($pm_msg);
                                    echo "<script>$(document).ready(function(){ var m = {$pm_msg_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#FFFFFF', color:'#2D3748', confirmButtonColor:'#00A859', heightAuto:false}); });</script>";
                                }
                            }

                            if ($_SERVER['REQUEST_METHOD'] === 'POST' || $paymongoReturn) {

                                //Remove Account
                                if (isset($_POST['checkout'])) {
                                    //Cash sales don't ask for a name; blank names are recorded as a walk-in customer
                                    $customer_name = trim($_POST['customer_name'] ?? '');
                                    if (($_POST['payment_method'] ?? '') === 'Cash' || $customer_name === '') {
                                        $customer_name = 'Walk-in Customer';
                                    }
                                    $order_type = "Pickup";
                                    $payment_amount = $_POST['customer_payment'];
                                    $payment_method = $_POST['payment_method'];

                                    //ONLINE PAYMENT: send the cashier to PayMongo first. The sale (order, stock, transaction) is saved only after payment is confirmed.
                                    $blockOrder = false;
                                    if ($payment_method === 'Gcash' && !$paymongoReturn && $customer_name) {
                                        $blockOrder = true;
                                        $online_total = 0.00;
                                        for ($i = 1; $i <= $counter; $i++) {
                                            if (isset($_POST['total_price-' . $i])) {
                                                $online_total += (float) $_POST['total_price-' . $i];
                                            }
                                        }

                                        $pm_token = bin2hex(random_bytes(8));
                                        $pm_back  = paymongoPageUrl() . '?pm_token=' . $pm_token;
                                        $pm = ($online_total > 0)
                                            ? paymongoCreateCheckout($online_total, 'ECO HYDRATE HUB POS Sale - ' . $customer_name, $pm_back, $pm_back . '&pm_cancel=1')
                                            : ['ok' => false, 'error' => 'The cart is empty.'];

                                        if ($pm['ok']) {
                                            $_SESSION['pm_pending'][$pm_token] = ['session_id' => $pm['id'], 'post' => $_POST, 'amount' => $online_total];
                                            echo "<script>window.location.href = " . json_encode($pm['url']) . ";</script>";
                                            exit;
                                        }
                                        $pm_err_js = json_encode($pm['error']);
                                        echo "<script>$(document).ready(function(){ Swal.fire({icon:'error', title:'Online payment unavailable', text:{$pm_err_js}, background:'#FFFFFF', color:'#2D3748', confirmButtonColor:'#00A859', heightAuto:false}); });</script>";
                                    }

                                    if (!$blockOrder && $customer_name && $order_type && $payment_method) {

                                        //if pickup is chosen
                                        $status = "Received";
                                        $customer_contact = "NO INFO";
                                        $customer_address = "NO INFO";

                                        $grand_total = 0.00;
                                        $total_tax = 0.00;

                                        //Date and time Information
                                        date_default_timezone_set('Asia/Manila');
                                        $time = date("h:iA");
                                        $date = date('Y/m/d');

                                        // NOTE: eto yung bagong lister ng orders na gagawin
                                        $order_content = "";
                                        $email_items = [];

                                        for ($i = 1; $i <= $counter; $i++) {
                                            if (isset($_POST['product_name-' . $i])) {

                                                //Variables to be submitted
                                                $product_name = $_POST['product_name-' . $i];
                                                $product_categoty = $_POST['product_category-' . $i];
                                                $product_quantity = $_POST['product_quantity-' . $i];
                                                $product_tax = $_POST['product_tax-' . $i];
                                                $product_measurement = $_POST['product_measurement-' . $i];
                                                $product_unit = $_POST['product_unit-' . $i];


                                                //Total Price
                                                $total_price = $_POST['total_price-' . $i];
                                                $grand_total += $total_price;

                                                //Total Tax
                                                $product_tax = $product_tax / 100;
                                                $tax_value = ($total_price * $product_tax);
                                                $total_tax += $tax_value;

                                                //Order content will replace order name para maging 1 row lang per order
                                                $order_content .= "" . $product_quantity . "x " . $product_name . " " . $product_measurement . $product_unit . "(" . $product_categoty . ")₱" . $total_price . " VAT:" . $product_tax . ",";

                                                //Used for receipt printing only
                                                $receipt = "" . $product_quantity . "x " . $product_name . " " . $product_measurement . $product_unit . "(" . $product_categoty . ")";
                                                $email_items[] = ['label' => $receipt, 'amount' => $total_price];

                                                //Deducts stocks on products table value based on quantity
                                                $sql = "UPDATE `product` SET `stock` = `stock` - ? WHERE product_name = '" . $product_name . "' AND category = '" . $product_categoty . "'";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("i", $product_quantity);
                                                if ($stmt->execute()) {
                                                    //Deducts stocks on stocks table value based on quantity
                                                    if($product_categoty=="New Container"){
                                                        $sql = "UPDATE `stocks` SET `current_stock` = `current_stock` - ? WHERE name = '" . $product_name . "'";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("i", $product_quantity);
                                                        if ($stmt->execute()) {}
                                                    }
                                                }

                                                
                                                

                                                //Loads the receipt with information
                                                echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            $("#bill-list").prepend(`
                                                                <div class="receipt-grid mb-2" style="display: grid; grid-template-columns: 4fr auto; align-items: start; gap: 15px; max-width: 450px; width: 100%;" id="{$counter}-bill" >
                                                                    <p id="{$counter}-order_content"></p>
                                                                    <p id="{$counter}-price" class="price"></p>
                                                                </div>
                                                            `);
                                                            $("#{$counter}-order_content").text("{$receipt}");
                                                            $("#{$counter}-price").text("₱" + parseFloat("{$total_price}").toFixed(2));
                                                        });
                                                    </script>
                                                HTML;
                                            }
                                        }

                                        //Removes the last , for propper loading in receipt
                                        $order_content = substr_replace($order_content, '', -1);

                                        //Upload Data
                                        $sql = "INSERT INTO `orders` (`customer_name`, `customer_contact`, `customer_address`, `order_content`, `total_price`, `total_vat`, `payment_amount`, `order_type`, `payment_method`, `status`, `time`, `date`, `cashier`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("ssssdddssssss", $customer_name, $customer_contact, $customer_address, $order_content, $grand_total, $total_tax, $payment_amount, $order_type, $payment_method, $status, $time, $date, $result->first_name);
                                        if ($stmt->execute()) {

                                            //Will insert value into transactions
                                            $sql = "SELECT MAX(id) as recent FROM orders";
                                            $query = $conn->query($sql);
                                            $order = $query->fetch_object();
                                            $description = "Order #" . $order->recent . " Payment";
                                            $category = "Sales";
                                            $type = "Income";
                                            $sql = "INSERT INTO `transactions` (`date`, `description`, `category`, `type`, `payment_method`, `amount`) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("ssssd", $description, $category, $type, $payment_method, $grand_total);
                                            if ($stmt->execute()) {
                                            }

                                            //PayMongo confirmed the payment -> email the customer (if an email was typed), this cashier and finance
                                            if ($paymongoReturn) {
                                                pe_pos_sale_paid($conn, [
                                                    'order_id'       => $order->recent,
                                                    'customer_name'  => $customer_name,
                                                    'customer_email' => $_POST['customer_email'] ?? '',
                                                    'cashier_name'   => $result->first_name,
                                                    'cashier_email'  => $result->email,
                                                    'amount'         => $grand_total,
                                                    'method'         => $payment_method,
                                                    'ref'            => $pending['session_id'] ?? '',
                                                    'items'          => $email_items,
                                                ]);
                                            }

                                            //Notification
                                            $sql = "SELECT * FROM employees WHERE role = 'Cashier' OR role = 'Delivery' OR role = 'Finance' AND deleted = 'False'";
                                            $query = $conn->query($sql);
                                            while ($emp_info = $query->fetch_object()) {
                                                $notif_id = $emp_info->id;
                                                $notif_role = $emp_info->role;
                                                $notif_category = "Order Confirmed";
                                                $notif_message = "Order #" . $order->recent . " has been Confirmed for " . $order_type;
                                                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                if ($stmt->execute()) {
                                                }
                                            }
                                        }

                                        //Receipt loader after process
                                        echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    //Shows Receipt after of loop
                                                    $('#receiptModal').modal('show');

                                                    $("#refresh").click(function(){

                                                        //Refreshed the page for the no-stock items to be removed and quantity adjusted
                                                        location.assign('home.php');
                                                    })   
                                                });
                                            </script>
                                            HTML;
                                    }
                                }
                            }
                            ?>

                            <!-- DITO NATAPOS YUNG FORM-->
                        </form>
                    </div>

                    <div class="totals-box mt-5">
                        <hr class="my-2 border-secondary">
                        <div class="total-row grand-total">
                            <span>Total</span>
                            <span id="total-amount">₱0.00</span>
                        </div>
                    </div>

                    <button type="button" class="btn-pay mt-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#checkoutCustomerModal" id="checkout" hidden><i class="bi bi-bag-check"></i> Checkout</button>
                </aside>
            </div>
        </main>
    </div>

    <!-- Receipt -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>
                                    <?php
                                    $sql = "SELECT MAX(id) AS id FROM orders";
                                    $query = $conn->query($sql);
                                    $highest = $query->fetch_object();

                                    echo ("#" . $highest->id);
                                    ?></strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>
                                <?php
                                date_default_timezone_set('Asia/Manila');
                                echo "Time:" . date("h:iA");
                                ?>
                            </p>
                            <p>
                                <?php
                                echo "Cashier:" . $result->first_name;
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <?php if (($payment_method ?? '') !== 'Cash'): ?>
                            <p style="overflow-wrap: break-word; max-width: 320px;">Name: <?php echo $customer_name; ?></p>
                        <?php endif; ?>
                        <p>Phone: <?php echo $customer_contact; ?></p>
                        <p class="receipt-address" style="overflow-wrap: break-word; max-width: 320px;">Address: <?php echo $customer_address; ?></p>
                        <p>Payment Method: <?php echo $payment_method; ?> </p>
                        <p>Order Type: <?php echo $order_type; ?> </p>

                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>
                        <!--Dito naka lagay yung mga custom part ng receipt-->
                        <div id="bill-list">

                        </div>
                        <div class="receipt-divider"></div>
                        <!-- Totals -->
                        <div class="receipt-flex mt-2" style="font-size: 14px;">
                            <p>Vatable Sales:</p>
                            <p>₱<?php echo number_format($grand_total - $total_tax, 2); ?></p>
                        </div>
                        <div class="receipt-flex" style="font-size: 14px;">
                            <p>VAT:</p>
                            <p>₱<?php echo number_format($total_tax, 2); ?></p>
                        </div>
                        <div class="receipt-divider"></div>
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>TOTAL:</p>
                            <p>₱<?php echo number_format($grand_total, 2); ?></p>
                        </div>
                        <?php if (($payment_method ?? '') === 'Cash'): ?>
                            <!-- Cash received and change -->
                            <div class="receipt-flex mt-2" style="font-size: 14px;">
                                <p>CASH:</p>
                                <p>₱<?php echo number_format((float) $payment_amount, 2); ?></p>
                            </div>
                            <div class="receipt-flex fw-bold" style="font-size: 16px;">
                                <p>CHANGE:</p>
                                <p>₱<?php echo number_format(max(0, (float) $payment_amount - $grand_total), 2); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal" id="refresh"><i class="bi bi-x-lg me-1"></i>Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print Receipt</button>
                </div>

            </div>
        </div>
    </div>



    <script>
        // Offline POS helpers: clock, empty-cart state, quick cash, change due
        $(document).ready(function() {
            function tick() {
                var d = new Date();
                $("#posClock").text(d.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}));
                $("#posDate").text(d.toLocaleDateString([], {month: 'short', day: 'numeric', year: 'numeric'}));
            }
            tick();
            setInterval(tick, 15000);

            function syncCart() {
                var n = $("#order_queue > .cart-list").length;
                $("#cartCount").text(n);
                $("#cartEmpty").toggleClass("show", n === 0);
                $("#checkout").attr("hidden", n === 0);
                $("#side_orders").prop("hidden", n === 0);
            }
            var q = document.getElementById("order_queue");
            if (q) {
                new MutationObserver(syncCart).observe(q, {childList: true});
            }
            syncCart();

            function money(n) {
                return "₱" + n.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
            }
            function dueTotal() {
                return parseFloat(($("#total-amount").text() || "0").replace(/[^0-9.]/g, "")) || 0;
            }
            function updateChange() {
                var due = dueTotal();
                var paid = parseFloat($("#payment_amount").val()) || 0;
                var diff = paid - due;
                var box = $("#changeDue");
                if (paid > 0 && diff < 0) {
                    box.addClass("short").find(".lbl").text("Short");
                    $("#changeAmt").text(money(Math.abs(diff)));
                } else {
                    box.removeClass("short").find(".lbl").text("Change");
                    $("#changeAmt").text(money(paid > 0 ? diff : 0));
                }
            }

            var modalEl = document.getElementById("checkoutCustomerModal");
            if (modalEl) {
                modalEl.addEventListener("show.bs.modal", function() {
                    $("#checkoutAmount").text(money(dueTotal()));
                    updateChange();
                });
            }

            $("#quickCash").on("click", "button", function() {
                var a = $(this).data("amt");
                $("#payment_amount").val(a === "exact" ? dueTotal() : a).trigger("change");
                updateChange();
            });
            $("#payment_amount").on("input change", updateChange);
        });
    </script>

    <!-- CUSTOMER CHECKOUT -->
    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    title: "Do you want to Log out?",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    html: `
                        <p class="text-muted small mb-4">This will count as you clocking out and you won't be able to log in until your next shift tommorow.</p>
                        <a href='../logout.php' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>`,
                    heightAuto: false
                });
            });
        });

        $(document).ready(function() {
            // Product type tab switching
            $('#productTypeTabs .nav-link').on('click', function() {
                $('#productTypeTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                var product = $(this).data('product');

                $('.product-panel').removeClass('active');
                $('#panel-' + product).addClass('active');
            });
        });
    </script>