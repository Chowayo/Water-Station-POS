<style>
    .top-nav {
        background-color: #112240;
        border-bottom: 1px solid #233554;
    }

    .top-nav-brand-logo {
        width: 42px;
        height: 42px;
        object-fit: contain;
        border-radius: 50%;
        border: 2px solid #64FFDA;
        background-color: #0A192F;
    }

    .top-nav-brand-name {
        font-weight: 800;
        font-size: 14px;
        letter-spacing: 0.5px;
        color: #FFFFFF;
        white-space: nowrap;
    }

    .top-nav-links {
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .top-nav-link {
        color: #b09b88;
        font-weight: 700;
        font-size: 14px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 14px;
        border-radius: 8px;
        white-space: nowrap;
        transition: 0.2s;
    }

    .top-nav-link:hover,
    .top-nav-link.active {
        color: #64FFDA;
        background-color: rgba(100, 255, 218, 0.1);
    }

    .cart-btn {
        position: relative;
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #8892B0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .cart-btn:hover {
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .cart-badge {
        position: absolute;
        top: -4px;
        right: -4px;
        background-color: #FF5252;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        min-width: 18px;
        height: 18px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
    }

    .cart-offcanvas {
        background-color: #112240;
        border-left: 1px solid #233554;
        width: 380px;
        max-width: 90vw;
    }

    .cart-offcanvas .offcanvas-header {
        border-bottom: 1px solid #233554;
        padding: 18px 20px;
    }

    .cart-offcanvas .offcanvas-title {
        font-weight: 800;
        font-size: 18px;
        color: #FFFFFF;
    }

    .cart-offcanvas .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    .cart-offcanvas .offcanvas-body {
        padding: 20px;
        display: flex;
        flex-direction: column;
    }

    .cart-scroll {
        flex: 1;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .cart-scroll::-webkit-scrollbar {
        width: 6px;
    }

    .cart-scroll::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.35);
        border-radius: 10px;
    }

    .cart-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .cart-store-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 14px;
        padding: 14px;
    }

    .cart-store-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .cart-store-info {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .cart-store-logo {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        object-fit: cover;
        flex-shrink: 0;
        background-color: #112240;
    }

    .cart-store-name {
        font-weight: 700;
        font-size: 14px;
        color: #E6F1FF;
        margin: 0;
    }

    .cart-store-meta {
        font-size: 12px;
        color: #8892B0;
        margin: 0;
    }

    .cart-store-meta .cyan-text {
        font-weight: 600;
    }

    .cart-remove-btn {
        background: none;
        border: none;
        color: #8892B0;
        cursor: pointer;
        transition: 0.2s;
    }

    .cart-remove-btn:hover {
        color: #FF5252;
    }

    .cart-thumbs {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .cart-thumb {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        object-fit: cover;
        background-color: #112240;
        border: 1px solid #233554;
    }

    .cart-thumb-add {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        border: 1px dashed #233554;
        background: none;
        color: #64FFDA;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .cart-thumb-add:hover {
        border-color: #64FFDA;
        background-color: rgba(100, 255, 218, 0.08);
    }

    .cart-subtotal-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 14px 0 10px;
    }

    .cart-subtotal-label {
        font-size: 13px;
        color: #8892B0;
    }

    .cart-subtotal-value {
        font-weight: 800;
        font-size: 16px;
        color: #FFFFFF;
    }

    .cart-checkout-btn {
        width: 100%;
        background-color: #64FFDA;
        color: #0A192F;
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-weight: 800;
        transition: 0.2s;
    }

    .cart-checkout-btn:hover {
        background-color: #1de9b6;
        color: #0A192F;
    }

    .cart-empty {
        text-align: center;
        color: #8892B0;
        font-size: 13px;
        padding: 30px 10px;
    }

    .top-nav .profile-avatar-btn {
        width: 42px;
        height: 42px;
        margin: 0;
        background-color: #0A192F;
        border: 2px solid #64FFDA;
        color: #64FFDA;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .top-nav .profile-avatar-btn:hover {
        background-color: rgba(100, 255, 218, 0.1);
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .top-nav .profile-avatar-btn svg {
        width: 20px;
        height: 20px;
    }

    @media (max-width: 991.98px) {
        .top-nav-links {
            display: none;
        }
    }
</style>

<div class="top-nav d-flex justify-content-between align-items-center gap-3 px-4 py-2">

    <!-- Brand -->
    <div class="d-flex align-items-center gap-2">
        <a href="home.php" style="text-decoration: none;">
            <img src="../Images/logo.png" alt="Logo" class="top-nav-brand-logo">
            <span class="top-nav-brand-name"><span class="green-text">ECO</span> HYDRATE HUB</span>
        </a>
    </div>

    <div class="d-flex align-items-center gap-3">

        <?php

        $carts = [
            [
                'store_name' => 'Eco Hydrate - Dasmarinas',
                'store_logo' => '../Images/pizzahut-logo.png',
                'eta' => '5-20 mins',
                'delivery_fee' => 'Free',
                'subtotal' => 2892.00,
                'items' => [
                    '../Images/cart-item-1.jpg',
                    '../Images/cart-item-2.jpg',
                ],
            ],
        ];
        $cart_grand_total = array_sum(array_column($carts, 'subtotal'));
        ?>

        <button class="cart-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas" aria-label="View cart">
            <i class="bi bi-cart3"></i>
            <?php if (count($carts) > 0): ?>
                <span class="cart-badge"><?php echo count($carts); ?></span>
            <?php endif; ?>
        </button>

        <!-- Profile avatar -->
        <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="#adminProfileModal" aria-label="Open profile">
            <i class="bi bi-person"></i>
        </button>

        <!-- Logout -->
        <a href="../logout.php" class="cart-btn" aria-label="Logout" title="Logout">
            <i class="bi bi-box-arrow-right"></i>
        </a>

    </div>
</div>

<!-- Cart offcanvas panel -->
<div class="offcanvas offcanvas-end cart-offcanvas" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="cartOffcanvasLabel">All carts</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">

        <div class="cart-scroll">
            <?php if (empty($carts)): ?>
                <div class="cart-empty">Your cart is empty.</div>
                <?php else: foreach ($carts as $cart): ?>
                    <div class="cart-store-card">
                        <div class="cart-store-row">
                            <div class="cart-store-info">
                                <img src="<?php echo $cart['store_logo']; ?>" alt="" class="cart-store-logo">
                                <div>
                                    <p class="cart-store-name"><?php echo htmlspecialchars($cart['store_name']); ?></p>
                                    <p class="cart-store-meta"><?php echo htmlspecialchars($cart['eta']); ?> &bull; <span class="cyan-text"><?php echo htmlspecialchars($cart['delivery_fee']); ?></span></p>
                                </div>
                            </div>
                            <button type="button" class="cart-remove-btn" aria-label="Remove cart">
                                <i class="bi bi-trash3"></i>
                            </button>
                        </div>

                        <div class="cart-thumbs">
                            <?php foreach ($cart['items'] as $thumb): ?>
                                <img src="<?php echo $thumb; ?>" alt="" class="cart-thumb">
                            <?php endforeach; ?>
                            <button type="button" class="cart-thumb-add" aria-label="Add item">
                                <i class="bi bi-plus-lg"></i>
                            </button>
                        </div>
                    </div>
            <?php endforeach;
            endif; ?>
        </div>

        <?php if (!empty($carts)): ?>
            <div class="cart-subtotal-row">
                <span class="cart-subtotal-label">Subtotal</span>
                <span class="cart-subtotal-value">&#8369;<?php echo number_format($cart_grand_total, 2); ?></span>
            </div>

            <a href="checkout.php" class="btn cart-checkout-btn">Go to checkout</a>
        <?php endif; ?>

    </div>
</div>

<?php include __DIR__ . '/profile.php'; ?>