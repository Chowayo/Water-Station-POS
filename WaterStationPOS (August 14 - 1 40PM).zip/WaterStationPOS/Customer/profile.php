<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">

            <div class="modal-header pb-3 pt-3 px-4">
                <h5 class="modal-title m-0">Employee Profile</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!-- Read-Only -->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3 profile-section-title">Personal Information</h6>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <p class="small mb-1" style="color: #8892B0;">Employee ID</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->id : '1'; ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small mb-1" style="color: #8892B0;">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? ($result->first_name . " " . $result->last_name) : 'chow lu'; ?></p>
                        </div>
                        <div class="col-12">
                            <p class="small mb-1" style="color: #8892B0;">Email Address</p>
                            <p class="fw-bold profile-info-text mb-0"><?php echo isset($result) ? $result->email : 'cashierlu@gmail.com'; ?></p>
                        </div>
                    </div>
                </div>

                <hr style="border-color: #233554;" class="mb-4">

                <!-- Change Password Section -->
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="customerChangePasswordForm" method="POST">
                        <div class="mb-3">
                            <label for="customerCurrentPassword" class="profile-label mb-1">Current Password</label>
                            <input type="password" class="form-control profile-input" id="customerCurrentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="customerNewPassword" class="profile-label mb-1">New Password</label>
                            <input type="password" class="form-control profile-input" id="customerNewPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="customerConfirmPassword" class="profile-label mb-1">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="customerConfirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" name="changePass" class="btn btn-update-pass">Update Password</button>
                        </div>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($result, $conn)) {
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];

                            if (password_verify($current_pass, $result->password)) {
                                if (strlen($new_pass) >= 8) {
                                    if ($new_pass == $confirm_pass) {
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT);

                                            $sql = "UPDATE `customers` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'Your password has been updated!',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script>
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                            })
                                                        })
                                                    </script>
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    })
                                                </script>
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    });
                                                </script>
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                })
                                            });
                                        </script>
                                    HTML;
                            }
                        }
                    }
                    ?>

                </div>
            </div>

        </div>
    </div>
</div>