<?php
include 'header.php';
?>

<style>
    body {
        background: #0a192f !important;
        display: block !important;
        overflow-y: auto !important;
        padding: 0 !important;
        min-height: 100vh;
    }

    .content {
        min-height: 100vh;
    }

    /* TOP TEXT */
    .top-text h1 {
        font-weight: 800;
        color: #ffffff;
        margin-bottom: 0;
    }

    .first-title-text {
        color: #00e676;
    }

    .top-text h6 {
        font-weight: 600;
        color: #8892b0;
        margin-top: 5px;
    }

    /* SEARCH BAR */
    .box {
        background-color: #112240;
        border-radius: 15px;
        border: 1px solid #233554;
    }

    .search-icon-wrap {
        position: relative;
        flex: 1;
    }

    .search-icon-inside {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #8892b0;
    }

    .search-icon-wrap input {
        padding-left: 38px !important;
        background-color: #0d1b2e !important;
        border: 1px solid #233554 !important;
        color: #ccd6f6 !important;
        border-radius: 8px;
    }

    .search-icon-wrap input:focus {
        background-color: #0a192f !important;
        border-color: #00e676 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .btn-filter {
        background-color: #0d1b2e;
        border: 1px solid #233554;
        color: #ccd6f6;
        font-weight: 600;
        border-radius: 8px;
        padding: 0.4rem 1.1rem;
        transition: 0.2s;
    }

    .btn-filter:hover,
    .btn-filter.active {
        background-color: rgba(100, 255, 218, 0.15);
        border-color: #64ffda;
        color: #64ffda;
    }

    /* PRODUCT CARDS */
    .item-card {
        background-color: #112240;
        border: 2px solid #233554;
        border-radius: 20px;
        height: 100%;
        width: 100%;
        font-weight: 700;
        color: #ccd6f6;
        transition: all 0.2s ease;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        padding: 15px 10px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .item-card:hover {
        border-color: #00e676;
        transform: translateY(-3px);
        box-shadow: 0 8px 15px rgba(0, 230, 118, 0.12);
    }

    .product-image {
        display: flex;
        justify-content: center;
        margin-bottom: 10px;
    }

    .product-img {
        width: 180px;
        height: 180px;
        object-fit: contain;
    }

    .price {
        font-size: 16px;
        font-weight: 800;
        color: #00e676;
        margin-bottom: 4px;
    }

    .stock-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
    }

    .stock-badge.stock-ok {
        background-color: rgba(0, 230, 118, 0.12);
        color: #00e676;
        border: 1px solid rgba(0, 230, 118, 0.35);
    }

    .stock-badge.stock-medium {
        background-color: rgba(255, 193, 7, 0.15);
        color: #ffc107;
        border: 1px solid rgba(255, 193, 7, 0.4);
    }

    .stock-badge.stock-low {
        background-color: rgba(220, 53, 69, 0.15);
        color: #ff6b6b;
        border: 1px solid rgba(220, 53, 69, 0.4);
    }

    .btn-add {
        background-color: #007bff;
        color: #ffffff;
        border: none;
        border-radius: 10px;
        width: 100%;
        font-weight: bold;
        padding: 8px 0;
        font-size: 14px;
        transition: 0.2s;
        margin-top: 10px;
    }

    .btn-add:hover {
        background-color: #28a745;
    }

    .right-panel {
        display: none;
        flex-direction: column;
        width: 320px;
        min-width: 320px;
        flex-shrink: 0;
        background-color: #112240;
        border: 2px solid #1e293b;
        border-radius: 24px;
        margin: 20px;
        padding: 24px;
        max-height: calc(100vh - 40px);
    }

    .right-panel.active {
        display: flex !important;
    }

    .orders-panel-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .btn-orders-pill {
        background-color: transparent;
        color: #64ffda;
        border: 2px solid #64ffda;
        border-radius: 30px;
        font-weight: 700;
        padding: 10px 24px;
        font-size: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .btn-clear-round {
        width: 65px;
        height: 65px;
        border-radius: 50%;
        background-color: #ff5252;
        color: #ffffff;
        border: none;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s;
    }

    #order_queue {
        flex-grow: 1;
        overflow-y: auto;
        min-height: 0;
    }

    #order_queue::-webkit-scrollbar {
        width: 6px;
    }

    #order_queue::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.25);
        border-radius: 10px;
    }

    .cart-item {
        background-color: #111b2d;
        /* Darker blue card background */
        border: 1px solid #1e293b;
        /* Subtle inner border */
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 12px;
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .cart-name {
        font-weight: 600;
        color: #ffffff;
        font-size: 14px;
        line-height: 1.3;
    }

    .cart-row-2 {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
    }

    .cart-calc {
        color: #8892b0;
        font-size: 12px;
    }

    .cart-line-total-wrapper {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-left: auto;
    }

    .cart-line-total {
        color: #00e676;
        font-weight: 800;
        font-size: 14px;
    }

    .btn-remove {
        background-color: rgba(255, 77, 77, 0.15);
        color: #ff4d4d;
        border: none;
        border-radius: 6px;
        width: 26px;
        height: 26px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .cart-row-3 {
        display: flex;
        gap: 6px;
        margin-top: 2px;
    }

    .btn-qty {
        background-color: #1a2a40;
        border: none;
        color: #64ffda;
        width: 30px;
        height: 30px;
        border-radius: 6px;
        font-weight: bold;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .qty-display {
        background-color: transparent;
        border: 1px solid #233554;
        color: #ffffff;
        width: 36px;
        height: 30px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        font-weight: 600;
    }

    .totals-box {
        background-color: #111b2d;
        border: 1px solid #1e293b;
        border-radius: 12px;
        padding: 20px;
        margin-top: 15px;
    }

    .total-divider {
        border-color: #233554;
        margin: 0 0 15px 0;
        opacity: 1;
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        font-size: 18px;
        font-weight: 800;
    }

    .total-label,
    #order-total {
        color: #00e676;
    }

    .btn-checkout {
        background-color: #00e676;
        color: #000000;
        border: none;
        border-radius: 20px;
        width: 100%;
        padding: 14px;
        font-size: 16px;
        font-weight: 700;
        margin-top: 15px;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        transition: 0.2s;
    }

    .btn-checkout:hover {
        background-color: #00c866;
    }
</style>

<div class="content d-flex flex-column flex-grow-1">
    <?php include 'topbar.php'; ?>

    <div class="d-flex flex-grow-1 pos-content-row">
        <section class="flex-grow-1 p-4">

            <div class="top-text mb-4">
                <h1>Welcome, <span class="first-title-text">Customer</span></h1>
                <h6>What's your order for today?</h6>
            </div>

            <div class="box shadow p-2">
                <div class="d-flex gap-2" id="productTypeTabs">
                    <div class="search-icon-wrap">
                        <i class="bi bi-search search-icon-inside"></i>
                        <input type="text" class="form-control w-25" placeholder="Search product..." id="searcher">
                    </div>
                    <button class="btn btn-filter ms-auto nav-link active" data-product="All">All</button>
                    <button class="btn btn-filter nav-link" data-product="Refill">Refill</button>
                    <button class="btn btn-filter nav-link" data-product="Container">Container</button>
                </div>
            </div>

            <h4 class="mt-4 mb-3" style="color: #ffffff; font-weight: 700;">All Products</h4>
            <hr style="border-color: #233554;">

            <div class="row g-3 product-container">
                <?php

                function customer_render_product($product_name, $price, $stock, $image, $product_id = 0)
                {
                    if ($stock <= 5) {
                        $stock_class = 'stock-low';
                    } elseif ($stock <= 15) {
                        $stock_class = 'stock-medium';
                    } else {
                        $stock_class = 'stock-ok';
                    }

                    echo '<div class="col-6 col-md-4">
                        <div class="item-card">
                            <div class="product-image">
                                <img src="' . $image . '" class="product-img">
                            </div>
                            <div>' . $product_name . '</div>
                            <div class="price">&#8369;' . $price . '</div>
                            <div class="mb-2"><span class="stock-badge ' . $stock_class . '">Stock: ' . $stock . '</span></div>
                            <button class="btn-add" data-product-id="' . $product_id . '" data-product-name="' . htmlspecialchars($product_name) . '" data-product-price="' . $price . '"><i class="bi bi-cart-plus"></i> Add</button>
                        </div>
                    </div>';
                }

                function customer_product_loader($conn, $category)
                {
                    if ($category === "All") {
                        $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False'";
                    } else {
                        $sql = "SELECT * FROM product WHERE stock > 0 AND deleted = 'False' AND category = '" . $category . "'";
                    }

                    $query = $conn->query($sql);

                    while ($set = $query->fetch_object()) {
                        customer_render_product(
                            $set->product_name . ' ' . $set->measurement . $set->unit . ' ' . $set->category,
                            $set->price,
                            $set->stock,
                            '../Images/' . $set->image,
                            $set->id
                        );
                    }
                }

                if (isset($conn)) {
                    customer_product_loader($conn, "All");
                } else {
                    // Dummy product
                    customer_render_product(
                        'Slim Gallon 20.00L Refill',
                        '35.00',
                        50,
                        'pic',
                        0
                    );
                }
                ?>
            </div>

        </section>

        <aside class="right-panel" id="orderPanel">
            <div class="orders-panel-header">
                <button type="button" class="btn-orders-pill" onclick="location.assign('orders.php')">
                    <i class="bi bi-receipt"></i> Orders
                </button>
                <button type="button" class="btn-clear-round" id="clearOrders">
                    <i class="bi bi-arrow-counterclockwise"></i>
                    Clear
                </button>
            </div>

            <div id="order_queue"></div>

            <div class="totals-box">
                <hr class="total-divider">
                <div class="total-row grand-total">
                    <span class="total-label">Total</span>
                    <span id="order-total">&#8369;0.00</span>
                </div>
            </div>

            <a class="btn-checkout" style="text-decoration: none;" href="checkout.php">
                <i class="bi bi-bag-check"></i> Checkout
            </a>
        </aside>
    </div>
</div>

<script>
    $(document).ready(function() {
        var order = {}; // productId -> { name, price, qty }

        function renderOrderPanel() {
            var $queue = $('#order_queue');
            $queue.empty();

            var total = 0;
            var count = 0;

            $.each(order, function(id, item) {
                count++;
                var lineTotal = item.price * item.qty;
                total += lineTotal;

                var $row = $(
                    '<div class="cart-item" data-order-id="' + id + '">' +
                    '<div class="cart-name">' + item.name + '</div>' +
                    '<div class="cart-row-2">' +
                    '<div class="cart-calc">' + item.qty + ' x \u20B1' + item.price.toFixed(2) + '</div>' +
                    '<div class="cart-line-total-wrapper">' +
                    '<div class="cart-line-total">\u20B1' + lineTotal.toFixed(2) + '</div>' +
                    '<button type="button" class="btn-remove" data-remove-id="' + id + '"><i class="bi bi-x"></i></button>' +
                    '</div>' +
                    '</div>' +
                    '<div class="cart-row-3">' +
                    '<button type="button" class="btn-qty btn-minus" data-id="' + id + '">-</button>' +
                    '<div class="qty-display">' + item.qty + '</div>' +
                    '<button type="button" class="btn-qty btn-plus" data-id="' + id + '">+</button>' +
                    '</div>' +
                    '</div>'
                );

                $queue.append($row);
            });

            $('#order-total').text('\u20B1' + total.toFixed(2));

            if (count > 0) {
                $('#orderPanel').addClass('active');
            } else {
                $('#orderPanel').removeClass('active');
            }
        }

        $('#productTypeTabs .nav-link').on('click', function() {
            $('#productTypeTabs .nav-link').removeClass('active');
            $(this).addClass('active');
        });

        $(document).on('click', '.btn-add', function() {
            var $btn = $(this);
            var id = $btn.data('product-id');
            var name = $btn.data('product-name');
            var price = parseFloat($btn.data('product-price'));

            if (order[id]) {
                order[id].qty += 1;
            } else {
                order[id] = {
                    name: name,
                    price: price,
                    qty: 1
                };
            }

            renderOrderPanel();

            // Visual feedback: Turn button green and say "Added"
            var originalText = $btn.html();
            $btn.html('<i class="bi bi-check-lg"></i> Added');
            $btn.css('background-color', '#28a745');

            // Revert back to original state after 1 second
            setTimeout(function() {
                $btn.html(originalText);
                $btn.css('background-color', '');
            }, 1000);
        });

        $(document).on('click', '.btn-remove', function() {
            var id = $(this).data('remove-id');
            delete order[id];
            renderOrderPanel();
        });

        $('#clearOrders').on('click', function() {
            order = {};
            renderOrderPanel();
        });

        $(document).on('click', '.btn-qty', function() {
            var id = $(this).data('id');

            if ($(this).hasClass('btn-plus')) {
                order[id].qty += 1;
            } else if ($(this).hasClass('btn-minus')) {
                order[id].qty -= 1;
                if (order[id].qty <= 0) {
                    delete order[id];
                }
            }

            renderOrderPanel();
        });
    });
</script>