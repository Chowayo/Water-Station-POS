<!DOCTYPE html>
<html lang="en">

<?php

include 'header.php';

?>

<body>

    <div class="auth-card">

        <img src="../Images/logo.png" alt="Eco Hydrate Hub" class="auth-logo">

        <div class="auth-title"><b>Welcome!</b></div>
        <div class="auth-subtitle">Join the Eco Hydrate Community</div>

        <form action="#" method="POST">

            <div class="auth-field">
                <label for="fullName" class="auth-label">Full Name</label>
                <input type="text" id="fullName" name="fullName" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="email" class="auth-label">Email</label>
                <input type="email" id="email" name="email" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="password" class="auth-label">Password</label>
                <input type="password" id="password" name="password" class="auth-input">
                <div class="auth-hint">At least 8 characters, 1 number</div>
            </div>

            <div class="auth-field">
                <label for="confirmPassword" class="auth-label">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" class="auth-input" required>
            </div>

            <button type="submit" class="btn-create-account">Create account</button>

            <div class="auth-footer">
                Already have an account? <a href="../index.php">Login</a>
            </div>

        </form>

    </div>

</body>

</html>