<?php
include 'header.php';
?>

<style>
    body {
        background: #0a192f !important;
        display: block !important;
        overflow-y: auto !important;
        padding: 0 !important;
        min-height: 100vh;
    }

    .checkout-container {
        max-width: 1100px;
        margin: 0 auto;
    }

    /* Card Styling */
    .checkout-card {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .text-primary-accent {
        color: #00e676 !important;
    }

    .btn-primary-accent {
        background-color: #00fc9e;
        color: #000000;
        font-weight: 700;
        border: none;
        border-radius: 25px;
        padding: 14px;
        width: 100%;
        transition: 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }

    .btn-primary-accent:hover {
        background-color: #00e676;
    }

    /* Form Inputs & Checkboxes */
    .form-control {
        background-color: #0d1b2e !important;
        border: 1px solid #233554 !important;
        color: #ccd6f6 !important;
    }

    .form-control:focus {
        background-color: #0a192f !important;
        border-color: #00e676 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .form-control::placeholder {
        color: #8892b0 !important;
    }

    .form-check-input {
        background-color: #0d1b2e;
        border: 1px solid #233554;
    }

    .form-check-input:checked {
        background-color: #00e676;
        border-color: #00e676;
    }

    .delivery-option-box,
    .payment-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: 0.2s;
    }

    .payment-box {
        display: block;
    }

    /* When checked */
    .delivery-option-box:has(input:checked),
    .payment-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    /* Tip Buttons */
    .tip-btn {
        border: 1px solid #233554;
        color: #ccd6f6;
        font-weight: 600;
        padding: 6px 16px;
        background: #0d1b2e;
        transition: 0.2s;
    }

    h2,
    h4,
    h6,
    .text-white {
        color: #ffffff !important;
    }

    .text-muted {
        color: #8892b0 !important;
    }

    .custom-link {
        color: #64ffda;
        text-decoration: none;
        font-weight: 600;
        transition: 0.2s;
    }

    .custom-link:hover {
        color: #00e676;
    }

    .divider {
        border-color: #233554;
        opacity: 1;
    }

    .icon-box {
        background-color: #112240;
        border: 1px solid #233554;
    }

    .modal-content {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
    }

    .modal-header {
        border-bottom: 1px solid #233554;
    }

    .btn-close-white {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    /* Address Box styling */
    .address-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        transition: 0.2s;
    }

    .address-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    .address-box:has(input:checked) .bi-geo-alt {
        color: #00e676 !important;
    }

    .address-actions .btn-icon {
        background: transparent;
        border: none;
        color: #8892b0;
        padding: 4px;
        transition: 0.2s;
        font-size: 18px;
    }

    .address-actions .btn-icon:hover {
        color: #00e676;
    }

    /* Map Placeholder */
    .map-placeholder {
        width: 100%;
        height: 160px;
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Label Buttons */
    .label-btn {
        background-color: #0d1b2e;
        color: #ccd6f6;
        border: 1px solid #233554;
        border-radius: 20px;
        padding: 6px 16px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .label-btn:hover,
    .label-btn.active {
        background-color: rgba(0, 230, 118, 0.1);
        border-color: #00e676;
        color: #00e676;
    }

    .label-btn i {
        font-size: 16px;
    }

    /* Add Address Custom Input */
    .address-search-wrapper {
        position: relative;
        margin-bottom: 20px;
    }

    .address-search-wrapper label {
        position: absolute;
        top: -9px;
        left: 12px;
        background-color: #112240;
        padding: 0 5px;
        font-size: 11px;
        color: #8892b0;
        z-index: 1;
    }

    .address-search-input {
        width: 100%;
        background-color: transparent !important;
        border: 1px solid #233554 !important;
        border-radius: 10px;
        color: #ccd6f6 !important;
        padding: 14px 40px 14px 15px;
        font-size: 14px;
    }

    .address-search-input:focus {
        border-color: #00e676 !important;
        outline: none;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .address-clear-btn {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #8892b0;
        padding: 0;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .address-clear-btn:hover {
        color: #ccd6f6;
    }

    /* Large Map Placeholder */
    .map-placeholder-lg {
        width: 100%;
        height: 380px;
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 10px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
    }

    .map-tooltip {
        background-color: #112240;
        border: 1px solid #233554;
        color: #ffffff;
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        position: relative;
        margin-bottom: 2px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        z-index: 2;
    }

    .map-tooltip::after {
        content: '';
        position: absolute;
        bottom: -6px;
        left: 50%;
        transform: translateX(-50%);
        border-width: 6px 6px 0;
        border-style: solid;
        border-color: #112240 transparent transparent transparent;
    }

    .map-tooltip::before {
        content: '';
        position: absolute;
        bottom: -7px;
        left: 50%;
        transform: translateX(-50%);
        border-width: 7px 7px 0;
        border-style: solid;
        border-color: #233554 transparent transparent transparent;
        z-index: -1;
    }
</style>

<div class="content d-flex flex-column flex-grow-1">
    <?php include 'topbar.php'; ?>

    <div class="checkout-container py-5 px-3 flex-grow-1">

        <!-- Page Title -->
        <h2 class="fw-bold mb-4" style="font-size: 28px;">Review and place your order</h2>

        <div class="row g-4">

            <!-- LEFT COLUMN: Delivery Details & Options -->
            <div class="col-lg-7">

                <!-- Delivery Address Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h4 class="fw-bold m-0">Delivery address</h4>
                        <a href="#" class="custom-link" data-bs-toggle="modal" data-bs-target="#addressModal">Change</a>
                    </div>

                    <div class="d-flex mb-3 align-items-start">
                        <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                        <div>
                            <p class="m-0 text-white fw-semibold">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa veniam rerum suscipit ipsum fugit, necessitatibus labore, asperiores nihil aliquam voluptas delectus explicabo doloremque laborum aut velit at maiores minima nesciunt.</p>
                        </div>
                    </div>

                    <!-- Note to rider input -->
                    <textarea class="form-control mb-4 mt-3" placeholder="Note to rider - e.g. building, landmark" rows="2" style="resize: none;"></textarea>

                </div>

                <!-- Delivery Options Card -->
                <div class="checkout-card p-4 mb-4">
                    <h4 class="fw-bold mb-4">Delivery options</h4>

                    <label class="delivery-option-box mb-3">
                        <div class="d-flex align-items-center gap-3">
                            <input class="form-check-input fs-5 m-0" type="radio" name="delOption" checked>
                            <span class="fw-bold text-white">Standard <span class="fw-normal text-muted ms-2">10 - 25 mins</span></span>
                        </div>
                    </label>

                    <label class="delivery-option-box mb-3">
                        <div class="d-flex align-items-center gap-3">
                            <input class="form-check-input fs-5 m-0" type="radio" name="delOption">
                            <span class="fw-bold text-white">Priority <span class="fw-normal text-muted ms-2">5 - 20 mins</span></span>
                        </div>
                        <span class="badge rounded-pill border border-secondary fw-normal text-muted bg-transparent">+ ₱ 49.00</span>
                    </label>

                    <label class="delivery-option-box">
                        <div class="d-flex align-items-center gap-3">
                            <input class="form-check-input fs-5 m-0" type="radio" name="delOption">
                            <span class="fw-bold text-white">Scheduled <span class="fw-normal text-muted ms-2">Select a date and time</span></span>
                        </div>
                    </label>
                </div>

                <!-- Personal Details Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Personal details</h4>
                        <a href="#" class="custom-link">Edit</a>
                    </div>
                    <div>
                        <div class="fw-bold text-white">Luz Cantos</div>
                        <div class="text-muted mt-1">luzcantos@gmail.com</div>
                        <div class="text-muted">+63 123456678456</div>
                    </div>
                </div>

                <!-- Payment Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Payment</h4>
                    </div>

                    <label class="payment-box mb-2">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption" checked>
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-cash fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Cash On Delivery</span>
                            <span class="badge rounded-pill" style="background-color: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35);">Primary</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Consider payment upon ordering for contactless delivery. You can't pay by a card to the rider upon delivery.
                        </div>
                    </label>
                    <label class="payment-box mb-0">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption" checked>
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-cash fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Gcash</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Pay Via Gcash
                        </div>
                    </label>
                </div>

                <button class="btn-primary-accent d-block d-lg-none mt-2 mb-5"><i class="bi bi-bag-check"></i> Place order</button>

            </div>

            <!-- RIGHT COLUMN: Sticky Order Summary -->
            <div class="col-lg-5">

                <div class="checkout-card p-4 position-sticky" style="top: 24px;">

                    <h4 class="fw-bold m-0">Your order from</h4>
                    <p class="text-muted mb-4 mt-1">Eco Hydrate - Dasmarinas</p>

                    <!-- Cart Items -->
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="fw-semibold text-white">1 x Slim Gallon Refill</div>
                        <div class="fw-bold text-primary-accent">₱ 35.00</div>
                    </div>

                    <div class="mb-4 mt-3">
                        <a href="#" class="custom-link"><i class="bi bi-plus-lg me-2"></i>Add more items</a>
                    </div>

                    <hr class="divider">


                    <!-- Price Breakdown -->
                    <div class="d-flex justify-content-between text-muted mb-2 mt-3" style="font-size: 14px;">
                        <span>Subtotal</span>
                        <span>₱ 35.00</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;">
                        <span style="color: #00e676;">Standard delivery</span>
                        <span>Free</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;">
                        <span>VAT</span>
                        <span>₱ 0.00</span>
                    </div>

                    <!-- Grand Total -->
                    <div class="d-flex justify-content-between align-items-end mb-4">
                        <div>
                            <h4 class="fw-bold m-0">Total</h4>
                            <span class="text-muted" style="font-size: 12px;">(incl. fees and tax)</span>
                        </div>
                        <div class="text-end">
                            <h4 class="fw-bold m-0 text-primary-accent">₱ 74.23</h4>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button class="btn-primary-accent d-none d-lg-flex"><i class="bi bi-bag-check"></i> Place order</button>

                </div>
            </div>

        </div>
    </div>

    <!-- Delivery Address Modal -->
    <div class="modal fade" id="addressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">
                    <h6 class="fw-bold text-white mb-3">Saved Addresses</h6>

                    <div class="d-flex flex-column gap-3 mb-4">
                        <!-- Address 1 -->
                        <label class="address-box m-0">
                            <input class="form-check-input flex-shrink-0 fs-5 mt-1" type="radio" name="savedAddress" checked>
                            <i class="bi bi-geo-alt fs-5 mt-1 text-muted transition"></i>
                            <div class="flex-grow-1 text-white">
                                <div class="fw-semibold" style="line-height: 1.4;">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio fugit saepe vitae repellendus dolore ipsa porro architecto aperiam libero, voluptate repellat laboriosam optio deleniti aut maiores natus maxime, soluta vero.</div>
                                <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                                <div class="text-muted" style="font-size: 13px;">Note to rider: none</div>
                            </div>
                            <div class="address-actions d-flex flex-column gap-2 flex-shrink-0">
                                <button type="button" class="btn-icon" data-bs-toggle="modal" data-bs-target="#editAddressModal"><i class="bi bi-pencil"></i></button>
                                <button type="button" class="btn-icon"><i class="bi bi-trash"></i></button>
                            </div>
                        </label>

                        <!-- Address 2 -->
                        <label class="address-box m-0">
                            <input class="form-check-input flex-shrink-0 fs-5 mt-1" type="radio" name="savedAddress">
                            <i class="bi bi-geo-alt fs-5 mt-1 text-muted transition"></i>
                            <div class="flex-grow-1 text-white">
                                <div class="fw-semibold" style="line-height: 1.4;">Lorem ipsum dolor sit amet, consectetur </div>
                                <div class="text-muted mt-1" style="font-size: 13px;">Dasmarinas</div>
                                <div class="text-muted" style="font-size: 13px;">Floor: Lorem ipsum dolor sit amet, consectetur</div>
                                <div class="text-muted" style="font-size: 13px;">Note to rider: none</div>
                            </div>
                            <div class="address-actions d-flex flex-column gap-2 flex-shrink-0">
                                <button type="button" class="btn-icon" data-bs-toggle="modal" data-bs-target="#editAddressModal"><i class="bi bi-pencil"></i></button>
                                <button type="button" class="btn-icon"><i class="bi bi-trash"></i></button>
                            </div>
                        </label>
                    </div>

                    <!-- Add Address Button -->
                    <a href="#" class="custom-link d-inline-flex align-items-center gap-2 mb-2" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                        <i class="bi bi-plus-lg fs-5"></i> Add address
                    </a>
                </div>

            </div>
        </div>
    </div>

    <!-- Edit Address Modal -->
    <div class="modal fade" id="editAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2 d-flex justify-content-between align-items-center">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <a href="#" class="text-muted text-decoration-none fw-semibold" data-bs-dismiss="modal">Cancel</a>
                </div>

                <div class="modal-body p-4 pt-3">

                    <!-- Map Placeholder -->
                    <div class="map-placeholder mb-4">
                        <i class="bi bi-map text-muted opacity-50" style="font-size: 40px;"></i>
                    </div>

                    <!-- Address Text & Edit Link -->
                    <div class="d-flex align-items-start mb-3">
                        <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                        <div class="flex-grow-1 text-white">
                            <div class="fw-semibold" style="line-height: 1.4;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque consectetur ut explicabo ratione rem expedita, fugiat rerum necessitatibus harum ipsa, quae obcaecati deleniti architecto quisquam voluptatum aliquid saepe deserunt minima.</div>
                            <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                        </div>
                        <a href="#" class="custom-link ms-2">Edit</a>
                    </div>

                    <hr class="divider mb-4">

                    <!-- Floor Input -->
                    <input type="text" class="form-control mb-3" placeholder="Floor">

                    <!-- Note to rider -->
                    <textarea class="form-control mb-4" placeholder="Note to rider - e.g. building, landmark" rows="3" style="resize: none;"></textarea>

                    <!-- Labels -->
                    <h6 class="text-white fw-bold mb-3">Add a Label</h6>
                    <div class="d-flex flex-wrap gap-2 mb-4">
                        <button type="button" class="btn label-btn"><i class="bi bi-house"></i> Home</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-briefcase"></i> Work</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-heart"></i> Partner</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-plus-lg"></i> Other</button>
                    </div>

                    <!-- Submit Button -->
                    <button type="button" class="btn-primary-accent w-100" data-bs-dismiss="modal">SUBMIT</button>

                </div>
            </div>
        </div>
    </div>

    <!-- Add Address Modal -->
    <div class="modal fade" id="addAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <!-- Header -->
                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt fs-4"></i> What's your exact location?
                    </h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">

                    <p class="text-muted mb-4" style="font-size: 14.5px;">
                        Providing your location enables more accurate search and delivery ETA, seamless order tracking and personalised recommendations.
                    </p>

                    <!-- Custom Input Field -->
                    <div class="address-search-wrapper">
                        <label>Enter your address</label>
                        <input type="text" class="form-control address-search-input" value="addresssssssssssssssssssssssssssssssssssssssss">
                        <button class="address-clear-btn"><i class="bi bi-x-circle"></i></button>
                    </div>

                    <!-- Large Map Placeholder -->
                    <div class="map-placeholder-lg">
                        <!-- Tooltip and Pin -->
                        <div class="map-tooltip">We'll deliver here</div>
                        <i class="bi bi-geo-alt-fill text-primary-accent position-relative" style="font-size: 38px; z-index: 2; top: -5px;"></i>

                        <!-- Faded background map icon -->
                        <i class="bi bi-map text-muted position-absolute" style="font-size: 100px; opacity: 0.15; z-index: 0;"></i>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>