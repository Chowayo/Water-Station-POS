<?php

include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<head>
    <title>Admin Dashboard - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">

    <style>
        .table-scroll-wrap {
            max-height: 520px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Admin Dashboard</h1>
                    <h6>Control Center For Monitoring</h6>
                </div>
            </header>

            <!-- TODAY: SALES  -->
            <div class="row g-4 mb-4 justify-content-center">

                <div class="col-md-4">
                    <div class="dash-card d-flex justify-content-between align-items-center text-start px-4 py-3">
                        <div>
                            <div class="dash-title">Todays Income</div>
                            <div class="dash-value green-text">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date = CURDATE() AND type ='Income'";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                } else {
                                    echo "₱0.00";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="icon-wrapper-square icon-income-square">
                            <i class="bi bi-cash-stack"></i>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card d-flex justify-content-between align-items-center text-start px-4 py-3">
                        <div>
                            <div class="dash-title">Total Orders Today</div>
                            <div class="dash-value">
                                <?php
                                $sql = "SELECT COUNT(id) AS total FROM orders WHERE date = CURDATE() AND deleted = 'False'";
                                $query = $conn->query($sql);
                                $set = $query->fetch_object();
                                echo $set->total;
                                ?>
                            </div>
                        </div>
                        <div class="icon-wrapper-square icon-orders-square">
                            <i class="bi bi-cart-check"></i>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Overview -->
            <div class="pulse-strip mb-4">
                <div class="pulse-item">
                    <span class="pulse-label">Employees</span>
                    <span class="pulse-value">
                        <?php
                        $sql = "SELECT COUNT(id) AS total FROM employees";
                        $query = $conn->query($sql);
                        $set = $query->fetch_object();
                        echo $set->total;
                        ?>
                    </span>
                </div>
                <div class="pulse-divider"></div>
                <div class="pulse-item">
                    <span class="pulse-label">Present Today</span>
                    <span class="pulse-value" style="color:#64FFDA;">
                        <?php

                        $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status != 'Absent' AND date = CURDATE()";
                        $query = $conn->query($sql);
                        $set = $query->fetch_object();
                        echo $set->total;
                        ?>
                    </span>
                </div>
                <div class="pulse-divider"></div>
                <div class="pulse-item">
                    <span class="pulse-label">Pending Leave</span>
                    <span class="pulse-value" style="color:#FFC107;">
                        <?php
                        $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Pending'";
                        $query = $conn->query($sql);
                        $set = $query->fetch_object();
                        echo $set->total;
                        ?>
                    </span>
                </div>
                <div class="pulse-divider d-none d-md-block"></div>
                <div class="pulse-item">
                    <span class="pulse-label">Revenue (Month)</span>
                    <span class="pulse-value" style="color:#00E676;">
                        <?php
                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                        $query = $conn->query($sql);
                        $income = $query->fetch_object();

                        if ($income != "") {
                            echo "₱" . $income->total;
                            $month_income = $income->total;
                        } else {
                            echo "₱0.00";
                            $month_income = 0.00;
                        }
                        ?>
                    </span>
                </div>
                <div class="pulse-divider d-none d-md-block"></div>
                <div class="pulse-item">
                    <span class="pulse-label">Net P/L (Month)</span>
                    <span class="pulse-value" style="color:#FF5252;">
                        <?php
                        //Getting monthly expenses from TRANSACTION table
                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Expense'";
                        $query = $conn->query($sql);
                        $month_expense = $query->fetch_object();

                        //Getting monthly expenses from EXPENSE table
                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')";
                        $query = $conn->query($sql);
                        $extra_expense = $query->fetch_object();

                        if ($month_expense == "") {
                            $month_expense = 0.00;
                        }

                        if ($extra_expense == "") {
                            $extra_expense = 0.00;
                        }

                        $total_expense = ($month_expense->total + $extra_expense->total);
                        echo "₱" . ($month_income - $total_expense);
                        ?>
                    </span>
                </div>

                <div class="pulse-actions">
                    <a href="hr.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                        <i class="bi bi-people me-1"></i>HR
                    </a>
                    <a href="finance.php" class="btn btn-sm btn-outline-light rounded-pill px-3">
                        <i class="bi bi-cash-coin me-1"></i>Finance
                    </a>
                </div>
            </div>

            <!--  RECENT SALES  -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-receipt me-2"></i>Recent Sales Report</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
                            <h5 class="mb-0 pt-1">Today's Orders</h5>
                            <div class="search-container">
                                <i class="bi bi-search"></i>
                                <input type="text" class="form-control table-search-input" placeholder="Search Order" id="searcher">
                            </div>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#order_list').DataTable({
                                    paging: true, // Paginate once the list grows
                                    pageLength: 6, // Rows per page before a new page is added
                                    lengthChange: false,
                                    searching: true, // Enable search functionality
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>' // Table scrolls in its own box; info + pagination sit below it
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw(); //Sets the input box as the new search bar
                                });


                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="order_list">
                            <thead>
                                <tr>
                                    <th>Order Number</th>
                                    <th>Customer Name</th>
                                    <th>Order Content</th>

                                    <th>Total</th>
                                    <th>Payment Method</th>
                                    <th>Order Type</th>
                                    <th>Time</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //Loading employee list
                                $sql = "SELECT * FROM orders WHERE date = CURDATE() AND payment_method != 'Pending' AND deleted = 'False'";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                                    <tr>
                                                        <td class="cyan-text fw-bold">#' . $set->id . '</td>
                                                        <td style="overflow-wrap: break-word; max-width: 320px;"><strong class="d-block">' . $set->customer_name . '</strong></td>
                                                        <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>' . $set->order_content . '</b></td>
                                                        <td class="green-text fw-bold fs-5">₱' . $set->total_price . '</td>';
                                    if ($set->payment_method == "Gcash") {
                                        echo '<td><span class="badge bg-warning"><i class="bi bi-credit-card me-1"></i>GCash</span></td>';
                                    } else if ($set->payment_method == "Cash") {
                                        echo '<td><span class="badge bg-success"><i class="bi bi-credit-card me-1"></i>Cash</span></td>';
                                    }

                                    echo '
                                                        <td>' . $set->order_type . '</td>
                                                        <td><i class="bi bi-clock me-1"></i>' . $set->time . '</td>
                                                        <td><i class="bi bi-calendar-event me-1"></i>' . $set->date . '</td>
                                                    ';
                                    if ($set->status == "Not received") {
                                        echo '
                                                        <td>
                                                            <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn" data-id="' . $set->id . '" id="btn-confirm"><i class="bi bi-hourglass-split me-1"></i>Order Pending</button>
                                                            <button class="btn btn-delete btn-sm rounded-pill px-3 delete-btn" data-id="' . $set->id . '" ><i class="bi bi-trash me-1"></i>Delete</button>
                                                        </td>';
                                    } else {
                                        echo '
                                                        <td>
                                                            <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn"><i class="bi bi-check-circle me-1"></i>Order Received</button>
                                                            <button class="btn btn-delete btn-sm rounded-pill px-3 delete-btn" data-id="' . $set->id . '"><i class="bi bi-trash me-1"></i>Delete</button>
                                                        </td>';
                                    }
                                    echo '
                                                </tr>';
                                }
                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                    //Approve Order
                                    if (isset($_POST['confirm'])) {
                                        $sql = "UPDATE `orders` SET `status` = 'Received' WHERE id = " . $_POST['confirm'];
                                        if ($conn->query($sql) === TRUE) {

                                            $sql = "SELECT * FROM orders WHERE id=" . $_POST['confirm'];
                                            $query = $conn->query($sql);
                                            $order = $query->fetch_object();


                                            //Will insert value into transactions
                                            if ($order->order_type == "Delivery") {
                                                $description = "Order #" . $order->id . " Payment";
                                                $category = "Sales";
                                                $type = "Income";
                                                $sql = "INSERT INTO `transactions` (`date`, `description`, `category`, `type`, `payment_method`, `amount`) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("ssssd", $description, $category, $type, $order->payment_method, $order->total_price);
                                                if ($stmt->execute()) {
                                                }
                                            }

                                            //Notification
                                            if ($order->order_type == "Delivery") {
                                                $sql = "SELECT * FROM employees WHERE role = 'Cashier' OR role = 'Delivery' OR role = 'Finance'";
                                                $query = $conn->query($sql);
                                                while ($emp_info = $query->fetch_object()) {
                                                    $notif_id = $emp_info->id;
                                                    $notif_role = $emp_info->role;

                                                    $notif_category = "Order Confirmed";
                                                    $notif_message = "Order #" . $order->id . " has been confirmed for " . $order->order_type;

                                                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                    if ($stmt->execute()) {
                                                    }
                                                }
                                            }

                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Order Received!',
                                                                    text: 'The order has been completed.',
                                                                    color: '#CCD6F6',
                                                                    background: '#112240',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('dashboard.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }
                                    if (isset($_POST['deleter'])) {
                                        $sql = "UPDATE `orders` SET `deleted` = 'True' WHERE id = " . $_POST['deleter'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Order Deleted!',
                                                                    text: 'The order has been deleted.',
                                                                    color: '#CCD6F6',
                                                                    background: '#112240',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('dashboard.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }
                                }



                                ?>
                                <!--
                                    <tr>
                                        <td class="cyan-text fw-bold">#7</td>
                                        <td><strong class="d-block">Luz</strong></td>
                                        <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>1x Alkaline Water 5G</b></td>
                                        <td class="green-text fw-bold fs-5">₱20.00</td>
                                        <td><span class="badge bg-success"><i class="bi bi-credit-card me-1"></i>Cash</span></td>
                                        <td>Delivery</td>
                                        <td><i class="bi bi-clock me-1"></i>08:21:34</td>
                                        <td><i class="bi bi-calendar-event me-1"></i>07/19/2026</td>
                                        <td>
                                            <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn"><i class="bi bi-check2-circle me-1"></i>Order Received</button>
                                            <button class="btn btn-delete btn-sm rounded-pill px-3 delete-btn"><i class="bi bi-trash me-1"></i>Delete</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="cyan-text fw-bold">#4</td>
                                        <td><strong class="d-block">Maybelle</strong></td>
                                        <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>2x Purified Water 5G</b></td>
                                        <td class="green-text fw-bold fs-5">₱30.00</td>
                                        <td><span class="badge bg-warning"><i class="bi bi-credit-card me-1"></i>GCash</span></td>
                                        <td>Pickup</td>
                                        <td><i class="bi bi-clock me-1"></i>08:21:56</td>
                                        <td><i class="bi bi-calendar-event me-1"></i>07/19/2026</td>
                                        <td>
                                            <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn"><i class="bi bi-hourglass-split me-1"></i>Order Pending</button>
                                            <button class="btn btn-delete btn-sm rounded-pill px-3 delete-btn"><i class="bi bi-trash me-1"></i>Delete</button>
                                        </td>
                                    </tr>-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            //Confirming Delivery
            $(".confirm-btn").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Confirm Delivery?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="confirm" value="' + id + '" class="btn btn-confirm">Confirm Order</button></form>',
                    heightAuto: false
                })
            });

            $(".done-btn").click(function() {
                Swal.fire({
                    title: 'Order Complete',
                    text: "The order has been received",
                    icon: 'success',
                    background: '#112240',
                    confirmButtonColor: '#00A859',
                    color: '#CCD6F6',
                    showConfirmButton: true,
                    heightAuto: false
                })
            });

            //Delete Order
            $(".delete-btn").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Delete Order?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-delete">Confirm Delete</button></form>',

                    heightAuto: false
                })
            });

            // Logout SweetAlert
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>