<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<head>
    <title>Expenses - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>
        .ap-scroll-wrap {
            max-height: 420px;
            overflow-y: auto;
        }

        .ap-scroll-wrap thead th {
            position: sticky;
            top: 0;
            z-index: 2;
            background-color: #0A1F3C;
        }

        .ap-scroll-wrap::-webkit-scrollbar {
            width: 8px;
        }

        .ap-scroll-wrap::-webkit-scrollbar-thumb {
            background-color: rgba(100, 255, 218, 0.35);
            border-radius: 10px;
        }

        .ap-scroll-wrap::-webkit-scrollbar-track {
            background: transparent;
        }

        /* ===== Scrollable table container (Recent Expenses) ===== */
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Expenses</h1>
                    <h6>Operating costs, inventory restocks, and utilities</h6>
                </div>
            </header>

            <!-- Budget vs Actuals -->
            <div class="section-header"><i class="bi bi-graph-up me-2"></i>Budget vs Actuals ( This Month )</div>
            <div class="row g-4 mb-4">
                <div class="col-md-3 col-6">
                    <div class="budget-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Supplies</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Supplies'";
                                $query = $conn->query($sql);
                                $supplies_total = $query->fetch_object();

                                if ($supplies_total != "") {
                                    echo "₱" . $supplies_total->total . "/ ₱20,000";
                                    $supplies_percent = ($supplies_total->total / 20000) * 100;
                                } else {
                                    echo "₱0.00 / ₱20,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">

                            <div class="budget-fill warning" style="width: <?php echo $supplies_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="budget-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Maintenance</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Maintenance'";
                                $query = $conn->query($sql);
                                $maintenance_total = $query->fetch_object();

                                if ($maintenance_total != "") {
                                    echo "₱" . $maintenance_total->total . "/ ₱10,000";
                                    $maintenance_percent = ($maintenance_total->total / 10000) * 100;
                                } else {
                                    echo "₱0.00 / ₱10,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-fill safe" style="width: <?php echo $maintenance_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="budget-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Transportation/Fuel</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Transport/Fuel'";
                                $query = $conn->query($sql);
                                $transport_total = $query->fetch_object();

                                if ($transport_total != "") {
                                    echo "₱" . $transport_total->total . "/ ₱5,000";
                                    $transport_percent = ($transport_total->total / 5000) * 100;
                                } else {
                                    echo "₱0.00 / ₱5,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-fill over" style="width: <?php echo $transport_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="budget-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Utilities</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Utilities'";
                                $query = $conn->query($sql);
                                $utilities_total = $query->fetch_object();

                                if ($utilities_total != "") {
                                    echo "₱" . $utilities_total->total . "/ ₱12,000";
                                    $utilities_percent = ($utilities_total->total / 12000) * 100;
                                } else {
                                    echo "₱0.00 / ₱12,000";
                                }


                                //Over budget notification
                                if ($supplies_percent > 100 || $maintenance_percent > 100 || $transport_percent > 100 || $utilities_percent > 100) {
                                    //Short Balance notification
                                    $role_list = array("Admin", "Financer");
                                    foreach ($role_list as $role) {
                                        if ($role == "Admin") {
                                            $sql = "SELECT * FROM admin";
                                        } elseif ($role == "Financer") {
                                            $sql = "SELECT * FROM employees WHERE role = '" . $role . "' AND deleted = 'False'";
                                        }

                                        $query = $conn->query($sql);
                                        while ($emp_info = $query->fetch_object()) {
                                            $notif_id = $emp_info->id;
                                            $notif_role = $emp_info->role;

                                            $categories = array();

                                            $notif_category = "Budget Exceeded";
                                            if ($supplies_percent > 100) {
                                                $categories[] = "supplies";
                                            }
                                            if ($maintenance_percent > 100) {
                                                $categories[] = "maintenance";
                                            }
                                            if ($transport_percent > 100) {
                                                $categories[] = "transport";
                                            }
                                            if ($utilities_percent > 100) {
                                                $categories[] = "utilities";
                                            }

                                            foreach ($categories as $cats) {
                                                $notif_message = "The category " . $cats . " has gone way off budget";

                                                //No repeation ON THE SAME DAY checker
                                                $sql = "SELECT * FROM notification WHERE message = '" . $notif_message . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                                                $checker_query = $conn->query($sql);
                                                $check = $checker_query->fetch_object();

                                                if (!$check) {
                                                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                    if ($stmt->execute()) {
                                                    }
                                                }

                                                echo <<<HTML
                                                        <script>
                                                            console.log("{$cats}");
                                                        </script>
                                                    HTML;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-fill safe" style="width: <?php echo $utilities_percent ?>%;"></div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row g-4 mb-4">

                <!-- Expense Entry Form -->
                <div class="col-12 col-lg-5">
                    <div class="section-header"><i class="bi bi-plus-circle me-2"></i>Log New Expense</div>
                    <div class="manage-box shadow-sm">

                        <div class="expense-mode-toggle mb-4" id="expenseModeToggle">
                            <button type="button" class="mode-btn active" data-mode="expense"><i class="bi bi-cash-stack me-1"></i>Expense</button>
                            <button type="button" class="mode-btn" data-mode="bill"><i class="bi bi-receipt me-1"></i>Bill / Invoice</button>
                        </div>

                        <form id="expenseForm" method="POST" enctype="multipart/form-data">
                            <div class="row g-3">
                                <div class="col-6">
                                    <label class="form-label" id="dateFieldLabel">Date</label>
                                    <input type="date" class="form-control" name="date" required>
                                </div>
                                <div class="col-6">
                                    <label class="form-label">Amount</label>
                                    <input type="number" step="0.01" class="form-control" name="amount" placeholder="0.00" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label" id="supplierFieldLabel">Supplier Name</label>
                                    <input type="text" class="form-control" name="supplier_name" placeholder="e.g. Aqua Supplies Co." required>
                                </div>

                                <!-- Installment Plan -->
                                <div class="col-12 bill-only-field" style="display: none;">
                                    <label class="form-label">Payment Terms</label>
                                    <select class="form-select" name="payment_term" id="paymentTermsSelect">
                                        <option value="One Time" selected>One-time Payment</option>
                                        <option value="Monthly">Installment - Every Month</option>
                                        <option value="Quarterly">Installment - Every 3 Months</option>
                                        <option value="Semi-Annual">Installment - Every 6 Months</option>
                                        <option value="Custom">Custom Interval</option>
                                    </select>
                                </div>

                                <div class="col-6 bill-only-field installment-conditional" id="customIntervalField" style="display: none;">
                                    <label class="form-label">Custom Interval (months)</label>
                                    <input type="number" min="1" class="form-control" name="custom_interval_months" placeholder="e.g. 2">
                                </div>

                                <div class="col-6 bill-only-field installment-conditional" id="installmentCountField" style="display: none;">
                                    <label class="form-label">Number of Installments</label>
                                    <input type="number" min="1" class="form-control" name="installment_count" id="installmentCountInput" placeholder="e.g. 4">
                                </div>

                                <div class="col-6 bill-only-field installment-conditional" id="interestRateField" style="display: none;">
                                    <label class="form-label">Interest Rate (%)</label>
                                    <input type="number" step="0.01" min="0" class="form-control" name="interest_rate" id="interestRateInput" placeholder="e.g. 5">
                                </div>

                                <!-- Expense-only fields -->
                                <div class="col-12 expense-only-field">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category" required>
                                        <option value="" selected disabled>Select a category</option>
                                        <option>Supplies</option>
                                        <option>Maintenance</option>
                                        <option>Transport/Fuel</option>
                                        <option>Utilities</option>
                                        <option>Other</option>
                                    </select>
                                </div>
                                <div class="col-12 expense-only-field">
                                    <label class="form-label">Receipt</label>
                                    <label for="receiptUpload" class="receipt-upload-btn">
                                        <i class="bi bi-upload"></i>
                                        <span id="receiptFileName">Click to upload receipt (image or PDF)</span>
                                    </label>
                                    <input type="file" id="receiptUpload" name="receipt" accept="image/*,.pdf" hidden>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end mt-4">
                                <button type="submit" name="adder" id="submitExpenseBtn" class="btn btn-add rounded-pill px-4 fw-bold"><i class="bi bi-check2-circle me-1"></i>Log Expense</button>
                                <button type="submit" name="bill_adder" id="submitBillBtn" class="btn btn-add rounded-pill px-4 fw-bold" style="display: none;"><i class="bi bi-plus-circle me-1"></i>Add Bill</button>
                            </div>
                        </form>

                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                            //Add Expense
                            if (isset($_POST['adder'])) {
                                $date = $_POST['date'];
                                $amount = $_POST['amount'];
                                $supplier = $_POST['supplier_name'];
                                $category = $_POST['category'];

                                //Handle the uploaded receipt file
                                $receipt = "";
                                $upload_error = "";
                                $upload_dir = __DIR__ . '/../Images/receipts/';

                                if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
                                    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
                                    $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));

                                    if (in_array($ext, $allowed_ext)) {
                                        if (!is_dir($upload_dir)) {
                                            mkdir($upload_dir, 0755, true);
                                        }
                                        $receipt = uniqid('receipt_', true) . '.' . $ext;
                                        if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $upload_dir . $receipt)) {
                                            $receipt = "";
                                            $upload_error = "Failed to save the uploaded file.";
                                        }
                                    } else {
                                        $upload_error = "Unsupported file type. Please upload an image or PDF.";
                                    }
                                } elseif (isset($_FILES['receipt']) && $_FILES['receipt']['error'] !== UPLOAD_ERR_NO_FILE) {
                                    $upload_error = "There was a problem uploading the receipt.";
                                }

                                //Amount prevents "-" and "e"
                                $number_checked = True;
                                if (strpbrk($amount, 'e-') !== false) {
                                    $number_checked = False;
                                }

                                if ($upload_error) {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Receipt Upload Failed!',
                                                        text: '{$upload_error}',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#e60000',
                                                        heightAuto: false
                                                    });
                                                })
                                                </script>
                                        HTML;
                                } elseif ($date && $amount && $supplier && $category && $receipt) {
                                    if ($number_checked) {
                                        $sql = "INSERT INTO `expenses` (`date`, `amount`, `supplier`, `category`, `receipt`) VALUES (?, ?, ?, ?, ?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("sdsss", $date, $amount, $supplier, $category, $receipt);
                                        if ($stmt->execute()) {

                                            $sql = "SELECT * FROM expenses ORDER BY id DESC LIMIT 1";
                                            $query = $conn->query($sql);
                                            $expenses_info = $query->fetch_object();

                                            $description = "Paid Expense";
                                            $category = $expenses_info->category;
                                            $type = "Expense";
                                            $payment_method = "Cash";

                                            $sql = "INSERT INTO transactions (date, description, category, type, payment_method, amount) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("ssssd", $description, $category, $type, $payment_method, $expenses_info->amount);
                                            if ($stmt->execute()) {
                                            }

                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'success',
                                                                title: 'Expense Added!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                confirmButtonColor: '#00E676',
                                                                heightAuto: false
                                                            }).then((result) => {
                                                                if(result.isConfirmed) {
                                                                    location.assign('expenses.php');
                                                                }});
                                                        })
                                                        
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        //NUMBER HAS A -e
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Value!',
                                                            text: 'Ensure that the amount(₱) is greater than 0 and only contain numerical characters',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        });
                                                    })
                                                    </script> 
                                            HTML;
                                    }
                                }
                            }

                            //Add Bill / Invoice
                            if (isset($_POST['bill_adder'])) {
                                $due_date = $_POST['date'];
                                $amount = $_POST['amount'];
                                $supplier = $_POST['supplier_name'];
                                $payment_term = $_POST['payment_term'];

                                if ($due_date && $amount && $supplier && $payment_term) {
                                    $payment_dates = array();
                                    //Processes the payment terms based on selected
                                    if ($payment_term != "One Time") {
                                        $installment = $_POST['installment_count'];
                                        $interest_rate = $_POST['interest_rate'];

                                        if ($payment_term == "Custom") {
                                            $custom_interval = $_POST['custom_interval_months'];
                                        } else if ($payment_term == "Monthly") {
                                            $custom_interval = 1;
                                        } else if ($payment_term == "Quarterly") {
                                            $custom_interval = 3;
                                        } else if ($payment_term == "Semi-Annual") {
                                            $custom_interval = 6;
                                        }

                                        //Installment Amount
                                        $installment_amount = ($amount / $installment);

                                        //Interest Amount Calculation
                                        if ($interest_rate != 0) {
                                            $interest_rate_amount = $installment_amount * ($interest_rate / 100);
                                        } else {
                                            $interest_rate_amount = 0;
                                        }

                                        //Amount value
                                        $amount = $installment_amount + $interest_rate_amount;

                                        //Installment Months
                                        $interval_month = 0;
                                        $payment_dates[] = $due_date;

                                        for ($i = 0; $i < ($installment - 1); $i++) {
                                            //$interval_month += $custom_interval;

                                            $due_date = strtotime($due_date . '+' . $custom_interval . ' month');
                                            $due_date  = date('Y-m-d', $due_date);

                                            //Adds value into array
                                            $payment_dates[] = $due_date;
                                        }
                                    } else {
                                        $installment = 0;
                                        $interest_rate_amount = 0;
                                        $custom_interval = 0;
                                        $payment_dates[] = $due_date;
                                    }

                                    //Amount prevents "-" and "e"
                                    $number_checked = True;
                                    if (strpbrk($amount, 'e-') !== false || strpbrk($installment, 'e-') !== false || strpbrk($interest_rate, 'e-') !== false || strpbrk($custom_interval, 'e-') !== false) {
                                        $number_checked = False;
                                    }

                                    //Due date cannot be in the past
                                    $today = strtotime('today');
                                    if (strtotime($due_date) >= $today) {
                                        if ($number_checked) {
                                            foreach ($payment_dates as $pay_date) {
                                                echo <<<HTML
                                                    <script>
                                                        console.log("{$amount}");
                                                        console.log("{$pay_date}");
                                                        console.log(" ");
                                                    </script>
                                                HTML;

                                                $sql = "INSERT INTO `bills` (`supplier`, `due_date`, `amount`, `payment_term`, `interval_month`, `installment`, `interest`) VALUES (?, ?, ?, ?, ?, ?, ?)";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("ssdsidi", $supplier, $pay_date, $amount, $payment_term, $custom_interval, $installment, $interest_rate_amount);
                                                if ($stmt->execute()) {
                                                    echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Bill Added!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00E676',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('expenses.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                    HTML;
                                                }
                                            }
                                        } else {
                                            //Numbers must not have - or e
                                            echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Number Values!',
                                                            text: 'Make sure that any number input is not negative or does not contain "e"',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        });
                                                    })
                                                </script> 
                                            HTML;
                                        }
                                    } else {
                                        //DUE can't be in the past
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Due Date!',
                                                            text: 'Due date cannot be set on the past',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        });
                                                    })
                                                </script> 
                                            HTML;
                                    }
                                }
                            }

                            //Edit Expense
                            if (isset($_POST['editer'])) {
                                $id = $_POST['id'];
                                $date = $_POST['date'];
                                $amount = $_POST['amount'];
                                $supplier = $_POST['supplier_name'];
                                $category = $_POST['category'];

                                //Handle a newly uploaded receipt file, if any
                                $new_receipt = "";
                                $upload_error = "";
                                $upload_dir = __DIR__ . '/../Images/receipts/';

                                if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
                                    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
                                    $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));

                                    if (in_array($ext, $allowed_ext)) {
                                        if (!is_dir($upload_dir)) {
                                            mkdir($upload_dir, 0755, true);
                                        }
                                        $new_receipt = uniqid('receipt_', true) . '.' . $ext;
                                        if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $upload_dir . $new_receipt)) {
                                            $new_receipt = "";
                                            $upload_error = "Failed to save the uploaded file.";
                                        }
                                    } else {
                                        $upload_error = "Unsupported file type. Please upload an image or PDF.";
                                    }
                                } elseif (isset($_FILES['receipt']) && $_FILES['receipt']['error'] !== UPLOAD_ERR_NO_FILE) {
                                    $upload_error = "There was a problem uploading the receipt.";
                                }

                                //Amount prevents "-" and "e"
                                $number_checked = True;
                                if (strpbrk($amount, 'e-') !== false) {
                                    $number_checked = False;
                                }

                                if ($upload_error) {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Receipt Upload Failed!',
                                                        text: '{$upload_error}',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#e60000',
                                                        heightAuto: false
                                                    });
                                                })
                                                </script>
                                        HTML;
                                } elseif ($date && $amount && $supplier && $category) {
                                    if ($number_checked) {

                                        //Only overwrite the receipt column if a new file was uploaded
                                        if ($new_receipt != "") {
                                            //UPDATE WITH PHOTO
                                            $sql = "UPDATE `expenses` SET `date` = ?, `amount` = ?, `supplier` = ?, `category` = ?, `receipt` = ? WHERE id = '" . $id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sdsss", $date, $amount, $supplier, $category, $new_receipt);
                                        } else {
                                            //UPDATE WITHOUT PHOTO
                                            $sql = "UPDATE `expenses` SET `date` = ?, `amount` = ?, `supplier` = ?, `category` = ? WHERE id = '" . $id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sdsss", $date, $amount, $supplier, $category);
                                        }
                                        if ($stmt->execute()) {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'success',
                                                                title: 'Expense Edited!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                confirmButtonColor: '#00E676',
                                                                heightAuto: false
                                                            }).then((result) => {
                                                                if(result.isConfirmed) {
                                                                    location.assign('expenses.php');
                                                                }});
                                                        })
                                                        
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        //NUMBER HAS A -e
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid Value!',
                                                            text: 'Ensure that the amount(₱) is greater than 0 and only contain numerical characters',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#e60000',
                                                            heightAuto: false
                                                        });
                                                    })
                                                    </script> 
                                            HTML;
                                    }
                                }
                            }

                            //Sets Bill to paid
                            if (isset($_POST['confirm'])) {
                                $sql = "UPDATE `bills` SET `status` = 'Paid' WHERE id = " . $_POST['confirm'];
                                if ($conn->query($sql) === TRUE) {

                                    $sql = "SELECT * FROM bills WHERE id = '" . $_POST['confirm'] . "'";
                                    $query = $conn->query($sql);
                                    $bill_info = $query->fetch_object();

                                    $description = "Paid Invoice Bill";
                                    $category = "Invoice";
                                    $type = "Expense";
                                    $payment_method = "Cash";

                                    $sql = "INSERT INTO transactions (date, description, category, type, payment_method, amount) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("ssssd", $description, $category, $type, $payment_method, $bill_info->amount);
                                    if ($stmt->execute()) {
                                    }

                                    //Installment complete notification
                                    $role_list = array("Admin", "Financer");
                                    foreach ($role_list as $role) {
                                        if ($role == "Admin") {
                                            $sql = "SELECT * FROM admin";
                                        } elseif ($role == "Financer") {
                                            $sql = "SELECT * FROM employees WHERE role = '" . $role . "' AND deleted = 'False'";
                                        }

                                        $query = $conn->query($sql);
                                        while ($emp_info = $query->fetch_object()) {
                                            $notif_id = $emp_info->id;
                                            $notif_role = $emp_info->role;
                                            $notif_category = "Bill Payed";
                                            $notif_message = "Bill #" . $bill_info->id . " has been fully payed";
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            $stmt->execute();
                                        }
                                    }

                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Order Received!',
                                                        text: 'The order has been completed.',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#00A859',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('expenses.php');
                                                        }});
                                                })
                                            </script> 
                                            HTML;
                                }
                            }
                        }

                        ?>

                    </div>
                </div>



                <!-- Edit Expense Modal -->
                <div class="modal fade" id="editExpenseModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content shadow-lg">

                            <div class="modal-header">
                                <h5 class="modal-title">Add New Product</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body p-4">
                                <form id="expenseForm" method="POST" enctype="multipart/form-data">

                                    <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                                    <input type="number" name="id" id="edit-id" hidden>

                                    <div class="row g-3">
                                        <div class="col-6">
                                            <label class="form-label">Date</label>
                                            <input type="date" class="form-control" name="date" id="edit-date" required>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label">Amount</label>
                                            <input type="number" step="0.01" class="form-control" name="amount" placeholder="0.00" id="edit-amount" required>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Supplier Name</label>
                                            <input type="text" class="form-control" name="supplier_name" placeholder="e.g. Aqua Supplies Co." id="edit-supplier" required>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label">Category</label>
                                            <select class="form-select" name="category" required>
                                                <option selected id="edit-category"></option>
                                                <option>Supplies</option>
                                                <option>Maintenance</option>
                                                <option>Transport/Fuel</option>
                                                <option>Utilities</option>
                                                <option>Other</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Product Image</label>
                                            <input type="file" name="receipt" class="form-control" id="edit-receipt" accept="image/*">
                                        </div>

                                        <div class="mb-2 text-center" id="imagePreviewContainerEdit">
                                            <img id="imagePreviewEdit" value="" class="edit-image" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-end mt-4">
                                        <button type="submit" name="editer" class="btn btn-add rounded-pill px-4 fw-bold">Log Expense</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Accounts Payable Tracker -->
                <div class="col-12 col-lg-7">
                    <div class="section-header"><i class="bi bi-clipboard-check me-2"></i>Accounts Payable Tracker</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Upcoming Bills & Supplier Invoices</h5>
                        </div>

                        <div class="table-responsive ap-scroll-wrap">
                            <table class="table table-dark table-hover text-center mb-0 align-middle" id="ap_list">
                                <thead>
                                    <tr>
                                        <th>Bill #</th>
                                        <th>Supplier</th>
                                        <th>Due Date</th>
                                        <th>Amount</th>
                                        <th>Interest Amount</th>
                                        <th>Payment Interval</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //Checks date
                                    $today = strtotime('today');
                                    $sql = "SELECT * FROM bills";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo '
                                                <tr>
                                                    <td>BILL-' . $set->id . '</td>
                                                    <td>' . $set->supplier . '</td>
                                            ';

                                        if ($set->status == "Unpaid") {
                                            if (strtotime($set->due_date) <= $today) {
                                                echo '<td style="color: #FF5252;">' . $set->due_date . '</td>';
                                            } else {
                                                echo '<td>' . $set->due_date . '</td>';
                                            }
                                        } else {
                                            echo '<td>' . $set->due_date . '</td>';
                                        }

                                        echo '
                                            <td class="fw-bold">₱' . $set->amount . '</td>
                                            <td class="fw-bold">₱' . $set->interest . '</td>
                                            <td class="fw-bold">' . $set->interval_month . '</td>
                                            ';

                                        if ($set->status == "Unpaid") {
                                            if (strtotime($set->due_date) <= $today) {
                                                echo '<td><span class="ap-status ap-overdue">Overdue</span></td>';
                                            } else {
                                                echo '<td><span class="ap-status ap-upcoming">Upcoming</span></td>';
                                            }
                                        } else {
                                            echo '<td><span class="ap-status ap-upcoming">Paid</span></td>';
                                        }

                                        if ($set->status == "Unpaid") {
                                            echo '
                                                    <td><button class="btn btn-confirm btn-sm rounded-pill px-3 mark" data-id="' . $set->id . '" id="mark"><i class="bi bi-check2-circle me-1"></i>Mark Paid</button></td>
                                                </tr>
                                                ';
                                        } else {
                                            echo '
                                                    <td><button class="btn btn-confirm btn-sm rounded-pill px-3" Disabled><i class="bi bi-check2-circle me-1"></i>Paid</button></td>
                                                </tr>
                                                ';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- View Receipt Modal -->
                <div class="modal fade" id="viewReceiptModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content shadow-lg">

                            <div class="modal-header">
                                <h5 class="modal-title">Receipt Preview</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body p-4 text-center">
                                <img id="receiptPreviewImage" src="" alt="Receipt" style="max-width: 100%; max-height: 70vh; border-radius: 10px; border: 2px solid #64FFDA; display: none;">
                                <iframe id="receiptPreviewPdf" src="" style="width: 100%; height: 70vh; border: none; border-radius: 10px; display: none;"></iframe>
                                <div id="receiptNotFound" style="color: #8892B0; display: none;">No receipt was uploaded for this expense.</div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Recent Expenses -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-list-ul me-2"></i>Recent Expenses</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
                            <h5 class="mb-0 pt-1">All Logged Expenses</h5>
                            <input type="text" class="form-control table-search-input" placeholder="Search Supplier" id="expenseSearcher">
                        </div>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="expense_list">
                            <thead>
                                <tr>
                                    <th>Expense ID</th>
                                    <th>Date</th>
                                    <th>Supplier</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th>Receipt</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM expenses";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                                <tr>
                                                    <td>#' . $set->id . '</td>
                                                    <td>' . $set->date . '</td>
                                                    <td>' . $set->supplier . '</td>
                                            ';
                                    if ($set->category == "Supplies") {
                                        echo ' <td><span class="cat-tag cat-supplies">supplies</span></td>';
                                    } else if ($set->category == "Utilities") {
                                        echo '<td><span class="cat-tag cat-utilities">Utilities</span></td>';
                                    } else if ($set->category == "Maintenance") {
                                        echo '<td><span class="cat-tag cat-maintenance">Maintenance</span></td>';
                                    } else if ($set->category == "Transport/Fuel") {
                                        echo '<td><span class="cat-tag cat-transport">Transport Licenses</span></td>';
                                    } else {
                                        echo '<td><span class="cat-tag cat-transport">Other</span></td>';
                                    }

                                    echo "
                                                <td style='color: #FF5252;' class='fw-bold'>-₱" . $set->amount . "</td>
                                                <td><a href='#' class='cyan-text view-receipt' data-receipt='{$set->receipt}'><i class='bi bi-eye me-1'></i>View Receipt</a></td>
                                                <td><button class='btn btn-edit btn-sm rounded-pill px-3'
                                                    data-id='{$set->id}'
                                                    data-date='{$set->date}'
                                                    data-supplier='{$set->supplier}' 
                                                    data-category='{$set->category}'
                                                    data-amount='{$set->amount}'
                                                    data-receipt='{$set->receipt}'
                                                    ><i class='bi bi-pencil-square me-1'></i>Edit</button></td>
                                            </tr>
                                            
                                            ";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {

            //Confirming Delivery
            $(".mark").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Confirm Bill Payment?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="confirm" value="' + id + '" class="btn btn-confirm">Confirm Payment</button></form>',
                    heightAuto: false
                })
            });

            var table = $('#expense_list').DataTable({
                paging: true,
                pageLength: 8,
                lengthChange: false,
                searching: true,
                ordering: false,
                dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
            });

            $('#expenseSearcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });

            $('#ap_list').DataTable({
                paging: false,
                searching: false,
                ordering: false,
                dom: 't'
            });

            // Show the selected receipt file name
            $('#receiptUpload').on('change', function() {
                var fileName = this.files.length ? this.files[0].name : 'Click to upload receipt (image or PDF)';
                $('#receiptFileName').text(fileName);
            });

            // Toggle mode between Expense and Bill / Invoice
            $('#expenseModeToggle .mode-btn').on('click', function() {
                $('#expenseModeToggle .mode-btn').removeClass('active');
                $(this).addClass('active');

                var mode = $(this).data('mode');

                if (mode === 'bill') {
                    $('.expense-only-field').hide().find('select, input').prop('required', false);
                    $('.bill-only-field').not('.installment-conditional').show().find('input, select').prop('required', true);
                    $('#dateFieldLabel').text('Due Date');
                    $('#supplierFieldLabel').text('Supplier');
                    $('#submitExpenseBtn').hide();
                    $('#submitBillBtn').show();
                    $('#paymentTermsSelect').trigger('change');
                } else {
                    $('.bill-only-field').hide().find('input, select').prop('required', false);
                    $('.expense-only-field').show().find('select, input').prop('required', true);
                    $('#dateFieldLabel').text('Date');
                    $('#supplierFieldLabel').text('Supplier Name');
                    $('#submitBillBtn').hide();
                    $('#submitExpenseBtn').show();
                }
            });

            // Show/hide installment fields based on the selected payment terms
            $('#paymentTermsSelect').on('change', function() {
                var terms = $(this).val();

                if (terms === 'One Time') {
                    $('#customIntervalField, #installmentCountField, #interestRateField, #installmentPreview').hide();
                    $('#customIntervalField input, #installmentCountField input, #interestRateField input').prop('required', false).val('');
                } else if (terms === 'Custom') {
                    $('#customIntervalField, #installmentCountField, #interestRateField, #installmentPreview').show();
                    $('#customIntervalField input, #installmentCountField input').prop('required', true);
                } else {
                    $('#customIntervalField').hide();
                    $('#customIntervalField input').prop('required', false).val('');
                    $('#installmentCountField, #interestRateField, #installmentPreview').show();
                    $('#installmentCountField input').prop('required', true);
                }
            });


            // View Receipt
            $(document).on('click', '.view-receipt', function(e) {
                e.preventDefault();

                var receipt = $(this).data('receipt');
                var $img = $('#receiptPreviewImage');
                var $pdf = $('#receiptPreviewPdf');
                var $notFound = $('#receiptNotFound');

                $img.hide().attr('src', '');
                $pdf.hide().attr('src', '');
                $notFound.hide();

                if (!receipt) {
                    $notFound.show();
                } else {
                    var ext = receipt.split('.').pop().toLowerCase();
                    var path = '../Images/receipts/' + receipt;

                    if (ext === 'pdf') {
                        $pdf.attr('src', path).show();
                    } else {
                        $img.attr('src', path).show();
                    }
                }

                $('#viewReceiptModal').modal('show');
            });

            //Edit Expense
            $(".btn-edit").click(function() {
                id = $(this).data('id');
                date = $(this).data('date');
                supplier = $(this).data('supplier');
                amount = $(this).data('amount');
                category = $(this).data('category');
                receipt = $(this).data('receipt');

                $("#edit-id").val(id);
                $("#edit-date").val(date);
                $("#edit-supplier").val(supplier);
                $("#edit-amount").val(amount);
                $("#edit-category").text(category);

                //For receipt loading
                $("#imagePreviewEdit").attr("src", "../Images/receipts/" + receipt);
                $("#edit-receipt").val("");

                $('#edit-receipt').change(function(e) {
                    let reader = new FileReader();

                    // When the file is read, put it in the image tag and show the container
                    reader.onload = function(e) {
                        $('#imagePreviewEdit').attr('src', e.target.result);

                    }

                    // Read the file the user selected
                    if (this.files[0]) {
                        reader.readAsDataURL(this.files[0]);
                    }
                });


                //Shows Edit modal
                $('#editExpenseModal').modal('show');
            });

        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Finance Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>