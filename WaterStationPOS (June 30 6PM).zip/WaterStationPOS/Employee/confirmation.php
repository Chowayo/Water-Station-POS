<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Confirmation</title>


    <link rel="stylesheet" href="styles.css">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-4">

                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

            </div>

            <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#profileModal">Profile</a>
            <?php
            include 'profile.php';
            ?>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="home.php">POS</a>
                <a class="menu-link active" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout ➜]</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">
            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Delivery & Order Confirmation</h6>
                    </div>
                </header>

                <div class="box mt-2">
                    <div class="d-flex justify-content-between mb-3 align-items-center">
                        <h5 class="mb-0 fw-bold">Active Deliveries</h5>

                        <div class="input-group w-25">
                            <input type="text" class="form-control" placeholder="Search Order ID">
                            <button class="btn btn-primary fw-bold px-3" type="button">Search</button>
                        </div>
                    </div>

                    <table class="table table-hover text-center mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer Name</th>
                                <th>Produt Name</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Payment Method</th>
                                <th>Order Type</th>
                                <th>Time</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Row 1: Pending Order -->
                            <?php
                            //Loading employee list
                            $sql = "SELECT * FROM orders";
                            $query = $conn->query($sql);
                            while ($set = $query->fetch_object()) {
                                echo '
                                            <tr>
                                                <td class="cyan-text fw-bold">' . $set->id . '</td>
                                                <td><strong class="d-block">' . $set->customer_name . '</strong></td>
                                                <td>' . $set->product_name . '</td>
                                                <td>' . $set->quantity . '</td>
                                                <td class="green-text fw-bold fs-5">₱' . $set->total_price . '</td>
                                                <td><span class="badge bg-paid">' . $set->payment_method . '</span></td>
                                                <td>' . $set->order_type . '</td>
                                                <td>' . $set->time . '</td>
                                                <td>' . $set->date . '</td>

                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 confirm-btn">Confirm Delivery</button>
                                                </td>
                                            </tr>
                                            ';
                            }

                            echo <<<HTML
                                                <script>
                                                    $('.btn-remove').click(function() {
                                                        //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                                        id = $(this).data('id');

                                                        Swal.fire({
                                                            title: 'Remove Product?',
                                                            text: "It will be deleted in the database",
                                                            icon: 'warning',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showCancelButton: true,
                                                            showConfirmButton: false,
                                                            cancelButtonColor: '#8892B0',
                                                            html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
                                                            heightAuto: false
                                                        });
                                                    });
                                                </script>
                                                HTML;
                            ?>


                        </tbody>
                    </table>
                </div>

            </section>
        </main>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $(document).ready(function() {
            //Confirming Delivery
            $(".confirm-btn").click(function() {
                Swal.fire({
                    title: 'Confirm Delivery?',
                    text: "Has the customer received the water and settled the payment?",
                    icon: 'success',
                    background: '#FFFFFF',
                    color: '#2D3748',
                    showCancelButton: true,
                    confirmButtonColor: '#00A859',
                    cancelButtonColor: '#718096',
                    confirmButtonText: 'Yes, Confirm!',
                    heightAuto: false
                })
            });

            //Logout
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>
</body>

</html>