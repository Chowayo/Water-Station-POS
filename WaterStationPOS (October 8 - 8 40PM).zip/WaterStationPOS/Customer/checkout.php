<?php
include 'header.php';

$sql = "SELECT * FROM customers WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

//Only this customer's own, still-active order can be opened for checkout
$checkout_order_id = (int) ($_GET['id'] ?? 0);
$checkout_owner = 'USER ID:' . $result->id;
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND cashier = ? AND deleted = 'False'");
$stmt->bind_param("is", $checkout_order_id, $checkout_owner);
$stmt->execute();
$order_info = $stmt->get_result()->fetch_object();

if (!$order_info) {
    echo '<script>location.replace("home.php");</script>';
    exit;
}

?>

<style>
    body {
        background: #0a192f !important;
        display: block !important;
        overflow-y: auto !important;
        padding: 0 !important;
        min-height: 100vh;
    }

    .checkout-container {
        max-width: 1100px;
        margin: 0 auto;
    }

    /* Card Styling */
    .checkout-card {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .text-primary-accent {
        color: #00e676 !important;
    }

    .btn-primary-accent {
        background-color: #00fc9e;
        color: #000000;
        font-weight: 700;
        border: none;
        border-radius: 25px;
        padding: 14px;
        width: 100%;
        transition: 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }

    .btn-primary-accent:hover {
        background-color: #00e676;
    }

    /* Secondary Accent Button */
    .btn-secondary-accent {
        background-color: transparent;
        color: #1a1a1a;
        font-weight: 700;
        border: 2px solid #00e676;
        /* Green border */
        border-radius: 25px;
        padding: 12px;
        width: 100%;
        transition: 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }

    .btn-secondary-accent:hover {
        background-color: rgba(0, 230, 118, 0.1);
        border-color: #00e676;
    }

    .btn-edit-outline {
        background-color: transparent;
        color: #64ffda;
        font-size: 14px;
        text-decoration: none;
        transition: 0.2s;
    }

    .btn-edit-outline:hover {
        color: #00e676;
    }

    /* Form Inputs & Checkboxes */
    .form-control {
        background-color: #0d1b2e !important;
        border: 1px solid #233554 !important;
        color: #ccd6f6 !important;
    }

    .form-control:focus {
        background-color: #0a192f !important;
        border-color: #00e676 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .form-control::placeholder {
        color: #8892b0 !important;
    }

    .form-check-input {
        background-color: #0d1b2e;
        border: 1px solid #233554;
    }

    .form-check-input:checked {
        background-color: #00e676;
        border-color: #00e676;
    }

    .delivery-option-box,
    .payment-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: 0.2s;
    }

    .payment-box {
        display: block;
    }

    /* When checked */
    .delivery-option-box:has(input:checked),
    .payment-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    h2,
    h4,
    h6,
    .text-white {
        color: #ffffff !important;
    }

    .text-muted {
        color: #8892b0 !important;
    }

    .custom-link {
        color: #64ffda;
        text-decoration: none;
        font-weight: 600;
        transition: 0.2s;
    }

    .custom-link:hover {
        color: #00e676;
    }

    .divider {
        border-color: #233554;
        opacity: 1;
    }

    .icon-box {
        background-color: #112240;
        border: 1px solid #233554;
    }

    .modal-content {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
    }

    .modal-header {
        border-bottom: 1px solid #233554;
    }

    .btn-close-white {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    /* Address Box styling */
    .address-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        transition: 0.2s;
    }

    .address-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    .address-box:has(input:checked) .bi-geo-alt {
        color: #00e676 !important;
    }

    .address-actions .btn-icon {
        background: transparent;
        border: none;
        color: #8892b0;
        padding: 4px;
        transition: 0.2s;
        font-size: 18px;
    }

    .address-actions .btn-icon:hover {
        color: #00e676;
    }


    /* Label Buttons */
    .label-btn {
        background-color: #0d1b2e;
        color: #ccd6f6;
        border: 1px solid #233554;
        border-radius: 20px;
        padding: 6px 16px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .label-btn:hover,
    .label-btn.active {
        background-color: rgba(0, 230, 118, 0.1);
        border-color: #00e676;
        color: #00e676;
    }

    /* Add Address Custom Input */
    .address-search-wrapper {
        position: relative;
        margin-bottom: 20px;
    }

    .address-search-wrapper label {
        position: absolute;
        top: -9px;
        left: 12px;
        background-color: #112240;
        padding: 0 5px;
        font-size: 11px;
        color: #8892b0;
        z-index: 1;
    }

    .address-search-input {
        width: 100%;
        background-color: transparent !important;
        border: 1px solid #233554 !important;
        border-radius: 10px;
        color: #ccd6f6 !important;
        padding: 14px 40px 14px 15px;
        font-size: 14px;
    }

    .address-clear-btn {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #8892b0;
        padding: 0;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
    }


    /* Toggle Switch Styling */
    .order-type-toggle {
        display: inline-flex;
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 30px;
        padding: 4px;
        margin-bottom: 24px;
    }

    .toggle-btn {
        background: transparent;
        border: none;
        color: #8892b0;
        font-weight: 600;
        padding: 8px 32px;
        border-radius: 25px;
        transition: 0.3s ease;
    }

    .toggle-btn.active {
        background-color: #00e676;
        color: #000000;
    }

    /* Placing Order Modal Styles */
    body .placing-modal-content {
        background-color: #daefff;
        /* Light blue background */
        border-radius: 24px;
        color: #1a1a1a;
        border: none;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    }

    .placing-progress-bg {
        background-color: rgba(0, 0, 0, 0.1);
        height: 6px;
        border-radius: 3px;
        width: 100%;
        overflow: hidden;
        position: relative;
    }

    .placing-progress-bar {
        background-color: #2c2c2c;
        height: 100%;
        width: 0%;
        border-radius: 3px;
    }

    @keyframes progressAnim {
        0% {
            width: 0%;
        }

        50% {
            width: 70%;
        }

        100% {
            width: 100%;
        }
    }

    .placing-route-container {
        position: relative;
    }

    .placing-route-line {
        position: absolute;
        left: 11px;
        top: 24px;
        bottom: 24px;
        border-left: 2px dotted #a0a0a0;
        z-index: 1;
    }

    .placing-icon-wrapper {
        background: #daefff;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2;
    }

    .placing-divider {
        border-color: #b0c4d6;
        margin: 16px 0;
        opacity: 1;
    }

    #map{
        height: 500px;
        width: 100%;
        border-radius: 8px;
    }

    
</style>

<div class="content d-flex flex-column flex-grow-1">
    <?php include 'topbar.php'; ?>

    <div class="checkout-container py-5 px-3 flex-grow-1">

        <!-- Page Title -->
        <h2 class="fw-bold mb-4" style="font-size: 28px;">Review and place your order</h2>

        <div class="row g-4">

            <!-- LEFT COLUMN: Delivery Details & Options -->
            <div class="col-lg-7">

                <!-- Order Type Toggle -->
                <div class="order-type-toggle">
                    <button class="toggle-btn active" id="btnDelivery" type="button">Delivery</button>
                    <button class="toggle-btn" id="btnPickup" type="button">Pick-up</button>
                </div>

                <!-- Wrapper for all delivery-specific sections -->
                <div id="deliverySections">
                    <!-- Delivery Address Card -->
                    <div class="checkout-card p-4 mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="fw-bold m-0">Delivery address</h4>
                            <a href="#" class="custom-link" data-bs-toggle="modal" data-bs-target="#addAddressModal">Custom Address</a>
                        </div>

                        <div class="d-flex mb-3 align-items-start">
                            <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                            <div>
                                <p class="m-0 text-white fw-semibold">Account Address</p>
                            </div>
                        </div>

                        <!-- Note to rider input -->
                        <textarea class="form-control mb-4 mt-3" placeholder="Address" id="address_setter" rows="2" style="resize: none;"><?php echo $result->address; ?></textarea>
                    </div>

                    <!-- Delivery Options Card -->
                    <div class="checkout-card p-4 mb-4">
                        <h4 class="fw-bold mb-4">Delivery options</h4>

                        <label class="delivery-option-box mb-3">
                            <div class="d-flex align-items-center gap-3" id="standard_delivery">
                                <input class="form-check-input fs-5 m-0" type="radio" name="delOption" checked>
                                <span class="fw-bold text-white">Standard <span class="fw-normal text-muted ms-2">10 - 25 mins</span></span>
                            </div>
                        </label>

                        <label class="delivery-option-box mb-3">
                            <div class="d-flex align-items-center gap-3" id="priority_delivery">
                                <input class="form-check-input fs-5 m-0" type="radio" name="delOption">
                                <span class="fw-bold text-white">Priority <span class="fw-normal text-muted ms-2">5 - 20 mins</span></span>
                            </div>
                            <span class="badge rounded-pill border border-secondary fw-normal text-muted bg-transparent">+ ₱ 49.00</span>
                        </label>


                    </div>
                </div> <!-- End of deliverySections -->

                <!-- Personal Details Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Personal details</h4>

                    </div>
                    <div>
                        <div class="modal-body p-4 pt-3">
                            <form id="orderConfirm" method="POST">
                                <div class="mb-3">
                                    <label class="form-label text-white fw-semibold">Full Name</label>
                                    <input type="text" class="form-control" value="<?php echo $result->full_name; ?>" name="customer_name">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-white fw-semibold">Email Address</label>
                                    <input type="email" class="form-control" value="<?php echo $result->email; ?>" name="customer_email">
                                </div>
                                <div class="mb-4">
                                    <label class="form-label text-white fw-semibold">Phone Number</label>
                                    <input type="tel" class="form-control" value="<?php echo $result->contact ?>" name="customer_contact">
                                </div>

                                <input type="text" id="visual_delivery_getter" hidden> <!--Only used to maintain visuals-->

                                <input type="number" id="total_amount_getter" name="total_amount" hidden>   <!--(/)New Total-->
                                <input type="text" id="delivery_type_getter" name="delivery_type" hidden>   <!--(/)Delivery Type-->
                                <input type="text" id="payment_method_getter" name="payment_method" hidden> <!--(/)Payment Method-->
                                <input type="text" id="order_type_getter" name="order_type" hidden>         <!--(/)Order Type-->
                                <input type="text" id="address_getter" name="address" hidden>               <!--(/)Address-->
                                <input type="text" id="customer_lat_getter" name="customer_lat" hidden>     <!--(/)Confirmed delivery latitude, set only if the map was used-->
                                <input type="text" id="customer_lng_getter" name="customer_lng" hidden>     <!--(/)Confirmed delivery longitude, set only if the map was used-->
                            </form>
                        </div>
                    </div>
                </div>
                

                <?php
                    

                ?>

                <!-- Payment Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Payment</h4>
                    </div>

                    <label class="payment-box mb-2" id="cash_payment">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption" checked>
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-cash fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Cash On Delivery</span>
                            <span class="badge rounded-pill" style="background-color: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35);">Primary</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Consider payment upon ordering for contactless delivery. You can't pay by a card to the rider upon delivery.
                        </div>
                    </label>

                    <label class="payment-box mb-0" id="card_payment">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption">
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-credit-card fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Pay Online</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Pay via GCash, Maya, card or QR Ph. You'll be taken to PayMongo's secure checkout page.
                        </div>
                    </label>
                </div>

                <button type="button" class="btn-primary-accent d-block d-lg-none mt-2 mb-5" data-bs-toggle="modal" data-bs-target="#placingOrderModal"><i class="bi bi-bag-check"></i> Place order</button>

            </div>

            <!-- RIGHT COLUMN: Sticky Order Summary -->
            <div class="col-lg-5">

                <div class="checkout-card p-4 position-sticky" style="top: 24px;">

                    <h4 class="fw-bold m-0">Your order from</h4>
                    <p class="text-muted mb-4 mt-1">Eco Hydrate - Dasmarinas</p>

                    <!-- Cart Items -->
                    <?php
                        // Deconstruct the whole order_list to load 
                        $order_list = [];
                        $receipt_data = null; //filled once the order is placed (Cash On Delivery or paid via PayMongo)

                        // Deconstruct the whole order_list to load 
                        $order_string = $order_info->order_content;
                        $orders = explode(',', $order_string);
                        foreach ($orders as $value) {
                            $input = $value;
                            $pattern = '/^(\d+)x\s*(.*?)\s*₱([\d.]+)\s*VAT:([\d.]+)/u';
                            //Inserts order informations to $carts[items] based on the value present in the order_list
                            if (preg_match('/^(\d+)x\s*(.*?)\s*(\d+(?:\.\d+)?\s*(?:L|ML))\s*\((.*?)\)\s*₱([\d.]+)\s*VAT:([\d.]+)/ui', $input, $matches)) {
                                $order_list[] = [
                                    'name'             => trim($matches[2]),
                                    'measurement'      => $matches[3],
                                    'category'         => $matches[4],
                                    'qty'              => (int)$matches[1],
                                    'price'            => (float)$matches[5],
                                    'vat_rate'         => (float)$matches[6]
                                ];
                            }
                        }

                        
                        foreach($order_list as $order_array){
                            echo '
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div class="fw-semibold text-white">'.$order_array["name"].' '.$order_array["measurement"].' ('.$order_array["category"].')</div>
                                        <div class="fw-bold text-primary-accent">₱'.$order_array["price"].'</div>
                                    </div>
                                
                                ';
                        }

                        require_once __DIR__ . '/../paymongo.php';
                        require_once __DIR__ . '/../mailer/includes/payment_emails.php';

                        //Coming back from PayMongo: only place the order if PayMongo says it was paid
                        $paymongoReturn = false;
                        if (isset($_GET['pm_token'])) {
                            $pm_token = $_GET['pm_token'];
                            $pending = $_SESSION['pm_pending'][$pm_token] ?? null;
                            $pm_msg = null;

                            if (!$pending || $pending['order_id'] != $order_info->id) {
                                $pm_msg = ['info', 'Payment link expired', 'This payment was already processed or has expired.'];
                            } elseif (isset($_GET['pm_cancel'])) {
                                unset($_SESSION['pm_pending'][$pm_token]);
                                $pm_msg = ['warning', 'Payment cancelled', 'Your order was not placed. You can try again or choose Cash On Delivery.'];
                            } elseif (paymongoIsPaid($pending['session_id'])) {
                                unset($_SESSION['pm_pending'][$pm_token]); //one-time use so a refresh can't place it twice
                                $_POST = $pending['post'];
                                $_POST['confirmOrder'] = '1';
                                $paymongoReturn = true;
                            } else {
                                $pm_msg = ['error', 'Payment not confirmed', 'PayMongo has not confirmed this payment yet. Refresh this page in a moment.'];
                            }

                            if ($pm_msg) {
                                $pm_msg_js = json_encode($pm_msg);
                                echo "<script>$(document).ready(function(){ var m = {$pm_msg_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
                            }
                        }

                        if ($_SERVER['REQUEST_METHOD'] === 'POST' || $paymongoReturn) {
                            if (isset($_POST['confirmOrder'])) {


                                //Customer Information
                                $customer_name = $_POST['customer_name'];
                                $customer_email = $_POST['customer_email'];
                                $customer_contact = $_POST['customer_contact'];

                                //Order information
                                $order_type = $_POST['order_type'];
                                $total_amount = $_POST['total_amount'];
                                $payment_method = $_POST['payment_method'];
                                $status = "Submitted";
                                
                                //Date and time Information
                                date_default_timezone_set('Asia/Manila');
                                $time = date("h:iA");
                                $date = date('Y/m/d');


                                //ONLINE PAYMENT: send the customer to PayMongo first. The order is only submitted after payment is confirmed.
                                $blockOrder = false;
                                if ($payment_method === 'Gcash' && !$paymongoReturn && $customer_name && $customer_email && $customer_contact && $order_type) {
                                    $blockOrder = true;

                                    //Amount is recomputed on the server (order total + Priority fee) so it can't be edited in the browser
                                    $online_total = (float) $order_info->total_price;
                                    if ($order_type === "Delivery" && ($_POST['delivery_type'] ?? '') === "Priority") {
                                        $online_total += 49;
                                    }
                                    $_POST['total_amount'] = $online_total;

                                    $pm_token = bin2hex(random_bytes(8));
                                    $pm_back  = paymongoPageUrl() . '?id=' . $order_info->id . '&pm_token=' . $pm_token;
                                    $pm = paymongoCreateCheckout($online_total, 'ECO HYDRATE HUB Order #' . $order_info->id, $pm_back, $pm_back . '&pm_cancel=1');

                                    if ($pm['ok']) {
                                        $_SESSION['pm_pending'][$pm_token] = ['session_id' => $pm['id'], 'post' => $_POST, 'order_id' => $order_info->id];
                                        echo "<script>window.location.replace(" . json_encode($pm['url']) . ");</script>";
                                        exit;
                                    }
                                    $pm_err_js = json_encode($pm['error']);
                                    echo "<script>$(document).ready(function(){ Swal.fire({icon:'error', title:'Online payment unavailable', text:{$pm_err_js}, background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
                                }

                                if(!$blockOrder && $customer_name && $customer_email && $customer_contact && $order_type && $total_amount && $payment_method){
                                    if($order_type=="Delivery"){
                                        //Delivery Mode
                                        $delivery_type = $_POST['delivery_type'];
                                        $address = $_POST['address'];

                                        //If the customer confirmed a spot on the map, that location is the
                                        //real delivery point, so re-check which branch should fulfil it
                                        //(this is what lets someone deliver to a different branch's area
                                        //than the one they were auto-detected into on home.php).
                                        $delivery_branch_id = (int) $order_info->branch_id;
                                        $out_of_range_km = null;
                                        if (isset($_POST['customer_lat']) && $_POST['customer_lat'] !== '' && isset($_POST['customer_lng']) && $_POST['customer_lng'] !== '') {
                                            $pin_distance_km = null;
                                            $nearest = nearest_branch_id($conn, (float) $_POST['customer_lat'], (float) $_POST['customer_lng'], $pin_distance_km);
                                            if ($nearest !== null) {
                                                $delivery_branch_id = $nearest;
                                                //Even the CLOSEST branch is too far -- nowhere can fulfil this,
                                                //so the order shouldn't go through at all.
                                                if ($pin_distance_km !== null && $pin_distance_km > MAX_DELIVERY_RADIUS_KM) {
                                                    $out_of_range_km = $pin_distance_km;
                                                }
                                            }
                                        }

                                        if ($out_of_range_km !== null) {
                                            $blockOrder = true;
                                            $oor_text = 'This address is outside our delivery area (about ' . number_format($out_of_range_km, 1) . ' km from our nearest branch, ' . number_format(MAX_DELIVERY_RADIUS_KM, 0) . ' km max). Please choose a closer address or switch to Pickup.';
                                            $oor_msg_js = json_encode(['error', 'Delivery not available here', $oor_text]);
                                            echo "<script>$(document).ready(function(){ var m = {$oor_msg_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
                                        }

                                        $sql = "UPDATE `orders` SET `branch_id` = ?, `customer_name` = ?, `customer_email` = ?, `customer_address` = ?, `customer_contact` = ?, `total_price` = ?, `payment_amount` = ?, `order_type` = ?,  `delivery_type` = ?, `payment_method` = ?, `status` = ?, `time` = ?, `date` = ?  WHERE `id` = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("issssddssssssi", $delivery_branch_id,$customer_name,$customer_email,$address,$customer_contact,$total_amount,$total_amount,$order_type,$delivery_type,$payment_method,$status,$time,$date,$order_info->id);

                                        //Keep the session in step with the order, so home.php (and the
                                        //next order) default to the branch this delivery actually landed in.
                                        $_SESSION['customer_branch_id'] = $delivery_branch_id;
                                        $_SESSION['customer_branch_detected'] = true;
                                    }
                                    
                                    else if($order_type=="Pickup"){
                                        //Pickup Mode
                                        $sql = "UPDATE `orders` SET `customer_name` = ?, `customer_email` = ?, `customer_contact` = ?, `total_price` = ?, `payment_amount` = ?, `order_type` = ?, `payment_method` = ?, `status` = ?, `time` = ?, `date` = ?  WHERE `id` = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("sssddsssssi", $customer_name,$customer_email,$customer_contact,$total_amount,$total_amount,$order_type,$payment_method,$status,$time,$date,$order_info->id);
                                    }

                                    //Stock only comes off the branch that is fulfilling this order
                                    //(for Delivery that may be the branch the map pin switched it to)
                                    $order_final_branch_id = ($order_type == "Delivery" && isset($delivery_branch_id)) ? (int) $delivery_branch_id : (int) $order_info->branch_id;

                                    //Before touching the DB at all: make sure the branch that is actually
                                    //going to fulfil this order (which for Delivery may have just been
                                    //switched by the map pin / address) carries every item in the cart
                                    //with enough stock. Matching is by name+category, same as the stock
                                    //deduction below, since that's the only key this schema offers.
                                    //Skip this if the address was already rejected as out-of-range above --
                                    //no point checking stock at a branch the order can never be placed at,
                                    //and it would just overwrite the out-of-range Swal with a confusing one.
                                    $unavailable_items = [];
                                    if (!$blockOrder) {
                                    foreach ($order_list as $order_array) {
                                        $check_sql = "SELECT stock FROM `product` WHERE product_name = ? AND category = ? AND branch_id = ? AND deleted = 'False'";
                                        $check_stmt = $conn->prepare($check_sql);
                                        $check_stmt->bind_param("ssi", $order_array["name"], $order_array["category"], $order_final_branch_id);
                                        $check_stmt->execute();
                                        $check_row = $check_stmt->get_result()->fetch_object();
                                        if (!$check_row || (int) $check_row->stock < (int) $order_array["qty"]) {
                                            $unavailable_items[] = $order_array["qty"] . "x " . $order_array["name"] . " " . $order_array["measurement"] . " (" . $order_array["category"] . ")";
                                        }
                                    }
                                    }

                                    if (!empty($unavailable_items)) {
                                        $blockOrder = true;
                                        $branch_name_stmt = $conn->prepare("SELECT name FROM `branches` WHERE id = ?");
                                        $branch_name_stmt->bind_param("i", $order_final_branch_id);
                                        $branch_name_stmt->execute();
                                        $branch_name_row = $branch_name_stmt->get_result()->fetch_object();
                                        $unavail_branch_name = $branch_name_row->name ?? ('Branch #' . $order_final_branch_id);
                                        $unavail_text = ($order_type == "Delivery")
                                            ? ("The branch serving this address (" . $unavail_branch_name . ") doesn't carry: " . implode(', ', $unavailable_items) . ". Please remove the item(s), choose a different address, or switch to Pickup at your original branch.")
                                            : ($unavail_branch_name . " doesn't have enough stock for: " . implode(', ', $unavailable_items) . ". Please remove or adjust the item(s).");
                                        $unavail_msg_js = json_encode(['error', 'Some items are unavailable at this branch', $unavail_text]);
                                        echo "<script>$(document).ready(function(){ var m = {$unavail_msg_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
                                    }

                                    if (!$blockOrder && $stmt->execute()) {
                                        foreach($order_list as $order_array){
                                            //Deducts stock value based on quantity
                                            $sql = "UPDATE `product` SET `stock` = `stock` - ? WHERE product_name = ? AND category = ? AND branch_id = ?";
                                            $stmt = $conn->prepare($sql);
                                            $value = $order_array['qty'];
                                            $stmt->bind_param("issi", $value, $order_array["name"], $order_array["category"], $order_final_branch_id);
                                            if ($stmt->execute()) {
                                                //Deducts stocks on stocks table value based on quantity
                                                if($order_array["category"]=="New Container"){
                                                    $sql = "UPDATE `stocks` SET `current_stock` = `current_stock` - ? WHERE name = ? AND branch_id = ?";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isi", $order_array["qty"], $order_array["name"], $order_final_branch_id);
                                                    if ($stmt->execute()) {}
                                                }
                                            }
                                        }
                                            

                                        //PayMongo confirmed the payment -> email the customer, the cashiers and finance
                                        if ($paymongoReturn) {
                                            pe_customer_checkout_paid($conn, [
                                                //the branch the order actually landed in (delivery may have switched it above)
                                                'branch_id'        => $order_final_branch_id,
                                                'order_id'         => $order_info->id,
                                                'customer_name'    => $customer_name,
                                                'customer_email'   => $customer_email,
                                                'customer_contact' => $customer_contact,
                                                'order_type'       => $order_type,
                                                'delivery_type'    => $_POST['delivery_type'] ?? '',
                                                'address'          => $_POST['address'] ?? '',
                                                'amount'           => $total_amount,
                                                'method'           => $payment_method,
                                                'ref'              => $pending['session_id'] ?? '',
                                                'items'            => array_map(function ($o) {
                                                    return ['label' => $o['qty'] . 'x ' . $o['name'] . ' ' . $o['measurement'] . ' (' . $o['category'] . ')', 'amount' => $o['price']];
                                                }, $order_list),
                                            ]);
                                        }

                                        //Receipt shown (and printable) right after the order is placed
                                        $receipt_data = [
                                            'order_id'  => $order_info->id,
                                            'date'      => $date,
                                            'time'      => $time,
                                            'name'      => $customer_name,
                                            'contact'   => $customer_contact,
                                            'address'   => ($order_type == "Delivery") ? ($_POST['address'] ?? '') : '',
                                            'order_type'=> $order_type,
                                            'delivery'  => ($order_type == "Delivery") ? ($_POST['delivery_type'] ?? 'Standard') : '',
                                            'method'    => $payment_method,
                                            'paid'      => $paymongoReturn,
                                            'ref'       => $paymongoReturn ? ($pending['session_id'] ?? '') : '',
                                            'vat'       => (float) $order_info->total_vat,
                                            'total'     => (float) $total_amount,
                                        ];

                                        echo <<<HTML
                                            <script>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Order Confirmed!',
                                                    text: 'Your order has been placed successfully.',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#00E676',
                                                    heightAuto: false
                                                }).then((result) => {
                                                    if (result.isConfirmed || result.isDismissed) {
                                                        showOrderReceipt();
                                                    }
                                                });
                                            </script> 
                                            HTML;
                                    }
                                }

                            }
                            
                        }
                    ?>


                    




                    <hr class="divider">

                    <!-- Price Breakdown -->
                    <div class="d-flex justify-content-between text-muted mb-2 mt-3" style="font-size: 14px;">
                        <span>Subtotal</span>
                        <span>₱ <?php echo number_format((float)$order_info->total_price - (float)$order_info->total_vat, 2); ?></span>
                    </div>

                    <!-- Added ID for toggling delivery fee visibility -->
                    <div class="d-flex justify-content-between text-muted mb-2 d-none" style="font-size: 14px;" id="priorityFee">
                        <span style="color: #00e676;">Priority delivery</span>
                        <span>₱49.00</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;" id="standardFee">
                        <span style="color: #00e676;">Standard delivery</span>
                        <span>Free</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;">
                        <span>VAT</span>
                        <span>₱ <?php echo number_format((float)$order_info->total_vat, 2); ?></span>
                    </div>

                    <!-- Grand Total -->
                    <div class="d-flex justify-content-between align-items-end mb-4">
                        <div>
                            <h4 class="fw-bold m-0">Total</h4>
                            <span class="text-muted" style="font-size: 12px;">(incl. fees and tax)</span>
                        </div>
                        <div class="text-end">
                            <h4 class="fw-bold m-0 text-primary-accent" id="total_amount">₱ <?php echo $order_info->total_price?></h4>
                        </div>
                    </div>

                    <!-- Desktop Submit Button -->
                    <button type="button" class="btn-primary-accent d-none d-lg-flex" data-bs-toggle="modal" data-bs-target="#placingOrderModal"><i class="bi bi-bag-check"></i> Place order</button>

                </div>
            </div>

        </div>
    </div>


    <!-- Delivery Address Modal -->
    <div class="modal fade" id="addressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">
                    <h6 class="fw-bold text-white mb-3">Saved Addresses</h6>

                    <div class="d-flex flex-column gap-3 mb-4">
                        <!-- Address 1 -->
                        <label class="address-box m-0">
                            <input class="form-check-input flex-shrink-0 fs-5 mt-1" type="radio" name="savedAddress" checked>
                            <i class="bi bi-geo-alt fs-5 mt-1 text-muted transition"></i>
                            <div class="flex-grow-1 text-white">
                                <div class="fw-semibold" style="line-height: 1.4;">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio fugit saepe vitae repellendus dolore ipsa porro architecto aperiam libero, voluptate repellat laboriosam optio deleniti aut maiores natus maxime, soluta vero.</div>
                                <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                                
                            </div>
                            <div class="address-actions d-flex flex-column gap-2 flex-shrink-0">
                                <button type="button" class="btn-icon" data-bs-toggle="modal" data-bs-target="#editAddressModal"><i class="bi bi-pencil"></i></button>
                                <button type="button" class="btn-icon"><i class="bi bi-trash"></i></button>
                            </div>
                        </label>

                        
                    </div>

                    <!-- Add Address Button -->
                    <a href="#" class="custom-link d-inline-flex align-items-center gap-2 mb-2" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                        <i class="bi bi-plus-lg fs-5"></i> Add address
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Address Modal -->
    <div class="modal fade" id="editAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2 d-flex justify-content-between align-items-center">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <a href="#" class="text-muted text-decoration-none fw-semibold" data-bs-dismiss="modal">Cancel</a>
                </div>

                <div class="modal-body p-4 pt-3">

                    <!-- Map Placeholder -->
                    

                    <!-- Address Text & Edit Link -->
                    <div class="d-flex align-items-start mb-3">
                        <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                        <div class="flex-grow-1 text-white">
                            <div class="fw-semibold" style="line-height: 1.4;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque consectetur ut explicabo ratione rem expedita, fugiat rerum necessitatibus harum ipsa, quae obcaecati deleniti architecto quisquam voluptatum aliquid saepe deserunt minima.</div>
                            <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                        </div>
                        <a href="#" class="custom-link ms-2">Edit</a>
                    </div>

                    <hr class="divider mb-4">

                    <!-- Floor Input -->
                    <input type="text" class="form-control mb-3" placeholder="Floor">

                    <!-- Note to rider -->
                    <textarea class="form-control mb-4" placeholder="Note to rider - e.g. building, landmark" rows="3" style="resize: none;"></textarea>

                    <!-- Labels -->
                    <h6 class="text-white fw-bold mb-3">Add a Label</h6>
                    <div class="d-flex flex-wrap gap-2 mb-4">
                        <button type="button" class="btn label-btn"><i class="bi bi-house"></i> Home</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-briefcase"></i> Work</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-heart"></i> Partner</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-plus-lg"></i> Other</button>
                    </div>

                    <!-- Submit Button -->
                    <button type="button" class="btn-primary-accent w-100" data-bs-dismiss="modal">SUBMIT</button>

                </div>
            </div>
        </div>
    </div>

    <!-- Add Address Modal -->
    <div class="modal fade" id="addAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <!-- Header -->
                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt fs-4"></i> What's your exact location?
                    </h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">

                    <p class="text-muted mb-4" style="font-size: 14.5px;">
                        Providing your location enables more accurate search and delivery ETA, seamless order tracking and personalised recommendations.
                    </p>

                    <!-- Custom Input Field
                    <div class="address-search-wrapper">
                        <label>Enter your address</label>
                        <input type="text" class="form-control address-search-input" value="addresssssssssssssssssssssssssssssssssssssssss">
                        <button class="address-clear-btn"><i class="bi bi-x-circle"></i></button>
                    </div>-->

                    <!-- Large Map Placeholder
                    <div class="map-placeholder-lg">

                        <div class="map-tooltip">We'll deliver here</div>
                        <i class="bi bi-geo-alt-fill text-primary-accent position-relative" style="font-size: 38px; z-index: 2; top: -5px;"></i>


                        <i class="bi bi-map text-muted position-absolute" style="font-size: 100px; opacity: 0.15; z-index: 0;"></i>
                    </div>-->

                    <div class="container border border-1 border-light p-3">

                        <!-- Search + current location -->
                        <div class="d-flex flex-wrap gap-2 mb-2">
                            <input type="text" id="mapSearch" class="form-control flex-grow-1" style="min-width: 200px;" placeholder="Search address, barangay or landmark" autocomplete="off">
                            <button type="button" class="btn btn-outline-light" id="mapSearchBtn" title="Search"><i class="bi bi-search"></i></button>
                            <button type="button" class="btn btn-success fw-bold" id="useMyLocation"><i class="bi bi-crosshair me-1"></i>Use my location</button>
                        </div>
                        <div id="mapResults" class="list-group mb-2 d-none" style="max-height: 190px; overflow-y: auto;"></div>
                        <div id="mapStatus" class="small text-muted mb-2" style="min-height: 20px;">Search for your address, use your current location, click the map, or drag the pin.</div>

                        <div class="container w-100" id="map"></div>

                        <label class="mt-3 text-light" for="lat">Latitude</label>
                        <input type="text" id="lat" class="form-control mb-2" readonly>

                        <label class="text-light" for="lng">Longitude</label>
                        <input type="text" id="lng" class="form-control" readonly>

                        <button type="button" class="btn btn-success w-100 fw-bold mt-3" data-bs-dismiss="modal"><i class="bi bi-check-circle me-1"></i>Use this location</button>
                    </div>

                    <!-- LEAFLET JS -->
                    <script>
                        $(function() {
                            const customIcon = L.icon({
                                iconUrl: '../Images/leaflet/location.png',
                                iconSize: [38, 38],
                                iconAnchor: [19, 50],
                                popupAnchor: [0, -38]
                            });

                            const defaultCoords = [14.3232, 120.9408];
                            $("#lat").val(defaultCoords[0]);
                            $("#lng").val(defaultCoords[1]);

                            const map = L.map('map').setView(defaultCoords, 16);
                            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 19,
                                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                            }).addTo(map);

                            const currentMarker = L.marker(defaultCoords, { icon: customIcon, draggable: true }).addTo(map)
                                .bindPopup('<b>Water Station</b><br>Pick Up Point').openPopup();

                            //Modal fix: recalculate tile sizes when the modal opens
                            $('#addAddressModal').on('shown.bs.modal', function() {
                                map.invalidateSize();
                            });

                            function status(msg, isError) {
                                $("#mapStatus").text(msg).css('color', isError ? '#ff6b6b' : '');
                            }

                            function setAddress(text) {
                                $("#address_setter").val(text);
                                $("#address_getter").val(text);
                            }

                            //Turns coordinates into a readable address (falls back to "lat, lng")
                            function reverseGeocode(lat, lng) {
                                const fallback = lat.toFixed(6) + ", " + lng.toFixed(6);
                                setAddress(fallback);
                                fetch('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=' + lat + '&lon=' + lng)
                                    .then(r => r.json())
                                    .then(d => { setAddress(d && d.display_name ? d.display_name : fallback); })
                                    .catch(() => setAddress(fallback));
                            }

                            //Moves pin + fills the fields. label = address text when we already have it (from search)
                            function setLocation(lat, lng, label, zoom) {
                                currentMarker.setLatLng([lat, lng]);
                                map.setView([lat, lng], zoom || Math.max(map.getZoom(), 17));
                                $("#lat").val(lat);
                                $("#lng").val(lng);
                                // Only set once the customer actually confirms a spot on the map,
                                // so the server knows to re-check which branch this delivery belongs to.
                                $("#customer_lat_getter").val(lat);
                                $("#customer_lng_getter").val(lng);
                                currentMarker.bindPopup('<b>Selected Location</b><br>' + (label ? label : lat.toFixed(6) + ', ' + lng.toFixed(6))).openPopup();
                                if (label) setAddress(label); else reverseGeocode(lat, lng);
                            }

                            //Click the map / drag the pin
                            map.on('click', function(e) { setLocation(e.latlng.lat, e.latlng.lng); });
                            currentMarker.on('dragend', function() {
                                const p = currentMarker.getLatLng();
                                setLocation(p.lat, p.lng);
                            });

                            //SEARCH AS YOU TYPE (OpenStreetMap Nominatim, Philippines only, results near Dasmarinas ranked first)
                            let searchTimer = null, searchCtl = null;
                            const searchCache = {};

                            function showResults(list, q) {
                                const $res = $("#mapResults").empty();
                                if (!list.length) {
                                    $res.addClass("d-none");
                                    status("No results for \"" + q + "\". Try a nearby landmark, barangay or street.", true);
                                    return;
                                }
                                status("Pick your address below.");
                                list.forEach(function(item) {
                                    $('<button type="button" class="list-group-item list-group-item-action text-start"></button>')
                                        .css({ background: '#112240', color: '#CCD6F6', borderColor: '#233554', fontSize: '14px' })
                                        .text(item.display_name)
                                        .on('click', function() {
                                            setLocation(parseFloat(item.lat), parseFloat(item.lon), item.display_name, 18);
                                            $res.empty().addClass("d-none");
                                            $("#mapSearch").val(item.display_name);
                                            status("Location set. Drag the pin to fine-tune it.");
                                        })
                                        .appendTo($res);
                                });
                                $res.removeClass("d-none");
                            }

                            function runSearch() {
                                const q = $.trim($("#mapSearch").val());
                                if (q.length < 3) {
                                    $("#mapResults").empty().addClass("d-none");
                                    status("Type at least 3 characters to search.", true);
                                    return;
                                }
                                if (searchCache[q]) { showResults(searchCache[q], q); return; }

                                if (searchCtl) searchCtl.abort(); //cancel the previous request, only the latest one matters
                                searchCtl = new AbortController();
                                status("Searching...");

                                fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=ph&viewbox=120.80,14.45,121.10,14.20&q=' + encodeURIComponent(q), { signal: searchCtl.signal })
                                    .then(r => r.json())
                                    .then(list => {
                                        searchCache[q] = list;
                                        if ($.trim($("#mapSearch").val()) === q) showResults(list, q); //ignore outdated answers
                                    })
                                    .catch(err => {
                                        if (err.name !== 'AbortError') status("Search failed. Check your internet connection.", true);
                                    });
                            }

                            //Suggestions appear automatically while typing (waits 500ms after the last key)
                            $("#mapSearch").on('input', function() {
                                clearTimeout(searchTimer);
                                if ($.trim($(this).val()).length < 3) {
                                    $("#mapResults").empty().addClass("d-none");
                                    status("Keep typing... (at least 3 characters)");
                                    return;
                                }
                                searchTimer = setTimeout(runSearch, 500);
                            });
                            $("#mapSearchBtn").on('click', function() { clearTimeout(searchTimer); runSearch(); });
                            $("#mapSearch").on('keydown', function(e) {
                                if (e.key === 'Enter') { e.preventDefault(); clearTimeout(searchTimer); runSearch(); }
                            });

                            //USE MY LOCATION
                            $("#useMyLocation").on('click', function() {
                                if (!navigator.geolocation) { status("Your browser does not support location.", true); return; }
                                const $btn = $(this).prop('disabled', true);
                                status("Getting your location... please allow location access.");
                                navigator.geolocation.getCurrentPosition(function(pos) {
                                    $btn.prop('disabled', false);
                                    $("#mapResults").empty().addClass("d-none");
                                    setLocation(pos.coords.latitude, pos.coords.longitude, null, 18);
                                    status("Using your current location. Drag the pin if it's slightly off.");
                                }, function(err) {
                                    $btn.prop('disabled', false);
                                    const msgs = {
                                        1: "Location permission was denied. Allow it in your browser's site settings, or search for your address instead.",
                                        2: "Your location could not be determined. Try searching for your address instead.",
                                        3: "Getting your location timed out. Please try again."
                                    };
                                    status(msgs[err.code] || "Could not get your location.", true);
                                }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
                            });
                        });
                    </script>

                </div>
            </div>
        </div>
    </div>

    <?php if ($receipt_data): $rd = $receipt_data; ?>
    <!-- Order Receipt (shown after the order is placed) -->
    <style>
        #orderReceiptModal .modal-content { background-color: #e2e8f0 !important; border: none; border-radius: 10px; }
        #orderReceiptModal .receipt-paper { width: 100%; max-width: 320px; margin: 0 auto; background: #fff; color: #000; font-family: "Courier New", Courier, monospace; font-size: 14px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        #orderReceiptModal .receipt-paper p { margin: 0; line-height: 1.4; color: #000; }
        #orderReceiptModal .receipt-divider { border-top: 1px dashed #000; margin: 10px 0; }
        #orderReceiptModal .receipt-flex { display: flex; justify-content: space-between; gap: 10px; }
        #orderReceiptModal .receipt-item { display: flex; justify-content: space-between; gap: 10px; }
        #orderReceiptModal .receipt-stamp { border: 2px solid #000; text-align: center; font-weight: 700; padding: 6px; margin-top: 12px; letter-spacing: 1px; }
        @media print {
            body * { visibility: hidden; }
            #printableReceipt, #printableReceipt * { visibility: visible; }
            #printableReceipt { position: absolute; left: 0; top: 0; box-shadow: none !important; margin: 0 !important; }
        }
    </style>
    <div class="modal fade" id="orderReceiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0" style="color:#000;">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>
                        <div class="receipt-divider"></div>
                        <div class="receipt-stamp" style="margin: 0 0 10px; font-size: 16px;"><?php echo ($rd['order_type'] === 'Pickup') ? 'FOR PICKUP' : 'FOR DELIVERY'; ?></div>
                        <div class="receipt-flex">
                            <p>Order: <strong>#<?php echo (int) $rd['order_id']; ?></strong></p>
                            <p>Date: <?php echo htmlspecialchars($rd['date']); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>Time: <?php echo htmlspecialchars($rd['time']); ?></p>
                            <p>Online Order</p>
                        </div>
                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold"><?php echo ($rd['order_type'] === 'Pickup') ? 'PICKUP DETAILS' : 'DELIVERY DETAILS'; ?></p>
                        <p style="overflow-wrap:break-word;">Name: <?php echo htmlspecialchars($rd['name']); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($rd['contact']); ?></p>
                        <?php if ($rd['address'] !== ''): ?>
                            <p style="overflow-wrap:break-word;">Address: <?php echo htmlspecialchars($rd['address']); ?></p>
                        <?php endif; ?>
                        <p>Order Type: <?php echo htmlspecialchars($rd['order_type']); ?><?php echo $rd['delivery'] ? ' (' . htmlspecialchars($rd['delivery']) . ')' : ''; ?></p>
                        <p>Payment: <?php echo $rd['paid'] ? 'PayMongo (Paid Online)' : (($rd['order_type'] === 'Pickup') ? 'Cash On Pickup' : 'Cash On Delivery'); ?></p>
                        <?php if ($rd['ref']): ?>
                            <p style="overflow-wrap:anywhere;">Ref: <?php echo htmlspecialchars($rd['ref']); ?></p>
                        <?php endif; ?>
                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <?php foreach ($order_list as $it): ?>
                            <div class="receipt-item">
                                <p><?php echo (int) $it['qty'] . 'x ' . htmlspecialchars($it['name'] . ' ' . $it['measurement'] . ' (' . $it['category'] . ')'); ?></p>
                                <p>₱<?php echo number_format($it['price'], 2); ?></p>
                            </div>
                        <?php endforeach; ?>
                        <div class="receipt-divider"></div>
                        <div class="receipt-flex">
                            <p>Subtotal:</p>
                            <p>₱<?php echo number_format($rd['total'] - $rd['vat'] - ($rd['delivery'] === 'Priority' ? 49 : 0), 2); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>VAT:</p>
                            <p>₱<?php echo number_format($rd['vat'], 2); ?></p>
                        </div>
                        <?php if ($rd['delivery'] === 'Priority'): ?>
                            <div class="receipt-flex">
                                <p>Priority delivery:</p>
                                <p>₱49.00</p>
                            </div>
                        <?php endif; ?>
                        <div class="receipt-divider"></div>
                        <div class="receipt-flex fw-bold" style="font-size:16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱<?php echo number_format($rd['total'], 2); ?></p>
                        </div>
                        <div class="receipt-stamp"><?php echo $rd['paid'] ? 'PAID' : (($rd['order_type'] === 'Pickup') ? 'PAY ON PICKUP' : 'PAY ON DELIVERY'); ?></div>
                        <p class="text-center mt-3">Thank you for your order!</p>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 justify-content-center gap-2">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" id="btnReceiptDone"><i class="bi bi-check-lg me-1"></i>Done</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print Receipt</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        function showOrderReceipt() {
            bootstrap.Modal.getOrCreateInstance(document.getElementById('orderReceiptModal')).show();
        }
        document.getElementById('btnReceiptDone').addEventListener('click', function () {
            window.location.href = 'home.php';
        });
    </script>
    <?php endif; ?>

    <!-- Placing Order Modal -->
    <div class="modal fade" id="placingOrderModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content placing-modal-content">
                <div class="modal-body p-4 p-sm-5">

                    <div class="text-center mb-4">
                        <img src="../Images/receipt.gif" alt="Receipt" style="width: 70px; margin-bottom: 16px; border: 2px solid #b0c4d6; border-radius: 12px; padding: 8px; background-color: #ffffff; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                        <h4 class="mb-4" style="color: #000000 !important; font-size: 24px; font-weight: 800;">Placing your order...</h4>

                        <div class="placing-progress-bg">
                            <div class="placing-progress-bar"></div>
                        </div>
                    </div>

                    <div class="placing-route-container mt-5 mb-4">
                        <div class="placing-route-line"></div>

                        <div class="position-relative mb-4 d-flex align-items-center">
                            <div class="placing-icon-wrapper flex-shrink-0 me-3">
                                <i class="bi bi-geo-alt text-dark fs-5"></i>
                            </div>
                            <span class="fw-bold" style="font-size: 15px; color: #1a1a1a;">Eco Hydrate - Dasmarinas</span>
                        </div>

                        <div class="position-relative d-flex align-items-center">
                            <div class="placing-icon-wrapper flex-shrink-0 me-3">
                                <i class="bi bi-geo-alt text-dark fs-5"></i>
                            </div>
                            <span class="fw-bold text-truncate" style="font-size: 15px; color: #1a1a1a;">Dasmariñas, Cavite</span>
                        </div>
                    </div>

                    <hr class="placing-divider">

                    <?php 

                        foreach($order_list as $order_array){
                            echo '
                                    <div class="d-flex align-items-center my-3">
                                        <span class="fw-bold me-3" style="font-size: 15px; color: #1a1a1a;">'.$order_array["qty"].'x</span>
                                        <span class="fw-bold" style="font-size: 15px; color: #1a1a1a;">'.$order_array["name"].'</span>
                                    </div>
                                ';
                        }

                    ?>

                    <hr class="placing-divider">

                    <div class="d-flex align-items-center mt-3">
                        <div class="d-flex justify-content-center align-items-center rounded bg-white flex-shrink-0 me-3" style="width: 42px; height: 28px; border: 1px solid #b0c4d6; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                            <i class="bi bi-cash" style="color: #00a859; font-size: 16px;"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <span style="font-weight: 700; font-size: 14px; color: #000000;" id="modal_payment_method"></span>
                        </div>
                    </div>

                    <div class="d-flex gap-3 mt-4">
                        <button type="button" class="btn-secondary-accent" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn-primary-accent m-0" data-bs-dismiss="modal" id="btnLooksGood" form="orderConfirm" name="confirmOrder">Looks Good</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(document).ready(function() {


        //Delivery Type
        function deliveryMode(on, off, total_amount, delivery_type, visual_delivery){

            $("#standardFee").attr("class",on);
            $("#priorityFee").attr("class",off);
            $("#total_amount").text("₱"+total_amount);
            $("#total_amount_getter").val(total_amount);
            $("#delivery_type_getter").val(delivery_type);
            if(visual_delivery=="change"){
                $("#visual_delivery_getter").val(delivery_type);
            }
        }
        

        function paymentMethod(payment_method){
            $("#payment_method_getter").val(payment_method);
            if(payment_method=="Cash"){
                $("#modal_payment_method").text("Cash On Delivery");
            }else{
                $("#modal_payment_method").text("Online Payment");
            }                                      
        }

        function orderType(order_type){
            $("#order_type_getter").val(order_type);
        }

        //Default Values
        //Also re-applied on pageshow: when the customer comes back from PayMongo with the Back button,
        //the browser restores the radio buttons (e.g. "Pay Online") but not the hidden inputs the form
        //actually submits, so the screen and the submitted payment method could disagree.
        function resetCheckoutDefaults(){
            $("#standard_delivery input[type=radio]").prop("checked", true);
            $("#cash_payment input[type=radio]").prop("checked", true);
            deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
            paymentMethod("Cash");
            orderType("Delivery");
            if ($("#btnPickup").hasClass("active")) { $("#btnDelivery").trigger("click"); }
        }
        resetCheckoutDefaults();

        //After an order is placed the page reloads, which reset the summary to Standard (Free).
        //Re-apply what was actually ordered so the summary matches the receipt.
        <?php if (isset($receipt_data) && is_array($receipt_data)) : ?>
        (function(){
            var placed = <?php echo json_encode(['order_type' => $receipt_data['order_type'], 'delivery' => $receipt_data['delivery'], 'total' => (float) $receipt_data['total']]); ?>;
            if (placed.order_type === "Pickup") {
                $("#btnPickup").trigger("click");
            } else if (placed.delivery === "Priority") {
                $("#priority_delivery input[type=radio]").prop("checked", true);
                deliveryMode("d-flex justify-content-between text-muted mb-2 d-none","d-flex justify-content-between text-muted mb-2",placed.total.toFixed(1),"Priority","change");
            }
        })();
        <?php endif; ?>

        window.addEventListener("pageshow", function(e){
            if (e.persisted) { resetCheckoutDefaults(); }
        });

        //Delivery type setter
        $("#standard_delivery").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
        });

        $("#priority_delivery").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2 d-none","d-flex justify-content-between text-muted mb-2",(parseFloat(<?php echo $order_info->total_price?>)+49).toFixed(1),"Priority", "change");
        });


        //Payment method setter
        $("#cash_payment").click(function(){
            paymentMethod("Cash");
        });

        $("#card_payment").click(function(){
            paymentMethod("Gcash");
        });


        //Order Type setter
        $("#btnDelivery").click(function(){
            if($("#visual_delivery_getter").val()=="Priority"){
                deliveryMode("d-flex justify-content-between text-muted mb-2 d-none","d-flex justify-content-between text-muted mb-2",(parseFloat(<?php echo $order_info->total_price?>)+49).toFixed(1),"Priority", "change");
            }else{
                deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
            }
            orderType("Delivery");
        });

        $("#btnPickup").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","not-change");
            orderType("Pickup");
        });

        //Address setter re-route for form convinience 
        $("#address_getter").val($("#address_setter").val());

        $("#address_setter").on("input", function() {
            $("#address_getter").val($("#address_setter").val());
            
        });
    });
    document.addEventListener('DOMContentLoaded', function() {
        const btnDelivery = document.getElementById('btnDelivery');
        const btnPickup = document.getElementById('btnPickup');
        const deliverySections = document.getElementById('deliverySections');
        const summaryDeliveryFee = document.getElementById('summaryDeliveryFee');

        btnDelivery.addEventListener('click', function() {
            btnDelivery.classList.add('active');
            btnPickup.classList.remove('active');

            // Show delivery address and options
            deliverySections.style.display = 'block';

            // Show delivery fee in summary
            if (summaryDeliveryFee) summaryDeliveryFee.style.display = 'flex';
        });

        btnPickup.addEventListener('click', function() {
            btnPickup.classList.add('active');
            btnDelivery.classList.remove('active');

            // Hide delivery address and options
            deliverySections.style.display = 'none';

            // Hide delivery fee in summary
            if (summaryDeliveryFee) summaryDeliveryFee.style.display = 'none';
        });

        const placingModal = document.getElementById('placingOrderModal');
        if (placingModal) {
            const progressBar = placingModal.querySelector('.placing-progress-bar');
            placingModal.addEventListener('show.bs.modal', function() {
                progressBar.style.animation = 'none';
                progressBar.offsetHeight;
                progressBar.style.animation = 'progressAnim 4s ease-in-out forwards';
            });
        }

    });


    
</script>