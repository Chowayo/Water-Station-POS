<?php
// ---- Profile data (read once, used by the header, stats strip and Order History tab) ----
// ---- Save the delivery address picked in the Information tab ----
$pf_addr_msg = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['saveAddress']) && isset($result, $conn)) {
    $new_addr = preg_replace('/\s+/u', ' ', trim((string)($_POST['pf_address'] ?? '')));
    if ($new_addr === '') {
        $pf_addr_msg = ['error', 'Address is empty', 'Please search for your address on the map or type it in.'];
    } else {
        $new_addr = mb_substr($new_addr, 0, 255, 'UTF-8'); //customers.address is varchar(255)
        $a_id = (int)$result->id;
        $a_stmt = $conn->prepare("UPDATE `customers` SET `address` = ? WHERE `id` = ?");
        $a_stmt->bind_param("si", $new_addr, $a_id);
        if ($a_stmt->execute()) {
            $result->address = $new_addr; //so this page (and the checkout address box) show the new address right away
            $pf_addr_msg = ['success', 'Address saved', 'Your delivery address has been updated.'];
        } else {
            $pf_addr_msg = ['error', 'Could not save', 'Something went wrong while saving your address. Please try again.'];
        }
    }
}
if ($pf_addr_msg) {
    $pf_addr_js = json_encode($pf_addr_msg);
    echo "<script>$(document).ready(function(){ var m = {$pf_addr_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
}

$pf_name     = isset($result) ? trim((string)$result->full_name) : 'Customer';
$pf_email    = isset($result) ? trim((string)$result->email) : '';
$pf_contact  = isset($result) ? trim((string)$result->contact) : '';
$pf_address  = isset($result) ? trim((string)$result->address) : '';

// Initials for the avatar (first + last word of the name)
preg_match_all('/\p{L}+/u', $pf_name, $pf_words);
$pf_words = $pf_words[0];
$pf_initials = '';
if (count($pf_words) > 0) {
    $pf_initials = mb_substr($pf_words[0], 0, 1, 'UTF-8');
    if (count($pf_words) > 1) {
        $pf_initials .= mb_substr($pf_words[count($pf_words) - 1], 0, 1, 'UTF-8');
    }
    $pf_initials = mb_strtoupper($pf_initials, 'UTF-8');
} else {
    $pf_initials = 'C';
}

// Order history (non-pending orders of this customer)
$pf_orders = [];
$pf_completed = 0;
$pf_spent = 0.0;
if (isset($result, $conn)) {
    $h_owner = 'USER ID:' . $result->id;
    $h_stmt = $conn->prepare("SELECT * FROM orders WHERE cashier = ? AND deleted = 'False' AND status != 'Pending' ORDER BY id DESC");
    $h_stmt->bind_param("s", $h_owner);
    $h_stmt->execute();
    $h_query = $h_stmt->get_result();
    while ($h = $h_query->fetch_object()) {
        $pf_orders[] = $h;
        if ($h->status === 'Received') {
            $pf_completed++;
            $pf_spent += (float)$h->total_price;
        }
    }
}
$pf_order_count = count($pf_orders);
?>
<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-labelledby="pfName" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content pf-modal">

            <!-- HERO -->
            <header class="pf-hero">
                <svg class="pf-waves" viewBox="0 0 2400 120" preserveAspectRatio="none" aria-hidden="true">
                    <path class="pf-wave pf-wave-back" d="M0 52 q150 -44 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                    <path class="pf-wave pf-wave-front" d="M0 78 q150 -34 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                </svg>

                <button type="button" class="pf-close" data-bs-dismiss="modal" aria-label="Close profile"><i class="bi bi-x-lg"></i></button>

                <div class="pf-identity">
                    <div class="pf-avatar" aria-hidden="true"><?php echo htmlspecialchars($pf_initials); ?></div>
                    <div class="pf-identity-text">
                        <h5 class="pf-name" id="pfName"><?php echo htmlspecialchars($pf_name); ?></h5>
                        <?php if ($pf_email !== ''): ?>
                            <div class="pf-email"><i class="bi bi-envelope"></i><span class="pf-email-text"><?php echo htmlspecialchars($pf_email); ?></span></div>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <!-- STATS -->
            <div class="pf-stats">
                <div class="pf-stat">
                    <span class="pf-stat-value"><?php echo $pf_order_count; ?></span>
                    <span class="pf-stat-label">Orders</span>
                </div>
                <div class="pf-stat">
                    <span class="pf-stat-value"><?php echo $pf_completed; ?></span>
                    <span class="pf-stat-label">Completed</span>
                </div>
                <div class="pf-stat">
                    <span class="pf-stat-value">₱<?php echo number_format($pf_spent, 2); ?></span>
                    <span class="pf-stat-label">Total spent</span>
                </div>
            </div>

            <div class="pf-body">

                <ul class="nav pf-tabs" id="profileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profTabInfo" data-bs-toggle="tab" data-bs-target="#profPaneInfo" type="button" role="tab"><i class="bi bi-person"></i>Information</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profTabOrders" data-bs-toggle="tab" data-bs-target="#profPaneOrders" type="button" role="tab"><i class="bi bi-receipt"></i>Order History<?php if ($pf_order_count > 0): ?><span class="pf-tab-count"><?php echo $pf_order_count; ?></span><?php endif; ?></button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profTabPass" data-bs-toggle="tab" data-bs-target="#profPanePass" type="button" role="tab"><i class="bi bi-shield-lock"></i>Password</button>
                    </li>
                </ul>

                <div class="tab-content">

                    <!-- INFORMATION TAB -->
                    <div class="tab-pane fade show active" id="profPaneInfo" role="tabpanel">
                        <div class="pf-fields">
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-person"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Full name</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_name); ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-envelope"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Email address</span>
                                    <span class="pf-field-value"><?php echo $pf_email !== '' ? htmlspecialchars($pf_email) : '<span class="pf-empty">Not provided</span>'; ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-telephone"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Contact number</span>
                                    <span class="pf-field-value"><?php echo $pf_contact !== '' ? htmlspecialchars($pf_contact) : '<span class="pf-empty">Not provided</span>'; ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-geo-alt"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Delivery address</span>
                                    <span class="pf-field-value" id="pfAddrShown"><?php echo $pf_address !== '' ? htmlspecialchars($pf_address) : '<span class="pf-empty">Not provided</span>'; ?></span>
                                </div>
                                <button type="button" class="pf-btn pf-btn-ghost ms-auto flex-shrink-0" id="pfAddrEditBtn"><i class="bi bi-pencil"></i><?php echo $pf_address !== '' ? 'Change' : 'Add'; ?></button>
                            </div>
                        </div>

                        <!-- ADDRESS EDITOR (Leaflet map) -->
                        <form method="POST" id="pfAddressForm" class="pf-addr-editor d-none">
                            <div class="pf-addr-top">
                                <input type="text" id="pfMapSearch" class="form-control profile-input" placeholder="Search address, barangay or landmark" autocomplete="off">
                                <button type="button" class="pf-btn pf-btn-ghost" id="pfMapSearchBtn" title="Search"><i class="bi bi-search"></i></button>
                                <button type="button" class="pf-btn pf-btn-ghost" id="pfUseMyLocation"><i class="bi bi-crosshair"></i>My location</button>
                            </div>
                            <div id="pfMapResults" class="pf-addr-results d-none"></div>
                            <div id="pfMapStatus" class="pf-addr-status">Search for your address, use your current location, click the map, or drag the pin.</div>
                            <div id="pfMap"></div>

                            <label for="pfAddressInput" class="pf-label mt-3">Delivery address</label>
                            <textarea id="pfAddressInput" name="pf_address" class="form-control profile-input" rows="2" maxlength="255" required style="resize:none;"><?php echo htmlspecialchars($pf_address); ?></textarea>

                            <div class="d-flex justify-content-end gap-2 pt-3">
                                <button type="button" class="pf-btn pf-btn-ghost" id="pfAddrCancel"><i class="bi bi-x-lg"></i>Cancel</button>
                                <button type="submit" name="saveAddress" class="pf-btn pf-btn-primary"><i class="bi bi-check-circle"></i>Save address</button>
                            </div>
                        </form>
                    </div>

                    <!-- ORDER HISTORY TAB -->
                    <div class="tab-pane fade" id="profPaneOrders" role="tabpanel">
                        <div class="pf-orders">
                        <?php
                        foreach ($pf_orders as $h) {
                            //Items of the order
                            $h_items = [];
                            foreach (explode(',', $h->order_content) as $h_line) {
                                if (preg_match('/^(\d+)x\s*(.*?)\s*(\d+(?:\.\d+)?\s*(?:L|ML))\s*\((.*?)\)\s*₱([\d.]+)/ui', $h_line, $hm)) {
                                    $h_items[] = [
                                        'qty'   => $hm[1],
                                        'name'  => trim($hm[2]) . ' ' . $hm[3],
                                        'cat'   => $hm[4],
                                        'price' => (float)$hm[5],
                                    ];
                                }
                            }

                            $h_done   = ($h->status === 'Received');
                            $h_badge  = $h_done ? 'Completed' : 'Order placed';
                            $h_class  = $h_done ? 'is-done' : 'is-placed';
                            $h_icon   = $h_done ? 'bi-check-circle-fill' : 'bi-hourglass-split';
                            $h_online = ($h->payment_method === 'Gcash');
                            $h_pay    = $h_online ? 'Paid online' : 'Cash';
                            $h_payicon = $h_online ? 'bi-phone' : 'bi-cash-stack';
                            $h_typeicon = (stripos($h->order_type, 'deliver') !== false) ? 'bi-truck' : 'bi-bag';
                            ?>
                            <article class="pf-order <?php echo $h_class; ?>">
                                <div class="pf-order-head">
                                    <div>
                                        <div class="pf-order-id">Order #<?php echo (int)$h->id; ?></div>
                                        <div class="pf-order-date"><i class="bi bi-calendar3"></i><?php echo htmlspecialchars($h->date); ?><i class="bi bi-clock ms-2"></i><?php echo htmlspecialchars($h->time); ?></div>
                                    </div>
                                    <span class="pf-badge"><i class="bi <?php echo $h_icon; ?>"></i><?php echo $h_badge; ?></span>
                                </div>

                                <ul class="pf-order-items">
                                    <?php foreach ($h_items as $it): ?>
                                        <li>
                                            <span class="pf-qty"><?php echo (int)$it['qty']; ?>×</span>
                                            <span class="pf-item-name"><?php echo htmlspecialchars($it['name']); ?><small><?php echo htmlspecialchars($it['cat']); ?></small></span>
                                            <span class="pf-item-price">₱<?php echo number_format($it['price'], 2); ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>

                                <div class="pf-order-foot">
                                    <span class="pf-order-meta">
                                        <span><i class="bi <?php echo $h_typeicon; ?>"></i><?php echo htmlspecialchars($h->order_type); ?></span>
                                        <span><i class="bi <?php echo $h_payicon; ?>"></i><?php echo $h_pay; ?></span>
                                    </span>
                                    <span class="pf-order-total">₱<?php echo number_format((float)$h->total_price, 2); ?></span>
                                </div>
                            </article>
                            <?php
                        }
                        if ($pf_order_count === 0) {
                            echo '<div class="pf-empty-state">
                                    <span class="pf-empty-icon"><i class="bi bi-droplet"></i></span>
                                    <p class="pf-empty-title">No orders yet</p>
                                    <p class="pf-empty-text">Orders you place will show up here once they are confirmed.</p>
                                    <button type="button" class="pf-btn pf-btn-ghost" data-bs-dismiss="modal">Browse products</button>
                                  </div>';
                        }
                        ?>
                        </div>
                    </div>

                    <!-- PASSWORD TAB -->
                    <div class="tab-pane fade" id="profPanePass" role="tabpanel">
                    <div class="pf-pass">

                        <form id="customerChangePasswordForm" method="POST" class="pf-pass-form">
                            <div class="pf-input-group">
                                <label for="customerCurrentPassword" class="pf-label">Current password</label>
                                <div class="pf-input-wrap">
                                    <i class="bi bi-lock pf-input-icon"></i>
                                    <input type="password" class="form-control profile-input pf-input" id="customerCurrentPassword" name="current_password" autocomplete="current-password" required>
                                    <button type="button" class="pf-eye" data-target="customerCurrentPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                </div>
                            </div>
                            <div class="pf-input-group">
                                <label for="customerNewPassword" class="pf-label">New password</label>
                                <div class="pf-input-wrap">
                                    <i class="bi bi-key pf-input-icon"></i>
                                    <input type="password" class="form-control profile-input pf-input" id="customerNewPassword" name="new_password" autocomplete="new-password" required>
                                    <button type="button" class="pf-eye" data-target="customerNewPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                </div>
                            </div>
                            <div class="pf-input-group">
                                <label for="customerConfirmPassword" class="pf-label">Confirm new password</label>
                                <div class="pf-input-wrap">
                                    <i class="bi bi-key-fill pf-input-icon"></i>
                                    <input type="password" class="form-control profile-input pf-input" id="customerConfirmPassword" name="confirm_password" autocomplete="new-password" required>
                                    <button type="button" class="pf-eye" data-target="customerConfirmPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                </div>
                            </div>

                            <div class="d-flex justify-content-end pt-2">
                                <button type="submit" name="changePass" class="pf-btn pf-btn-primary"><i class="bi bi-shield-check"></i>Update password</button>
                            </div>
                        </form>

                        <aside class="pf-checklist" aria-live="polite">
                            <p class="pf-checklist-title">Your new password needs to</p>
                            <ul>
                                <li id="pfRuleLen"><i class="bi bi-circle"></i>Be at least 8 characters long</li>
                                <li id="pfRuleMatch"><i class="bi bi-circle"></i>Match the confirmation</li>
                                <li id="pfRuleDiff"><i class="bi bi-circle"></i>Differ from your current password</li>
                            </ul>
                        </aside>
                    </div>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($result, $conn)) {
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];

                            if (password_verify($current_pass, $result->password)) {
                                if (strlen($new_pass) >= 8) {
                                    if ($new_pass == $confirm_pass) {
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT);

                                            $sql = "UPDATE `customers` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'Your password has been updated!',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script>
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                            })
                                                        })
                                                    </script>
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                        })
                                                    })
                                                </script>
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                        })
                                                    });
                                                </script>
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                })
                                            });
                                        </script>
                                    HTML;
                            }
                        }
                    }
                    ?>
                    </div><!-- /password pane -->

                </div><!-- /tab-content -->
            </div><!-- /pf-body -->

        </div>
    </div>
</div>

<style>
    /* ===== Customer profile modal ===== */
    #adminProfileModal .pf-modal {
        background: var(--ws-panel-2, #0b3054);
        border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 30px 70px rgba(0, 0, 0, .55);
    }

    /* Hero */
    #adminProfileModal .pf-hero {
        position: relative;
        padding: 34px 32px 84px;
        background:
            radial-gradient(circle at 12% 0%, rgba(111, 227, 255, .34), transparent 55%),
            linear-gradient(135deg, #12609b 0%, #0b3f6e 55%, #08305a 100%);
        overflow: hidden;
    }
    #adminProfileModal .pf-waves {
        position: absolute; left: 0; bottom: -1px; width: 100%; height: 64px; pointer-events: none;
    }
    #adminProfileModal .pf-wave { fill: #0b3054; }
    #adminProfileModal .pf-wave-back { opacity: .4; animation: none; }
    #adminProfileModal .pf-wave-front { opacity: 1; }
    #adminProfileModal .pf-waves { width: 200%; animation: pfDrift 22s linear infinite; }
    @keyframes pfDrift { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    #adminProfileModal .pf-close {
        position: absolute; top: 16px; right: 16px; z-index: 2;
        width: 36px; height: 36px; border-radius: 12px;
        display: inline-flex; align-items: center; justify-content: center;
        background: rgba(4, 23, 41, .35); border: 1px solid rgba(255, 255, 255, .18);
        color: #fff; font-size: 14px; cursor: pointer; transition: background .15s, transform .15s;
    }
    #adminProfileModal .pf-close:hover { background: rgba(255, 107, 122, .35); }
    #adminProfileModal .pf-close:active { transform: scale(.94); }

    #adminProfileModal .pf-identity { position: relative; z-index: 1; display: flex; align-items: center; gap: 20px; }
    #adminProfileModal .pf-avatar {
        flex: 0 0 auto; width: 88px; height: 88px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 32px; font-weight: 800; letter-spacing: 1px; color: #04213b;
        background: linear-gradient(145deg, #8cecff, #29c5f6 60%, #1e88e5);
        box-shadow: 0 0 0 4px rgba(4, 23, 41, .35), 0 0 0 6px rgba(111, 227, 255, .55), 0 14px 28px rgba(0, 0, 0, .35);
    }
    #adminProfileModal .pf-identity-text { min-width: 0; overflow: hidden; }
    #adminProfileModal .pf-name { padding-right: 44px; }
    #adminProfileModal .pf-name {
        margin: 0 0 6px; color: #fff; font-size: 26px; font-weight: 800; line-height: 1.15;
        overflow-wrap: anywhere;
    }
    #adminProfileModal .pf-email {
        display: flex; align-items: center; gap: 8px; color: rgba(230, 246, 255, .85);
        font-size: 14px; white-space: nowrap;
    }
    #adminProfileModal .pf-email i { flex: 0 0 auto; }
    #adminProfileModal .pf-email-text { min-width: 0; overflow: hidden; text-overflow: ellipsis; }

    /* Stats strip */
    #adminProfileModal .pf-stats {
        position: relative; z-index: 1;
        display: grid; grid-template-columns: repeat(3, 1fr);
        margin: -34px 32px 0; padding: 14px 0;
        background: #06203a; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
        border-radius: 18px; box-shadow: 0 12px 28px rgba(0, 0, 0, .3);
    }
    #adminProfileModal .pf-stat { display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 4px 10px; }
    #adminProfileModal .pf-stat + .pf-stat { border-left: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
    #adminProfileModal .pf-stat-value { color: #fff; font-size: 22px; font-weight: 800; font-variant-numeric: tabular-nums; line-height: 1.2; }
    #adminProfileModal .pf-stat:nth-child(3) .pf-stat-value { color: var(--ws-aqua-2, #6fe3ff); }
    #adminProfileModal .pf-stat-label { color: var(--ws-muted, #8fb4cf); font-size: 12.5px; font-weight: 600; }

    /* Body + tabs */
    #adminProfileModal .pf-body { padding: 22px 32px 30px; }
    #adminProfileModal .pf-tabs {
        display: flex; gap: 6px; padding: 5px; margin-bottom: 22px; flex-wrap: nowrap;
        background: #06203a; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); border-radius: 14px;
        border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #adminProfileModal .pf-tabs .nav-item { flex: 1 1 0; }
    #adminProfileModal .pf-tabs .nav-link {
        width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
        padding: 10px 12px; border: none; border-radius: 10px;
        background: transparent; color: var(--ws-muted, #8fb4cf);
        font-size: 14px; font-weight: 700; white-space: nowrap; transition: background .15s, color .15s;
    }
    #adminProfileModal .pf-tabs .nav-link:hover { color: #fff; background: rgba(41, 197, 246, .08); }
    #adminProfileModal .pf-tabs .nav-link.active { color: #04213b; background: linear-gradient(135deg, #6fe3ff, #29c5f6); }
    #adminProfileModal .pf-tab-count {
        min-width: 22px; padding: 1px 7px; border-radius: 999px; font-size: 12px; font-weight: 800;
        background: rgba(41, 197, 246, .2); color: var(--ws-aqua-2, #6fe3ff);
    }
    #adminProfileModal .pf-tabs .nav-link.active .pf-tab-count { background: rgba(4, 33, 59, .18); color: #04213b; }

    /* Information */
    #adminProfileModal .pf-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 0 28px; }
    #adminProfileModal .pf-field {
        display: flex; align-items: center; gap: 14px; padding: 16px 0;
        border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #adminProfileModal .pf-field:nth-last-child(-n+2) { border-bottom: none; }
    #adminProfileModal .pf-field-icon {
        flex: 0 0 auto; width: 42px; height: 42px; border-radius: 13px;
        display: flex; align-items: center; justify-content: center; font-size: 18px;
        color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px solid rgba(41, 197, 246, .25);
    }
    #adminProfileModal .pf-field-text { display: flex; flex-direction: column; min-width: 0; }
    #adminProfileModal .pf-field-label { color: var(--ws-muted, #8fb4cf); font-size: 12.5px; font-weight: 600; }
    #adminProfileModal .pf-field-value { color: #fff; font-size: 15.5px; font-weight: 600; overflow-wrap: anywhere; }
    #adminProfileModal .pf-empty { color: var(--ws-muted, #8fb4cf); font-weight: 500; font-style: italic; }

    /* Order history */
    #adminProfileModal .pf-orders {
        display: flex; flex-direction: column; gap: 14px;
        max-height: 400px; overflow-y: auto; padding-right: 6px;
    }
    #adminProfileModal .pf-orders::-webkit-scrollbar { width: 6px; }
    #adminProfileModal .pf-orders::-webkit-scrollbar-thumb { background: rgba(41, 197, 246, .3); border-radius: 10px; }
    #adminProfileModal .pf-order {
        flex-shrink: 0; padding: 16px 18px 14px 20px; border-radius: 16px;
        background: rgba(4, 23, 41, .55); border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
        border-left: 4px solid var(--ws-amber, #ffc857);
    }
    #adminProfileModal .pf-order.is-done { border-left-color: var(--ws-green, #2ee6a6); }
    #adminProfileModal .pf-order-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; }
    #adminProfileModal .pf-order-id { color: #fff; font-size: 16px; font-weight: 800; }
    #adminProfileModal .pf-order-date { color: var(--ws-muted, #8fb4cf); font-size: 12.5px; margin-top: 2px; display: flex; align-items: center; gap: 5px; }
    #adminProfileModal .pf-badge {
        display: inline-flex; align-items: center; gap: 6px; padding: 4px 11px; border-radius: 999px;
        font-size: 12px; font-weight: 700; white-space: nowrap;
        background: rgba(255, 200, 87, .13); color: var(--ws-amber, #ffc857); border: 1px solid rgba(255, 200, 87, .38);
    }
    #adminProfileModal .pf-order.is-done .pf-badge {
        background: rgba(46, 230, 166, .13); color: var(--ws-green, #2ee6a6); border-color: rgba(46, 230, 166, .38);
    }
    #adminProfileModal .pf-order-items { list-style: none; margin: 12px 0; padding: 10px 0; border-top: 1px dashed var(--ws-line, rgba(140, 214, 255, .16)); border-bottom: 1px dashed var(--ws-line, rgba(140, 214, 255, .16)); }
    #adminProfileModal .pf-order-items li { display: flex; align-items: baseline; gap: 10px; padding: 5px 0; color: var(--ws-text, #e6f6ff); font-size: 14px; }
    #adminProfileModal .pf-qty { flex: 0 0 auto; min-width: 30px; color: var(--ws-aqua-2, #6fe3ff); font-weight: 800; font-variant-numeric: tabular-nums; }
    #adminProfileModal .pf-item-name { flex: 1 1 auto; min-width: 0; }
    #adminProfileModal .pf-item-name small { margin-left: 8px; color: var(--ws-muted, #8fb4cf); font-size: 12px; }
    #adminProfileModal .pf-item-price { flex: 0 0 auto; color: var(--ws-muted, #8fb4cf); font-variant-numeric: tabular-nums; }
    #adminProfileModal .pf-order-foot { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
    #adminProfileModal .pf-order-meta { display: flex; gap: 16px; color: var(--ws-muted, #8fb4cf); font-size: 13px; flex-wrap: wrap; }
    #adminProfileModal .pf-order-meta span { display: inline-flex; align-items: center; gap: 6px; }
    #adminProfileModal .pf-order-total { color: #fff; font-size: 20px; font-weight: 800; font-variant-numeric: tabular-nums; }

    /* Empty state */
    #adminProfileModal .pf-empty-state { text-align: center; padding: 34px 10px 18px; }
    #adminProfileModal .pf-empty-icon {
        width: 64px; height: 64px; margin: 0 auto 14px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center; font-size: 28px;
        color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px dashed rgba(41, 197, 246, .45);
    }
    #adminProfileModal .pf-empty-title { margin: 0 0 4px; color: #fff; font-size: 17px; font-weight: 800; }
    #adminProfileModal .pf-empty-text { margin: 0 auto 16px; max-width: 320px; color: var(--ws-muted, #8fb4cf); font-size: 14px; }

    /* Buttons */
    #adminProfileModal .pf-btn {
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        padding: 11px 22px; border-radius: 14px; font-size: 14.5px; font-weight: 800; border: none; cursor: pointer;
        transition: transform .12s, filter .15s, background .15s;
    }
    #adminProfileModal .pf-btn:active { transform: scale(.97); }
    #adminProfileModal .pf-btn-primary { color: #032a1e; background: linear-gradient(135deg, #2ee6a6, #12b886); box-shadow: 0 10px 22px rgba(46, 230, 166, .25); }
    #adminProfileModal .pf-btn-primary:hover { filter: brightness(1.08); }
    #adminProfileModal .pf-btn-ghost { color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px solid rgba(41, 197, 246, .4); }
    #adminProfileModal .pf-btn-ghost:hover { background: rgba(41, 197, 246, .24); }

    /* Password */
    #adminProfileModal .pf-pass { display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr); gap: 28px; align-items: start; }
    #adminProfileModal .pf-input-group { margin-bottom: 16px; }
    #adminProfileModal .pf-label { display: block; margin-bottom: 6px; color: var(--ws-text, #e6f6ff); font-size: 13.5px; font-weight: 700; }
    #adminProfileModal .pf-input-wrap { position: relative; }
    #adminProfileModal .pf-input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--ws-muted, #8fb4cf); pointer-events: none; }
    #adminProfileModal .pf-input { height: 48px; padding: 0 46px 0 42px; border-radius: 14px; font-size: 15px; }
    #adminProfileModal .pf-input:focus { border-color: var(--ws-aqua, #29c5f6) !important; box-shadow: 0 0 0 .25rem rgba(41, 197, 246, .22) !important; }
    #adminProfileModal .pf-eye {
        position: absolute; right: 6px; top: 50%; transform: translateY(-50%);
        width: 36px; height: 36px; border: none; border-radius: 10px; background: transparent;
        color: var(--ws-muted, #8fb4cf); cursor: pointer;
    }
    #adminProfileModal .pf-eye:hover { color: #fff; background: rgba(41, 197, 246, .14); }

    #adminProfileModal .pf-checklist {
        padding: 18px; border-radius: 16px; background: rgba(4, 23, 41, .55); border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #adminProfileModal .pf-checklist-title { margin: 0 0 12px; color: #fff; font-size: 14px; font-weight: 800; }
    #adminProfileModal .pf-checklist ul { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
    #adminProfileModal .pf-checklist li { display: flex; align-items: center; gap: 10px; color: var(--ws-muted, #8fb4cf); font-size: 13.5px; transition: color .15s; }
    #adminProfileModal .pf-checklist li.ok { color: var(--ws-green, #2ee6a6); }

    /* Keyboard focus */
    #adminProfileModal .pf-close:focus-visible,
    #adminProfileModal .pf-eye:focus-visible,
    #adminProfileModal .pf-btn:focus-visible,
    #adminProfileModal .pf-tabs .nav-link:focus-visible { outline: 2px solid var(--ws-aqua-2, #6fe3ff); outline-offset: 2px; }

    /* Responsive */
    @media (max-width: 767.98px) {
        #adminProfileModal .pf-hero { padding: 28px 20px 76px; }
        #adminProfileModal .pf-avatar { width: 68px; height: 68px; font-size: 24px; }
        #adminProfileModal .pf-name { font-size: 21px; }
        #adminProfileModal .pf-stats { margin: -30px 16px 0; }
        #adminProfileModal .pf-stat-value { font-size: 17px; }
        #adminProfileModal .pf-body { padding: 18px 16px 24px; }
        #adminProfileModal .pf-fields { grid-template-columns: 1fr; }
        #adminProfileModal .pf-field:nth-last-child(2) { border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
        #adminProfileModal .pf-tabs .nav-link { font-size: 12.5px; padding: 9px 6px; gap: 5px; }
        #adminProfileModal .pf-tabs .nav-link i { display: none; }
        #adminProfileModal .pf-pass { grid-template-columns: 1fr; gap: 18px; }
        #adminProfileModal .pf-checklist { order: -1; }
    }
    /* Address editor */
    #adminProfileModal .pf-addr-editor { margin-top: 8px; padding-top: 18px; border-top: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
    #adminProfileModal .pf-addr-top { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 8px; }
    #adminProfileModal .pf-addr-top .form-control { flex: 1 1 200px; min-width: 0; }
    #adminProfileModal .pf-addr-results { max-height: 180px; overflow-y: auto; margin-bottom: 8px; border-radius: 12px; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
    #adminProfileModal .pf-addr-results button {
        display: block; width: 100%; text-align: left; padding: 9px 12px; font-size: 13.5px; border: 0;
        border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); background: rgba(6, 32, 58, .7); color: #fff;
    }
    #adminProfileModal .pf-addr-results button:hover { background: rgba(41, 197, 246, .2); }
    #adminProfileModal .pf-addr-status { font-size: 13px; color: var(--ws-muted, #8fb4cf); min-height: 20px; margin-bottom: 8px; }
    #adminProfileModal .pf-addr-status.is-error { color: #ff6b6b; }
    #pfMap { height: 280px; width: 100%; border-radius: 14px; overflow: hidden; isolation: isolate; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }

    @media (prefers-reduced-motion: reduce) {
        #adminProfileModal .pf-waves { animation: none; }
    }
</style>

<script>
    //After a password error popup, reopen the profile on the Password tab instead of Information
    function openProfilePassTab() {
        var el = document.getElementById('profTabPass');
        if (el && window.bootstrap) { bootstrap.Tab.getOrCreateInstance(el).show(); }
    }

    (function () {
        //Show / hide password buttons
        document.querySelectorAll('#adminProfileModal .pf-eye').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(btn.getAttribute('data-target'));
                var icon = btn.querySelector('i');
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
                btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            });
        });

        //Live password checklist (the server still does the real validation)
        var cur = document.getElementById('customerCurrentPassword');
        var nw  = document.getElementById('customerNewPassword');
        var cf  = document.getElementById('customerConfirmPassword');
        var rules = {
            len:   document.getElementById('pfRuleLen'),
            match: document.getElementById('pfRuleMatch'),
            diff:  document.getElementById('pfRuleDiff')
        };
        function mark(li, ok) {
            li.classList.toggle('ok', ok);
            li.querySelector('i').className = ok ? 'bi bi-check-circle-fill' : 'bi bi-circle';
        }
        function refresh() {
            mark(rules.len, nw.value.length >= 8);
            mark(rules.match, nw.value.length > 0 && nw.value === cf.value);
            mark(rules.diff, nw.value.length > 0 && cur.value.length > 0 && nw.value !== cur.value);
        }
        [cur, nw, cf].forEach(function (el) { el.addEventListener('input', refresh); });
    })();
</script>
<script>
    //Delivery address editor (Leaflet + OpenStreetMap Nominatim, same approach as the checkout page)
    (function () {
        var form = document.getElementById('pfAddressForm');
        if (!form || !window.L) { return; }

        var editBtn = document.getElementById('pfAddrEditBtn');
        var cancelBtn = document.getElementById('pfAddrCancel');
        var addrInput = document.getElementById('pfAddressInput');
        var searchInput = document.getElementById('pfMapSearch');
        var results = document.getElementById('pfMapResults');
        var statusEl = document.getElementById('pfMapStatus');
        var savedAddress = addrInput.value;
        var map = null, marker = null, searchTimer = null, searchCtl = null, cache = {};
        var defaultCoords = [14.3232, 120.9408];

        function status(msg, isError) {
            statusEl.textContent = msg;
            statusEl.classList.toggle('is-error', !!isError);
        }
        function setAddress(text) {
            addrInput.value = text.length > 255 ? text.slice(0, 255) : text;
        }
        function hideResults() { results.innerHTML = ''; results.classList.add('d-none'); }

        function reverseGeocode(lat, lng) {
            var fallback = lat.toFixed(6) + ', ' + lng.toFixed(6);
            setAddress(fallback);
            fetch('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=' + lat + '&lon=' + lng)
                .then(function (r) { return r.json(); })
                .then(function (d) { setAddress(d && d.display_name ? d.display_name : fallback); })
                .catch(function () { setAddress(fallback); });
        }

        function setLocation(lat, lng, label, zoom) {
            marker.setLatLng([lat, lng]);
            map.setView([lat, lng], zoom || Math.max(map.getZoom(), 17));
            if (label) { setAddress(label); } else { reverseGeocode(lat, lng); }
        }

        function initMap() {
            if (map) { return; }
            var icon = L.icon({ iconUrl: '../Images/leaflet/location.png', iconSize: [38, 38], iconAnchor: [19, 50], popupAnchor: [0, -38] });
            map = L.map('pfMap').setView(defaultCoords, 16);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);
            marker = L.marker(defaultCoords, { icon: icon, draggable: true }).addTo(map);

            map.on('click', function (e) { setLocation(e.latlng.lat, e.latlng.lng); });
            marker.on('dragend', function () { var p = marker.getLatLng(); setLocation(p.lat, p.lng); });

            //Start the pin where the saved address is (without changing the address text)
            var m = savedAddress.match(/^\s*(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)\s*$/);
            if (m) {
                marker.setLatLng([parseFloat(m[1]), parseFloat(m[2])]);
                map.setView([parseFloat(m[1]), parseFloat(m[2])], 17);
            } else if (savedAddress.trim().length >= 3) {
                fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=ph&q=' + encodeURIComponent(savedAddress))
                    .then(function (r) { return r.json(); })
                    .then(function (list) {
                        if (list && list.length) {
                            var la = parseFloat(list[0].lat), lo = parseFloat(list[0].lon);
                            marker.setLatLng([la, lo]);
                            map.setView([la, lo], 17);
                        }
                    }).catch(function () {});
            }
        }

        function showResults(list, q) {
            results.innerHTML = '';
            if (!list.length) {
                results.classList.add('d-none');
                status('No results for "' + q + '". Try a nearby landmark, barangay or street.', true);
                return;
            }
            status('Pick your address below.');
            list.forEach(function (item) {
                var b = document.createElement('button');
                b.type = 'button';
                b.textContent = item.display_name;
                b.addEventListener('click', function () {
                    setLocation(parseFloat(item.lat), parseFloat(item.lon), item.display_name, 18);
                    hideResults();
                    searchInput.value = item.display_name;
                    status('Location set. Drag the pin to fine-tune it.');
                });
                results.appendChild(b);
            });
            results.classList.remove('d-none');
        }

        function runSearch() {
            var q = searchInput.value.trim();
            if (q.length < 3) { hideResults(); status('Type at least 3 characters to search.', true); return; }
            if (cache[q]) { showResults(cache[q], q); return; }
            if (searchCtl) { searchCtl.abort(); }
            searchCtl = new AbortController();
            status('Searching...');
            fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=ph&viewbox=120.80,14.45,121.10,14.20&q=' + encodeURIComponent(q), { signal: searchCtl.signal })
                .then(function (r) { return r.json(); })
                .then(function (list) {
                    cache[q] = list;
                    if (searchInput.value.trim() === q) { showResults(list, q); }
                })
                .catch(function (err) { if (err.name !== 'AbortError') { status('Search failed. Check your internet connection.', true); } });
        }

        searchInput.addEventListener('input', function () {
            clearTimeout(searchTimer);
            if (searchInput.value.trim().length < 3) { hideResults(); status('Keep typing... (at least 3 characters)'); return; }
            searchTimer = setTimeout(runSearch, 500);
        });
        searchInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); clearTimeout(searchTimer); runSearch(); }
        });
        document.getElementById('pfMapSearchBtn').addEventListener('click', function () { clearTimeout(searchTimer); runSearch(); });

        document.getElementById('pfUseMyLocation').addEventListener('click', function () {
            var btn = this;
            if (!navigator.geolocation) { status('Your browser does not support location.', true); return; }
            btn.disabled = true;
            status('Getting your location... please allow location access.');
            navigator.geolocation.getCurrentPosition(function (pos) {
                btn.disabled = false;
                hideResults();
                setLocation(pos.coords.latitude, pos.coords.longitude, null, 18);
                status("Using your current location. Drag the pin if it's slightly off.");
            }, function (err) {
                btn.disabled = false;
                status(err && err.code === 1 ? 'Location access was blocked. Allow it in your browser, or search for your address instead.' : 'Could not get your location. Search for your address instead.', true);
            }, { enableHighAccuracy: true, timeout: 15000 });
        });

        //Open / close the editor
        editBtn.addEventListener('click', function () {
            form.classList.remove('d-none');
            editBtn.classList.add('d-none');
            initMap();
            setTimeout(function () { map.invalidateSize(); }, 80); //map was hidden, recalculate its size
            form.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
        cancelBtn.addEventListener('click', function () {
            form.classList.add('d-none');
            editBtn.classList.remove('d-none');
            addrInput.value = savedAddress;
            searchInput.value = '';
            hideResults();
        });

        form.addEventListener('submit', function (e) {
            if (addrInput.value.trim() === '') { e.preventDefault(); status('Please choose or type your address first.', true); }
        });
    })();
</script>
