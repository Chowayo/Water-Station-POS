
<?php
require(__DIR__ . '/../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../login.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory"){
    header('location: /Inventory/stocks.php');
    exit;
}


//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier"){
    header('location: /Supplier/orders.php');
    exit;
}


$user = $_SESSION['users'];

// Every Customer page needs a branch to scope products/orders to.
// Default to the fallback branch until geolocation (below) narrows it down,
// and don't re-run the browser prompt once a branch has been detected.
if (!isset($_SESSION['customer_branch_id'])) {
    $_SESSION['customer_branch_id'] = default_branch_id($conn);
}
$branch_id = (int) $_SESSION['customer_branch_id'];
$branch_detected = isset($_SESSION['customer_branch_detected']) && $_SESSION['customer_branch_detected'];

?>


<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<script>
    // Auto-detect the customer's branch once per session by nearest distance.
    // Runs silently; if the browser denies/lacks geolocation, the page just
    // keeps using the fallback branch set in header.php. The customer can
    // still pick a different delivery location manually at checkout, which
    // overrides this branch for that order.
    <?php if (!$branch_detected): ?>
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(pos) {
            fetch('geo_branch.php?lat=' + pos.coords.latitude + '&lng=' + pos.coords.longitude)
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data && data.changed) {
                        window.location.reload();
                    }
                })
                .catch(function() { /* keep using the fallback branch */ });
        }, function() { /* permission denied or unavailable: keep fallback branch */ });
    }
    <?php endif; ?>
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>

    <!-- Leaflet Libraries -->
    <link rel="stylesheet" href="../css/leaflet.css" />
    <script src="../js/leaflet.js"></script>

    <!-- Geocoder Libraries -->
    <link rel="stylesheet" href="../css/Control.Geocoder.css" />
    <script src="../js/Control.Geocoder.js"></script>

    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

