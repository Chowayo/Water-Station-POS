<?php
require(__DIR__ . '/../dbConn.php');
header('Content-Type: application/json');

// Called from header.php's geolocation script to set the customer's branch
// by nearest distance. Only ever moves a logged-in customer's own session.
if (!isset($_SESSION['users']) || $_SESSION['users']->role !== 'Customer') {
    http_response_code(403);
    echo json_encode(['error' => 'Not logged in as a customer']);
    exit;
}

$lat = isset($_GET['lat']) ? (float) $_GET['lat'] : null;
$lng = isset($_GET['lng']) ? (float) $_GET['lng'] : null;

if ($lat === null || $lng === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing lat/lng']);
    exit;
}

$nearest = nearest_branch_id($conn, $lat, $lng);
$previous = isset($_SESSION['customer_branch_id']) ? (int) $_SESSION['customer_branch_id'] : null;

if ($nearest !== null) {
    $_SESSION['customer_branch_id'] = $nearest;
}
$_SESSION['customer_branch_detected'] = true;

echo json_encode([
    'branch_id' => $_SESSION['customer_branch_id'],
    'changed' => $nearest !== null && $nearest !== $previous,
]);
