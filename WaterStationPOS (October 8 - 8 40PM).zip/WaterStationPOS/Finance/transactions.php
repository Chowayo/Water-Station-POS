<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
    
<head>
    <title>Transactions</title>


    <style>
        /* Ledger table: show all 10 rows of a page without an inner scrollbar */
        .table-scroll-wrap {
            overflow-x: auto;
            border-radius: 12px;
        }

        #txn_list thead th {
            background-color: rgba(6, 32, 58, 0.55);
            white-space: nowrap;
        }

        #txn_list td.txn-desc {
            max-width: 240px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        #txn_list td.txn-datetime {
            white-space: nowrap;
        }

        #txn_list td.txn-amount {
            font-weight: 800;
            font-variant-numeric: tabular-nums;
            white-space: nowrap;
        }

        .txn-amount-in { color: #2ee6a6; }
        .txn-amount-out { color: #ff6b7a; }

        .pay-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            background: rgba(143, 180, 207, 0.14);
            color: #b8d6ea;
            border: 1px solid rgba(143, 180, 207, 0.35);
        }

        .pay-badge.pay-cash { background: rgba(46, 230, 166, 0.14); color: #2ee6a6; border-color: rgba(46, 230, 166, 0.4); }
        .pay-badge.pay-gcash { background: rgba(41, 197, 246, 0.14); color: #6fe3ff; border-color: rgba(41, 197, 246, 0.4); }
        .pay-badge.pay-bank { background: rgba(255, 200, 87, 0.14); color: #ffc857; border-color: rgba(255, 200, 87, 0.4); }

        /* DataTables footer (info + pagination) */
        .dataTables_wrapper { color: #e6f6ff; }

        .dataTables_wrapper .dataTables_info {
            color: #8fb4cf;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #e6f6ff !important;
            border: 1px solid rgba(140, 214, 255, 0.2) !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4f7699 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(41, 197, 246, 0.16) !important;
            border-color: #29c5f6 !important;
            color: #fff !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current,
        .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: linear-gradient(135deg, #29c5f6, #1e88e5) !important;
            border-color: transparent !important;
            color: #04213b !important;
            font-weight: 800;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }

        table.dataTable tbody td.dataTables_empty {
            padding: 36px 10px;
            color: #8fb4cf;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Transactions</h1>
                    <h6>Full record of income and expenses</h6>
                </div>
            </header>

            <?php
            // Month totals: everything is based on the transaction "type" so the cards always agree with the ledger
            // Scoped to this Financer's own branch
            $branch_id = $result->branch_id;
            $month_where = "date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND branch_id = ?";

            $stmt = $conn->prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE $month_where AND type = 'Income'");
            $stmt->bind_param("i", $branch_id);
            $stmt->execute();
            $income_total = (float) $stmt->get_result()->fetch_object()->total;

            $stmt = $conn->prepare("SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE $month_where AND type = 'Expense'");
            $stmt->bind_param("i", $branch_id);
            $stmt->execute();
            $expenses_total = (float) $stmt->get_result()->fetch_object()->total;

            $net_total = $income_total - $expenses_total;
            ?>

            <!-- Summary Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Total_Income.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Income (This Month)</div>
                        <div class="dash-value green-text">₱<?php echo number_format($income_total, 2); ?></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Total_expenses.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Total Expenses (This Month)</div>
                        <div class="dash-value" style="color: #ff6b7a;">₱<?php echo number_format($expenses_total, 2); ?></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Transactions/Net_Cash.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Net Cash Flow (This Month)</div>
                        <div class="dash-value <?php echo $net_total < 0 ? '' : 'cyan-text'; ?>" <?php echo $net_total < 0 ? 'style="color: #ff6b7a;"' : ''; ?>>
                            <?php echo ($net_total < 0 ? '-' : '') . '₱' . number_format(abs($net_total), 2); ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Transaction Ledger -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-journal-text me-2"></i>Transaction Ledger</div>
                    <div class="manage-box shadow-sm">

                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <ul class="txn-filter-tabs" id="txnFilterTabs">
                                <li><button type="button" class="nav-link active" data-filter="all"><i class="bi bi-list-ul me-1"></i>All</button></li>
                                <li><button type="button" class="nav-link" data-filter="Income"><i class="bi bi-arrow-down-circle me-1"></i>Income</button></li>
                                <li><button type="button" class="nav-link" data-filter="Expense"><i class="bi bi-arrow-up-circle me-1"></i>Expense</button></li>
                            </ul>

                            <div class="d-flex flex-wrap gap-2">
                                <select id="category" class="form-select form-select-sm" style="width: auto;">
                                    <option value="all">All Categories</option>
                                    <?php
                                    $cat_stmt = $conn->prepare("SELECT DISTINCT category FROM transactions WHERE category <> '' AND branch_id = ? ORDER BY category ASC");
                                    $cat_stmt->bind_param("i", $branch_id);
                                    $cat_stmt->execute();
                                    $cat_query = $cat_stmt->get_result();
                                    while ($cat = $cat_query->fetch_object()) {
                                        echo '<option value="' . htmlspecialchars($cat->category) . '">' . htmlspecialchars($cat->category) . '</option>';
                                    }
                                    ?>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search transaction" id="searcher">
                                </div>
                            </div>
                        </div>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="txn_list">
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Type</th>
                                    <th>Payment Method</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Newest first: date, then time, then id (this branch only)
                                $sql = "SELECT * FROM transactions WHERE branch_id = ? ORDER BY date DESC, time DESC, id DESC";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("i", $branch_id);
                                $stmt->execute();
                                $query = $stmt->get_result();
                                while ($set = $query->fetch_object()) {

                                    $is_income = ($set->type == "Income");
                                    $type_key = $is_income ? "Income" : "Expense";
                                    $desc = htmlspecialchars($set->description);
                                    $cat = htmlspecialchars($set->category);
                                    $date_txt = $set->date ? date('M d, Y', strtotime($set->date)) : '—';
                                    $time_txt = $set->time ? date('h:i A', strtotime($set->time)) : '—';

                                    // Payment method badge (always renders a cell so columns never shift)
                                    $method = trim((string) $set->payment_method);
                                    if ($method === "Gcash") {
                                        $pay_html = '<span class="pay-badge pay-gcash"><i class="bi bi-phone"></i>GCash</span>';
                                    } else if ($method === "Cash") {
                                        $pay_html = '<span class="pay-badge pay-cash"><i class="bi bi-cash-coin"></i>Cash</span>';
                                    } else if ($method === "Bank Transfer") {
                                        $pay_html = '<span class="pay-badge pay-bank"><i class="bi bi-bank"></i>Bank Transfer</span>';
                                    } else {
                                        $pay_html = '<span class="pay-badge">' . ($method !== '' ? htmlspecialchars($method) : '—') . '</span>';
                                    }

                                    echo '<tr data-type="' . $type_key . '">';
                                    echo '<td class="cyan-text fw-bold">#' . (int) $set->id . '</td>';
                                    echo '<td class="txn-datetime">' . $date_txt . '</td>';
                                    echo '<td class="txn-datetime">' . $time_txt . '</td>';
                                    echo '<td class="txn-desc" title="' . $desc . '">' . $desc . '</td>';
                                    echo '<td data-category="' . $cat . '">' . $cat . '</td>';

                                    if ($is_income) {
                                        echo '<td><span class="txn-type-badge txn-type-income" data-filter="Income">Income</span></td>';
                                    } else {
                                        echo '<td><span class="txn-type-badge txn-type-expense" data-filter="Expense">Expense</span></td>';
                                    }

                                    echo '<td>' . $pay_html . '</td>';

                                    if ($is_income) {
                                        echo '<td class="txn-amount txn-amount-in">+₱' . number_format($set->amount, 2) . '</td>';
                                    } else {
                                        echo '<td class="txn-amount txn-amount-out">-₱' . number_format($set->amount, 2) . '</td>';
                                    }

                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            var table = $('#txn_list').DataTable({
                paging: true,
                pageLength: 10,
                lengthChange: false,
                searching: true,
                ordering: false,
                pagingType: 'simple_numbers',
                dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>',
                language: {
                    emptyTable: 'No transactions recorded yet.',
                    zeroRecords: 'No transactions match your filters.',
                    info: 'Showing _START_ to _END_ of _TOTAL_ transactions',
                    infoEmpty: 'Showing 0 transactions',
                    infoFiltered: '(filtered from _MAX_ total)'
                },
                // hide the page buttons when everything fits on one page
                drawCallback: function() {
                    var pages = this.api().page.info().pages;
                    $(this.api().table().container()).find('.dataTables_paginate').toggle(pages > 1);
                }
            });

            $('#searcher').on('input keyup change clear', function() {
                table.search(this.value).draw();
            });

            var activeTypeFilter = 'all';
            var activeCategoryFilter = 'all';

            $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
                if (settings.nTable.id !== 'txn_list') return true;

                var row = table.row(dataIndex).node();

                if (activeTypeFilter !== 'all' && $(row).data('type') !== activeTypeFilter) {
                    return false;
                }

                if (activeCategoryFilter !== 'all') {
                    var matchCat = $(row).find('td[data-category]').filter(function() {
                        return $(this).data('category') === activeCategoryFilter;
                    }).length > 0;

                    if (!matchCat) return false;
                }

                return true;
            });

            $('#txnFilterTabs .nav-link').on('click', function() {
                $('#txnFilterTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                activeTypeFilter = $(this).data('filter');
                table.draw();
            });

            //Selection searcher
            $('#category').on('change', function() {
                activeCategoryFilter = $(this).val();
                table.draw();
            });

        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#0b3054',
                    color: '#e6f6ff',
                    title: "Log out of Finance Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>