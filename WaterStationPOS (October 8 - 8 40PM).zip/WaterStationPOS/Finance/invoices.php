<?php

include "header.php";

?>

<?php

    ob_start();

    $sql = "SELECT * FROM employees WHERE id = " . $user->id;
    $query = $conn->query($sql);
    $result = $query->fetch_object();

    // Scoped to this Financer's own branch
    $branch_id = (int) $result->branch_id;

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    #invoice_match_list thead th,
    #invoice_match_list.dataTable thead th {
        text-align: center !important;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-hold {
        background-color: rgba(255, 145, 0, 0.1);
        color: #ff9100;
        border: 1px solid #ff9100;
    }

    .status-paid {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
    }

    .status-closed {
        background-color: rgba(136, 146, 176, 0.12);
        color: #8892B0;
        border: 1px solid #8892B0;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* 3-way match comparison */
    .match-column-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
        height: 100%;
    }

    .match-column-label {
        font-size: 11px;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .match-column-card .req-detail-item {
        padding: 6px 0;
        font-size: 0.9rem;
    }

    /* Invoice receipt */
    .receipt-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 20px 22px;
    }

    .receipt-company {
        font-size: 1.15rem;
        font-weight: 700;
        color: #CCD6F6;
    }

    .receipt-company-sub {
        font-size: 0.8rem;
        color: #8892B0;
    }

    .receipt-doc-title {
        font-size: 0.85rem;
        letter-spacing: 0.08em;
        color: #64FFDA;
        font-weight: 700;
    }

    .receipt-divider {
        border-color: #233554;
        opacity: 1;
        margin: 14px 0;
    }

    .receipt-meta-label {
        font-size: 11px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 2px;
    }

    .receipt-meta-value {
        font-size: 0.9rem;
        color: #CCD6F6;
        font-weight: 500;
    }

    .receipt-items table {
        background-color: transparent;
    }

    .receipt-items thead th {
        color: #8892B0;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        border-bottom: 1px solid #233554;
    }

    .receipt-items td {
        border-color: #233554;
        color: #CCD6F6;
    }

    .receipt-totals {
        max-width: 280px;
    }

    .receipt-grand-total {
        border-top: 1px solid #233554;
        margin-top: 4px;
        padding-top: 10px;
        font-size: 1.05rem;
        color: #64FFDA;
    }

    .receipt-footnote {
        font-size: 0.78rem;
        color: #8892B0;
        text-align: center;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Invoice &amp; 3-Way Match</h1>
                    <h6>Match supplier invoices against the Purchase Order and Goods Receipt before releasing payment</h6>
                </div>
            </header>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Match</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Invoice Sent' AND branch_id = " . $branch_id;
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Matched This Month</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php

                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND (status = 'Approved' OR status = 'Finance Approves Invoice') AND branch_id = " . $branch_id;
                            $query = $conn->query($sql);
                            $approved_month = $query->fetch_object();

                            if ($approved_month != "") {
                                echo $approved_month->total;
                            } else {
                                echo "0";
                            }
                            ?>

                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Mismatched</div>
                        <div class="dash-value" style="color:#ff9100;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Finance Return to Supplier' AND branch_id = " . $branch_id;
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Invoice Value</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT SUM(invoice_amount) AS total FROM stock_request WHERE deleted ='False' AND status = 'Supplier Invoice Sent' AND branch_id = " . $branch_id;
                            $query = $conn->query($sql);
                            if ($query && $row = $query->fetch_object()) {
                                if (empty($row->total)) {
                                    $pending_value = 0;
                                } else {
                                    $pending_value = $row->total;
                                }
                            } else {
                                $pending_value = 0;
                            }

                            echo '₱' . $pending_value;
                            ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Supplier Invoices</div>
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Awaiting 3-Way Match</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="invoiceStatusFilter" style="width: 190px;">
                                    <option value="">All Status</option>
                                    <option value="Pending Match">Pending Match</option>
                                    <option value="Matched">Matched</option>
                                    <option value="Paid">Paid</option>
                                    <option value="Closed">Closed</option>
                                    <option value="Returned to Supplier">Returned to Supplier</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Invoice" id="invoiceSearcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var invoiceTable = $('#invoice_match_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#invoiceSearcher').on('keyup change clear', function() {
                                    invoiceTable.search(this.value).draw();
                                });

                                $('#invoiceStatusFilter').on('change', function() {
                                    invoiceTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="invoice_match_list">
                            <thead>
                                <tr>
                                    <th>Invoice No.</th>
                                    <th>PO Number</th>
                                    <th>Request ID</th>
                                    <th>Supplier</th>
                                    <th>Category</th>
                                    <th>Invoice Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->
                                <?php
                                $sql = "SELECT * FROM stock_request WHERE deleted = 'False' AND branch_id = " . $branch_id . " AND (status = 'Supplier Invoice Sent' OR status = 'Finance Approves Invoice' OR status = 'Finance Invoice Done' OR status = 'Supplier Payment Received' OR status = 'Finance Return to Supplier') ORDER BY id DESC";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                            <tr>
                                                <td>INV-' . $set->invoice_number . '</td>
                                                <td>PO-' . $set->order_number . '</td>
                                                <td>REQ-' . $set->id . '</td>
                                                <td>' . $set->supplier_name . '</td>
                                                <td><span class="category-chip">' . ucfirst($set->category) . '</span></td>
                                                <td>₱' . $set->invoice_amount . '</td>';



                                    if ($set->status == "Supplier Invoice Sent") {
                                        echo '
                                                <td><span class="status-badge status-pending">Finance Review Pending</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-match"
                                                        data-invoice="INV-' . $set->invoice_number . '"
                                                        data-po="PO-' . $set->order_number . '"
                                                        data-req="REQ-' . $set->id . '"
                                                        data-supplier="' . $set->supplier_name . '"
                                                        data-number="' . $set->id . '"
                                                        data-category="' . ucfirst($set->category) . '"';
                                        echo <<<HTML
                                                            data-po-items='[{"name":"$set->supplier_product_name","qty":"","price":$set->final_cost}]'
                                                            data-grn-items='[{"name":"$set->supplier_product_name","qty":"","price":$set->final_cost}]'
                                                            data-inv-items='[{"name":"$set->supplier_product_name","qty":"","price":$set->final_cost}]'><i class="bi bi-search me-1"></i>Review Match</button></td></tr>
                                                HTML;
                                    } else if ($set->status == "Finance Approves Invoice") {
                                        $inv_category = ucfirst($set->category);
                                        echo '
                                                <td><span class="status-badge status-approved">Finance Approved Invoice</span></td>
                                                    <td>';
                                        echo <<<HTML
                                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-process-payment"
                                                            data-invoice="INV-$set->invoice_number"
                                                            data-po="PO-$set->order_number"
                                                            data-req="REQ-$set->id"
                                                            data-supplier="$set->supplier_name"
                                                            data-category="$inv_category"
                                                            data-date="$set->date_requested"
                                                            data-amount="₱$set->invoice_amount"
                                                            data-amounts="$set->invoice_amount"
                                                            data-number="$set->id"
                                                            data-items='[{"name":"$set->supplier_product_name","qty":"","price":$set->final_cost}]'>
                                                            <i class="bi bi-cash-coin me-1"></i>Process Payment
                                                        </button>
                                            HTML;
                                        echo '
                                                    </td>
                                                </tr>
                                            ';
                                    } else if ($set->status == "Finance Invoice Done") {
                                        echo '
                                                    <td><span class="status-badge status-paid">Invoice Paid</span></td>
                                                    <td>
                                                        <form method="POST">
                                                            <input type="text" name="id" value="' . $set->id . '" hidden>
                                                            <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-close-done" type="submit" name="payment_done" value="Supplier Payment Received">
                                                                <i class="bi bi-check-lg me-1"></i>Done
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            ';
                                    } else if ($set->status == "Supplier Payment Received") {
                                        echo '
                                                    <td><span class="status-badge status-closed">Closed</span></td>
                                                    <td>
                                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                            <i class="bi bi-check-circle me-1"></i>Closed
                                                        </button>
                                                    </td>
                                                </tr>
                                            ';
                                    } else if ($set->status == "Finance Return to Supplier") {
                                        echo '
                                                    <td><span class="status-badge status-rejected">Returned to Supplier</span></td>
                                                    <td>
                                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                            <i class="bi bi-x-circle me-1"></i>Returned
                                                        </button>
                                                    </td>
                                                </tr>
                                            ';
                                    }
                                }


                                ?>

                                <!--
                                <tr>
                                    <td>INV-1007</td>
                                    <td>PO-1007</td>
                                    <td>REQ-0007</td>
                                    <td>HydroChem Philippines</td>
                                    <td><span class="category-chip">Chemicals</span></td>
                                    <td>₱2,900.00</td>
                                    <td><span class="status-badge status-pending">Pending Match</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-match"
                                            data-invoice="INV-1007"
                                            data-po="PO-1007"
                                            data-req="REQ-0007"
                                            data-supplier="HydroChem Philippines"
                                            data-category="Chemicals"
                                            data-po-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'
                                            data-grn-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'
                                            data-inv-items='[{"name":"Chlorine Solution","qty":10,"price":290.00}]'>
                                            <i class="bi bi-search me-1"></i>Review Match
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>INV-1002</td>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td>BlueCap Packaging Solutions</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-approved">Matched</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-process-payment"
                                            data-invoice="INV-1002"
                                            data-supplier="BlueCap Packaging Solutions"
                                            data-amount="₱1,200.00">
                                            <i class="bi bi-cash-coin me-1"></i>Process Payment
                                        </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>INV-0995</td>
                                    <td>PO-0995</td>
                                    <td>REQ-0004</td>
                                    <td>AquaTech Solutions</td>
                                    <td><span class="category-chip">Equipment</span></td>
                                    <td>₱8,400.00</td>
                                    <td><span class="status-badge status-paid">Paid</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-close-done">
                                            <i class="bi bi-check-lg me-1"></i>Done
                                        </button>
                                    </td>
                                </tr>

                                <tr>
                                    <td>INV-0989</td>
                                    <td>PO-0989</td>
                                    <td>REQ-0009</td>
                                    <td>HydroChem Philippines</td>
                                    <td><span class="category-chip">Filters</span></td>
                                    <td>₱15,750.00</td>
                                    <td><span class="status-badge status-rejected">Returned to Supplier</span></td>
                                    <td>
                                        <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-x-circle me-1"></i>Returned
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>INV-0975</td>
                                    <td>PO-0975</td>
                                    <td>REQ-0005</td>
                                    <td>BlueCap Packaging Solutions</td>
                                    <td><span class="category-chip">Caps &amp; Seals</span></td>
                                    <td>₱3,480.00</td>
                                    <td><span class="status-badge status-closed">Closed</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                            <i class="bi bi-check-circle me-1"></i>Closed
                                        </button>
                                    </td>
                                </tr>-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- 3-Way Match Review Modal -->
            <div class="modal fade" id="reviewMatchModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">3-Way Match — <span id="matchInvoiceNo">INV-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <div>
                                    <span class="fw-semibold d-block" id="matchSupplier">Supplier</span>
                                    <span class="category-chip" id="matchCategory">Category</span>
                                </div>
                                <div class="text-end">
                                    <div class="small" style="color:#8892B0;">PO Reference</div>
                                    <span id="matchPoNumber">—</span>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Related Request</span>
                                <span id="matchReqId">—</span>
                            </div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-file-earmark-text"></i>Purchase Order</div>
                                        <div id="matchPoItems"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-box-seam"></i>Goods Receipt</div>
                                        <div id="matchGrnItems"></div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="match-column-card">
                                        <div class="match-column-label"><i class="bi bi-receipt"></i>Supplier Invoice</div>
                                        <div id="matchInvItems"></div>
                                    </div>
                                </div>
                            </div>


                            <div class="modal-footer flex-wrap">
                                <form method="POST">
                                    <input type="text" class="idNumber" name="id" hidden>
                                    <button type="submit" name="review_match" value="Finance Return to Supplier" class="btn btn-remove rounded-pill px-4" id="btnMatchReturn">
                                        <i class="bi bi-x-lg me-1"></i>Return to Supplier
                                    </button>
                                    <button type="submit" name="review_match" value="Finance Approves Invoice" class="btn btn-confirm rounded-pill px-4" id="btnMatchApprove">
                                        <i class="bi bi-check-lg me-1"></i>Approve for Payment
                                    </button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Process Payment / Invoice Receipt Modal -->
            <div class="modal fade" id="processPaymentModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg receipt-modal">

                        <div class="modal-header">
                            <h5 class="modal-title"><i class="bi bi-receipt me-2"></i>Invoice Receipt</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="receipt-box" id="receiptPrintArea">

                                <!-- Letterhead -->
                                <div class="d-flex justify-content-between align-items-start receipt-letterhead">
                                    <div>
                                        <div class="receipt-company">Eco Hydrate Hub</div>
                                        <div class="receipt-company-sub">Water Refilling Station &amp; Supply Management</div>
                                    </div>
                                    <div class="text-end">
                                        <div class="receipt-doc-title">INVOICE RECEIPT</div>
                                        <div class="small" style="color:#8892B0;">No. <span id="paymentInvoiceNo" class="fw-semibold" style="color:#CCD6F6;">INV-0000</span></div>
                                    </div>
                                </div>

                                <hr class="receipt-divider">

                                <!-- Meta grid -->
                                <div class="row g-3 receipt-meta">
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">Billed To</div>
                                        <div class="receipt-meta-value" id="paymentSupplier">—</div>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">Category</div>
                                        <div class="receipt-meta-value" id="paymentCategory">—</div>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">PO Reference</div>
                                        <div class="receipt-meta-value" id="paymentPoNumber">—</div>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">Request ID</div>
                                        <div class="receipt-meta-value" id="paymentReqId">—</div>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">Invoice Date</div>
                                        <div class="receipt-meta-value" id="paymentDate">—</div>
                                    </div>
                                    
                                    <div class="col-6 col-md-3">
                                        <div class="receipt-meta-label">Status</div>
                                        <div class="receipt-meta-value"><span class="status-badge status-approved">Approved for Payment</span></div>
                                    </div>
                                </div>

                                <!-- Line items -->
                                <div class="receipt-items mt-3">
                                    <table class="table table-dark table-sm mb-0">
                                        <thead>
                                            <tr>
                                                <th>Description</th>
                                                <th class="text-end">Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody id="paymentItemsBody">
                                            <!-- populated by JS -->
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Totals -->
                                <div class="receipt-totals mt-3 ms-auto">
                                    <div class="req-detail-item">
                                        <span>Subtotal</span>
                                        <span id="paymentSubtotal">—</span>
                                    </div>
                                    <div class="req-detail-item receipt-grand-total">
                                        <span>Total Due</span>
                                        <span class="fw-semibold" id="paymentAmount">—</span>
                                    </div>
                                </div>

                                <div class="receipt-footnote mt-3">
                                    This receipt confirms the invoice has passed 3-way match and is approved for payment release.
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <form method="POST">
                                <input type="value" name="total_cost" id="paymentAmountValue" hidden>
                                <input type="text" class="idNumber" name="id" hidden>
                                <button type="submit" name="confirm_payment" value="Finance Invoice Closed" class="btn btn-confirm rounded-pill px-4" id="btnConfirmPayment">
                                    <i class="bi bi-check-lg me-1"></i>Confirm Payment
                                </button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

            <?php

            //Notification Function
            function notif_insert($conn, $role, $category, $message){
                // Notify staff of this Financer's branch only (Supplier accounts are shared, so not branch-limited)
                global $branch_id;
                if($role=="Admin"){
                    $sql = "SELECT * FROM admin WHERE deleted = 'False'";
                    $query = $conn->query($sql);
                }
                else{
                    $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False'" . ($role === "Supplier" ? "" : " AND branch_id = " . (int) $branch_id);
                    $query = $conn->query($sql);
                }

                while ($emp_info = $query->fetch_object()) {
                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("isss", $emp_info->id, $emp_info->role, $category, $message);
                    if ($stmt->execute()) {}
                }
            }

            //PayMongo (shared helper - same one used by cashier and customer pages)
            require_once __DIR__ . '/../paymongo.php';
            require_once __DIR__ . '/../mailer/includes/payment_emails.php';

            //Coming back from PayMongo: only email finance if PayMongo says the supplier payment was really paid
            if (isset($_GET['pm_token'])) {
                $pm_token = $_GET['pm_token'];
                $pending = $_SESSION['pm_pending'][$pm_token] ?? null;
                $pm_msg = null;

                if (!$pending || !isset($pending['stock_request_id'])) {
                    $pm_msg = ['info', 'Payment link expired', 'This payment was already processed or has expired.'];
                } elseif (isset($_GET['pm_cancel'])) {
                    unset($_SESSION['pm_pending'][$pm_token]);
                    $pm_msg = ['warning', 'Payment cancelled', 'No payment was made to the supplier.'];
                } elseif (paymongoIsPaid($pending['session_id'])) {
                    unset($_SESSION['pm_pending'][$pm_token]); //one-time use so a refresh can't send the emails twice

                    //Payment confirmed -> NOW mark the invoice as paid. The status is set here on the server and only
                    //moves an approved invoice of this branch, so a second payment can never close it twice.
                    $paid_request_id = (int) $pending['stock_request_id'];
                    $paid_status = "Finance Invoice Closed";
                    $stmt = $conn->prepare("UPDATE `stock_request` SET `status` = ? WHERE id = ? AND branch_id = ? AND status = 'Finance Approves Invoice'");
                    $stmt->bind_param("sii", $paid_status, $paid_request_id, $branch_id);
                    $stmt->execute();
                    $paid_marked = ($stmt->affected_rows > 0);

                    $sr = null;
                    $sr_query = $conn->query("SELECT * FROM stock_request WHERE id = " . (int) $pending['stock_request_id'] . " AND branch_id = " . $branch_id);
                    if ($sr_query) {
                        $sr = $sr_query->fetch_object();
                    }

                    pe_supplier_invoice_paid($conn, [
                        'branch_id'      => (int) $branch_id,
                        'payer_name'     => trim($result->first_name . ' ' . $result->last_name),
                        'payer_email'    => $result->email,
                        'request_id'     => (int) $pending['stock_request_id'],
                        'invoice_number' => $sr->invoice_number ?? '',
                        'order_number'   => $sr->order_number ?? '',
                        'supplier'       => $sr->supplier_name ?? '',
                        'category'       => $sr->category ?? '',
                        'amount'         => $pending['amount'],
                        'ref'            => $pending['session_id'],
                    ]);
                    if ($paid_marked) {
                        notif_insert($conn, "Supplier", "Finance Payment Received", "Financer " . $result->last_name . " has sent the payment for the supplies of stock request #" . $paid_request_id);
                        $pm_msg = ['success', 'Payment successful', 'The supplier payment was confirmed and finance has been emailed.'];
                    } else {
                        $pm_msg = ['info', 'Already processed', 'This invoice was already marked as paid, so nothing was changed.'];
                    }
                } else {
                    $pm_msg = ['error', 'Payment not confirmed', 'PayMongo has not confirmed this payment yet. Refresh this page in a moment.'];
                }

                if ($pm_msg) {
                    $pm_msg_js = json_encode($pm_msg);
                    echo "<script>$(document).ready(function(){ var m = {$pm_msg_js}; Swal.fire({icon:m[0], title:m[1], text:m[2], background:'#112240', color:'#CCD6F6', confirmButtonColor:'#00E676', heightAuto:false}); });</script>";
                }
            }

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                if (isset($_POST['review_match'])) {
                    $id = (int) trim($_POST['id']);
                    //Only the two real review outcomes are accepted, and only for an invoice still waiting for review
                    $review_status = ($_POST['review_match'] === 'Finance Approves Invoice') ? 'Finance Approves Invoice' : 'Finance Return to Supplier';
                    $sql = "UPDATE `stock_request` SET `status` = ? WHERE id = ? AND branch_id = ? AND status = 'Supplier Invoice Sent'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sii",  $review_status, $id, $branch_id);
                    if ($stmt->execute() && $stmt->affected_rows > 0) {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Invoice Updated!',
                                            text: '',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('invoices.php');
                                            }});
                                    })
                                </script> 
                            HTML;
                    }
                }

                if (isset($_POST['confirm_payment'])) {
                    $id = (int) trim($_POST['id']);
                    $description = "Supplier Invoice for Stock Request #".$id;

                    //The amount to charge always comes from the invoice on record, never from the browser.
                    //The invoice must also be approved and belong to this branch.
                    $stmt = $conn->prepare("SELECT invoice_amount FROM stock_request WHERE id = ? AND branch_id = ? AND deleted = 'False' AND status = 'Finance Approves Invoice'");
                    $stmt->bind_param("ii", $id, $branch_id);
                    $stmt->execute();
                    $pay_row = $stmt->get_result()->fetch_object();
                    $total_cost = $pay_row ? (float) $pay_row->invoice_amount : 0;

                    //The invoice is NOT marked as paid here. That happens only after PayMongo confirms the payment (see the return handler above).
                    if ($total_cost > 0) {

                        //Paymongo Loader
                        $pm_token = bin2hex(random_bytes(8));
                        $pm_back  = paymongoPageUrl() . '?pm_token=' . $pm_token;
                        $pm = paymongoCreateCheckout($total_cost, $description, $pm_back, $pm_back . '&pm_cancel=1');
                        if (!$pm['ok']) {
                            echo '<pre>' . htmlspecialchars($pm['error']) . '</pre>';
                            exit;
                        }
                        //Remember this checkout so we can confirm it (and send the emails) when PayMongo sends the user back
                        $_SESSION['pm_pending'][$pm_token] = ['session_id' => $pm['id'], 'stock_request_id' => $id, 'amount' => (float) $total_cost];
                        $checkoutUrl = $pm['url'];
                        if ($checkoutUrl) {
                            header("Location: " . $checkoutUrl);
                            exit;
                        }

                        //Only reached if PayMongo gave no checkout page to open
                        echo <<<HTML
                            <script>
                                $(document).ready(function() {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Could not open the payment page',
                                        text: 'No payment was made. Please try again.',
                                        background: '#112240',
                                        color: '#CCD6F6',
                                        confirmButtonColor: '#00E676',
                                        heightAuto: false
                                    });
                                })
                            </script>
                        HTML;
                    } else {
                        echo <<<HTML
                            <script>
                                $(document).ready(function() {
                                    Swal.fire({
                                        icon: 'warning',
                                        title: 'Invoice not payable',
                                        text: 'This invoice is not approved for payment, has no amount, or is not in this branch.',
                                        background: '#112240',
                                        color: '#CCD6F6',
                                        confirmButtonColor: '#00E676',
                                        heightAuto: false
                                    });
                                })
                            </script>
                        HTML;
                    }
                }

                if (isset($_POST['payment_done'])) {
                    $id = (int) trim($_POST['id']);
                    $closed_status = "Supplier Payment Received";
                    $sql = "UPDATE `stock_request` SET `status` = ? WHERE id = ? AND branch_id = ? AND status = 'Finance Invoice Done'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sii",  $closed_status, $id, $branch_id);
                    if ($stmt->execute() && $stmt->affected_rows > 0) {

                        //Colects information of stock_request
                        $sql = "SELECT * FROM stock_request WHERE id = " . $id . " AND branch_id = " . $branch_id;
                        $querys = $conn->query($sql);
                        $infor = $querys->fetch_object();


                        //Inserts info of stock_request]
                        $category = "Supplies";
                        $receipt = "No Receipt";
                        $sql = "INSERT INTO `expenses` (`branch_id`, `date`, `supplier`, `category`, `amount`, `receipt` ) VALUES (?, CURDATE(), ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("issds", $branch_id, $infor->supplier_name, $category, $infor->final_cost, $receipt);
                        if ($stmt->execute()) {
                            notif_insert($conn, "Inventory", "Stock Request Closed", "Finance has confirmed that stock request #".$id." is complete and is ready to be rated");
                            echo <<<HTML
                            <script>
                                window.location.href = 'invoices.php';
                            </script>
                            HTML;
                        }
                    }
                }
            }
            ?>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            function renderMatchColumn(elId, items) {
                var $col = $(elId).empty();
                items.forEach(function(item) {
                    $col.append(
                        '<div class="req-detail-item">' +
                        '<span>' + item.name + item.qty + '</span>' +
                        '<span>' + formatPeso(item.price) + '</span>' +
                        '</div>'
                    );
                });
            }

            var $activeMatchRow = null;

            $(document).on('click', '.btn-review-match', function() {
                $activeMatchRow = $(this).closest('tr');
                var $btn = $(this);

                var poItems = $btn.data('po-items') || [];
                var grnItems = $btn.data('grn-items') || [];
                var invItems = $btn.data('inv-items') || [];

                $('#matchInvoiceNo').text($btn.data('invoice'));
                $('#matchSupplier').text($btn.data('supplier'));
                $('#matchCategory').text($btn.data('category'));
                $('#matchPoNumber').text($btn.data('po'));
                $('#matchReqId').text($btn.data('req'));
                $('#matchFinanceNotes').val('');
                $('.idNumber').val($(this).data('number'));

                renderMatchColumn('#matchPoItems', poItems);
                renderMatchColumn('#matchGrnItems', grnItems);
                renderMatchColumn('#matchInvItems', invItems);

                $('#reviewMatchModal').modal('show');
            });

            function setInvoiceStatus(label, statusClass, icon, buttonClass) {
                if (!$activeMatchRow) return;

                $activeMatchRow.find('td').eq(6)
                    .html('<span class="status-badge ' + statusClass + '">' + label + '</span>');

                $activeMatchRow.find('.btn-review-match')
                    .removeClass('btn-review-match btn-confirm')
                    .addClass(buttonClass)
                    .prop('disabled', true)
                    .html('<i class="bi ' + icon + ' me-1"></i>' + label);
            }

            $('#btnMatchApprove').click(function() {
                if (!$activeMatchRow) return;

                var invoiceNo = $('#matchInvoiceNo').text();
                var supplier = $('#matchSupplier').text();
                var amount = $activeMatchRow.find('td').eq(5).text();

                $activeMatchRow.find('td').eq(6)
                    .html('<span class="status-badge status-approved">Matched</span>');

                $activeMatchRow.find('.btn-review-match')
                    .removeClass('btn-review-match btn-confirm')
                    .addClass('btn-confirm btn-process-payment')
                    .attr('data-invoice', invoiceNo)
                    .attr('data-supplier', supplier)
                    .attr('data-amount', amount)
                    .html('<i class="bi bi-cash-coin me-1"></i>Process Payment');

                $('#reviewMatchModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Invoice Matched',
                    text: invoiceNo + ' passed the 3-way match and is cleared for payment.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            // ---- Payment ----
            var $activePaymentRow = null;

            $(document).on('click', '.btn-process-payment', function() {
                $activePaymentRow = $(this).closest('tr');
                var $btn = $(this);

                var items = $btn.data('items') || [];
                var subtotal = 0;
                items.forEach(function(item) {
                    subtotal += Number(item.price) || 0;
                });

                $('#paymentInvoiceNo').text($btn.data('invoice') || '—');
                $('#paymentSupplier').text($btn.data('supplier') || '—');
                $('#paymentCategory').text($btn.data('category') || '—');
                $('#paymentPoNumber').text($btn.data('po') || '—');
                $('#paymentReqId').text($btn.data('req') || '—');
                $('#paymentDate').text($btn.data('date') || '—');
                $('#paymentAmount').text($btn.data('amount'));
                $('#paymentAmountValue').val($btn.data('amounts'));

                var $itemsBody = $('#paymentItemsBody').empty();
                if (items.length) {
                    items.forEach(function(item) {
                        var label = item.name + (item.qty ? ' × ' + item.qty : '');
                        $itemsBody.append(
                            '<tr><td>' + label + '</td><td class="text-end">' + formatPeso(Number(item.price) || 0) + '</td></tr>'
                        );
                    });
                    $('#paymentSubtotal').text(formatPeso(subtotal));
                } else {
                    $itemsBody.append('<tr><td colspan="2" class="text-center" style="color:#8892B0;">No itemized details available</td></tr>');
                    $('#paymentSubtotal').text($btn.data('amount') || '—');
                }

                $('.idNumber').val($(this).data('number'));

                $('#processPaymentModal').modal('show');
            });

            $('#btnConfirmPayment').click(function() {
                //if (!$activePaymentRow) return;



                var invoiceNo = $('#paymentInvoiceNo').text();
                var supplier = $('#paymentSupplier').text();

                $activePaymentRow.find('td').eq(6)
                    .html('<span class="status-badge status-paid">Paid</span>');

                $activePaymentRow.find('.btn-process-payment')
                    .removeClass('btn-process-payment')
                    .addClass('btn-confirm btn-close-done')
                    .html('<i class="bi bi-check-lg me-1"></i>Done');

                $('#processPaymentModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Payment Confirmed',
                    text: invoiceNo + ' has been marked as paid. Payment advice sent to ' + supplier + '.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 2200,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $(document).on('click', '.btn-close-done', function() {
                /*$(this).closest('tr').find('td').eq(6)
                    .html('<span class="status-badge status-closed">Closed</span>');

                $(this)
                    .removeClass('btn-confirm btn-close-done')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-check-circle me-1"></i>Closed');*/
            });

            $('#btnMatchReturn').click(function() {
                if (!$('#matchFinanceNotes').val().trim()) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Note Required',
                        text: 'Please explain why this invoice is being returned to the supplier.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                setInvoiceStatus('Returned to Supplier', 'status-rejected', 'bi-x-circle', 'btn-remove');
                $('#reviewMatchModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Invoice Returned',
                    text: $('#matchInvoiceNo').text() + ' has been returned to the supplier for correction.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>