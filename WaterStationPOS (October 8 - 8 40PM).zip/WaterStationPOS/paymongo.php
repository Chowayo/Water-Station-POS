<?php
/**
 * Shared PayMongo helper for ECO HYDRATE HUB.
 * Used by: Finance/invoices.php, Employee/home.php (cashier), Customer/checkout.php (customer)
 * Include with: require_once __DIR__ . '/../paymongo.php';
 */

if (!defined('PAYMONGO_SECRET_KEY')) {
    define('PAYMONGO_SECRET_KEY', 'sk_test_czCP9LyCpptvSJtZYwKj1n4B'); // TEST key - move to a private config before going live
}

// Full URL of the page currently running (e.g. http://localhost/WaterStationPOS/Employee/home.php)
// Built from the real script path so it works whether the project is in a subfolder or the web root.
function paymongoPageUrl() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    return $scheme . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
}

// Low-level call. Returns ['ok' => bool, 'data' => array, 'error' => string]
function paymongoRequest($method, $endpoint, $payload = null) {
    $ch = curl_init('https://api.paymongo.com/v1/' . $endpoint);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Basic ' . base64_encode(PAYMONGO_SECRET_KEY . ':')
        ]
    ];
    if ($method === 'POST') {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $opts);
    $response = curl_exec($ch);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        return ['ok' => false, 'data' => [], 'error' => 'Connection error: ' . $curlErr];
    }
    $data = json_decode($response, true);
    if (!is_array($data)) {
        return ['ok' => false, 'data' => [], 'error' => 'Invalid response from PayMongo'];
    }
    if (isset($data['errors'])) {
        $msg = $data['errors'][0]['detail'] ?? 'PayMongo rejected the request';
        return ['ok' => false, 'data' => $data, 'error' => $msg];
    }
    return ['ok' => true, 'data' => $data, 'error' => ''];
}

// Creates a hosted checkout page. Returns ['ok' => bool, 'id' => session id, 'url' => checkout url, 'error' => msg]
function paymongoCreateCheckout($amountInPesos, $description, $successUrl, $cancelUrl) {
    $payload = [
        'data' => [
            'attributes' => [
                'line_items' => [[
                    'name'     => $description,
                    'amount'   => (int) round($amountInPesos * 100),
                    'currency' => 'PHP',
                    'quantity' => 1
                ]],
                'payment_method_types' => ['card', 'gcash', 'paymaya', 'qrph'],
                'send_email_receipt'   => true,
                'show_description'     => true,
                'show_line_items'      => true,
                'cancel_url'           => $cancelUrl,
                'success_url'          => $successUrl
            ]
        ]
    ];
    $res = paymongoRequest('POST', 'checkout_sessions', $payload);
    if (!$res['ok']) {
        return ['ok' => false, 'id' => '', 'url' => '', 'error' => $res['error']];
    }
    $d = $res['data']['data'];
    return ['ok' => true, 'id' => $d['id'], 'url' => $d['attributes']['checkout_url'], 'error' => ''];
}

// Asks PayMongo whether the checkout session was really paid (don't trust the redirect alone).
// Retries a few times because PayMongo can take a second or two to mark the payment as paid after redirecting back.
function paymongoIsPaid($sessionId) {
    for ($try = 0; $try < 4; $try++) {
        $res = paymongoRequest('GET', 'checkout_sessions/' . urlencode($sessionId));
        if ($res['ok']) {
            $attr = $res['data']['data']['attributes'];

            foreach (($attr['payments'] ?? []) as $p) {
                if (($p['attributes']['status'] ?? '') === 'paid') return true;
            }

            $pi = $attr['payment_intent'] ?? null;
            if (is_string($pi) && $pi !== '') {
                $r2 = paymongoRequest('GET', 'payment_intents/' . urlencode($pi));
                if ($r2['ok'] && ($r2['data']['data']['attributes']['status'] ?? '') === 'succeeded') return true;
            } elseif (is_array($pi) && ($pi['attributes']['status'] ?? '') === 'succeeded') {
                return true;
            }
        }
        if ($try < 3) sleep(1);
    }
    return false;
}

// Same behaviour the Finance page already had (returns the checkout URL, prints errors and stops)
function createPayMongoCheckoutSession($amountInPesos, $description) {
    $back = paymongoPageUrl();
    $r = paymongoCreateCheckout($amountInPesos, $description, $back, $back);
    if (!$r['ok']) {
        echo '<pre>' . htmlspecialchars($r['error']) . '</pre>';
        exit;
    }
    return $r['url'];
}
