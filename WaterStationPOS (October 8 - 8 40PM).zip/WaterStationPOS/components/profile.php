<?php
// ---- Profile data (same fallback pattern the old modal used: $admin_profile if set, else $result) ----
$pf_id         = isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : '1');
$pf_first      = (isset($admin_profile) && $admin_profile->first_name) ? $admin_profile->first_name : (isset($result) ? $result->first_name : 'Admin');
$pf_last       = (isset($admin_profile) && $admin_profile->first_name) ? $admin_profile->last_name : (isset($result) ? $result->last_name : '');
$pf_name       = trim($pf_first . ' ' . $pf_last);
$pf_email      = isset($admin_profile) ? $admin_profile->email : (isset($result) ? $result->email : 'Admin@gmail.com');
$pf_role       = isset($admin_profile) ? $admin_profile->role : (isset($result) ? $result->role : 'Admin');

// Initials for the avatar (first + last word of the name), same approach as the Customer profile
preg_match_all('/\p{L}+/u', $pf_name, $pf_words);
$pf_words = $pf_words[0];
$pf_initials = '';
if (count($pf_words) > 0) {
    $pf_initials = mb_substr($pf_words[0], 0, 1, 'UTF-8');
    if (count($pf_words) > 1) {
        $pf_initials .= mb_substr($pf_words[count($pf_words) - 1], 0, 1, 'UTF-8');
    }
    $pf_initials = mb_strtoupper($pf_initials, 'UTF-8');
} else {
    $pf_initials = 'A';
}
?>
<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-labelledby="adminPfName" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content pf-modal">

            <!-- HERO -->
            <header class="pf-hero">
                <svg class="pf-waves" viewBox="0 0 2400 120" preserveAspectRatio="none" aria-hidden="true">
                    <path class="pf-wave pf-wave-back" d="M0 52 q150 -44 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                    <path class="pf-wave pf-wave-front" d="M0 78 q150 -34 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                </svg>

                <button type="button" class="pf-close" data-bs-dismiss="modal" aria-label="Close profile"><i class="bi bi-x-lg"></i></button>

                <div class="pf-identity">
                    <div class="pf-avatar" aria-hidden="true"><?php echo htmlspecialchars($pf_initials); ?></div>
                    <div class="pf-identity-text">
                        <h5 class="pf-name" id="adminPfName"><?php echo htmlspecialchars($pf_name); ?></h5>
                        <?php if ($pf_email !== ''): ?>
                            <div class="pf-email"><i class="bi bi-envelope"></i><span class="pf-email-text"><?php echo htmlspecialchars($pf_email); ?></span></div>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <div class="pf-body">

                <ul class="nav pf-tabs" id="adminProfileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profTabInfo" data-bs-toggle="tab" data-bs-target="#profPaneInfo" type="button" role="tab"><i class="bi bi-person-badge"></i>Account Info</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profTabSecurity" data-bs-toggle="tab" data-bs-target="#profPaneSecurity" type="button" role="tab"><i class="bi bi-shield-lock"></i>Security</button>
                    </li>
                </ul>

                <div class="tab-content">

                    <!-- ACCOUNT INFO TAB -->
                    <div class="tab-pane fade show active" id="profPaneInfo" role="tabpanel">
                        <div class="pf-fields">
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-hash"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">ID</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_id); ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-person"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Full name</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_name); ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-envelope"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Email address</span>
                                    <span class="pf-field-value"><?php echo $pf_email !== '' ? htmlspecialchars($pf_email) : '<span class="pf-empty">Not provided</span>'; ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-briefcase"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Role</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_role); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECURITY TAB -->
                    <div class="tab-pane fade" id="profPaneSecurity" role="tabpanel">
                        <div class="pf-pass">

                            <form id="adminChangePasswordForm" method="POST" class="pf-pass-form">
                                <input type="hidden" name="admin_id" value="<?php echo htmlspecialchars($pf_role); ?>">

                                <div class="pf-input-group">
                                    <label for="adminCurrentPassword" class="pf-label">Current password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-lock pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="adminCurrentPassword" name="current_password" autocomplete="current-password" required>
                                        <button type="button" class="pf-eye" data-target="adminCurrentPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>
                                <div class="pf-input-group">
                                    <label for="adminNewPassword" class="pf-label">New password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-key pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="adminNewPassword" name="new_password" autocomplete="new-password" required>
                                        <button type="button" class="pf-eye" data-target="adminNewPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>
                                <div class="pf-input-group">
                                    <label for="adminConfirmPassword" class="pf-label">Confirm new password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-key-fill pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="adminConfirmPassword" name="confirm_password" autocomplete="new-password" required>
                                        <button type="button" class="pf-eye" data-target="adminConfirmPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end pt-2">
                                    <button type="submit" name="changePass" class="pf-btn pf-btn-primary"><i class="bi bi-shield-check"></i>Update password</button>
                                </div>
                            </form>

                            <aside class="pf-checklist" aria-live="polite">
                                <p class="pf-checklist-title">Your new password needs to</p>
                                <ul>
                                    <li id="adminPfRuleLen"><i class="bi bi-circle"></i>Be at least 8 characters long</li>
                                    <li id="adminPfRuleMatch"><i class="bi bi-circle"></i>Match the confirmation</li>
                                    <li id="adminPfRuleDiff"><i class="bi bi-circle"></i>Differ from your current password</li>
                                </ul>
                            </aside>
                        </div>

                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            //Change Password
                            if (isset($_POST['changePass'])) {
                                $current_pass = $_POST['current_password'];
                                $new_pass = $_POST['new_password'];
                                $confirm_pass = $_POST['confirm_password'];
                                $role = $_POST['admin_id'];

                                //Checking if current password matched
                                if (password_verify($current_pass, $result->password)) {
                                    //Password must be atleast 8 characters
                                    if (strlen($new_pass) >= 8) {
                                        //Confirm pass and new pass mathes
                                        if ($new_pass == $confirm_pass) {
                                            //New pass must not match current pass
                                            if (!password_verify($new_pass, $result->password)) {
                                                $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process

                                                if ($role == "Admin") {
                                                    $sql = "UPDATE `admin` SET `password` = ? WHERE id = '" . $result->id . "'";
                                                } else if ($role == "HR" || $role == "Financer") {
                                                    $sql = "UPDATE `employees` SET `password` = ? WHERE id = '" . $result->id . "' AND role = '" . $result->role . "'";
                                                }

                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("s", $password);
                                                if ($stmt->execute()) {
                                                    echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Password Updated!',
                                                                                text: 'The employee information has been updated!.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',
                                                                                heightAuto: false
                                                                            });
                                                                        })
                                                                    </script> 
                                                                    HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Password Re-used!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    showConfirmButton: false,
                                                                    html:`
                                                                        <p>New password must not match with current password!</p>
                                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openAdminProfileSecurityTab();">Ok</a>`
                                                                })
                                                            })
                                                        </script> 
                                                    HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Unmatched!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must match with confirm password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openAdminProfileSecurityTab();">Ok</a>`
                                                            })
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',  
                                                                title: 'Invalid New Password!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must be atleast 8 characters long</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openAdminProfileSecurityTab();">Ok</a>`
                                                            })
                                                        });
                                                    </script> 
                                                HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'error',  
                                                        title: 'Incorrect Password!',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        showConfirmButton: false,
                                                        html:`
                                                            <p>Re-enter current password</p>
                                                            <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openAdminProfileSecurityTab();">Ok</a>`
                                                    })
                                                });
                                            </script> 
                                        HTML;
                                }
                            }
                        }
                        ?>

                    </div><!-- /security pane -->

                </div><!-- /tab-content -->
            </div><!-- /pf-body -->

        </div>
    </div>
</div>

<style>
    /* ===== Admin/HR/Finance profile modal -- same visual language as the Customer profile modal ===== */
    #adminProfileModal .pf-modal {
        background: var(--ws-panel-2, #0b3054);
        border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 30px 70px rgba(0, 0, 0, .55);
    }

    /* Hero */
    #adminProfileModal .pf-hero {
        position: relative;
        padding: 34px 32px;
        background:
            radial-gradient(circle at 12% 0%, rgba(111, 227, 255, .34), transparent 55%),
            linear-gradient(135deg, #12609b 0%, #0b3f6e 55%, #08305a 100%);
        overflow: hidden;
    }
    #adminProfileModal .pf-waves {
        position: absolute; left: 0; bottom: -1px; width: 100%; height: 64px; pointer-events: none;
    }
    #adminProfileModal .pf-wave { fill: #0b3054; }
    #adminProfileModal .pf-wave-back { opacity: .4; }
    #adminProfileModal .pf-wave-front { opacity: 1; }
    #adminProfileModal .pf-waves { width: 200%; animation: pfDrift 22s linear infinite; }
    @keyframes pfDrift { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    #adminProfileModal .pf-close {
        position: absolute; top: 16px; right: 16px; z-index: 2;
        width: 36px; height: 36px; border-radius: 12px;
        display: inline-flex; align-items: center; justify-content: center;
        background: rgba(4, 23, 41, .35); border: 1px solid rgba(255, 255, 255, .18);
        color: #fff; font-size: 14px; cursor: pointer; transition: background .15s, transform .15s;
    }
    #adminProfileModal .pf-close:hover { background: rgba(255, 107, 122, .35); }
    #adminProfileModal .pf-close:active { transform: scale(.94); }

    #adminProfileModal .pf-identity { position: relative; z-index: 1; display: flex; align-items: center; gap: 20px; }
    #adminProfileModal .pf-avatar {
        flex: 0 0 auto; width: 88px; height: 88px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 32px; font-weight: 800; letter-spacing: 1px; color: #04213b;
        background: linear-gradient(145deg, #8cecff, #29c5f6 60%, #1e88e5);
        box-shadow: 0 0 0 4px rgba(4, 23, 41, .35), 0 0 0 6px rgba(111, 227, 255, .55), 0 14px 28px rgba(0, 0, 0, .35);
    }
    #adminProfileModal .pf-identity-text { min-width: 0; overflow: hidden; }
    #adminProfileModal .pf-name { padding-right: 44px; margin: 0 0 6px; color: #fff; font-size: 26px; font-weight: 800; line-height: 1.15; overflow-wrap: anywhere; }
    #adminProfileModal .pf-email { display: flex; align-items: center; gap: 8px; color: rgba(230, 246, 255, .85); font-size: 14px; white-space: nowrap; }
    #adminProfileModal .pf-email i { flex: 0 0 auto; }
    #adminProfileModal .pf-email-text { min-width: 0; overflow: hidden; text-overflow: ellipsis; }

    /* Body + tabs */
    #adminProfileModal .pf-body { padding: 22px 32px 30px; }
    #adminProfileModal .pf-tabs {
        display: flex; gap: 6px; padding: 5px; margin-bottom: 22px; flex-wrap: nowrap;
        background: #06203a; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); border-radius: 14px;
    }
    #adminProfileModal .pf-tabs .nav-item { flex: 1 1 0; }
    #adminProfileModal .pf-tabs .nav-link {
        width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
        padding: 10px 12px; border: none; border-radius: 10px;
        background: transparent; color: var(--ws-muted, #8fb4cf);
        font-size: 14px; font-weight: 700; white-space: nowrap; transition: background .15s, color .15s;
    }
    #adminProfileModal .pf-tabs .nav-link:hover { color: #fff; background: rgba(41, 197, 246, .08); }
    #adminProfileModal .pf-tabs .nav-link.active { color: #04213b; background: linear-gradient(135deg, #6fe3ff, #29c5f6); }

    /* Account info */
    #adminProfileModal .pf-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 0 28px; }
    #adminProfileModal .pf-field {
        display: flex; align-items: center; gap: 14px; padding: 16px 0;
        border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #adminProfileModal .pf-field:nth-last-child(-n+2) { border-bottom: none; }
    #adminProfileModal .pf-field-icon {
        flex: 0 0 auto; width: 42px; height: 42px; border-radius: 13px;
        display: flex; align-items: center; justify-content: center; font-size: 18px;
        color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px solid rgba(41, 197, 246, .25);
    }
    #adminProfileModal .pf-field-text { display: flex; flex-direction: column; min-width: 0; }
    #adminProfileModal .pf-field-label { color: var(--ws-muted, #8fb4cf); font-size: 12.5px; font-weight: 600; }
    #adminProfileModal .pf-field-value { color: #fff; font-size: 15.5px; font-weight: 600; overflow-wrap: anywhere; }
    #adminProfileModal .pf-empty { color: var(--ws-muted, #8fb4cf); font-weight: 500; font-style: italic; }

    /* Buttons */
    #adminProfileModal .pf-btn {
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        padding: 11px 22px; border-radius: 14px; font-size: 14.5px; font-weight: 800; border: none; cursor: pointer;
        transition: transform .12s, filter .15s, background .15s;
    }
    #adminProfileModal .pf-btn:active { transform: scale(.97); }
    #adminProfileModal .pf-btn-primary { color: #032a1e; background: linear-gradient(135deg, #2ee6a6, #12b886); box-shadow: 0 10px 22px rgba(46, 230, 166, .25); }
    #adminProfileModal .pf-btn-primary:hover { filter: brightness(1.08); }
    #adminProfileModal .pf-btn-ghost { color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px solid rgba(41, 197, 246, .4); }
    #adminProfileModal .pf-btn-ghost:hover { background: rgba(41, 197, 246, .24); }

    /* Password */
    #adminProfileModal .pf-pass { display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr); gap: 28px; align-items: start; }
    #adminProfileModal .pf-input-group { margin-bottom: 16px; }
    #adminProfileModal .pf-label { display: block; margin-bottom: 6px; color: var(--ws-text, #e6f6ff); font-size: 13.5px; font-weight: 700; }
    #adminProfileModal .pf-input-wrap { position: relative; }
    #adminProfileModal .pf-input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--ws-muted, #8fb4cf); pointer-events: none; }
    #adminProfileModal .pf-input { height: 48px; padding: 0 46px 0 42px; border-radius: 14px; font-size: 15px; }
    #adminProfileModal .pf-input:focus { border-color: var(--ws-aqua, #29c5f6) !important; box-shadow: 0 0 0 .25rem rgba(41, 197, 246, .22) !important; }
    #adminProfileModal .pf-eye {
        position: absolute; right: 6px; top: 50%; transform: translateY(-50%);
        width: 36px; height: 36px; border: none; border-radius: 10px; background: transparent;
        color: var(--ws-muted, #8fb4cf); cursor: pointer;
    }
    #adminProfileModal .pf-eye:hover { color: #fff; background: rgba(41, 197, 246, .14); }

    #adminProfileModal .pf-checklist {
        padding: 18px; border-radius: 16px; background: rgba(4, 23, 41, .55); border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #adminProfileModal .pf-checklist-title { margin: 0 0 12px; color: #fff; font-size: 14px; font-weight: 800; }
    #adminProfileModal .pf-checklist ul { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
    #adminProfileModal .pf-checklist li { display: flex; align-items: center; gap: 10px; color: var(--ws-muted, #8fb4cf); font-size: 13.5px; transition: color .15s; }
    #adminProfileModal .pf-checklist li.ok { color: var(--ws-green, #2ee6a6); }

    /* Keyboard focus */
    #adminProfileModal .pf-close:focus-visible,
    #adminProfileModal .pf-eye:focus-visible,
    #adminProfileModal .pf-btn:focus-visible,
    #adminProfileModal .pf-tabs .nav-link:focus-visible { outline: 2px solid var(--ws-aqua-2, #6fe3ff); outline-offset: 2px; }

    /* Responsive */
    @media (max-width: 767.98px) {
        #adminProfileModal .pf-hero { padding: 28px 20px; }
        #adminProfileModal .pf-avatar { width: 68px; height: 68px; font-size: 24px; }
        #adminProfileModal .pf-name { font-size: 21px; }
        #adminProfileModal .pf-body { padding: 18px 16px 24px; }
        #adminProfileModal .pf-fields { grid-template-columns: 1fr; }
        #adminProfileModal .pf-field:nth-last-child(2) { border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
        #adminProfileModal .pf-tabs .nav-link { font-size: 12.5px; padding: 9px 6px; gap: 5px; }
        #adminProfileModal .pf-tabs .nav-link i { display: none; }
        #adminProfileModal .pf-pass { grid-template-columns: 1fr; gap: 18px; }
        #adminProfileModal .pf-checklist { order: -1; }
    }

    @media (prefers-reduced-motion: reduce) {
        #adminProfileModal .pf-waves { animation: none; }
    }
</style>

<script>
    //After a password error popup, reopen the profile on the Security tab instead of Account Info
    function openAdminProfileSecurityTab() {
        var el = document.getElementById('profTabSecurity');
        if (el && window.bootstrap) { bootstrap.Tab.getOrCreateInstance(el).show(); }
    }

    (function () {
        //Show / hide password buttons
        document.querySelectorAll('#adminProfileModal .pf-eye').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(btn.getAttribute('data-target'));
                var icon = btn.querySelector('i');
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
                btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            });
        });

        //Live password checklist (the server still does the real validation)
        var cur = document.getElementById('adminCurrentPassword');
        var nw  = document.getElementById('adminNewPassword');
        var cf  = document.getElementById('adminConfirmPassword');
        var rules = {
            len:   document.getElementById('adminPfRuleLen'),
            match: document.getElementById('adminPfRuleMatch'),
            diff:  document.getElementById('adminPfRuleDiff')
        };
        function mark(li, ok) {
            li.classList.toggle('ok', ok);
            li.querySelector('i').className = ok ? 'bi bi-check-circle-fill' : 'bi bi-circle';
        }
        function refresh() {
            mark(rules.len, nw.value.length >= 8);
            mark(rules.match, nw.value.length > 0 && nw.value === cf.value);
            mark(rules.diff, nw.value.length > 0 && cur.value.length > 0 && nw.value !== cur.value);
        }
        [cur, nw, cf].forEach(function (el) { el.addEventListener('input', refresh); });
    })();
</script>
