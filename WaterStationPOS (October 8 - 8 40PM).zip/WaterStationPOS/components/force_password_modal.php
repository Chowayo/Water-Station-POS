<?php
// ============================================================================
// Forces an employee to set a new password the first time they log in with
// the default temporary password ("12345678") that Admin/HR assigns when
// their account is created. Include this AFTER $conn and $user (the logged
// in employee row, from $_SESSION['users']) are available.
// ============================================================================

$force_password_error = $force_password_error ?? '';
$force_password_change = isset($user->password) && password_verify('12345678', $user->password);

// Handle the submission from the modal below
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['force_password_change'])) {
    $new_pass = $_POST['new_password'] ?? '';
    $confirm_pass = $_POST['confirm_password'] ?? '';

    if ($new_pass === '' || $confirm_pass === '') {
        $force_password_error = 'Please fill in both fields.';
    } elseif (strlen($new_pass) < 8) {
        $force_password_error = 'New password must be at least 8 characters long.';
    } elseif ($new_pass !== $confirm_pass) {
        $force_password_error = 'New password and confirmation do not match.';
    } elseif ($new_pass === '12345678') {
        $force_password_error = 'Please choose a password other than the default one.';
    } else {
        $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $sql = "UPDATE `employees` SET `password` = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $new_hash, $user->id);
        if ($stmt->execute()) {
            // Keep the session's copy in sync so the modal doesn't pop up again this session
            $_SESSION['users']->password = $new_hash;
            $user->password = $new_hash;
            $force_password_change = false;

            echo <<<HTML
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            icon: 'success',
                            title: 'Password Updated!',
                            text: 'Your password has been changed.',
                            background: '#112240',
                            color: '#CCD6F6',
                            confirmButtonColor: '#00E676',
                            heightAuto: false
                        });
                    });
                </script>
                HTML;
        } else {
            $force_password_error = 'Something went wrong, please try again.';
        }
    }
}

if ($force_password_change) {
    $fp_error_html = $force_password_error !== '' ? '<div class="alert alert-danger py-2 mb-3">' . htmlspecialchars($force_password_error) . '</div>' : '';
    echo <<<HTML
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var modalHtml = '<div class="modal fade" id="forcePasswordModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">' +
                    '<div class="modal-dialog modal-dialog-centered">' +
                        '<div class="modal-content shadow-lg" style="background:#112240; color:#CCD6F6;">' +
                            '<div class="modal-header border-0">' +
                                '<h5 class="modal-title"><i class="bi bi-shield-lock me-2"></i>Set a New Password</h5>' +
                            '</div>' +
                            '<div class="modal-body p-4">' +
                                '<p class="mb-3">You are still using the default password. Please set a new one to continue.</p>' +
                                '{$fp_error_html}' +
                                '<form method="POST">' +
                                    '<input type="hidden" name="force_password_change" value="1">' +
                                    '<div class="mb-3">' +
                                        '<label class="form-label">New Password</label>' +
                                        '<input type="password" class="form-control" name="new_password" required minlength="8" placeholder="At least 8 characters">' +
                                    '</div>' +
                                    '<div class="mb-4">' +
                                        '<label class="form-label">Confirm New Password</label>' +
                                        '<input type="password" class="form-control" name="confirm_password" required minlength="8" placeholder="Re-enter the new password">' +
                                    '</div>' +
                                    '<button type="submit" class="btn btn-add rounded-pill px-4 w-100">Update Password</button>' +
                                '</form>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';

                $('body').append(modalHtml);
                $('#forcePasswordModal').modal('show');
            });
        </script>
        HTML;
}
?>
