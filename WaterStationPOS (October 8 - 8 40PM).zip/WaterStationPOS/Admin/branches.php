<?php

include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

// ADD, EDIT, TOGGLE branch data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    //Add Branch
    if (isset($_POST['adder'])) {
        $name = trim($_POST['name']);
        $latitude = $_POST['latitude'] !== '' ? (float) $_POST['latitude'] : null;
        $longitude = $_POST['longitude'] !== '' ? (float) $_POST['longitude'] : null;

        if ($name) {
            $sql = "SELECT name FROM branches";
            $check_query = $conn->query($sql);
            $name_taken = false;
            while ($set = $check_query->fetch_object()) {
                if (strcasecmp($set->name, $name) === 0) {
                    $name_taken = true;
                    break;
                }
            }

            if (!$name_taken) {
                $sql = "INSERT INTO `branches` (`name`, `status`, `latitude`, `longitude`) VALUES (?, 'Active', ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sdd", $name, $latitude, $longitude);
                if ($stmt->execute()) {
                    echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Branch Added!',
                                    text: 'The new branch is now available.',
                                    background: '#112240',
                                    color: '#CCD6F6',
                                    confirmButtonColor: '#00E676',
                                    heightAuto: false
                                }).then((result) => {
                                    if(result.isConfirmed) {
                                        location.assign('branches.php');
                                    }});
                            })
                        </script>
                        HTML;
                }
            } else {
                echo <<<HTML
                    <script>
                        $(document).ready(function() {
                            Swal.fire({
                                icon: 'error',
                                title: 'Branch Name Already in Use!',
                                text: 'Enter a different branch name.',
                                background: '#112240',
                                color: '#CCD6F6',
                                confirmButtonColor: '#e60000',
                                heightAuto: false
                            }).then((result) => {
                                if(result.isConfirmed) {
                                    $('#addBranchModal').modal('show');
                                }});
                        })
                    </script>
                    HTML;
            }
        }
    }

    //Edit Branch
    if (isset($_POST['editer'])) {
        $id = $_POST['id'];
        $name = trim($_POST['name']);
        $latitude = $_POST['latitude'] !== '' ? (float) $_POST['latitude'] : null;
        $longitude = $_POST['longitude'] !== '' ? (float) $_POST['longitude'] : null;
        $status = $_POST['status'];

        if ($id && $name && $status) {
            $sql = "SELECT name FROM branches WHERE id != " . (int) $id;
            $check_query = $conn->query($sql);
            $name_taken = false;
            while ($set = $check_query->fetch_object()) {
                if (strcasecmp($set->name, $name) === 0) {
                    $name_taken = true;
                    break;
                }
            }

            if (!$name_taken) {
                $sql = "UPDATE `branches` SET `name` = ?, `status` = ?, `latitude` = ?, `longitude` = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssddi", $name, $status, $latitude, $longitude, $id);
                if ($stmt->execute()) {
                    echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Branch Updated!',
                                    text: 'The branch information has been saved.',
                                    background: '#112240',
                                    color: '#CCD6F6',
                                    confirmButtonColor: '#00E676',
                                    heightAuto: false
                                }).then((result) => {
                                    if(result.isConfirmed) {
                                        location.assign('branches.php');
                                    }});
                            })
                        </script>
                        HTML;
                }
            } else {
                echo <<<HTML
                    <script>
                        $(document).ready(function() {
                            Swal.fire({
                                icon: 'error',
                                title: 'Branch Name Already in Use!',
                                text: 'Enter a different branch name.',
                                background: '#112240',
                                color: '#CCD6F6',
                                confirmButtonColor: '#e60000',
                                heightAuto: false
                            }).then((result) => {
                                if(result.isConfirmed) {
                                    location.assign('branches.php');
                                }});
                        })
                    </script>
                    HTML;
            }
        }
    }

    //Activate / Deactivate toggle (soft, since employees/products/orders are tied to branch_id)
    if (isset($_POST['toggler'])) {
        $sql = "SELECT status FROM branches WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $_POST['toggler']);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_object();

        if ($row) {
            $new_status = $row->status === 'Active' ? 'Inactive' : 'Active';
            $sql = "UPDATE `branches` SET `status` = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $new_status, $_POST['toggler']);
            if ($stmt->execute()) {
                echo <<<HTML
                    <script>
                        $(document).ready(function() {
                            Swal.fire({
                                icon: 'success',
                                title: 'Branch Updated!',
                                text: 'The branch status has been changed.',
                                background: '#112240',
                                color: '#CCD6F6',
                                confirmButtonColor: '#00E676',
                                heightAuto: false
                            }).then((result) => {
                                if(result.isConfirmed) {
                                    location.assign('branches.php');
                                }});
                        })
                    </script>
                    HTML;
            }
        }
    }
}

?>

<head>
    <title>Branches - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/leaflet.css" />
    <script src="../js/leaflet.js"></script>

    <style>
        .search-container {
            position: relative;
        }

        .search-container .bi-search {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
        }

        .search-container input {
            padding-left: 35px !important;
        }

        .table-scroll-wrap {
            max-height: 520px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }

        .branch-map {
            height: 440px;
            border-radius: 12px;
            margin-top: 10px;
            border: 1px solid #233554;
            isolation: isolate;
        }

        .branch-map-status {
            font-size: 12px;
            color: #8892B0;
            margin-top: 6px;
            min-height: 16px;
        }

        .branch-map-status.is-error {
            color: #ff6b6b;
        }

        .branch-search-row {
            display: flex;
            gap: 8px;
        }

        .branch-search-row .form-control {
            flex: 1 1 auto;
            min-width: 0;
        }

        .branch-search-results {
            max-height: 180px;
            overflow-y: auto;
            margin-top: 8px;
            border-radius: 10px;
            border: 1px solid #233554;
        }

        .branch-search-results button {
            display: block;
            width: 100%;
            text-align: left;
            padding: 9px 12px;
            font-size: 13.5px;
            border: 0;
            border-bottom: 1px solid #233554;
            background: #0A192F;
            color: #CCD6F6;
        }

        .branch-search-results button:last-child {
            border-bottom: 0;
        }

        .branch-search-results button:hover {
            background: rgba(100, 255, 218, 0.12);
            color: #64FFDA;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <!-- MAIN DASHBOARD CONTENT -->
    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Branch Management</h1>
                </div>
            </header>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Branch Management</div>
                    <div class="box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">All Branches</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Branch" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap" id="openAddBranch">+ Add Branch</button>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#branch_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });
                            });
                        </script>
                        <table class="table table-dark table-hover text-center mb-0 align-middle table-card-mobile" id="branch_list">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Branch Name</th>
                                    <th>Coordinates</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM branches ORDER BY id ASC";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    $coords = ($set->latitude !== null && $set->longitude !== null)
                                        ? number_format($set->latitude, 6) . ', ' . number_format($set->longitude, 6)
                                        : '<span class="text-muted">Not set</span>';

                                    echo "
                                        <tr>
                                        <td data-label='ID'>$set->id</td>
                                        <td data-label='Branch Name'>" . htmlspecialchars($set->name) . "</td>
                                        <td data-label='Coordinates'>$coords</td>
                                        ";

                                    if ($set->status == "Active") {
                                        echo "<td data-label='Status'><span class='status-badge status-active'><i class='bi bi-circle-fill me-1' style='font-size: 0.6rem;'></i>$set->status</span></td>";
                                    } else {
                                        echo "<td data-label='Status'><span class='status-badge status-inactive'><i class='bi bi-circle-fill me-1' style='font-size: 0.6rem;'></i>$set->status</span></td>";
                                    }

                                    $toggle_label = $set->status == "Active" ? "Deactivate" : "Activate";
                                    $toggle_icon = $set->status == "Active" ? "bi-slash-circle" : "bi-check-circle";

                                    echo "
                                        <td data-label='Actions' class='card-actions-cell'>
                                            <button class='btn btn-edit btn-sm rounded-pill px-3 me-1'
                                                data-id='{$set->id}'
                                                data-name='" . htmlspecialchars($set->name, ENT_QUOTES) . "'
                                                data-status='{$set->status}'
                                                data-latitude='{$set->latitude}'
                                                data-longitude='{$set->longitude}'>
                                            <i class='bi bi-pencil-square me-1'></i>Edit
                                            </button>
                                            <button class='btn btn-remove btn-sm rounded-pill px-3'
                                                    data-id='{$set->id}'
                                                    data-label='{$toggle_label}'>
                                            <i class='bi {$toggle_icon} me-1'></i>{$toggle_label}
                                            </button>
                                        </td>
                                        </tr>
                                        ";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        //Delegated to the document so it still fires for rows on page 2+ of the DataTable
        $(document).on('click', '.btn-remove', function() {
            var id = $(this).data('id');
            var label = $(this).data('label');

            Swal.fire({
                title: label + ' Branch?',
                text: label === 'Deactivate'
                    ? 'Staff and customers will no longer see this branch as available.'
                    : 'This branch will become available again.',
                icon: 'warning',
                background: '#112240',
                color: '#CCD6F6',
                showCancelButton: true,
                showConfirmButton: true,
                confirmButtonText: 'Confirm ' + label,
                confirmButtonColor: label === 'Deactivate' ? '#e60000' : '#00E676',
                cancelButtonColor: '#8892B0',
                heightAuto: false
            }).then((result) => {
                if (result.isConfirmed) {
                    $('<form method="POST"><input type="hidden" name="toggler" value="' + id + '"></form>').appendTo('body').submit();
                }
            });
        });
    </script>

    <!-- Add Branch Modal -->
    <div class="modal fade" id="addBranchModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Branch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addBranchForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Branch Name</label>
                            <input type="text" class="form-control" name="name" required placeholder="e.g. Eco Hydrate Hub - Bacoor">
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Location <span class="text-muted">(search, click the map, or drag the pin -- optional)</span></label>
                            <div class="branch-search-row">
                                <input type="text" class="form-control" id="addBranchSearch" placeholder="Search address, barangay or landmark" autocomplete="off">
                                <button type="button" class="btn btn-outline-light rounded-pill px-3" id="addBranchSearchBtn" title="Search"><i class="bi bi-search"></i></button>
                            </div>
                            <div class="branch-search-results d-none" id="addBranchSearchResults"></div>
                            <div id="addBranchMap" class="branch-map"></div>
                            <div class="branch-map-status" id="addBranchMapStatus">No location set yet.</div>
                        </div>

                        <input type="hidden" name="latitude" id="add-latitude">
                        <input type="hidden" name="longitude" id="add-longitude">

                        <div class="modal-footer mt-3">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="adder" class="btn btn-add rounded-pill px-4">Save Branch</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Branch Modal -->
    <div class="modal fade" id="editBranchModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Branch</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="editBranchForm" method="POST">
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label">Branch Name</label>
                            <input type="text" class="form-control" name="name" required id="edit-name">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="edit-status">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>

                        <div class="mb-2">
                            <label class="form-label">Location <span class="text-muted">(search, click the map, or drag the pin to change)</span></label>
                            <div class="branch-search-row">
                                <input type="text" class="form-control" id="editBranchSearch" placeholder="Search address, barangay or landmark" autocomplete="off">
                                <button type="button" class="btn btn-outline-light rounded-pill px-3" id="editBranchSearchBtn" title="Search"><i class="bi bi-search"></i></button>
                            </div>
                            <div class="branch-search-results d-none" id="editBranchSearchResults"></div>
                            <div id="editBranchMap" class="branch-map"></div>
                            <div class="branch-map-status" id="editBranchMapStatus">No location set yet.</div>
                        </div>

                        <input type="hidden" name="latitude" id="edit-latitude">
                        <input type="hidden" name="longitude" id="edit-longitude">

                        <div class="modal-footer mt-3">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="editer" class="btn btn-add rounded-pill px-4">Update Branch</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function() {
            var defaultCoords = [14.3232, 120.9408]; //Bacoor, Cavite -- used when a branch has no pin yet
            var icon = L.icon({ iconUrl: '../Images/leaflet/location.png', iconSize: [38, 38], iconAnchor: [19, 38], popupAnchor: [0, -38] });

            // One controller per modal (add / edit). Builds the map lazily the first time its
            // modal is shown (Leaflet can't size a map inside a still-hidden element), and wires
            // up click-to-place, drag-to-adjust, and address search -- all writing into the same
            // pair of hidden lat/lng inputs the form submits.
            function createBranchMapController(opts) {
                var map = null, marker = null, searchTimer = null, searchCtl = null, cache = {};
                var mapEl = document.getElementById(opts.mapId);
                var statusEl = document.getElementById(opts.statusId);
                var searchInput = document.getElementById(opts.searchInputId);
                var searchBtn = document.getElementById(opts.searchBtnId);
                var resultsEl = document.getElementById(opts.resultsId);
                var latInput = document.getElementById(opts.latInputId);
                var lngInput = document.getElementById(opts.lngInputId);

                function status(msg, isError) {
                    statusEl.textContent = msg;
                    statusEl.classList.toggle('is-error', !!isError);
                }

                function hideResults() {
                    resultsEl.innerHTML = '';
                    resultsEl.classList.add('d-none');
                }

                function setCoords(lat, lng) {
                    latInput.value = lat.toFixed(6);
                    lngInput.value = lng.toFixed(6);
                }

                function placePin(lat, lng, zoom) {
                    if (marker) {
                        marker.setLatLng([lat, lng]);
                    } else {
                        marker = L.marker([lat, lng], { icon: icon, draggable: true }).addTo(map);
                        marker.on('dragend', function() {
                            var p = marker.getLatLng();
                            setCoords(p.lat, p.lng);
                            status('Location set: ' + p.lat.toFixed(6) + ', ' + p.lng.toFixed(6));
                        });
                    }
                    map.setView([lat, lng], zoom || Math.max(map.getZoom(), 16));
                }

                function buildMap() {
                    map = L.map(mapEl).setView(defaultCoords, 12);
                    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        maxZoom: 19,
                        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    }).addTo(map);
                    map.on('click', function(e) {
                        placePin(e.latlng.lat, e.latlng.lng);
                        setCoords(e.latlng.lat, e.latlng.lng);
                        status('Location set: ' + e.latlng.lat.toFixed(6) + ', ' + e.latlng.lng.toFixed(6));
                        hideResults();
                    });
                }

                function showResults(list, q) {
                    resultsEl.innerHTML = '';
                    if (!list.length) {
                        resultsEl.classList.add('d-none');
                        status('No results for "' + q + '". Try a nearby landmark or street.', true);
                        return;
                    }
                    status('Pick a result below, or fine-tune by dragging the pin.');
                    list.forEach(function(item) {
                        var b = document.createElement('button');
                        b.type = 'button';
                        b.textContent = item.display_name;
                        b.addEventListener('click', function() {
                            var lat = parseFloat(item.lat), lng = parseFloat(item.lon);
                            placePin(lat, lng, 17);
                            setCoords(lat, lng);
                            searchInput.value = item.display_name;
                            status('Location set: ' + lat.toFixed(6) + ', ' + lng.toFixed(6));
                            hideResults();
                        });
                        resultsEl.appendChild(b);
                    });
                    resultsEl.classList.remove('d-none');
                }

                function runSearch() {
                    var q = searchInput.value.trim();
                    if (q.length < 3) { hideResults(); status('Type at least 3 characters to search.', true); return; }
                    if (cache[q]) { showResults(cache[q], q); return; }
                    if (searchCtl) { searchCtl.abort(); }
                    searchCtl = new AbortController();
                    status('Searching...');
                    fetch('https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=ph&q=' + encodeURIComponent(q), { signal: searchCtl.signal })
                        .then(function(r) { return r.json(); })
                        .then(function(list) {
                            cache[q] = list;
                            if (searchInput.value.trim() === q) { showResults(list, q); }
                        })
                        .catch(function(err) { if (err.name !== 'AbortError') { status('Search failed. Check your internet connection.', true); } });
                }

                searchInput.addEventListener('input', function() {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(runSearch, 400);
                });
                searchInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') { e.preventDefault(); clearTimeout(searchTimer); runSearch(); }
                });
                searchBtn.addEventListener('click', function() { clearTimeout(searchTimer); runSearch(); });
                document.addEventListener('click', function(e) {
                    if (!resultsEl.contains(e.target) && e.target !== searchInput) { hideResults(); }
                });

                return {
                    ensureBuilt: function() {
                        if (!map) { buildMap(); }
                        map.invalidateSize();
                    },
                    reset: function() {
                        if (marker) { map.removeLayer(marker); marker = null; }
                        map.setView(defaultCoords, 12);
                        searchInput.value = '';
                        hideResults();
                        status('No location set yet.');
                    },
                    loadCoords: function(lat, lng) {
                        if (marker) { map.removeLayer(marker); marker = null; }
                        searchInput.value = '';
                        hideResults();
                        if (lat !== null && lng !== null) {
                            placePin(lat, lng, 16);
                            status('Location set: ' + lat.toFixed(6) + ', ' + lng.toFixed(6));
                        } else {
                            map.setView(defaultCoords, 12);
                            status('No location set yet.');
                        }
                    }
                };
            }

            var addCtl = createBranchMapController({
                mapId: 'addBranchMap', statusId: 'addBranchMapStatus',
                searchInputId: 'addBranchSearch', searchBtnId: 'addBranchSearchBtn', resultsId: 'addBranchSearchResults',
                latInputId: 'add-latitude', lngInputId: 'add-longitude'
            });
            var editCtl = createBranchMapController({
                mapId: 'editBranchMap', statusId: 'editBranchMapStatus',
                searchInputId: 'editBranchSearch', searchBtnId: 'editBranchSearchBtn', resultsId: 'editBranchSearchResults',
                latInputId: 'edit-latitude', lngInputId: 'edit-longitude'
            });

            //ADD MODAL
            $('#addBranchModal').on('shown.bs.modal', function() { addCtl.ensureBuilt(); });

            $('#openAddBranch').click(function() {
                $('#addBranchForm')[0].reset();
                $('#add-latitude, #add-longitude').val('');
                $('#addBranchModal').modal('show');
                $('#addBranchModal').one('shown.bs.modal', function() { addCtl.reset(); });
            });

            //EDIT MODAL
            $('#editBranchModal').on('shown.bs.modal', function() { editCtl.ensureBuilt(); });

            $(document).on('click', '.btn-edit', function() {
                var id = $(this).data('id');
                var name = $(this).data('name');
                var status = $(this).data('status');
                var lat = $(this).data('latitude');
                var lng = $(this).data('longitude');

                $('#edit-id').val(id);
                $('#edit-name').val(name);
                $('#edit-status').val(status);

                var hasCoords = lat !== '' && lng !== '' && lat !== null && lng !== null && !isNaN(parseFloat(lat)) && !isNaN(parseFloat(lng));
                $('#edit-latitude').val(hasCoords ? lat : '');
                $('#edit-longitude').val(hasCoords ? lng : '');

                $('#editBranchModal').modal('show');

                //Position the pin once the modal (and map) has actually been shown and sized
                $('#editBranchModal').one('shown.bs.modal', function() {
                    editCtl.loadCoords(hasCoords ? parseFloat(lat) : null, hasCoords ? parseFloat(lng) : null);
                });
            });
        })();
    </script>
