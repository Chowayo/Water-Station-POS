<!DOCTYPE html>
<html lang="en">

<?php
require(__DIR__ . '/../dbConn.php');


//NOTE: This header will only be used by admin side

//No Login
if (!isset($_SESSION['users'])) {
    header('location:../login.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
    exit;
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}


//Sends customer back to home if role is customer
if ($_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier"){
    header('location: /Supplier/orders.php');
    exit;
}





// Branch of the logged-in Inventory employee: stock alerts use this branch's products only
$hdr_branch = 0;
$hdr_branch_name = '';
if (isset($_SESSION['users']->id)) {
    $hdr_q = $conn->query("SELECT e.branch_id, b.name FROM employees e LEFT JOIN branches b ON b.id = e.branch_id WHERE e.id = " . (int) $_SESSION['users']->id);
    $hdr_row = $hdr_q ? $hdr_q->fetch_object() : null;
    if ($hdr_row) {
        $hdr_branch = (int) $hdr_row->branch_id;
        $hdr_branch_name = (string) $hdr_row->name;
    }
}

//Low and No Stock Notification
$sql = "SELECT * FROM product WHERE stock <= 5 AND deleted = 'False' AND branch_id = " . $hdr_branch;
$query = $conn->query($sql);
while ($product = $query->fetch_object()) {

    $sql = "SELECT * FROM admin WHERE role = 'Admin'";
    $querys = $conn->query($sql);
    while ($emp_info = $querys->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        if ($product->stock == 0) {
            $notif_category = "Product Out of Stock";
            $notif_message = $product->product_name . " is currently out of stock" . ($hdr_branch_name !== '' ? " (" . $conn->real_escape_string($hdr_branch_name) . ")" : "");
        } else if ($product->stock > 0) {
            $notif_category = "Product Low on Stock";
            $notif_message = $product->product_name . " Only has " . $product->stock . " stock left" . ($hdr_branch_name !== '' ? " (" . $conn->real_escape_string($hdr_branch_name) . ")" : "");
        }

        //No repeation ON THE SAME DAY checker
        $sql = "SELECT * FROM notification WHERE message = '" . $conn->real_escape_string($notif_message) . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
        $checker_query = $conn->query($sql);
        $check = $checker_query->fetch_object();

        if (!$check) {
            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {
            }
        }
    }
}

$user = $_SESSION['users'];

?>

<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>