-- Run ONCE in phpMyAdmin before using the patched Finance/Inventory pages.
-- Existing rows are assigned to branch 1 (the default branch).
ALTER TABLE `stock_request` ADD COLUMN `branch_id` int(11) NOT NULL DEFAULT 1 AFTER `id`;
ALTER TABLE `stocks`        ADD COLUMN `branch_id` int(11) NOT NULL DEFAULT 1 AFTER `id`;
