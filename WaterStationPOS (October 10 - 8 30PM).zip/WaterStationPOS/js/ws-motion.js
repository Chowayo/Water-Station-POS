/*!
 * ws-motion.js : maliliit na animation helpers para sa buong system
 *   1. Sunod-sunod na pasok ng sidebar menu (nagtatakda ng --i)
 *   2. Tumutulong tubig (ripple) kapag pinindot ang button / menu / card
 *   3. Count-up ng mga numero sa dashboard (.dash-value)
 * Walang binabago sa data o logic ng mga page.
 */
(function () {
    "use strict";
    if (window.WSMotion) return;
    window.WSMotion = true;

    var reduce = window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function onReady(fn) {
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
        else fn();
    }

    /* 1. Sidebar stagger */
    function staggerMenu() {
        document.querySelectorAll(".left-menu .menu-link").forEach(function (a, i) {
            a.style.setProperty("--i", i);
        });
    }

    /* 2. Water tap */
    var TAP_TARGETS = ".btn, .menu-link, .start-btn, .dash-card, .product-card, .item-card, .notif-btn, .btn-book-login";
    function bindTap() {
        if (reduce) return;
        document.addEventListener("pointerdown", function (e) {
            if (e.pointerType === "mouse" && e.button !== 0) return;
            var t = e.target.closest && e.target.closest(TAP_TARGETS);
            if (!t || t.disabled || t.classList.contains("disabled") || t.getAttribute("aria-disabled") === "true") return;
            var d = document.createElement("span");
            d.className = "ws-tap";
            d.style.left = e.clientX + "px";
            d.style.top = e.clientY + "px";
            document.body.appendChild(d);
            setTimeout(function () { d.remove(); }, 900);
        }, { passive: true });
    }

    /* 3. Count-up (₱1,234.50 / 25 / 85% ...) */
    function countUp(el) {
        var original = el.textContent;
        var m = original.trim().match(/^([^\d\-]*)(-?[\d,]*\.?\d+)([^\d]*)$/);
        if (!m) return;
        var target = parseFloat(m[2].replace(/,/g, ""));
        if (!isFinite(target) || target === 0) return;

        var decimals = (m[2].split(".")[1] || "").length;
        var grouped = m[2].indexOf(",") !== -1;
        var fmt = function (v) {
            var s = v.toFixed(decimals);
            if (grouped) {
                var p = s.split(".");
                p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                s = p.join(".");
            }
            return m[1] + s + m[3];
        };

        var dur = 900, start = null;
        function step(ts) {
            if (start === null) start = ts;
            var p = Math.min((ts - start) / dur, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            el.textContent = p < 1 ? fmt(target * eased) : original;   // ibinabalik ang eksaktong orihinal
            if (p < 1) requestAnimationFrame(step);
        }
        el.textContent = fmt(0);
        requestAnimationFrame(step);
    }

    function bindCountUp() {
        if (reduce || !("IntersectionObserver" in window)) return;
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (!en.isIntersecting) return;
                io.unobserve(en.target);
                countUp(en.target);
            });
        }, { threshold: 0.4 });
        document.querySelectorAll(".dash-value").forEach(function (el) {
            if (el.children.length === 0) io.observe(el);   // plain text lang, para walang masirang markup
        });
    }

    onReady(function () {
        staggerMenu();
        bindTap();
        bindCountUp();
    });
})();
