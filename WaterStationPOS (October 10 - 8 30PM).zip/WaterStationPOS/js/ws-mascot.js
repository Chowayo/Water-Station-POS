/*!
 * ws-mascot.js : "Hydie", ang mascot ng Eco Hydrate Hub
 *
 * Ano ang ginagawa nito:
 *   1. Gumagawa ng inline-SVG ng mascot (WSMascot.svg) para ma-animate ng css/ws-mascot.css
 *   2. Pinapalitan ang <div data-mascot="wave"></div> ng mascot  (data-look = sumusunod ang mata sa mouse)
 *   3. Pinapalitan ang patak sa "Please wait" loader ng tumatalon na Hydie
 *   4. <script data-helper> = lumilitaw si Hydie sa kanang-ibaba at bumabati / nagbibigay ng tip
 *   5. Sa login page: sumusunod ang mata sa email, tinatakpan ang mata sa password, malungkot kapag mali
 *
 * Hindi ito humahawak sa kahit anong existing na logic ng system.
 */
(function () {
    "use strict";
    if (window.WSMascot) return;

    // Kunin agad habang tumatakbo pa ang script (null na ito pagkatapos).
    var SELF = document.currentScript;
    var uid = 0;
    var reduceMotion = window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* ------------------------------------------------------------------ *
     * 1. SVG
     *    Lahat ng alternate na parte (masayang mata, malungkot na bibig)
     *    ay may opacity="0" attribute para gumana rin ang static .svg file.
     *    Ang CSS (ws-mascot.css) ang nagpapalit nito kapag may state class.
     * ------------------------------------------------------------------ */
    function svg(opts) {
        opts = opts || {};
        var n = ++uid;
        var cls = "hy" + (opts.state ? " " + opts.state.split(" ").map(function (s) { return "is-" + s; }).join(" ") : "");
        var sad = opts.mood === "sad";
        var happy = opts.mood === "happy";
        var a11y = opts.decorative
            ? 'aria-hidden="true"'
            : 'role="img" aria-label="Hydie, ang mascot ng Eco Hydrate Hub"';

        return '' +
        '<svg class="' + cls + '" viewBox="0 -10 200 272" xmlns="http://www.w3.org/2000/svg" ' + a11y + ' focusable="false">' +
          '<defs>' +
            '<linearGradient id="hyg' + n + '" x1="0" y1="0" x2="0" y2="1">' +
              '<stop offset="0" stop-color="#9aedff"/><stop offset=".5" stop-color="#34c9f7"/><stop offset="1" stop-color="#1b7fe0"/>' +
            '</linearGradient>' +
            '<linearGradient id="hyl' + n + '" x1="0" y1="0" x2="1" y2="1">' +
              '<stop offset="0" stop-color="#7bf5c6"/><stop offset="1" stop-color="#1fb87f"/>' +
            '</linearGradient>' +
          '</defs>' +

          '<ellipse class="hy-shadow" cx="100" cy="254" rx="52" ry="6.5" fill="#031425" opacity=".22"/>' +

          '<g class="hy-jumper"><g class="hy-bob">' +

            /* dahon sa ulo (eco) */
            '<g class="hy-leaf">' +
              '<path d="M100 46 C99 34 100 22 104 12" stroke="#1fb87f" stroke-width="5" stroke-linecap="round" fill="none"/>' +
              '<path d="M104 14 C114 -3 141 -1 147 12 C135 27 112 27 104 14Z" fill="url(#hyl' + n + ')"/>' +
              '<path d="M103 21 C94 8 76 8 70 17 C80 29 96 29 103 21Z" fill="url(#hyl' + n + ')"/>' +
              '<path d="M109 15 Q125 12 139 13" stroke="#14946a" stroke-width="1.8" stroke-linecap="round" fill="none" opacity=".55"/>' +
            '</g>' +

            /* paa */
            '<ellipse cx="78" cy="245" rx="13" ry="6.5" fill="#1b7fe0"/>' +
            '<ellipse cx="122" cy="245" rx="13" ry="6.5" fill="#1b7fe0"/>' +

            /* katawan */
            '<path class="hy-body" d="M100 40 C100 40 28 122 28 172 A72 72 0 0 0 172 172 C172 122 100 40 100 40Z" fill="url(#hyg' + n + ')"/>' +
            '<path d="M64 124 Q53 140 57 158" stroke="#fff" stroke-opacity=".6" stroke-width="8" stroke-linecap="round" fill="none"/>' +
            '<circle cx="76" cy="106" r="4.5" fill="#fff" fill-opacity=".6"/>' +

            /* mukha */
            '<g class="hy-face">' +
              '<g class="hy-eyes"' + (happy ? ' opacity="0"' : '') + '>' +
                '<ellipse cx="74" cy="172" rx="14.5" ry="17" fill="#fff"/>' +
                '<ellipse cx="126" cy="172" rx="14.5" ry="17" fill="#fff"/>' +
                '<g class="hy-pupil">' +
                  '<circle cx="76" cy="175" r="10.5" fill="#06203a"/><circle cx="80.5" cy="170" r="3.6" fill="#fff"/><circle cx="72" cy="180" r="1.8" fill="#fff"/>' +
                  '<circle cx="128" cy="175" r="10.5" fill="#06203a"/><circle cx="132.5" cy="170" r="3.6" fill="#fff"/><circle cx="124" cy="180" r="1.8" fill="#fff"/>' +
                '</g>' +
              '</g>' +
              '<g class="hy-eyes-happy" fill="none" stroke="#06203a" stroke-width="5.5" stroke-linecap="round"' + (happy ? '' : ' opacity="0"') + '>' +
                '<path d="M60 175 Q74 155 88 175"/><path d="M112 175 Q126 155 140 175"/>' +
              '</g>' +
              '<ellipse cx="52" cy="195" rx="9" ry="5.5" fill="#ff8fab" opacity=".55"/>' +
              '<ellipse cx="148" cy="195" rx="9" ry="5.5" fill="#ff8fab" opacity=".55"/>' +
              '<g class="hy-mouth-open"' + (sad ? ' opacity="0"' : '') + '>' +
                '<path d="M87 191 Q100 217 113 191 Q100 196 87 191Z" fill="#06203a"/>' +
                '<ellipse cx="100" cy="200" rx="6" ry="3.4" fill="#ff7b93"/>' +
              '</g>' +
              '<path class="hy-mouth-sad" d="M88 205 Q100 192 112 205" fill="none" stroke="#06203a" stroke-width="4.5" stroke-linecap="round"' + (sad ? '' : ' opacity="0"') + '/>' +
            '</g>' +

            /* kamay (nasa harap ng katawan para matakpan ang mata) */
            '<g class="hy-arm hy-arm-l"><ellipse class="hy-hand hy-hand-l" cx="24" cy="200" rx="12" ry="10" fill="#8be0ff" stroke="#1b7fe0" stroke-width="3"/></g>' +
            '<g class="hy-arm hy-arm-r"><ellipse class="hy-hand hy-hand-r" cx="176" cy="200" rx="12" ry="10" fill="#8be0ff" stroke="#1b7fe0" stroke-width="3"/></g>' +

          '</g></g>' +
        '</svg>';
    }

    /* ------------------------------------------------------------------ *
     * 2. Helpers
     * ------------------------------------------------------------------ */
    function setState(el, name, on, autoOffMs) {
        if (!el) return;
        el.classList[on ? "add" : "remove"]("is-" + name);
        if (on && autoOffMs) {
            clearTimeout(el["_hyT_" + name]);
            el["_hyT_" + name] = setTimeout(function () { el.classList.remove("is-" + name); }, autoOffMs);
        }
    }

    function look(el, x, y) {
        if (!el) return;
        el.style.setProperty("--hy-lx", x.toFixed(1) + "px");
        el.style.setProperty("--hy-ly", y.toFixed(1) + "px");
    }

    function onReady(fn) {
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
        else fn();
    }

    /* ------------------------------------------------------------------ *
     * 3. <div data-mascot="wave"> placeholders
     * ------------------------------------------------------------------ */
    function hydrate(root) {
        (root || document).querySelectorAll("[data-mascot]").forEach(function (host) {
            if (host.querySelector(".hy")) return;
            var state = host.getAttribute("data-mascot") || "";
            host.insertAdjacentHTML("afterbegin", svg({
                state: state,
                decorative: host.hasAttribute("aria-hidden") || host.hasAttribute("data-decorative")
            }));
            host.classList.add("hy-host");
        });
    }

    /* Ang mata ay sumusunod sa mouse (para sa [data-look]) */
    function bindLook() {
        if (reduceMotion) return;
        var ticking = false, mx = 0, my = 0;
        function update() {
            ticking = false;
            document.querySelectorAll(".hy-host[data-look] .hy, .hy-helper .hy").forEach(function (el) {
                var r = el.getBoundingClientRect();
                if (!r.width) return;
                var cx = r.left + r.width / 2, cy = r.top + r.height * 0.62;
                var dx = mx - cx, dy = my - cy, d = Math.sqrt(dx * dx + dy * dy) || 1;
                var m = Math.min(d / 160, 1) * 5.5;
                look(el, (dx / d) * m, (dy / d) * m * 0.8);
            });
        }
        window.addEventListener("pointermove", function (e) {
            mx = e.clientX; my = e.clientY;
            if (!ticking) { ticking = true; requestAnimationFrame(update); }
        }, { passive: true });
    }

    /* ------------------------------------------------------------------ *
     * 4. "Please wait" loader: tumatalon na si Hydie imbes na patak
     * ------------------------------------------------------------------ */
    function upgradeLoader() {
        document.querySelectorAll("#wsGlobalLoader .ws-drop-wrap").forEach(function (wrap) {
            if (wrap.querySelector(".hy")) return;
            wrap.classList.add("hy-loader-wrap");
            var holder = document.createElement("div");
            holder.className = "hy-loader";
            holder.innerHTML = svg({ state: "loading", decorative: true });
            wrap.insertBefore(holder, wrap.firstChild);
        });
    }

    /* ------------------------------------------------------------------ *
     * 5. Floating helper (kanang-ibaba)
     * ------------------------------------------------------------------ */
    var TIPS = [
        "Tip: Drink some water now, even just a little!",
        "Don’t forget to check the stock of the containers.",
        "Clean water, happy customers!",
        "Take a break for a few seconds. You've got this!",
        "Thank you for your hard work today!",
        "Every refill is one less piece of plastic.",
        "Just a smile, and work becomes easier!",
        "Tap me again, I have more tips!"
    ];

    function greeting() {
        var h = new Date().getHours();
        var g = h < 12 ? "Good morning!" : h < 13 ? "Good afternoon!" : h < 18 ? "Good evening!" : "Good night!";
        return g + " I'm Hydie.";
    }

    function mountHelper() {
        try { if (sessionStorage.getItem("ws_hydie_hidden") === "1") return; } catch (e) {}
        if (document.querySelector(".hy-helper")) return;

        var el = document.createElement("div");
        el.className = "hy-helper";
        el.innerHTML =
            '<div class="hy-bubble" role="status" aria-live="polite"></div>' +
            '<button type="button" class="hy-hide" aria-label="Hide Hydie" title="Hide Hydie">&times;</button>' +
            '<button type="button" class="hy-btn" aria-label="Talk to Hydie">' + svg({ decorative: true }) + '</button>';
        document.body.appendChild(el);

        var bubble = el.querySelector(".hy-bubble");
        var btn = el.querySelector(".hy-btn");
        var face = el.querySelector(".hy");
        var tipIndex = 0, taps = 0, tapTimer, bubbleTimer;

        function say(text, ms) {
            bubble.textContent = text;
            bubble.classList.add("show");
            clearTimeout(bubbleTimer);
            bubbleTimer = setTimeout(function () { bubble.classList.remove("show"); }, ms || 4200);
        }

        btn.addEventListener("click", function () {
            taps++;
            clearTimeout(tapTimer);
            tapTimer = setTimeout(function () { taps = 0; }, 1500);
            setState(face, "jump", false);
            void face.getBoundingClientRect();           // i-restart ang talon
            setState(face, "jump", true, 700);
            setState(face, "happy", true, 1600);
            if (taps >= 5) { say("Hehehe, that tickles!", 2600); taps = 0; return; }
            say(TIPS[tipIndex++ % TIPS.length], 4600);
        });

        el.querySelector(".hy-hide").addEventListener("click", function () {
            try { sessionStorage.setItem("ws_hydie_hidden", "1"); } catch (e) {}
            el.classList.remove("is-in");
            setTimeout(function () { el.remove(); }, 450);
        });

        // Ang nag-iisang "pasok": pop-up, kumakaway, bumabati.
        setTimeout(function () {
            el.classList.add("is-in");
            setState(face, "wave", true, 2600);
            say(greeting(), 4200);
        }, 900);
    }

    /* ------------------------------------------------------------------ *
     * 6. Login page: reaksyon ni Hydie
     * ------------------------------------------------------------------ */
    function bindLogin() {
        var host = document.querySelector(".hy-login");
        var face = host && host.querySelector(".hy");
        var email = document.getElementById("username");
        var pass = document.getElementById("password");
        if (!face || !email || !pass) return;

        host.removeAttribute("data-look"); // ang email/password ang gumagabay sa mata

        function glance() {
            var len = Math.min(email.value.length, 28);
            look(face, -4.5 + (len / 28) * 9, 3.5);
        }
        email.addEventListener("focus", function () { setState(face, "cover", false); glance(); });
        email.addEventListener("input", glance);
        email.addEventListener("blur", function () { look(face, 0, 0); });

        pass.addEventListener("focus", function () { setState(face, "cover", true); });
        pass.addEventListener("blur", function () { setState(face, "cover", false); });

        // Kapag nag-error ang login (SweetAlert error), malulungkot si Hydie.
        if (window.MutationObserver) {
            new MutationObserver(function (list) {
                for (var i = 0; i < list.length; i++) {
                    for (var j = 0; j < list[i].addedNodes.length; j++) {
                        var node = list[i].addedNodes[j];
                        if (node.nodeType === 1 && node.querySelector &&
                            (node.matches(".swal2-container") || node.querySelector(".swal2-icon-error"))) {
                            var err = node.querySelector(".swal2-icon-error");
                            if (err) { setState(face, "cover", false); setState(face, "sad", true, 2400); }
                        }
                    }
                }
            }).observe(document.body, { childList: true });
        }
    }

    /* ------------------------------------------------------------------ */
    window.WSMascot = { svg: svg, state: setState, look: look, hydrate: hydrate };

    onReady(function () {
        hydrate();
        bindLook();
        upgradeLoader();
        bindLogin();

        if (SELF && SELF.hasAttribute("data-helper")) mountHelper();
    });
})();
