<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<?php
require('../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../login.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory"){
    header('location: /Inventory/stocks.php');
    exit;
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if ($_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier"){
    header('location: /Supplier/orders.php');
    exit;
}

// Each employee only sees their own branch's stock alerts
$branch_id = (int) $_SESSION['users']->branch_id;

//Low and No Stock Notification
$sql = "SELECT * FROM product WHERE stock <= 5 AND deleted = 'False' AND branch_id = " . $branch_id;
$query = $conn->query($sql);
while ($product = $query->fetch_object()) {

    $sql = "SELECT * FROM employees WHERE role = 'Cashier' and deleted = 'False' AND branch_id = " . $branch_id;
    $querys = $conn->query($sql);
    while ($emp_info = $querys->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        if($product->stock==0){
            $notif_category = "Product Out of Stock";
            $notif_message = $product->product_name . " is currently out of stock"; 
        }
        else if($product->stock>0){
            $notif_category = "Product Low on Stock";
            $notif_message = $product->product_name . " Only has ".$product->stock." stock left";
        }
        
        //No repeation ON THE SAME DAY checker
        $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
        $checker_query = $conn->query($sql);
        $check = $checker_query->fetch_object();

        if(!$check){
            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {}
        }
    }
}


    
//End of shift reminder
date_default_timezone_set('Asia/Manila');
$cur_time = new DateTime(date('G:i:s'));
$scheduled_time = new DateTime("16:45:00");
if($cur_time>$scheduled_time){
    $sql = "SELECT * FROM employees WHERE id = ".$_SESSION['users']->id." AND deleted = 'False' AND role ='".$_SESSION['users']->role."'";
    $query = $conn->query($sql);
    $emp_info = $query->fetch_object();
    $notif_id = $emp_info->id;
    $notif_role = $emp_info->role;
    $notif_category = "Your Shift is Almost Over";
    $notif_message = "Make sure to log off at exactly 5:00PM";


    //No repeation ON THE SAME DAY checker
    $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
    $checker_query = $conn->query($sql);
    $check = $checker_query->fetch_object();

    if(!$check){
        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
        if ($stmt->execute()) {}
    }
}

$user = $_SESSION['users'];

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>

    <!-- Global loading overlay: shown while a form submits or an action is processing -->
    <style>
        #wsGlobalLoader {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 10000;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 18px;
            background: rgba(6, 32, 58, 0.78);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
        }

        #wsGlobalLoader.active {
            display: flex;
        }

        #wsGlobalLoader .ws-drop-wrap {
            position: relative;
            width: 76px;
            height: 92px;
        }

        #wsGlobalLoader .ws-drop {
            position: absolute;
            left: 50%;
            top: 0;
            width: 40px;
            height: 40px;
            transform: translateX(-50%);
            animation: wsDropFall 1.2s cubic-bezier(.55, 0, 1, .45) infinite;
        }

        #wsGlobalLoader .ws-drop svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 4px 8px rgba(41, 197, 246, 0.45));
        }

        #wsGlobalLoader .ws-ripple {
            position: absolute;
            left: 50%;
            bottom: 2px;
            width: 54px;
            height: 14px;
            border-radius: 50%;
            transform: translateX(-50%) scale(0);
            border: 2px solid var(--ws-aqua, #29c5f6);
            opacity: 0;
            animation: wsRipple 1.2s cubic-bezier(.2, .6, .35, 1) infinite;
        }

        #wsGlobalLoader .ws-ripple.ws-ripple-2 {
            animation-delay: 0.6s;
        }

        @keyframes wsDropFall {
            0% {
                top: 0;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            70% {
                top: 48px;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            85% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }

            100% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }
        }

        @keyframes wsRipple {
            0% {
                transform: translateX(-50%) scale(0.2);
                opacity: 0;
            }

            30% {
                opacity: 0.8;
            }

            100% {
                transform: translateX(-50%) scale(1.6);
                opacity: 0;
            }
        }

        #wsGlobalLoader .ws-loader-text {
            color: var(--ws-text, #CCD6F6);
            font-weight: 600;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
        }

        #wsGlobalLoader .ws-loader-text::after {
            content: '';
            display: inline-block;
            width: 1.2em;
            text-align: left;
            animation: wsDots 1.2s steps(4, end) infinite;
        }

        @keyframes wsDots {

            0%,
            20% {
                content: '';
            }

            40% {
                content: '.';
            }

            60% {
                content: '..';
            }

            80%,
            100% {
                content: '...';
            }
        }
    </style>
    <div id="wsGlobalLoader" aria-live="polite" aria-busy="true">
        <div class="ws-drop-wrap">
            <div class="ws-drop">
                <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="wsDropGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#6fe3ff" />
                            <stop offset="100%" stop-color="#1e88e5" />
                        </linearGradient>
                    </defs>
                    <path d="M20 2 C20 2 6 20 6 29 a14 14 0 0 0 28 0 C34 20 20 2 20 2 Z" fill="url(#wsDropGrad)" />
                </svg>
            </div>
            <div class="ws-ripple"></div>
            <div class="ws-ripple ws-ripple-2"></div>
        </div>
        <div class="ws-loader-text">Please wait</div>
    </div>
    <script>
        function showGlobalLoader() {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.add('active');
        }
        window.showGlobalLoader = showGlobalLoader;

        // Show the overlay the moment any form on the page is submitted
        // (covers add/edit/submit/approve/reject forms app-wide).
        $(document).on('submit', 'form', function() {
            showGlobalLoader();
        });

        // Forms built dynamically and submitted via JS (delete/toggle confirms)
        // call form.submit() directly, which does NOT fire the 'submit' event,
        // so those call showGlobalLoader() explicitly right before submitting.

        // Hide the overlay again if the page is restored from bfcache
        // (e.g. the user hits Back after a submit).
        window.addEventListener('pageshow', function(e) {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.remove('active');
        });
    </script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <?php include __DIR__ . '/../components/force_password_modal.php'; ?>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/animate-init.js"></script>
    <link href="../css/ws-mascot.css" rel="stylesheet">
    <link href="../css/ws-motion.css" rel="stylesheet">
    <script src="../js/ws-motion.js"></script>
    <script src="../js/ws-mascot.js" data-helper></script>
    <script src="../js/jquery.dataTables.min.js"></script>


    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>


<body>
    <script>
        window.addEventListener('pageshow', function(events) {
            if (events.persisted) {
                window.location.reload();
            }
        });
    </script>