<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<?php
require(__DIR__ . '/../dbConn.php');


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
    exit;
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
    exit;
}


?>


<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>

    <!-- Global loading overlay: shown while a form submits or an action is processing -->
    <style>
        #wsGlobalLoader {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 10000;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 18px;
            background: rgba(6, 32, 58, 0.78);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
        }

        #wsGlobalLoader.active {
            display: flex;
        }

        #wsGlobalLoader .ws-drop-wrap {
            position: relative;
            width: 76px;
            height: 92px;
        }

        #wsGlobalLoader .ws-drop {
            position: absolute;
            left: 50%;
            top: 0;
            width: 40px;
            height: 40px;
            transform: translateX(-50%);
            animation: wsDropFall 1.2s cubic-bezier(.55, 0, 1, .45) infinite;
        }

        #wsGlobalLoader .ws-drop svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 4px 8px rgba(41, 197, 246, 0.45));
        }

        #wsGlobalLoader .ws-ripple {
            position: absolute;
            left: 50%;
            bottom: 2px;
            width: 54px;
            height: 14px;
            border-radius: 50%;
            transform: translateX(-50%) scale(0);
            border: 2px solid var(--ws-aqua, #29c5f6);
            opacity: 0;
            animation: wsRipple 1.2s cubic-bezier(.2, .6, .35, 1) infinite;
        }

        #wsGlobalLoader .ws-ripple.ws-ripple-2 {
            animation-delay: 0.6s;
        }

        @keyframes wsDropFall {
            0% {
                top: 0;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            70% {
                top: 48px;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            85% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }

            100% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }
        }

        @keyframes wsRipple {
            0% {
                transform: translateX(-50%) scale(0.2);
                opacity: 0;
            }

            30% {
                opacity: 0.8;
            }

            100% {
                transform: translateX(-50%) scale(1.6);
                opacity: 0;
            }
        }

        #wsGlobalLoader .ws-loader-text {
            color: var(--ws-text, #CCD6F6);
            font-weight: 600;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
        }

        #wsGlobalLoader .ws-loader-text::after {
            content: '';
            display: inline-block;
            width: 1.2em;
            text-align: left;
            animation: wsDots 1.2s steps(4, end) infinite;
        }

        @keyframes wsDots {

            0%,
            20% {
                content: '';
            }

            40% {
                content: '.';
            }

            60% {
                content: '..';
            }

            80%,
            100% {
                content: '...';
            }
        }
    </style>
    <div id="wsGlobalLoader" aria-live="polite" aria-busy="true">
        <div class="ws-drop-wrap">
            <div class="ws-drop">
                <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="wsDropGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#6fe3ff" />
                            <stop offset="100%" stop-color="#1e88e5" />
                        </linearGradient>
                    </defs>
                    <path d="M20 2 C20 2 6 20 6 29 a14 14 0 0 0 28 0 C34 20 20 2 20 2 Z" fill="url(#wsDropGrad)" />
                </svg>
            </div>
            <div class="ws-ripple"></div>
            <div class="ws-ripple ws-ripple-2"></div>
        </div>
        <div class="ws-loader-text">Please wait</div>
    </div>
    <script>
        function showGlobalLoader() {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.add('active');
        }
        window.showGlobalLoader = showGlobalLoader;

        // Show the overlay the moment any form on the page is submitted
        // (covers add/edit/submit/approve/reject forms app-wide).
        $(document).on('submit', 'form', function() {
            showGlobalLoader();
        });

        // Forms built dynamically and submitted via JS (delete/toggle confirms)
        // call form.submit() directly, which does NOT fire the 'submit' event,
        // so those call showGlobalLoader() explicitly right before submitting.

        // Hide the overlay again if the page is restored from bfcache
        // (e.g. the user hits Back after a submit).
        window.addEventListener('pageshow', function(e) {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.remove('active');
        });
    </script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
    <link href="../css/ws-mascot.css" rel="stylesheet">
    <link href="../css/ws-motion.css" rel="stylesheet">
    <script src="../js/ws-motion.js"></script>
    <script src="../js/ws-mascot.js"></script>

    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>



<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //Add Account
    if (isset($_POST['adder'])) {

        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $confirmPass = $_POST['confirmPassword'];
        $contact = $_POST['contact'];

        //Note: May possible issue to kapag sa login na kapag same ng email sa employees/HR/Admin/Finance/Customer
        if ($full_name && $email && $pass && $contact) {
            $sql = "SELECT email FROM customers WHERE deleted = 'False'";
            $query = $conn->query($sql);
            $email_checked = True;
            while ($set = $query->fetch_object()) {
                if ($set->email == $email) {
                    $email_checked = False;
                    break;
                }
            }
            if ($email_checked) {
                if (strlen($pass) >= 8 && $confirmPass == $pass) {
                    $pass = password_hash($pass, PASSWORD_DEFAULT); //ENCRYPTS PASSOWRD BEFORE THROWING IT TO DATABASE
                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                    $sql = "INSERT INTO `customers` (`full_name`, `email`, `contact`, `password`) VALUES (?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssss", $full_name, $email, $contact, $pass);
                    if ($stmt->execute()) {
                        //New Employee Notification
                        /*$role_list = array("Admin", "HR");
                            foreach ($role_list as $roles){
                                if($roles=="Admin"){
                                    $sql = "SELECT * FROM admin";
                                }
                                elseif($roles=="HR"){
                                    $sql = "SELECT * FROM employees WHERE role = '".$roles."' AND deleted = 'False'";
                                }
                                $query = $conn->query($sql);
                                while($emp_info = $query->fetch_object()) {
                                    $notif_id = $emp_info->id;
                                    $notif_role = $emp_info->role;
                                    $notif_category = "New Employee Added";
                                    $notif_message = "New ".$role." employee has been added";

                                    if($roles=="HR"){
                                        if($role!="HR"){
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            $stmt->execute();
                                        }
                                    }
                                    elseif($roles=="Admin"){
                                        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                        $stmt->execute();
                                    }
                                    
                                    

                                }
                            }*/
                        echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Account Created!',
                                                text: 'You can now login to your account',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('../login.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                    }
                } else {
                    echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Invalid Password!',
                                            text: 'Password must be atleast 8 characters long And it must match with confirm password',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#e60000',
                                            heightAuto: false
                                        });
                                    })
                                </script>
                            HTML;
                }
            } else {
                echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Email Already in use!',
                                    text: 'Enter a new email',
                                    background: '#112240',
                                    color: '#CCD6F6',
                                    confirmButtonColor: '#e60000',
                                    heightAuto: false
                                });
                            })
                        </script> 
                    HTML;
            }
        }
    }
}
?>

<body>
    <!-- Arrival transition: when coming from the landing page the water drains away to reveal this page -->
    <style>
        .lt-arrive { display: none; position: fixed; inset: 0; z-index: 99999; overflow: hidden; pointer-events: none; }
        .lt-arrive.show { display: block; }
        .lt-arrive .la-water { position: absolute; left: 0; right: 0; top: 0; height: calc(100% + 160px); transform: translateY(-80px); animation: laDrain 1.7s .7s cubic-bezier(.65, 0, .35, 1) forwards; }
        .lt-arrive .la-water::after { content: ""; position: absolute; inset: 58px 0 0 0; background: linear-gradient(180deg, #19d3ff 0%, #0b7fd0 30%, #0a2f5c 70%, #091a31 100%); }
        .lt-arrive svg { position: absolute; top: 0; left: 0; width: 200%; height: 60px; z-index: 1; animation: laWave 1.7s linear infinite reverse; }
        .lt-arrive svg path { fill: #19d3ff; }
        .lt-arrive img { position: absolute; z-index: 2; left: 50%; top: 50%; width: min(190px, 50vw); padding: 16px; border-radius: 50%; background: #fff; transform: translate(-50%, -50%); box-shadow: 0 0 0 6px rgba(255, 255, 255, .25), 0 0 40px rgba(0, 231, 120, .6), 0 18px 40px rgba(0, 0, 0, .35); animation: laLogo .7s .35s ease forwards; }
        @keyframes laDrain { to { transform: translateY(100%); } }
        @keyframes laWave { to { transform: translateX(-50%); } }
        @keyframes laLogo { to { opacity: 0; transform: translate(-50%, -62%) scale(.8); } }
        .lt-arriving .auth-card { animation: laCard .9s 1.5s cubic-bezier(.22, 1, .36, 1) both; }
        @keyframes laCard { from { opacity: 0; transform: translateY(28px) scale(.97); } to { opacity: 1; transform: none; } }
        @media (prefers-reduced-motion: reduce) {
            .lt-arrive.show { display: none; }
            .lt-arriving .auth-card { animation: none; }
        }
    </style>
    <div class="lt-arrive" id="ltArrive" aria-hidden="true">
        <div class="la-water"><svg viewBox="0 0 2400 60" preserveAspectRatio="none" aria-hidden="true"><path d="M0 30 q150 -40 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V60 H0 Z"/></svg></div>
        <img src="../Images/logo.png" alt="">
    </div>
    <script>
        (function () {
            var el = document.getElementById('ltArrive');
            var go = false;
            try { go = sessionStorage.getItem('ltArrive') === '1'; sessionStorage.removeItem('ltArrive'); } catch (e) {}
            if (!go) { return; }
            el.classList.add('show');
            document.documentElement.classList.add('lt-arriving');
            setTimeout(function () { el.remove(); document.documentElement.classList.remove('lt-arriving'); }, 3200);
        })();
    </script>


    <div class="auth-card">

        <div class="auth-hydie" data-mascot="wave" data-decorative></div>

        <img src="../Images/logo.png" alt="Eco Hydrate Hub" class="auth-logo">

        <div class="auth-title"><b>Welcome!</b></div>
        <div class="auth-subtitle">Join the Eco Hydrate Community</div>

        <form action="#" method="POST">

            <div class="auth-field">
                <label for="full_name" class="auth-label">Full Name</label>
                <input type="text" id="full_name" name="full_name" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="email" class="auth-label">Email</label>
                <input type="email" id="email" name="email" class="auth-input" required>
            </div>

            <div class="auth-field">
                <label for="contact" class="auth-label">Contact</label>
                <input type="text" id="contact" name="contact" class="auth-input" minlength="11" maxlength="11" required>
            </div>

            <div class="auth-field">
                <label for="password" class="auth-label">Password</label>
                <input type="password" id="password" name="password" class="auth-input">
                <div class="auth-hint">At least 8 characters</div>
            </div>

            <div class="auth-field">
                <label for="confirmPassword" class="auth-label">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" class="auth-input" required>
            </div>

            <button type="submit" class="btn-create-account" name="adder">Create account</button>

            <div class="auth-footer">
                Already have an account? <a href="../login.php">Login</a>
            </div>

        </form>

    </div>

</body>

</html>