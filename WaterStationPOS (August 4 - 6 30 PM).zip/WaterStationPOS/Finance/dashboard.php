<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<head>
    <title>Finance Dashboard</title>

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Finance Dashboard</h1>
                    <h6>Overview of revenue, cash flow, and pending actions</h6>
                </div>
            </header>

            <!-- Total Revenue Widget -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Finance Dashboard/Revenue_Today.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Revenue Today</div>
                        <div class="dash-value green-text">
                            <?php
                            $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date = CURDATE() AND type ='Income'";
                            $query = $conn->query($sql);
                            $income = $query->fetch_object();

                            if ($income != "") {
                                echo "₱" . $income->total;
                            } else {
                                echo "₱0.00";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Finance Dashboard/Revenue_This_week.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Revenue This Week</div>
                        <div class="dash-value cyan-text">
                            <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= CURDATE() - INTERVAL 7 DAY AND date <= CURDATE() AND type = 'Income';";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                } else {
                                    echo "₱0.00";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Finance Dashboard/Revenue_this_month.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Revenue This Month</div>
                        <div class="dash-value">
                            <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                } else {
                                    echo "₱0.00";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-lg-7 d-flex flex-column">
                    <div class="section-header"><i class="bi bi-bar-chart-line me-2"></i>Income and Expenses</div>
                    <div class="manage-box shadow-sm chart-card flex-fill">
                        <div class="d-flex justify-content-end align-items-center mb-2">
                            <span class="small" style="color: #8892B0;">Last 6 months</span>
                        </div>
                        <div class="bar-chart">
                            <?php

                            $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                            $current_month_num = (int)date('m');
                            $current_year = (int)date('Y');

                            $placeholder_revenue = array();
                            $placeholder_expenses = array();


                            for ($i = 0; $i < 6; $i++) {
                                $month_offset = 5 - $i;
                                $month_index = $current_month_num - 1 - $month_offset;
                                $year_label = $current_year;
                                if ($month_index < 0) {
                                    $month_index += 12;
                                    $year_label -= 1;
                                }

                                //Getting monthly income
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-" . ($month_index + 1) . "-01') AND date < DATE_FORMAT(CURDATE(), '%Y-" . ($month_index + 1) . "-01') + INTERVAL 1 MONTH AND type ='Income'";
                                $query = $conn->query($sql);
                                $month_revenue = $query->fetch_object();
                                $placeholder_revenue[] = $month_revenue->total;

                                //Getting monthly expenses from TRANSACTION table
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-" . ($month_index + 1) . "-01') AND date < DATE_FORMAT(CURDATE(), '%Y-" . ($month_index + 1) . "-01') + INTERVAL 1 MONTH AND type ='Expense'";
                                $query = $conn->query($sql);
                                $month_expense = $query->fetch_object();

                                $total_expense = $month_expense->total;


                                $placeholder_expenses[] = $total_expense;
                            }


                            $max_value = max(array_merge($placeholder_revenue, $placeholder_expenses));
                            if ($max_value == 0) {
                                $max_value = 1;
                            }

                            for ($i = 0; $i < 6; $i++) {
                                $month_offset = 5 - $i;
                                $month_index = $current_month_num - 1 - $month_offset;
                                $year_label = $current_year;
                                if ($month_index < 0) {
                                    $month_index += 12;
                                    $year_label -= 1;
                                }


                                $income = $placeholder_revenue[$i];
                                $expense = $placeholder_expenses[$i];
                                $income_pct = round(($income / $max_value) * 50, 1);
                                $expense_pct = round(($expense / $max_value) * 50, 1);
                                $income_display = "₱" . number_format($income);
                                $expense_display = "-₱" . number_format($expense);

                                echo <<<HTML
                                        <div class="bar-col">
                                            <div class="bar-pair mb-4">
                                                <div class="bar bar-income" style="height: {$income_pct}%;">
                                                    <div class="bar-value">{$income_display}</div>
                                                </div>
                                                <div class="bar bar-expense" style="height: {$expense_pct}%;">
                                                    <div class="bar-value">{$expense_display}</div>
                                                </div>
                                            </div>
                                            <div class="bar-label">{$months[$month_index]} {$year_label}</div>
                                        </div>
                                    HTML;
                            }
                            ?>
                        </div>
                        <div class="bar-chart-legend">
                            <div class="bar-chart-legend-item">
                                <span class="bar-chart-legend-dot" style="background-color: #00A3A3;"></span>
                                Income
                            </div>
                            <div class="bar-chart-legend-item">
                                <span class="bar-chart-legend-dot" style="background-color: #FF5252;"></span>
                                Expenses
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Top Expenses -->
                <div class="col-12 col-lg-5">
                    <div class="section-header"><i class="bi bi-pie-chart me-2"></i>Top Expenses</div>
                    <div class="manage-box shadow-sm">
                        <h5 class="mb-3">Biggest Outflows This Month</h5>

                        <?php
                            //Gets total of expenses
                            $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Marketing", "Payroll", "Invoice");
                            $expenses_total = array();

                            //Gets total of expenses
                            foreach ($expenses_category as $category) {

                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                                $query = $conn->query($sql);
                                $expense = $query->fetch_object();

                                //Adds total to array
                                $expenses_total[] = $expense->total;
                            }

                            //gets the highest value in the expense array
                            $max_expense = max($expenses_total);
                            for ($i = 0; $i < 8; $i++) {
                                $expense_percentage = ($expenses_total[$i] / $max_expense) * 100;
                                echo <<<HTML
                                        <div class="expense-row">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span>{$expenses_category[$i]}</span>
                                                <span class="fw-bold">₱{$expenses_total[$i]}</span>
                                            </div>
                                            <div class="expense-bar-track">
                                                <div class="expense-bar-fill" style="width: {$expense_percentage}%;"></div>
                                            </div>
                                        </div>
                                    HTML;
                            }
                        ?>


                    </div>
                </div>
            </div>

            <!-- Recent Activity Feed -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header"><i class="bi bi-clock-history me-2"></i>Recent Transactions</div>
                    <div class="manage-box shadow-sm">
                        <div class="activity-feed">

                            <?php
                                $sql = "SELECT * FROM transactions WHERE date = CURDATE()";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                        <div class="activity-item">
                                            <div class="activity-icon out">';
                                    if ($set->type == "Income") {
                                        echo '
                                                <div class="activity-icon in">
                                                    <span class="icon-arrow icon-arrow-up"></span>
                                                </div>
                                            ';
                                    } else {
                                        echo '
                                                <div class="activity-icon out">
                                                    <span class="icon-arrow icon-arrow-down"></span>
                                                </div>
                                            ';
                                    }

                                    date_default_timezone_set('Asia/Manila');
                                    $current_time = date('H:i:s');


                                    $trans_time = new DateTime($set->time);
                                    $current_time = new DateTime($current_time);

                                    //This will check if the time in is NOT past the the shift end
                                    if ($trans_time < $current_time) {

                                        //Gets the time difference between current time and time of transactions
                                        $interval_minutes = $trans_time->diff($current_time);

                                        //For hours
                                        $hour_difference = $interval_minutes->h;

                                        //For minutes
                                        $minute_difference = $interval_minutes->i;

                                        if ($hour_difference == 0) {
                                            $timeline = $minute_difference . " minute ago";
                                        } else {
                                            $timeline = $hour_difference . " hour ago";
                                        }
                                    }

                                    echo '
                                            </div>
                                            <div>
                                                <p class="activity-title mb-0">' . $set->description . '</p>
                                                <p class="activity-time mb-0">' . $timeline . '</p>
                                            </div>';

                                    if ($set->type == "Income") {
                                        echo '<div class="activity-amount green-text">+₱' . $set->amount . '</div>';
                                    } else {
                                        echo '<div class="activity-amount" style="color: #FF5252;">-₱' . $set->amount . '</div>';
                                    }


                                    echo '    
                                            </div>
                                        ';
                                }


                            ?>





                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Finance Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>