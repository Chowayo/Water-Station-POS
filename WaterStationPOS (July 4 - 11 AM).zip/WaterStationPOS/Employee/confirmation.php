<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Confirmation</title>


    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include 'navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">
        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-center align-items-center gap-3">
                <img src="../Images/logo.png" alt="Logo" class="header-logo">
                <div class="text-center">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Delivery & Order Confirmation</h6>
                </div>
            </header>

            <div class="box mt-2">
                <div class="d-flex flex-wrap gap-2 justify-content-between mb-3 align-items-center">
                    <h5 class="mb-0 fw-bold">Active Deliveries</h5>

                    <div class="input-group table-search-input">
                        <input type="text" class="form-control" placeholder="Search Order" id="searcher">
                    </div>
                </div>
                <script>
                    $(document).ready(function() {
                        var table = $('#order_list').DataTable({
                            paging: false, // Enable pagination
                            searching: true, // Enable search functionality
                            dom: 't' //Removes the built in search from datatables
                        });

                        $('#searcher').on('keyup change clear', function() {
                            table.search(this.value).draw(); //Sets the input box as the new search bar
                        });


                    });
                </script>

                <div class="table-responsive">
                    <table class="table table-hover text-center mb-0 align-middle" id="order_list">
                        <thead>
                            <tr>
                                <th>Order Number</th>
                                <th>Customer Name</th>
                                <th>Order Content</th>
                                <th>Total</th>
                                <th>Payment Method</th>
                                <th>Order Type</th>
                                <th>Time</th>
                                <th>Date</th>
                                <th>Actions</th>
                                <th>View Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Row 1: Pending Order -->
                            <?php
                            //Loading employee list
                            $sql = "SELECT * FROM orders";
                            $query = $conn->query($sql);
                            while ($set = $query->fetch_object()) {
                                echo '
                                        <tr>
                                            <td class="cyan-text fw-bold">#' . $set->id . '</td>
                                            <td style="overflow-wrap: break-word; max-width: 320px;"><strong class="d-block">' . $set->customer_name . '</strong></td>
                                            <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>' . $set->order_content . '</b></td>
                                            <td class="green-text fw-bold fs-5">₱' . $set->total_price . '</td>
                                            <td><span class="badge bg-' . $set->payment_method . '">' . $set->payment_method . '</span></td>
                                            <td>' . $set->order_type . '</td>
                                            <td>' . $set->time . '</td>
                                            <td>' . $set->date . '</td>
                                        ';
                                if ($set->status == "Not received") {
                                    echo '
                                            <td>
                                                <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn" data-id="' . $set->id . '" id="btn-confirm">Order Pending</button>
                                            </td>';
                                } else {
                                    echo '
                                            <td>
                                                <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn">Order Received</button>
                                            </td>';
                                }
                                echo '
                                        <td>
                                            <form method="POST"><button type="submit" name="receipt" value="' . $set->id . '" class="btn btn-dark btn-sm rounded-pill px-3">Open</button></form>
                                        </td>
                                    </tr>';
                            }

                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                //Remove Account
                                if (isset($_POST['confirm'])) {
                                    $sql = "UPDATE `orders` SET `status` = 'Received' WHERE id = " . $_POST['confirm'];
                                    if ($conn->query($sql) === TRUE) {
                                        echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Order Received!',
                                                        text: 'The order has been completed.',
                                                        background: '#FFFFFF',
                                                        color: '#2D3748',
                                                        confirmButtonColor: '#00A859',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('confirmation.php');
                                                        }});
                                                })
                                            </script> 
                                            HTML;
                                    }
                                }
                                if (isset($_POST['receipt'])) {
                                    $sql = "SELECT * FROM orders WHERE id=" . $_POST['receipt'];
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {

                                        //Breakdowns the string and makes it into an array
                                        $order_list = explode(",", $set->order_content);
                                        foreach ($order_list as $content) {

                                            //Sets Price on receipt
                                            if (preg_match('/(?<=₱)[^\sV]+/i', $content, $matches)) {
                                                $price = $matches[0];
                                            }

                                            //Sets value for tax
                                            $tax = substr($content, (strpos($content, ":")+1));
                                            $tax = (float)$tax * (float)$price ;
                                            

                                            //Cuts Price/Tax section of receipt
                                            $content = substr_replace($content, "", strpos($content, "₱"), 50);
                                            echo <<<HTML
                                                            <script>
                                                                $(document).ready(function() {
                                                                    $("#bill-list").prepend(`
                                                                        <div class="receipt-grid mb-2" style="display: grid; grid-template-columns: 4fr auto; align-items: start; gap: 15px; max-width: 450px; width: 100%;">
                                                                            <p>{$content}</p>
                                                                            <p class="price">₱{$price}</p>
                                                                            <p>VAT: {$tax}</p>
                                                                        </div>
                                                                    `);
                                                                });
                                                            </script>
                                                        HTML;
                                        }
                                    }

                                    $sql = "SELECT * FROM orders WHERE id=" . $_POST['receipt'];
                                    $query = $conn->query($sql);
                                    $result = $query->fetch_object();

                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        //Shows Receipt after of loop
                                                        $('#receiptModal').modal('show');    
                                                    });
                                                </script>
                                                HTML;
                                }
                            }

                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </main>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $(document).ready(function() {
            //Confirming Delivery
            $(".confirm-btn").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Confirm Delivery?',
                    text: "Has the customer received the water and settled the payment?",
                    icon: 'question',
                    background: '#FFFFFF',
                    color: '#2D3748',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="confirm" value="' + id + '" class="btn btn-confirm">Confirm Order</button></form>',
                    heightAuto: false
                })
            });

            $(".done-btn").click(function() {
                Swal.fire({
                    title: 'Order Complete',
                    text: "The order has been received",
                    icon: 'success',
                    background: '#FFFFFF',
                    confirmButtonColor: '#00A859',
                    color: '#2D3748',
                    showConfirmButton: true,
                    heightAuto: false
                })
            });

            //Logout
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>






    <!-- Receipt -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>#<?php echo $result->id; ?></strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>
                                <?php
                                date_default_timezone_set('Asia/Manila');
                                echo "Time:" . date("h:iA");
                                ?>
                            </p>
                            <p>
                                <?php
                                echo "Cashier:" . $result->cashier;
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Name: <?php echo $result->customer_name; ?></p>
                        <p>Phone: <?php echo $result->customer_contact; ?></p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Address: <?php echo $result->customer_address; ?></p>
                        <p>Payment Method: <?php echo $result->payment_method; ?> </p>
                        <p>Order Type: <?php echo $result->order_type; ?> </p>

                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>
                        <!--Dito naka lagay yung mga custom part ng receipt-->
                        <div id="bill-list">

                        </div>
                        <div class="receipt-divider"></div>
                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>VAT TOTAL:</p>
                            <p>₱<?php echo $result->total_vat; ?></p>
                        </div>
                        <div class="receipt-divider"></div>
                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱<?php echo $result->total_price; ?>0</p>
                        </div>


                    </div>

                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()">Print Receipt</button>
                </div>

            </div>
        </div>
    </div>
</body>

</html>