<!DOCTYPE html>
<html lang="en">

<?php
require(__DIR__ . '/../dbConn.php');
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>
</head>

<head>
    <title>HR Dashboard - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <img src="../Images/logo.png" alt="Logo" class="header-logo">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>HR Dashboard</h6>
                    </div>
                </div>
            </header>

            <div class="row g-4 mb-4 justify-content-center">

                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Total Employees</div>
                        <div class="dash-value green-text">24</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Pending Leave Requests</div>
                        <div class="dash-value">3</div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Present Today</div>
                        <div class="dash-value cyan-text">19</div>
                    </div>
                </div>

            </div>

            <!-- Recent Leave Requests -->
            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header">Recent Leave Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
                            <h5 class="mb-0 pt-1">Latest Submissions</h5>
                            <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#leave_list').DataTable({
                                    paging: false,
                                    searching: true,
                                    dom: 't'
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });
                            });
                        </script>

                        <div class="table-responsive">
                            <table class="table table-dark table-hover text-center mb-0 align-middle" id="leave_list">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Leave Type</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Reason</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong class="d-block">Luz</strong></td>
                                        <td>Sick Leave</td>
                                        <td>07/10/2026</td>
                                        <td>07/11/2026</td>
                                        <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">Fever and flu symptoms</td>
                                        <td><span class="badge bg-warning text-dark">Pending</span></td>
                                        <td>
                                            <button class="btn btn-confirm btn-sm rounded-pill px-3">Approve</button>
                                            <button class="btn btn-delete btn-sm rounded-pill px-3">Reject</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong class="d-block">Maybelle</strong></td>
                                        <td>Vacation Leave</td>
                                        <td>07/15/2026</td>
                                        <td>07/18/2026</td>
                                        <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 200px;">Family trip</td>
                                        <td><span class="badge bg-success">Approved</span></td>
                                        <td>
                                            <button class="btn btn-closed btn-sm rounded-pill px-3" disabled>Already Approved</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of HR Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>