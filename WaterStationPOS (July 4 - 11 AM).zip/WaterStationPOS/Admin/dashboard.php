<?php

include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Admin Dashboard - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <img src="../Images/logo.png" alt="Logo" class="header-logo">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Admin Dashboard</h6>
                    </div>
                </div>
            </header>

            <div class="row g-4 mb-4 justify-content-center">

                <div class="col-md-4">

                    <?php
                    $curdate = date('m/d/Y');
                    $sql = "SELECT total_price FROM orders WHERE date ='" . $curdate . "'";
                    $query = $conn->query($sql);
                    $daily_profit = 0;
                    $daily_orders = 0;
                    while ($set = $query->fetch_object()) {
                        $daily_profit += $set->total_price;
                        $daily_orders += 1;
                    }
                    ?>
                    <div class="dash-card text-center">
                        <div class="dash-title">Todays Income</div>
                        <div class="dash-value green-text">₱<?php echo ($daily_profit); ?></div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Total Purchases Today</div>
                        <div class="dash-value"><?php echo ($daily_orders); ?></div>
                    </div>
                </div>

            </div>

            <div class="row g-4">
                <div class="col-12">
                    <div class="section-header">Recent Sales Report</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between mb-3">
                            <h5 class="mb-0 pt-1">Today's Transactions</h5>
                            <input type="text" class="form-control table-search-input" placeholder="Search Order" id="searcher">
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#order_list').DataTable({
                                    paging: false, // Enable pagination
                                    searching: true, // Enable search functionality
                                    dom: 't' //Removes the built in search from datatables
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw(); //Sets the input box as the new search bar
                                });


                            });
                        </script>

                        <div class="table-responsive">
                            <table class="table table-dark table-hover text-center mb-0 align-middle" id="order_list">
                                <thead>
                                    <tr>
                                        <th>Order Number</th>
                                        <th>Customer Name</th>
                                        <th>Order Content</th>

                                        <th>Total</th>
                                        <th>Payment Method</th>
                                        <th>Order Type</th>
                                        <th>Time</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Row 1: Pending Order -->
                                    <?php
                                    //Loading employee list
                                    $sql = "SELECT * FROM orders";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo '
                                                <tr>
                                                    <td class="cyan-text fw-bold">#' . $set->id . '</td>
                                                    <td><strong class="d-block">' . $set->customer_name . '</strong></td>
                                                    <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>' . $set->order_content . '</b></td>
                                                    <td class="green-text fw-bold fs-5">₱' . $set->total_price . '</td>
                                                    <td><span class="badge bg-' . $set->payment_method . '">' . $set->payment_method . '</span></td>
                                                    <td>' . $set->order_type . '</td>
                                                    <td>' . $set->time . '</td>
                                                    <td>' . $set->date . '</td>
                                                ';
                                        if ($set->status == "Not received") {
                                            echo '
                                                    <td>
                                                        <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn" data-id="' . $set->id . '" id="btn-confirm">Order Pending</button>
                                                ';
                                        } else {
                                            echo '
                                                    <td>
                                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn">Order Received</button>
                                                ';
                                        }
                                        echo '
                                                    <button class="btn btn-delete btn-sm rounded-pill px-3 delete-btn" data-id="' . $set->id . '" id="btn-confirm">Delete Order</button>
                                                </td>
                                            </tr>

                                            ';
                                    }

                                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                        //Remove Account
                                        if (isset($_POST['confirm'])) {
                                            $sql = "UPDATE `orders` SET `status` = 'Received' WHERE id = " . $_POST['confirm'];
                                            if ($conn->query($sql) === TRUE) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Order Received!',
                                                                            text: 'The order has been completed.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00A859',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('dashboard.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        }

                                        if (isset($_POST['deleter'])) {
                                            $sql = "DELETE FROM orders WHERE id = " . $_POST['deleter'];
                                            if ($conn->query($sql) === TRUE) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Order Deleted!',
                                                                            text: 'The order has been removed.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('dashboard.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            //Confirming Delivery
            $(".confirm-btn").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Confirm Delivery?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="confirm" value="' + id + '" class="btn btn-confirm">Confirm Order</button></form>',
                    heightAuto: false
                })
            });

            $(".done-btn").click(function() {
                Swal.fire({
                    title: 'Order Complete',
                    text: "The order has been received",
                    icon: 'success',
                    background: '#112240',
                    confirmButtonColor: '#00A859',
                    color: '#CCD6F6',
                    showConfirmButton: true,
                    heightAuto: false
                })
            });

            //Delete Order
            $(".delete-btn").click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Delete Order?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-delete">Confirm Delete</button></form>',
                    heightAuto: false
                })
            });

            // Logout SweetAlert
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>