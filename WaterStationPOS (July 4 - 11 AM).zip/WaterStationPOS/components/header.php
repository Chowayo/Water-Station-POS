<!DOCTYPE html>
<html lang="en">

<?php
require(__DIR__ . '/../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:./index.php');
}

if (isset($_SESSION['users']) && ucfirst(substr($_SESSION['users']->email, 0, 5)) != "Admin") {
    header('location: /Employee/home.php');
    exit;
}

$user = $_SESSION['users'];

?>

<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>

    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>