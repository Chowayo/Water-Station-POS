<?php
$current_section = basename(dirname($_SERVER['SCRIPT_NAME']));

if ($current_section === 'Hr') {
    $nav_items = [
        'dashboard.php'         => 'Dashboard',
        '../Admin/employees.php' => 'Accounts',
        'attendance.php'        => 'Attendance',
        'leaverequests.php'     => 'Leave Requests',
    ];
    $sidebar_label   = 'HR DEPARTMENT';
    $profile_target  = '#adminProfileModal';
} else {
    //Admin section
    $nav_items = [
        'dashboard.php' => 'Dashboard',
        'employees.php' => 'Employees',
        'products.php'  => 'Products',
    ];
    $sidebar_label  = 'ADMINISTRATOR';
    $profile_target = '#adminProfileModal';
}

$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">

        <div class="profile-avatar-wrap text-center">
            <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="<?php echo $profile_target; ?>" aria-label="Open profile">
                <img>
            </button>
        </div>

        <div class="px-3 mb-3">
            <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;"><?php echo $sidebar_label; ?></p>
        </div>

        <nav class="nav flex-column px-2">

            <hr class="mx-3 border-secondary mt-0">

            <?php foreach ($nav_items as $link => $label): ?>
                <a class="menu-link <?php echo $current_page === $link ? 'active' : ''; ?>" href="<?php echo $link; ?>"><?php echo $label; ?></a>
            <?php endforeach; ?>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout ➜]</a>
    </aside>

    <?php include __DIR__ . '/profile.php'; ?>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }
    </script>