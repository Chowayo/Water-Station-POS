<?php

include "header.php";

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    #contract_final_list thead th,
    #contract_final_list.dataTable thead th {
        text-align: center !important;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-sent-back {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .contract-term-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
        margin-bottom: 14px;
    }

    .contract-term-card .req-detail-item {
        padding: 8px 0;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Contract Final Approval</h1>
                    <h6>Final checking of negotiated contract terms before an order is placed</h6>
                </div>
            </header>

            <!-- Mock data below is static HTML for UI preview only. Replace with a
                 real query against your contracts table (e.g. stock_request columns
                 for contract_type, payment_terms, sla, valid_until, final_cost,
                 contract_status) once the backend for this step is ready. -->

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Final Approval</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Negotiation Approved'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Contract Approved'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Sent Back</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Send Back'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Contract Value</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT SUM(final_cost) AS total FROM stock_request WHERE deleted ='False' AND status = 'Negotiation Approved'";
                            $query = $conn->query($sql);
                            if ($query && $row = $query->fetch_object()) {
                                if (empty($row->total)) {
                                    $pending_value = 0;
                                } else {
                                    $pending_value = $row->total;
                                }
                            } else {
                                $pending_value = 0;
                            }

                            echo '₱'.$pending_value;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Contracts Awaiting Final Sign-off</div>
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Final Checking Before Order</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="contractStatusFilter" style="width: 190px;">
                                    <option value="">All Status</option>
                                    <option value="Pending Final Approval">Pending Final Approval</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Sent Back">Sent Back</option>
                                </select>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var contractTable = $('#contract_final_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: false,
                                    ordering: false,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                                });

                                $('#contractStatusFilter').on('change', function() {
                                    contractTable.column(6).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="contract_final_list">
                            <thead>
                                <tr>
                                    <th>Product Order No.</th>
                                    <th>Request ID</th>
                                    <th>Supplier</th>
                                    <th>Category</th>
                                    <th>Payment Method</th>
                                    <th>Final Cost</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM stock_request WHERE deleted = 'False' AND status = 'Negotiation Approved' OR status = 'Send Back' OR status = 'Contract Approved' ORDER BY id DESC";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo'
                                        <tr>
                                            <td>PO-'.$set->order_number.'</td>
                                            <td>REQ-'.$set->id.'</td>
                                            <td>'.$set->supplier_name.'</td>
                                            <td><span class="category-chip">'.ucfirst($set->category).'</span></td>
                                            <td>'.$set->payment_method.'</td>
                                            <td>₱'.$set->final_cost.'</td>';

                                if($set->status=="Negotiation Approved"){
                                    echo'
                                        <td><span class="status-badge status-pending">Pending Final Approval</span></td>
                                        <td>
                                            <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review-contract"
                                                data-number="'.$set->id.'"
                                                data-id="REQ-'.$set->id.'"
                                                data-supplier="'.$set->supplier_name.'"
                                                data-category="'.ucfirst($set->category).'"
                                                data-contract-type="REMOVE"
                                                data-payment-terms="'.$set->payment_method.'"
                                                data-sla="'.$set->delivery_commitment.'"
                                                data-valid-until="REMOVED"
                                                data-final-cost="'.$set->final_cost.'"
                                                data-notes="'.$set->negotiation_note.'">
                                                <i class="bi bi-clipboard-check me-1"></i>Final Check
                                            </button>
                                        </td>';
                                }

                                else if($set->status=="Send Back"){
                                    echo'
                                        <td><span class="status-badge status-sent-back"><i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back</span></td>
                                        <td>
                                            <button class="btn btn-confirm btn-sm rounded-pill px-3" disabled>
                                                <i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back
                                            </button>
                                        </td>
                                    
                                    ';
                                }

                                else if($set->status=="Contract Approved"){
                                    echo'
                                        <td><span class="status-badge status-approved"><i class="bi bi-check-circle me-1"></i>Approved</span></td>
                                        <td>
                                            <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                <i class="bi bi-check-circle me-1"></i>Approved
                                            </button>
                                        </td>
                                    ';
                                }
                                echo'
                                        </tr>
                                    ';

                                }

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                    // Add Request
                                    if (isset($_POST['contract_update'])) {
                                        $final_finance_note = $_POST['final_finance_note'];
                                        $id = $_POST['id'];
                                        echo <<<HTML
                                            <script>
                                                console.log("{$final_finance_note}");
                                                console.log("{$_POST['contract_update']}");
                                                console.log("{$id}");
                                            </script>
                                        HTML;

                                        $sql = "UPDATE `stock_request` SET `status` = ?, final_finance_note = ? WHERE id = '" . $id . "'";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("ss", $_POST['contract_update'], $final_finance_note);
                                        if ($stmt->execute()) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Contract Updated!',
                                                                    text: '',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00E676',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('contract.php');
                                                                    }});
                                                            })
                                                            
                                                        </script> 
                                                    HTML;
                                        }


                                    }

                                }

                                ?>
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Final Contract Approval Modal -->
            <div class="modal fade" id="reviewContractModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">
                        <div class="modal-header">
                            <h5 class="modal-title">Final Contract Approval — <span id="reviewContractReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                <div>
                                    <span class="fw-semibold d-block" id="reviewContractSupplier">Supplier</span>
                                    <span class="category-chip" id="reviewContractCategory">Category</span>
                                </div>
                                <div class="text-end">
                                    <div class="small" style="color:#8892B0;">Final Cost</div>
                                    <span class="fw-bold fs-5" id="reviewContractCost">₱0.00</span>
                                </div>
                            </div>

                            <div class="contract-term-card">
                                <div class="req-detail-item">
                                    <span>Payment Terms</span>
                                    <span id="reviewContractPaymentTerms">—</span>
                                </div>
                                <div class="req-detail-item">
                                    <span>Supplier SLA</span>
                                    <span id="reviewContractSla">—</span>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small">Negotiation Notes</label>
                                <textarea class="form-control" id="reviewContractNotes" rows="2" disabled></textarea>
                            </div>
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Finance Sign-off Notes</label>
                                    <textarea class="form-control" name="final_finance_note" id="reviewContractFinanceNotes" rows="2" placeholder="Required if sending back for revision"></textarea>
                                    <input type="text" name="id" id="reviewContractId" hidden>
                                </div>

                            </div>
                            <div class="modal-footer flex-wrap">
                                <button type="submit" name="contract_update" value="Send Back" class="btn btn-remove rounded-pill px-4" id="btnContractSendBack">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>Send Back
                                </button>
                                <button type="submit" name="contract_update" value="Contract Approved" class="btn btn-confirm rounded-pill px-4" id="btnContractApprove">
                                    <i class="bi bi-check-lg me-1"></i>Approve Contract
                                </button>

                            </form>

                            
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        function formatPeso(amount) {
            return '₱' + amount.toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        $(document).ready(function() {

            var $activeContractRow = null;

            $(document).on('click', '.btn-review-contract', function() {
                var $btn = $(this);
                $activeContractRow = $btn.closest('tr');

                $('#reviewContractReqId').text($btn.data('id'));
                $('#reviewContractId').val($btn.data('number'));
                $('#reviewContractSupplier').text($btn.data('supplier'));
                $('#reviewContractCategory').text($btn.data('category'));
                $('#reviewContractType').text($btn.data('contract-type'));
                $('#reviewContractPaymentTerms').text($btn.data('payment-terms') === 'COD' ? 'Cash on Delivery' : $btn.data('payment-terms'));
                $('#reviewContractSla').text($btn.data('sla'));
                $('#reviewContractValidUntil').text($btn.data('valid-until'));
                $('#reviewContractNotes').val($btn.data('notes') || 'No additional notes.');
                $('#reviewContractFinanceNotes').val('');
                $('#reviewContractCost').text(formatPeso(parseFloat($btn.data('final-cost'))));

                $('#reviewContractModal').modal('show');
            });

            function setContractStatus(label, statusClass, icon) {
                if (!$activeContractRow) return;

                $activeContractRow.find('td').eq(6)
                    .html('<span class="status-badge ' + statusClass + '"><i class="bi ' + icon + ' me-1"></i>' + label + '</span>');

                var $actionCell = $activeContractRow.find('td').eq(7);
                if (label === 'Approved') {
                    $actionCell.html('<button class="btn btn-edit btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-check-circle me-1"></i>Approved</button>');
                } else {
                    $actionCell.html('<button class="btn btn-confirm btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back</button>');
                }
            }

            $('#btnContractApprove').click(function() {
                setContractStatus('Approved', 'status-approved', 'bi-check-circle');
                $('#reviewContractModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Contract Approved',
                    text: 'Finance has signed off — procurement can proceed to order.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnContractSendBack').click(function() {
                if (!$('#reviewContractFinanceNotes').val().trim()) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Note Required',
                        text: 'Please explain why this contract is being sent back.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                setContractStatus('Sent Back', 'status-sent-back', 'bi-arrow-counterclockwise');
                $('#reviewContractModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Sent Back for Revision',
                    text: 'Procurement will be notified to renegotiate the contract terms.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>