<?php 
    include "header.php"; 
?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-ordered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64ffda;
        border: 1px solid #64ffda;
    }

    /* Budget check indicators */
    .budget-ok {
        color: #00e676;
        font-weight: 700;
    }

    .budget-over {
        color: #ff5252;
        font-weight: 700;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* Request detail list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    /* Budget usage bar */
    .budget-bar-wrap {
        background-color: #0A192F;
        border-radius: 8px;
        height: 8px;
        overflow: hidden;
        margin-top: 6px;
    }

    .budget-bar-fill {
        height: 100%;
        border-radius: 8px;
    }

    .budget-bar-fill.ok {
        background-color: #00e676;
    }

    .budget-bar-fill.warn {
        background-color: #ffc107;
    }

    .budget-bar-fill.over {
        background-color: #ff5252;
    }

    .cost-centre-card {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 12px;
        padding: 14px 16px;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Request Approvals</h1>
                    <h6>Review requisitions against budget and approve or reject</h6>
                </div>
            </header>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Awaiting Review</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Pending'";
                                $query = $conn->query($sql);
                                $currents_pending = $query->fetch_object();

                                if ($currents_pending != "") {
                                    echo $currents_pending->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved This Month</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Approved' OR status = 'Supplier Approved'";
                                $query = $conn->query($sql);
                                $approved_month = $query->fetch_object();

                                if ($approved_month!= "") {
                                    echo $approved_month->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Rejected This Month</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Rejected' ";
                                $query = $conn->query($sql);
                                $reject_month = $query->fetch_object();

                                if ($reject_month!= "") {
                                    echo $reject_month->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Value</div>
                        <div class="dash-value">
                            <?php
                                $sql = "SELECT SUM(cost) AS total FROM stock_request WHERE deleted ='False' AND status = 'Pending'";
                                $query = $conn->query($sql);
                                $pending_value = $query->fetch_object();

                                // Safely format the total, defaulting to 0 if total is NULL
                                $total = $pending_value->total ?? 0;

                                echo "₱" . number_format($total, 2);
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Budget Overview -->
            <div class="section-header">Budgets (This Month)</div>
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Supplies</span>
                            <span style="color: #8892B0;">
                                <?php
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Supplies'";
                                    $query = $conn->query($sql);
                                    $supplies_total = $query->fetch_object();

                                    if ($supplies_total != "") {
                                        echo "₱" . $supplies_total->total . "/ ₱20,000";
                                        $supplies_percent = ($supplies_total->total / 20000) * 100;
                                    } else {
                                        echo "₱0.00 / ₱20,000";
                                    }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill ok" style="width: <?php echo $supplies_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Maintenance</span>
                            <span style="color: #8892B0;">
                                <?php
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Maintenance'";
                                    $query = $conn->query($sql);
                                    $maintenance_total = $query->fetch_object();

                                    if ($maintenance_total != "") {
                                        echo "₱" . $maintenance_total->total . "/ ₱10,000";
                                        $maintenance_percent = ($maintenance_total->total / 10000) * 100;
                                    } else {
                                        echo "₱0.00 / ₱10,000";
                                    }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill warn" style="width: <?php echo $maintenance_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="cost-centre-card">
                        <div class="d-flex justify-content-between small mb-0">
                            <span class="fw-bold">Transportation/Fuel</span>
                            <span style="color: #8892B0;">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Transport/Fuel'";
                                $query = $conn->query($sql);
                                $transport_total = $query->fetch_object();

                                if ($transport_total != "") {
                                    echo "₱" . $transport_total->total . "/ ₱5,000";
                                    $transport_percent = ($transport_total->total / 5000) * 100;
                                } else {
                                    echo "₱0.00 / ₱5,000";
                                }
                                ?>
                            </span>
                        </div>
                        <div class="budget-track">
                            <div class="budget-bar-fill over" style="width: <?php echo $transport_percent ?>%;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Request Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="statusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                </select>
                                <!--<select class="form-select" id="centreFilter" style="width: 170px;">
                                    <option value="">Category</option>
                                    <option value="Supplies">Supplies</option>
                                    <option value="Maintenance">Maintenance</option>
                                    <option value="Delivery">Delivery</option>
                                </select>-->
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Request" id="searcher">
                                </div>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#request_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>',
                                    "order": [[ 0, "desc" ]]
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#statusFilter').on('change', function() {
                                    table.column(6).search(this.value).draw();
                                });

                                $('#centreFilter').on('change', function() {
                                    table.column(3).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="request_list">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Requested By</th>
                                    <th>Date Requested</th>
                                    <th>Category</th>
                                    <th>Items</th>
                                    <th>Est. Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sql = "SELECT * FROM stock_request WHERE deleted = 'False' AND status = 'Pending' OR status = 'Approved' OR status = 'Ordered' OR status = 'Rejected' OR status = 'Cancelled Negotiation' ORDER BY id DESC";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        $pattern = '/([A-Za-z0-9\s-]+?)\s+x(\d+)\s+P([\d.]+)/';
                                        preg_match_all($pattern, $set->items, $matches, PREG_SET_ORDER);
                                        $parsed_items = [];
                                        foreach ($matches as $match) {
                                            $parsed_items[] = [
                                                'name'     => trim($match[1]),
                                                'quantity' => (int)$match[2],
                                                'price'    => round((float)$match[3], 2)
                                            ];
                                        }
                                        echo'
                                            <tr>
                                                <td>REQ-'.$set->id.'</td>
                                                <td>'.$set->requester.'</td>
                                                <td>'.$set->date_requested.'</td>
                                                <td>'.$set->category.'</td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                                        data-id="REQ-'.$set->id.'"
                                                        data-number="'.$set->id.'">'.count($parsed_items).' items
                                                    </button>
                                                </td>
                                                <td>₱'.$set->cost.'</td>';

                                        if($set->status=="Pending"){
                                            echo '
                                                <td><span class="status-badge status-pending">Pending</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-review"
                                                        data-id="REQ-0001" data-number="'.$set->id.'" data-centre="Supplies" data-budget="within">
                                                        <i class="bi bi-clipboard-check me-1"></i>Review
                                                    </button>
                                                </td>
                                            ';

                                        }
                                        else if($set->status=="Approved"){
                                            echo'
                                                <td><span class="status-badge status-approved">Approved</span></td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-truck me-1"></i>Approved
                                                    </button>
                                                </td>
                                            ';

                                        }
                                        else if($set->status=="Supplier Approved"){
                                            echo'
                                                <td><span class="status-badge status-approved">Supplier Approved</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-negotiate"
                                                        data-id="REQ-'.$set->id.'"
                                                        data-supplier="HydroChem Philippines"
                                                        data-category="Chemicals"
                                                        data-range="₱125.00 – ₱320.00">
                                                        <i class="bi bi-chat-dots me-1"></i>Negotiate
                                                    </button>
                                                </td>
                                            ';

                                        }
                                        else if($set->status=="Ordered"){
                                            echo'
                                                <td><span class="status-badge status-ordered">Ordered</span></td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-truck me-1"></i>Ordered
                                                    </button>
                                                </td>
                                            ';

                                        }
                                        else if($set->status=="Rejected"){
                                            echo'
                                                <td><span class="status-badge status-rejected">Rejected</span></td>
                                                <td>
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-x-circle me-1"></i>Rejected
                                                    </button>
                                                </td>
                                            ';
                                        }

                                        else if($set->status=="Cancelled Negotiation"){
                                            echo'
                                                <td><span class="status-badge status-rejected">Cancelled Negotiation</span></td>
                                                <td>
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-x-circle me-1"></i>Cancelled Negotiation
                                                    </button>
                                                </td>
                                            ';
                                        }

                                        //Review per Items
                                        echo'
                                            </tr><div class="modal fade" id="viewRequestModal-'.$set->id.'" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content shadow-lg">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Request Details — <span id="viewReqId">REQ-'.$set->id.'</span></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">';
                                        for($i=0; $i<count($parsed_items); $i++){
                                            echo '<div class="req-detail-item">
                                                    <span>'.$parsed_items[$i]['name'].' x'.$parsed_items[$i]['quantity'].'</span>
                                                    <span>₱'.number_format($parsed_items[$i]['price'], 2).'</span>
                                                </div>';
                                        }
                                        echo' <div class="req-total-box d-flex justify-content-between align-items-center mt-3">
                                                                <span class="fw-semibold">Total</span>
                                                                <span class="fw-bold fs-5">₱'.number_format($set->cost, 2).'</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ';
                                        echo'
                                            <div class="modal fade" id="reviewRequestModal-'.$set->id.'" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content shadow-lg">

                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Review Request — <span id="reviewReqId">REQ-'.$set->id.'</span></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">';
                                        for($i=0; $i<count($parsed_items); $i++){
                                            echo '<div class="req-detail-item">
                                                    <span>'.$parsed_items[$i]['name'].' x'.$parsed_items[$i]['quantity'].'</span>
                                                    <span>₱'.number_format($parsed_items[$i]['price'], 2).'</span>
                                                </div>';
                                        }
                                        echo '
                                                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                                                <span class="fw-semibold">Requested Total</span>
                                                                <span class="fw-bold fs-5">₱'.number_format($set->cost, 2).'</span>
                                                            </div>

                                                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                                                <span class="fw-semibold" style="color:#8892B0;">Budget</span>
                                                                <span id="reviewCentreLabel">Supplies — ₱10,000.00 / mo</span>
                                                            </div>

                                                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                                                <span class="fw-semibold" style="color:#8892B0;">Budget Status</span>';

                                        $approved = True;
                                        $sqls = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='Supplies'";
                                        $querys = $conn->query($sqls);
                                        $supplies_total = $querys->fetch_object();

                                        if ($supplies_total != "") {
                                            if(($supplies_total->total + $set->cost)>20000){
                                                $approved = False;
                                            }
                                            
                                        } else {
                                            if((0 + $set->cost)>20000){
                                                $approved = False;
                                            }
                                        }
                                        

                                        if($approved){
                                            echo '
                                                                <span id="reviewBudgetStatus" class="budget-ok"><i class="bi bi-check-circle-fill me-1"></i>Within Budget</span>';

                                        }
                                        else{echo '
                                                                <span id="reviewBudgetStatus" class="budget-ok"><i class="bi bi-x-circle-fill text-danger"></i>Out of Budget</span>';
                                        }
                                        echo'               </div>
                                                            <form method="POST">
                                                                <div class="mb-3">
                                                                    <label class="form-label">Rejection / Approval Notes</label>
                                                                    <textarea class="form-control" name="finance_note" rows="2" placeholder="Required if rejecting or requesting reallocation"></textarea>
                                                                </div>
                                                                <input type="number" value="'.$set->id.'" name="id" hidden>

                                                                <div class="modal-footer flex-wrap">
                                                                    <button type="submit" name="review" value="Rejected" class="btn btn-remove rounded-pill px-4">
                                                                        <i class="bi bi-x-lg me-1"></i>Reject
                                                                    </button>';
                                        if($approved){
                                            echo '
                                                                    <button type="submit" name="review" value="Approved" class="btn btn-confirm rounded-pill px-4">
                                                                        <i class="bi bi-check-lg me-1"></i>Approve
                                                                    </button>';}                                                                    
                                        echo'                   </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        ';


                                        
                                    }

                                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                        // Add Inventory Item
                                        if (isset($_POST['review'])) {
                                            $finance_note = trim($_POST['finance_note']);
                                            $id = trim($_POST['id']);
                                            if($finance_note==""){
                                                $finance_note = $_POST['review']." With no Note";
                                            }

                                            $sql = "UPDATE `stock_request` SET `status` = ?, `finance_note` = ? WHERE id = '" . $id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("ss",  $_POST['review'], $finance_note);

                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'success',
                                                                title: 'Request Updated!',
                                                                text: 'The new request has been Updated.',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                confirmButtonColor: '#00E676',
                                                                heightAuto: false
                                                            }).then((result) => {
                                                                if(result.isConfirmed) {
                                                                    location.assign('requisitions.php');
                                                                }});
                                                        })
                                                    </script> 
                                                HTML;
                                            } 
                                        }
                                    }



                                ?>

                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Review Request Modal -->
            

            <!-- Review Supplier Negotiation Modal -->
            <div class="modal fade" id="reviewSupplierNegotiationModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Review Supplier — <span id="reviewSupplierName">Supplier</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-3 px-1">
                                <span class="fw-semibold" style="color:#8892B0;">Category</span>
                                <span id="reviewSupplierCategory" class="category-chip">Filters</span>
                            </div>

                            <div class="req-detail-item">
                                <span>Recommended By</span>
                                <span id="reviewSupplierRecommender">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Negotiated Payment Terms</span>
                                <span id="reviewSupplierTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="reviewSupplierSla">—</span>
                            </div>

                            <div class="mb-3 mt-3">
                                <label class="form-label small text-muted">Procurement Recommendation Notes</label>
                                <textarea class="form-control" id="reviewSupplierProcNotes" rows="2" disabled></textarea>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Est. Total Cost of Ownership</span>
                                <span class="fw-bold fs-5" id="reviewSupplierCost">₱0.00</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Finance Notes</label>
                                <textarea class="form-control" id="reviewSupplierFinanceNotes" rows="2" placeholder="Required if requesting revision"></textarea>
                            </div>

                            <div class="modal-footer flex-wrap">
                                <button type="button" class="btn btn-remove rounded-pill px-4" id="btnSupplierNeedsRevision">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i>Needs Revision
                                </button>
                                <button type="button" class="btn btn-confirm rounded-pill px-4" id="btnSupplierApprove">
                                    <i class="bi bi-check-lg me-1"></i>Approve
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <script>
        $(document).ready(function() {

            $('.btn-view').click(function() {
                $('#viewReqId').text($(this).data('id'));
                $('#viewRequestModal-'+$(this).data('number')).modal('show');
            });

            $('.btn-review').click(function() {
                var id = $(this).data('id');
                var centre = $(this).data('centre');
                var budget = $(this).data('budget');

                $('#reviewReqId').text(id);
                $('#reviewCentreLabel').text(centre + ' — Monthly Budget');
                

                if (budget === 'over') {
                    $('#reviewBudgetStatus')
                        .removeClass('budget-ok')
                        .addClass('budget-over')
                        .html('<i class="bi bi-exclamation-triangle-fill me-1"></i>Over Budget');
                } else {
                    $('#reviewBudgetStatus')
                        .removeClass('budget-over')
                        .addClass('budget-ok')
                        .html('<i class="bi bi-check-circle-fill me-1"></i>Within Budget');
                }

                //$('#reviewRequestModal').modal('show');
                $('#reviewRequestModal-'+$(this).data('number')).modal('show');
            });

            function formatPeso(amount) {
                return '₱' + amount.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            $('.btn-review-supplier').click(function() {
                var $row = $(this).closest('tr');
                var $btn = $(this);

                $('#reviewSupplierName').text($btn.data('supplier'));
                $('#reviewSupplierCategory').text($btn.data('category'));
                $('#reviewSupplierRecommender').text($btn.data('recommender'));
                $('#reviewSupplierTerms').text($btn.data('terms'));
                $('#reviewSupplierSla').text($btn.data('sla'));
                $('#reviewSupplierProcNotes').val($btn.data('notes'));
                $('#reviewSupplierCost').text(formatPeso(parseFloat($btn.data('cost'))));
                $('#reviewSupplierFinanceNotes').val('');
                $('#reviewSupplierNegotiationModal').data('activeRow', $row);

                $('#reviewSupplierNegotiationModal').modal('show');
            });

            function setSupplierReviewStatus(label, statusClass) {
                var $row = $('#reviewSupplierNegotiationModal').data('activeRow');
                if (!$row) return;

                $row.find('td').eq(5).html('<span class="status-badge ' + statusClass + '">' + label + '</span>');

                var $actionCell = $row.find('td').eq(6);
                if (label === 'Approved') {
                    $actionCell.html('<button class="btn btn-edit btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-check-circle me-1"></i>Approved</button>');
                } else {
                    $actionCell.html('<button class="btn btn-confirm btn-sm rounded-pill px-3" disabled>' +
                        '<i class="bi bi-arrow-counterclockwise me-1"></i>Sent Back</button>');
                }
            }

            $('#btnSupplierApprove').click(function() {
                setSupplierReviewStatus('Approved', 'status-approved');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Supplier Approved',
                    text: 'Procurement can proceed to finalize the contract.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnSupplierNeedsRevision').click(function() {
                setSupplierReviewStatus('Needs Revision', 'status-needs-revision');
                $('#reviewSupplierNegotiationModal').modal('hide');

                Swal.fire({
                    icon: 'info',
                    title: 'Sent Back for Revision',
                    text: 'Procurement will be notified to renegotiate terms.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>