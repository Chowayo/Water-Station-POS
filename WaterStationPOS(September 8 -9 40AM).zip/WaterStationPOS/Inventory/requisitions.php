<?php

//NOTE: ADMIN SIDE NALANG YUNG GAGAMIT NG components since nasisira yung header if doon sya ilalagay
//include __DIR__ . '/../components/header.php'; 
include 'header.php';
require_once __DIR__ . '/../mailer/includes/send_mail.php';

// Emails every active Inventory/Ops staff member with the given subject/body.
function notify_inventory_team($conn, string $subject, string $body): void
{
    $sql = "SELECT email FROM employees WHERE role = 'Inventory' AND deleted = 'False'";
    $query = $conn->query($sql);
    while ($staff = $query->fetch_object()) {
        if ($staff->email) {
            send_email($staff->email, $subject, $body);
        }
    }
}

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

// Normalizes any raw category string (e.g. "caps", "container", "Chemicals")
// into one of the canonical filter keys used by the supplier filter chips.
function normalize_category_key($raw)
{
    $key = rtrim(strtolower(trim($raw)), 's');
    $map = [
        'container' => 'Containers',
        'cap'       => 'Caps',
        'seal'      => 'Caps',
        'filter'    => 'Filters',
        'chemical'  => 'Chemicals',
        'other'     => 'Others',
    ];
    return $map[$key] ?? 'Others';
}

function category_display_label($raw)
{
    $labels = [
        'Containers' => 'Containers',
        'Caps'       => 'Caps & Seals',
        'Filters'    => 'Filters',
        'Chemicals'  => 'Chemicals',
        'Others'     => 'Others',
    ];
    return $labels[normalize_category_key($raw)];
}

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Status badges */
    .status-pending {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-approved {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-rejected {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }

    .status-ordered {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64ffda;
        border: 1px solid #64ffda;
    }

    .status-contracted {
        background-color: rgba(130, 170, 255, 0.1);
        color: #82aaff;
        border: 1px solid #82aaff;
    }

    .status-received {
        background-color: rgba(64, 196, 255, 0.1);
        color: #40c4ff;
        border: 1px solid #40c4ff;
    }

    .status-rated {
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
    }

    .rating-group {
        margin-bottom: 16px;
    }

    .rating-group-label {
        font-size: 0.85rem;
        color: #CCD6F6;
        margin-bottom: 6px;
        display: block;
    }

    .star-rating {
        display: flex;
        gap: 6px;
        font-size: 1.4rem;
    }

    .star-rating i {
        cursor: pointer;
        color: #4d5f82;
        transition: color 0.15s ease, transform 0.1s ease;
    }

    .star-rating i.bi-star-fill {
        color: #ffc107;
    }

    .star-rating i:hover {
        color: #ffc107;
        transform: scale(1.1);
    }

    /* Negotiate modal */
    .negotiate-section-label {
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.03em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 10px;
    }

    /* Budget check indicators */
    .budget-ok {
        color: #00e676;
        font-weight: 700;
    }

    .budget-over {
        color: #ff5252;
        font-weight: 700;
    }

    .req-item-row {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px;
        margin-bottom: 10px;
    }

    .req-item-remove {
        color: #ff5252;
        cursor: pointer;
        font-size: 18px;
    }

    .req-total-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 14px 16px;
    }

    /* Request detail (view) list */
    .req-detail-item {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #233554;
    }

    .req-detail-item:last-child {
        border-bottom: none;
    }

    .form-control:disabled,
    .form-control[disabled] {
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #CCD6F6;
        opacity: 1;
    }

    .form-control:disabled::placeholder {
        color: #8892B0;
    }

    .category-chip {
        display: inline-block;
        background-color: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        border: 1px solid #64FFDA;
        font-size: 11px;
        font-weight: 600;
        padding: 3px 9px;
        border-radius: 20px;
        white-space: nowrap;
    }

    .price-cell {
        color: #64FFDA;
        font-weight: 600;
    }

    /* Recommend Supplier modal */
    .supplier-option-card {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px 16px;
        margin-bottom: 8px;
        cursor: pointer;
        transition: all 0.15s ease;
    }

    .supplier-option-card:hover {
        border-color: #64FFDA;
    }

    .supplier-option-card input[type="radio"]:checked~.supplier-option-info,
    .supplier-option-card:has(input[type="radio"]:checked) {
        border-color: #64FFDA;
        background-color: rgba(100, 255, 218, 0.06);
    }

    #recommendSupplierModal .text-muted {
        color: #8892B0 !important;
    }

    .supplier-option-card.d-none {
        display: none !important;
    }

    .supplier-option-card .form-check-input {
        margin-top: 0;
    }

    /* Goods receipt */
    .receipt-box {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 20px 22px;
    }

    .receipt-company {
        font-size: 1.15rem;
        font-weight: 700;
        color: #CCD6F6;
    }

    .receipt-company-sub {
        font-size: 0.8rem;
        color: #8892B0;
    }

    .receipt-doc-title {
        font-size: 0.85rem;
        letter-spacing: 0.08em;
        color: #40c4ff;
        font-weight: 700;
    }

    .receipt-divider {
        border-color: #233554;
        opacity: 1;
        margin: 14px 0;
    }

    .receipt-meta-label {
        font-size: 11px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        color: #8892B0;
        margin-bottom: 2px;
    }

    .receipt-meta-value {
        font-size: 0.9rem;
        color: #CCD6F6;
        font-weight: 500;
    }

    .receipt-items table {
        background-color: transparent;
    }

    .receipt-items thead th {
        color: #8892B0;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        border-bottom: 1px solid #233554;
    }

    .receipt-items td {
        border-color: #233554;
        color: #CCD6F6;
    }

    .receipt-totals {
        max-width: 280px;
    }

    .receipt-grand-total {
        border-top: 1px solid #233554;
        margin-top: 4px;
        padding-top: 10px;
        font-size: 1.05rem;
        color: #40c4ff;
    }

    .receipt-footnote {
        font-size: 0.78rem;
        color: #8892B0;
        text-align: center;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Purchase Requests</h1>
                    <h6>Submit and track your restock requests - Finance reviews and approves separately</h6>
                </div>
            </header>

            <!-- KPI Summary Cards  -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Requests</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Pending'";
                            $query = $conn->query($sql);
                            $currents_pending = $query->fetch_object();

                            if ($currents_pending != "") {
                                echo $currents_pending->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Approved This Month</div>
                        <div class="dash-value" style="color:#00e676;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE date_requested >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_requested < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND deleted = 'False' AND status = 'Approved' OR status = 'Supplier Approved'";
                            $query = $conn->query($sql);
                            $approved_month = $query->fetch_object();

                            if ($approved_month != "") {
                                echo $approved_month->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Rejected</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM stock_request WHERE deleted ='False' AND status = 'Rejected'";
                            $query = $conn->query($sql);
                            $currents_reject = $query->fetch_object();
                            if ($currents_reject != "") {
                                echo $currents_reject->total;
                            } else {
                                echo "0";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Pending Value</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT SUM(cost) AS total FROM stock_request WHERE deleted ='False' AND status = 'Pending'";
                            $query = $conn->query($sql);
                            if ($query && $row = $query->fetch_object()) {
                                if (empty($row->total)) {
                                    $pending_value = 0;
                                } else {
                                    $pending_value = $row->total;
                                }
                            } else {
                                $pending_value = 0;
                            }

                            echo '₱' . $pending_value;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Requests</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Request Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <select class="form-select" id="statusFilter" style="width: 170px;">
                                    <option value="">All Status</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Ordered">Ordered</option>
                                    <option value="Goods Received">Goods Received</option>
                                </select>
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Request" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap" id="btnNewRequest">+ New Request</button>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#request_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>',
                                    "order": [
                                        [0, "desc"]
                                    ]
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#statusFilter').on('change', function() {
                                    table.column(7).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="request_list">
                            <thead>
                                <tr>
                                    <th>Purchase Order No.</th>
                                    <th>Request ID</th>
                                    <th>Requested By</th>
                                    <th>Date Requested</th>
                                    <th>Category</th>
                                    <th>Items</th>
                                    <th>Est. Value</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--<tr>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td>Ana Dela Cruz</td>
                                    <td>Aug 20, 2026</td>
                                    <td>Caps &amp; Seals</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-bs-toggle="modal" data-bs-target="#viewRequestModal-EXAMPLE">1 items</button>
                                    </td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-received">Goods Received</span></td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3"
                                            data-bs-toggle="modal" data-bs-target="#goodsReceivedModal-EXAMPLE">
                                            <i class="bi bi-box-seam me-1"></i>View Goods Received
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>PO-1002</td>
                                    <td>REQ-0002</td>
                                    <td>Ana Dela Cruz</td>
                                    <td>Aug 20, 2026</td>
                                    <td>Caps &amp; Seals</td>
                                    <td>
                                        <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                            data-bs-toggle="modal" data-bs-target="#viewRequestModal-EXAMPLE">1 items</button>
                                    </td>
                                    <td>₱1,200.00</td>
                                    <td><span class="status-badge status-received">Goods Received</span></td>
                                    <td>
                                        <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-rate-supplier"
                                            data-id="REQ-0002"
                                            data-supplier="BlueCap Packaging Solutions">
                                            <i class="bi bi-star me-1"></i>Rate Supplier
                                        </button>
                                    </td>
                                </tr>
                                <div class="modal fade" id="viewRequestModal-EXAMPLE" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content shadow-lg">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Request Details — <span>REQ-0002</span></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="req-detail-item">
                                                    <span>Bottle Caps (Blue) x500</span>
                                                    <span>₱2.40</span>
                                                </div>
                                                <div class="req-total-box d-flex justify-content-between align-items-center mt-3">
                                                    <span class="fw-semibold">Total</span>
                                                    <span class="fw-bold fs-5">₱1,200.00</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="goodsReceivedModal-EXAMPLE" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content shadow-lg">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Goods Received — <span>PO-1002</span></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body p-4">

                                                <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                                    <span class="small" style="color:#8892B0;">Receipt No.</span>
                                                    <span>RCPT-1002</span>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                                    <span class="small" style="color:#8892B0;">Supplier</span>
                                                    <span>BlueCap Packaging Solutions</span>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                                    <span class="small" style="color:#8892B0;">Related Request</span>
                                                    <span>REQ-0002</span>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                                    <span class="small" style="color:#8892B0;">Date Delivered</span>
                                                    <span>Aug 25, 2026</span>
                                                </div>

                                                <div class="req-detail-item">
                                                    <span>Bottle Caps (Blue) — Ordered 500 / Received 500</span>
                                                    <span>₱2.40</span>
                                                </div>

                                                <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                                    <span class="fw-semibold">Total Received Value</span>
                                                    <span class="fw-bold fs-5">₱1,200.00</span>
                                                </div>


                                                <div class="modal-footer flex-wrap">
                                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">
                                                        Close
                                                    </button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="viewRequestModal-EXAMPLE2" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content shadow-lg">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Request Details — <span>REQ-0004</span></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="req-detail-item">
                                                    <span>Dosing Pump Unit x1</span>
                                                    <span>₱8,400.00</span>
                                                </div>
                                                <div class="req-total-box d-flex justify-content-between align-items-center mt-3">
                                                    <span class="fw-semibold">Total</span>
                                                    <span class="fw-bold fs-5">₱8,400.00</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>-->

                                <?php

                                $sql = "SELECT * 
                                        FROM stock_request 
                                        WHERE deleted = 'False' 
                                        AND status IN (
                                            'Pending', 
                                            'Supplier Pending', 
                                            'Approved', 
                                            'Negotiation Approved', 
                                            'Supplier Approved', 
                                            'Ordered', 
                                            'rejected', 
                                            'Need Revision', 
                                            'Supplier Delivered',
                                            'Supplier Payment Received', 
                                            'Finance Service Rated', 
                                            'Cancelled Negotiation', 
                                            'Send Back'
                                        ) 
                                        ORDER BY id DESC";
                                $query = $conn->query($sql);
                                $modalsHtml = '';
                                while ($set = $query->fetch_object()) {

                                    $pattern = '/([A-Za-z0-9\s-]+?)\s+x(\d+)\s+P([\d.]+)/';
                                    preg_match_all($pattern, $set->items, $matches, PREG_SET_ORDER);
                                    $parsed_items = [];

                                    foreach ($matches as $match) {
                                        $parsed_items[] = [
                                            'name'     => trim($match[1]),
                                            'quantity' => (int)$match[2],
                                            'price'    => round((float)$match[3], 2)
                                        ];
                                    }

                                    echo '
                                            <tr>
                                                <td>PO-' . $set->order_number . '</td>
                                                <td>REQ-' . $set->id . '</td>
                                                <td>' . $set->requester . '</td>
                                                <td>' . $set->date_requested . '</td>
                                                <td>' . $set->category . '</td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3 btn-view"
                                                        data-id="REQ-' . $set->id . '"
                                                        data-number="' . $set->id . '">' . count($parsed_items) . ' items</button>
                                                </td>
                                                <td>₱' . $set->cost . '</td>';

                                    if ($set->status == "Pending") {
                                        echo '
                                                <td><span class="status-badge status-pending">Pending</span></td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-hourglass-split me-1"></i>Awaiting Finance
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Supplier Pending") {
                                        echo '
                                                <td><span class="status-badge status-pending">Supplier Pending</span></td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-hourglass-split me-1"></i>Awaiting Supplier Finance
                                                    </button> 
                                                </td>
                                            ';
                                    } else if ($set->status == "Approved") {
                                        echo '
                                                <td><span class="status-badge status-approved">Approved</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-recommend-supplier" data-id="REQ-' . $set->id . '" data-number="' . $set->id . '" data-category="' . normalize_category_key($set->category) . '">
                                                        <i class="bi bi-person-check me-1"></i>Recommend Supplier   
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Negotiation Approved") {
                                        echo '
                                                <td><span class="status-badge status-approved">Negotiation Approved</span></td>
                                                <td>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-truck me-1"></i>Stock Request Fully Approved
                                                    </button>   
                                                </td>
                                            ';
                                    } else if ($set->status == "Supplier Approved") {
                                        echo '
                                                <td><span class="status-badge status-approved">Supplier Approved</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-negotiate"
                                                        data-id="REQ-' . $set->id . '"
                                                        data-supplier="' . $set->supplier_name . '"
                                                        data-category="' . ucfirst($set->category) . '"
                                                        data-number="' . $set->id . '"
                                                        data-range="' . $set->supplier_price . '"
                                                        >
                                                        <i class="bi bi-chat-dots me-1"></i>Negotiate
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Supplier Delivered") {
                                        echo '
                                                <td><span class="status-badge status-ordered">Ordered</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-order-received"
                                                        data-id="REQ-' . $set->id . '"
                                                        data-supplier="' . $set->supplier_name . '"
                                                        data-number="' . $set->id . '"
                                                        data-bs-toggle="modal" data-bs-target="#confirmReceiptModal-' . $set->id . '">
                                                        <i class="bi bi-box-seam me-1"></i>Order Received
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Rejected") {
                                        echo '
                                                <td><span class="status-badge status-rejected">Rejected</span></td>
                                                <td>
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                        <i class="bi bi-x-circle me-1"></i>Rejected
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Need Revision") {
                                        echo '
                                                <td><span class="status-badge status-rejected">Need Revision</span></td>
                                                <td>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-recommend-supplier" data-id="REQ-' . $set->id . '" data-number="' . $set->id . '" data-category="' . normalize_category_key($set->category) . '">
                                                        <i class="bi bi-person-check me-1"></i>Re-recommend Supplier   
                                                    </button>
                                                </td>
                                            ';
                                    } else if ($set->status == "Supplier Payment Received") {
                                        echo '
                                            <td><span class="status-badge status-received">Goods Received</span></td>
                                            <td>
                                                <div class="d-flex flex-column gap-2 align-items-center">
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#goodsReceivedModal-' . $set->id . '">
                                                        <i class="bi bi-box-seam me-1"></i>View Goods Received
                                                    </button>
                                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-rate-supplier" 
                                                        data-id="REQ-' . $set->id . '"
                                                        data-supplier="' . $set->supplier_name . '"
                                                        data-number="' . $set->id . '">
                                                        <i class="bi bi-star me-1"></i>Rate Supplier
                                                    </button>
                                                </div>
                                            </td>
                                        ';
                                    } else if ($set->status == "Finance Service Rated") {
                                        echo '
                                            <td><span class="status-badge status-rated">Rated</span></td>
                                            <td>
                                                <div class="d-flex flex-column gap-2 align-items-center">
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#goodsReceivedModal-' . $set->id . '">
                                                        <i class="bi bi-box-seam me-1"></i>View Goods Received
                                                    </button>
                                                    <button class="btn btn-edit btn-sm rounded-pill px-3" disabled title="AquaTech Solutions rated 4.5 / 5">
                                                        <i class="bi bi-star-fill me-1"></i>Rated ' . $set->rating_star . '/5
                                                    </button>
                                                </div>
                                            </td>
                                        ';
                                    } else if ($set->status == "Cancelled Negotiation") {
                                        echo '
                                            <td><span class="status-badge status-rejected">Cancelled Negotiation</span></td>
                                            <td>
                                                <button class="btn btn-remove btn-sm rounded-pill px-3" disabled>
                                                    <i class="bi bi-x-circle me-1"></i>Cancelled Negotiation
                                                </button>
                                            </td>
                                        ';
                                    } else if ($set->status == "Send Back") {
                                        echo '
                                            <td><span class="status-badge status-rejected">Sent Back</span></td>
                                            <td>
                                                <button class="btn btn-confirm btn-sm rounded-pill px-3 btn-negotiate"
                                                    data-id="REQ-' . $set->id . '"
                                                    data-supplier="' . $set->supplier_name . '"
                                                    data-category="' . ucfirst($set->category) . '"
                                                    data-number="' . $set->id . '"
                                                    data-range="' . $set->supplier_price . '"
                                                    >
                                                    <i class="bi bi-chat-dots me-1"></i>Re-negotiate
                                                </button>
                                            </td>
                                        ';
                                    }

                                    //Modal per Items
                                    echo '</tr>';

                                    // Buffer all per-row modals so they render after the table closes,
                                    // instead of as invalid direct children of <tbody> (which browsers
                                    // will silently pull out of the hidden .modal wrapper and into the
                                    // visible page flow).
                                    ob_start();
                                    echo '
                                            <div class="modal fade" id="viewRequestModal-' . $set->id . '" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content shadow-lg">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Request Details — <span id="viewReqId">REQ-' . $set->id . '</span></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">';
                                    for ($i = 0; $i < count($parsed_items); $i++) {
                                        echo '<div class="req-detail-item">
                                                    <span>' . $parsed_items[$i]['name'] . ' x' . $parsed_items[$i]['quantity'] . '</span>
                                                    <span>₱' . number_format($parsed_items[$i]['price'], 2) . '</span>
                                                </div>';
                                    }
                                    echo ' <div class="req-total-box d-flex justify-content-between align-items-center mt-3">
                                                                <span class="fw-semibold">Total</span>
                                                                <span class="fw-bold fs-5">₱' . number_format($set->cost, 2) . '</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ';

                                    // Extra modals for the "Order Received" flow (confirm receipt -> view goods received)
                                    if ($set->status == "Supplier Delivered") {
                                        echo '
                                            <div class="modal fade" id="confirmReceiptModal-' . $set->id . '" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                                    <div class="modal-content shadow-lg receipt-modal">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"><i class="bi bi-box-seam me-2"></i>Confirm Goods Receipt</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">

                                                            <div class="receipt-box">

                                                                <div class="d-flex justify-content-between align-items-start receipt-letterhead">
                                                                    <div>
                                                                        <div class="receipt-company">Eco Hydrate Hub</div>
                                                                        <div class="receipt-company-sub">Water Refilling Station &amp; Supply Management</div>
                                                                    </div>
                                                                    <div class="text-end">
                                                                        <div class="receipt-doc-title">DELIVERY RECEIPT</div>
                                                                        <div class="small" style="color:#8892B0;">Req. REQ-' . $set->id . '</div>
                                                                    </div>
                                                                </div>

                                                                <hr class="receipt-divider">

                                                                <div class="row g-3 receipt-meta">
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Supplier</div>
                                                                        <div class="receipt-meta-value">' . $set->supplier_name . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Category</div>
                                                                        <div class="receipt-meta-value">' . category_display_label($set->category) . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">PO Reference</div>
                                                                        <div class="receipt-meta-value">PO-' . $set->order_number . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Date Requested</div>
                                                                        <div class="receipt-meta-value">' . $set->date_requested . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Date Delivered</div>
                                                                        <div class="receipt-meta-value">' . $set->date_delivered . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Date Expected</div>
                                                                        <div class="receipt-meta-value">' . $set->expected_delivery . '</div>
                                                                    </div>
                                                                </div>
                                                                <div class="receipt-items mt-3">
                                                                    <table class="table table-dark table-sm mb-0">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Item</th>
                                                                                <th class="text-center">Qty</th>
                                                                                <th class="text-end">Unit Price</th>
                                                                                <th class="text-end">Line Total</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>';
                                        for ($i = 0; $i < count($parsed_items); $i++) {
                                            $line_total = $parsed_items[$i]['quantity'] * $parsed_items[$i]['price'];
                                            echo '
                                                            <tr>
                                                                <td>' . $parsed_items[$i]['name'] . '</td>
                                                                <td class="text-center">' . $parsed_items[$i]['quantity'] . '</td>
                                                                <td class="text-end">₱' . number_format($parsed_items[$i]['price'], 2) . '</td>
                                                                <td class="text-end">₱' . number_format($line_total, 2) . '</td>
                                                            </tr>';
                                        }
                                        echo '
                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                                <div class="receipt-totals mt-3 ms-auto">
                                                                    <div class="req-detail-item receipt-grand-total">
                                                                        <span>Total Order Value</span>
                                                                        <span class="fw-semibold">₱' . number_format($set->cost, 2) . '</span>
                                                                    </div>
                                                                </div>

                                                                <div class="receipt-footnote mt-3">
                                                                    Confirm that all items above were received in good condition. This will mark the request as fully received.
                                                                </div>

                                                            </div>

                                                            <div class="modal-footer flex-wrap">
                                                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">
                                                                    Cancel
                                                                </button>
                                                                <form method="POST">
                                                                    <input type="text" name="id" value="' . $set->id . '" hidden>
                                                                    <button type="submit" name="received" value="Inventory Order Received" class="btn btn-confirm rounded-pill px-4 btn-confirm-receipt"
                                                                        data-id="REQ-' . $set->id . '"
                                                                        data-target="#goodsReceivedModal-' . $set->id . '">
                                                                        <i class="bi bi-check-lg me-1"></i>Confirm Receipt
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ';
                                    }

                                    if (in_array($set->status, ['Supplier Delivered', 'Supplier Payment Received', 'Finance Service Rated'])) {
                                        echo '
                                            <div class="modal fade" id="goodsReceivedModal-' . $set->id . '" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                                    <div class="modal-content shadow-lg receipt-modal">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"><i class="bi bi-box-seam me-2"></i>Goods Receipt</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body p-4">

                                                            <div class="receipt-box">

                                                                <div class="d-flex justify-content-between align-items-start receipt-letterhead">
                                                                    <div>
                                                                        <div class="receipt-company">Eco Hydrate Hub</div>
                                                                        <div class="receipt-company-sub">Water Refilling Station &amp; Supply Management</div>
                                                                    </div>
                                                                    <div class="text-end">
                                                                        <div class="receipt-doc-title">GOODS RECEIPT</div>
                                                                        <div class="small" style="color:#8892B0;">No. RCPT-' . $set->id . '</div>
                                                                    </div>
                                                                </div>

                                                                <hr class="receipt-divider">

                                                                <div class="row g-3 receipt-meta">
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Supplier</div>
                                                                        <div class="receipt-meta-value">' . $set->supplier_name . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Category</div>
                                                                        <div class="receipt-meta-value">' . category_display_label($set->category) . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">PO Reference</div>
                                                                        <div class="receipt-meta-value">PO-' . $set->order_number . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Request ID</div>
                                                                        <div class="receipt-meta-value">REQ-' . $set->id . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Date Requested</div>
                                                                        <div class="receipt-meta-value">' . $set->date_requested . '</div>
                                                                    </div>
                                                                    <div class="col-6 col-md-4">
                                                                        <div class="receipt-meta-label">Date Received</div>
                                                                        <div class="receipt-meta-value">' . date('M d, Y') . '</div>
                                                                    </div>
                                                                </div>

                                                                <div class="receipt-items mt-3">
                                                                    <table class="table table-dark table-sm mb-0">
                                                                        <thead>
                                                                            <tr>
                                                                                <th>Item</th>
                                                                                <th class="text-center">Ordered</th>
                                                                                <th class="text-center">Received</th>
                                                                                <th class="text-end">Unit Price</th>
                                                                                <th class="text-end">Line Total</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>';
                                        for ($i = 0; $i < count($parsed_items); $i++) {
                                            $line_total = $parsed_items[$i]['quantity'] * $parsed_items[$i]['price'];
                                            echo '
                                                            <tr>
                                                                <td>' . $parsed_items[$i]['name'] . '</td>
                                                                <td class="text-center">' . $parsed_items[$i]['quantity'] . '</td>
                                                                <td class="text-center">' . $parsed_items[$i]['quantity'] . '</td>
                                                                <td class="text-end">₱' . number_format($parsed_items[$i]['price'], 2) . '</td>
                                                                <td class="text-end">₱' . number_format($line_total, 2) . '</td>
                                                            </tr>';
                                        }
                                        echo '
                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                                <div class="receipt-totals mt-3 ms-auto">
                                                                    <div class="req-detail-item receipt-grand-total">
                                                                        <span>Total Received Value</span>
                                                                        <span class="fw-semibold">₱' . number_format($set->cost, 2) . '</span>
                                                                    </div>
                                                                </div>

                                                                <div class="receipt-footnote mt-3">
                                                                    This receipt confirms all items above were received in good condition and match the purchase order and quantities delivered.
                                                                </div>

                                                            </div>

                                                            <div class="modal-footer flex-wrap">
                                                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">
                                                                    Close
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ';
                                    }

                                    $modalsHtml .= ob_get_clean();
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php echo $modalsHtml; ?>

            <!-- New Request Modal -->
            <div class="modal fade" id="newRequestModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">New Purchase Request</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form method="POST" id="newRequestForm">

                                <div class="row mb-3">
                                    <div class="col-md-6 mb-3 mb-md-0">
                                        <label class="form-label">Category</label>
                                        <select class="form-select category-select" name="category" required>
                                            <option value="" disabled selected>Select category...</option>
                                            <script>
                                                var selection_array = [];
                                            </script>
                                            <?php
                                            $sql = "SELECT category FROM stocks WHERE deleted = 'False' GROUP BY category";
                                            $query = $conn->query($sql);
                                            while ($set = $query->fetch_object()) {
                                                echo '<option value="' . $set->category . '">' . $set->category . '</option>';

                                                echo <<<HTML
                                                        <script>
                                                            selection_array.push("{$set->category}");
                                                        </script>
                                                    HTML;
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Requested By</label>
                                        <input type="text" class="form-control" value="<?php echo $result->first_name . " " . $result->last_name; ?>" disabled>
                                    </div>
                                </div>

                                <label class="form-label">Requested Items</label>

                                <div id="reqItemsContainer">
                                    <div class="req-item-row row g-2 align-items-end">
                                        <div class="col-5">
                                            <label class="form-label small mb-1">Item</label>
                                            <select class="form-select form-select-sm req-item-array" name="item[]">
                                                <option value="" disabled selected>Select item...</option>
                                                <?php
                                                $sql = "SELECT * FROM stocks WHERE deleted = 'False'";
                                                $query = $conn->query($sql);
                                                while ($set = $query->fetch_object()) {
                                                    //On shows available items in stocks table
                                                    echo '<option value="' . $set->name . '" data-cost="' . $set->cost . '" class="' . $set->category . '">' . $set->name . '-' . $set->category . '</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="col-3">
                                            <label class="form-label small mb-1">Qty</label>
                                            <input type="number" class="form-control form-control-sm req-qty" name="qty[]" placeholder="0" min="1" required>
                                        </div>
                                        <div class="col-3">
                                            <label class="form-label small mb-1">Est. Subtotal</label>
                                            <input type="text" class="form-control form-control-sm req-subtotal" value="₱0.00" disabled>
                                        </div>
                                        <div class="col-1 text-center">
                                            <i class="bi bi-x-circle req-item-remove" title="Remove item"></i>
                                        </div>
                                    </div>

                                    <input type="text" name="items" class="w-100" id="items_complete" hidden>
                                    <input type="text" name="requester" value="<?php echo $result->first_name . " " . $result->last_name; ?>" hidden>
                                    <input type="number" class="w-100" name="total_value" id="total_value" hidden>
                                </div>

                                <button type="button" class="btn btn-secondary btn-sm rounded-pill px-3 mb-3" id="btnAddItemRow">
                                    <i class="bi bi-plus-lg me-1"></i>Add Another Item
                                </button>

                                <div class="req-total-box d-flex justify-content-between align-items-center mb-3">
                                    <span class="fw-semibold">Estimated Total</span>
                                    <span class="fw-bold fs-5" id="reqEstTotal">₱0.00</span>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Notes (optional)</label>
                                    <textarea class="form-control" name="note" rows="2" placeholder="e.g. Needed before end of month"></textarea>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" name="adder" class="btn btn-add rounded-pill px-4">Submit Request</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recommend Supplier Modal -->
            <div class="modal fade" id="recommendSupplierModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Recommend Supplier — <span id="recommendReqId">REQ-0001</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <p class="text-muted small mb-3">Suppliers matching this request's category. See Suppliers for full pricing and contact details.</p>

                            <div id="supplierOptionsList">
                                <form method="POST">
                                    <input type="text" id="id_change" name="id_change" hidden>
                                    <?php
                                    $sql = "SELECT * FROM supplier_offers WHERE deleted = 'False' ORDER BY id DESC";
                                    $query = $conn->query($sql);

                                    while ($set = $query->fetch_object()) {
                                        $parsed_items = [];

                                        if (!empty($set->products)) {

                                            $raw_products = explode(',', $set->products);

                                            foreach ($raw_products as $item) {
                                                $item = trim($item);
                                                if (empty($item)) continue;

                                                if (preg_match('/^(.*?)\s+((?:₱|P).+)$/u', $item, $match)) {
                                                    $name_and_category = trim($match[1]);
                                                    $price = trim($match[2]);

                                                    $parts = explode(' ', $name_and_category);
                                                    if (count($parts) > 1) {
                                                        $category = array_pop($parts);
                                                        $name = implode(' ', $parts);
                                                    } else {
                                                        $name = $name_and_category;
                                                        $category = 'Uncategorized';
                                                    }
                                                    $parsed_items[] = [
                                                        'name'     => $name,
                                                        'category' => $category,
                                                        'price'    => $price
                                                    ];
                                                }
                                            }
                                        }

                                        if (!empty($parsed_items)) {
                                            foreach ($parsed_items as $product) {
                                                echo '
                                                        <label class="supplier-option-card mb-2" data-category="' . normalize_category_key($product['category']) . '">
                                                            <span class="d-flex align-items-center gap-2">
                                                                <input class="form-check-input" type="radio" name="recommendSupplierChoice" value="' . $set->supplier_name . '/' . $product['price'] . '/' . $product['name'] . '">
                                                                
                                                                <span>
                                                                    <span class="fw-semibold d-block">' . $set->supplier_name . '</span>
                                                                    <span class="category-chip">' . category_display_label($product['category']) . '</span>
                                                                    <span class="text-muted small ms-1">Product: ' . ucfirst($product['name']) . '</span>
                                                                </span>
                                                            </span>
                                                            <span class="price-cell">' . $product['price'] . '</span>
                                                        </label>
                                                    ';
                                            }
                                        } else {
                                            echo '<p class="text-muted">No products listed.</p>';
                                        }
                                    }


                                    ?>

                                    <p class="text-muted small mb-0 d-none" id="supplierNoResults">No suppliers found in this category.</p>

                            </div>

                            <div class="modal-footer px-0 pb-0 mt-3">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="recommend" class="btn btn-add rounded-pill px-4" id="btnConfirmRecommend" disabled>Confirm Recommendation</button>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Negotiate Terms Modal -->
            <div class="modal fade" id="negotiateModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Negotiate Terms — <span id="negotiateReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">


                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="negotiateSupplierName">Supplier</span>
                                <span class="category-chip" id="negotiateCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Finance-Approved Range</span>
                                <span class="price-cell" id="negotiateApprovedRange">₱0.00 - ₱0.00</span>
                            </div>

                            <div class="negotiate-section-label">Negotiated Terms</div>
                            <form method="POST">
                                <input type="text" class="id_change" name="id_change" hidden>

                                <div class="row g-3 mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Final Unit Price / Total Cost</label>
                                        <div class="input-group">
                                            <span class="input-group-text" style="background-color:#0A192F;border:1px solid #233554;color:#8892B0;">₱</span>
                                            <input type="number" name="final_cost" class="form-control" id="negotiateFinalCost" placeholder="0.00" min="0" step="0.01" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Payment Method</label>
                                        <select class="form-select" name="payment_method" id="negotiatePaymentTerms" required>
                                            <option value="" disabled>Select Payment Method</option>
                                            <option value="COD">Cash on Delivery</option>
                                            <option value="Gcash">Gcash</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row g-3 mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">SLA / Delivery Commitment</label>
                                        <input type="text" name="delivery_commitment" class="form-control" id="negotiateSla" placeholder="e.g. Ships within 3 business days" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label" hidden>Contract Type</label>
                                        <select class="form-select" id="negotiateContractType" hidden>
                                            <option value="One-time">One-time Purchase</option>
                                            <option value="Framework">Framework / Standing Agreement</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row g-3 mb-3 d-none" id="negotiateValidUntilRow">
                                    <div class="col-md-6">
                                        <label class="form-label">Valid Until</label>
                                        <input type="date" class="form-control" id="negotiateValidUntil">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Negotiation Notes</label>
                                    <textarea class="form-control" name="negotiation_notes" id="negotiateNotes" rows="2" placeholder="e.g. 10% discount for orders over ₱5,000" required></textarea>
                                </div>

                                <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                    <span class="fw-semibold">Final Negotiated Cost</span>
                                    <span class="fw-bold fs-5" id="negotiateFinalCostDisplay">₱0.00</span>
                                </div>

                                <div class="modal-footer flex-wrap">
                                    <button type="submit" name="negotiation" value="Cancelled Negotiation" class="btn btn-remove rounded-pill px-4" id="btnCancelNegotiation">
                                        <i class="bi bi-x-lg me-1"></i>Cancel Negotiation
                                    </button>

                                    <button type="submit" name="negotiation" value="Contract Approved" class="btn btn-confirm rounded-pill px-4" id="btnFinalizeContract">
                                        <i class="bi bi-check-lg me-1"></i>Finalize &amp; Create Contract
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <!-- View Contract Modal -->
            <div class="modal fade" id="viewContractModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Contract — <span id="contractReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">

                            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
                                <span class="fw-semibold d-block" id="contractSupplierName">Supplier</span>
                                <span class="category-chip" id="contractCategory">Category</span>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4 px-1">
                                <span class="small" style="color:#8892B0;">Contract Status</span>
                                <span class="status-badge status-contracted"><i class="bi bi-file-earmark-check me-1"></i>Active</span>
                            </div>

                            <div class="req-detail-item">
                                <span>Payment Method</span>
                                <span id="contractPaymentTerms">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>SLA / Delivery Commitment</span>
                                <span id="contractSla">—</span>
                            </div>
                            <div class="req-detail-item">
                                <span>Contract Type</span>
                                <span id="contractType">—</span>
                            </div>
                            <div class="req-detail-item" id="contractValidUntilRow">
                                <span>Valid Until</span>
                                <span id="contractValidUntil">—</span>
                            </div>

                            <div class="mb-3 mt-3">
                                <label class="form-label small text-muted">Negotiation Notes</label>
                                <textarea class="form-control" id="contractNotes" rows="2" disabled></textarea>
                            </div>

                            <div class="req-total-box d-flex justify-content-between align-items-center mt-3 mb-3">
                                <span class="fw-semibold">Final Negotiated Cost</span>
                                <span class="fw-bold fs-5" id="contractFinalCost">₱0.00</span>
                            </div>

                            <div class="modal-footer px-0 pb-0">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <!-- Supplier Rating Modal -->
            <div class="modal fade" id="supplierRatingModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Rate Supplier — <span id="ratingReqId">REQ-0000</span></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <form method="POST">
                            <div class="modal-body p-4">

                                <div class="req-total-box mb-3">
                                    <div class="req-detail-item">
                                        <span>Supplier</span>
                                        <span class="fw-semibold" id="ratingSupplier">—</span>
                                    </div>
                                    <div class="req-detail-item">
                                        <span>Related Request</span>
                                        <span class="fw-semibold" id="ratingReqIdDisplay">—</span>
                                    </div>
                                </div>

                            </div>

                            <div class="mb-3 w-75 mx-auto">
                                <label for="rating" class="form-label fw-bold">Rate Supplier</label>
                                <select name="rating" id="rating" class="form-select form-select-lg" required>
                                    <option value="" disabled selected>Select a rating...</option>
                                    <option value="5">★★★★★ — 5 - Excellent</option>
                                    <option value="4">★★★★☆ — 4 - Very Good</option>
                                    <option value="3">★★★☆☆ — 3 - Good</option>
                                    <option value="2">★★☆☆☆ — 2 - Fair</option>
                                    <option value="1">★☆☆☆☆ — 1 - Poor</option>
                                </select>
                            </div>

                            <input type="text" class="idNumber" name="id" hidden>


                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="rate" value="Finance Service Rated" class="btn btn-confirm rounded-pill px-4" id="btnSubmitRating">
                                    <i class="bi bi-star-fill me-1"></i>Submit Rating
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                // Add Request
                if (isset($_POST['adder'])) {
                    $requester = $_POST['requester'];
                    $items = $_POST['items'];
                    $cost = $_POST['total_value'];
                    $category = $_POST['category'];
                    $note = $_POST['note'];
                    $status = "Pending";

                    if ($requester && $items && $cost && $category) {
                        if (trim($note) == '') {
                            $note = "No Note";
                        }

                        $sql = "INSERT INTO `stock_request` (`requester`, `date_requested`, `category`, `items`, `cost`, `note`, `status`) VALUES (?, CURDATE(), ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);

                        // "ssssds" = string, string, string, string, double/float, string
                        $stmt->bind_param("sssdss", $requester, $category, $items, $cost, $note, $status);

                        if ($stmt->execute()) {
                            echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Request Added!',
                                                text: 'The new request has been registered.',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('requisitions.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                        }
                        $stmt->close();
                    } else {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Invalid Input!',
                                            text: 'Make sure that every input if valid',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#e60000',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('requisitions.php');
                                            }});
                                    })
                                </script> 
                            HTML;
                    }
                }

                if (isset($_POST['recommend'])) {
                    $recommended_info = $_POST['recommendSupplierChoice'];
                    $id = $_POST['id_change'];
                    $status = "Supplier Pending";
                    $recommend = $result->first_name . " " . $result->last_name;
                    list($supplier, $price, $product_name) = explode('/', $recommended_info);

                    echo <<<HTML
                            <script>
                                console.log("{$supplier}");
                                console.log("{$price}");
                                console.log("{$id}");
                            </script>
                        HTML;

                    $sql = "UPDATE `stock_request` SET `supplier_name` = ?, `supplier_price` = ?, `status` = ?, recommended_by = ?, supplier_product_name = ? WHERE id = '" . $id . "'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sssss", $supplier, $price, $status, $recommend, $product_name);
                    if ($stmt->execute()) {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Recommendation Sent',
                                            text: 'Please wait for a finance member to approve the recommendation',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('requisitions.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                    }
                }

                if (isset($_POST['negotiation'])) {
                    $final_cost = $_POST['final_cost'];
                    $payment_method = $_POST['payment_method'];
                    $delivery_commitment = $_POST['delivery_commitment'];
                    $negotiation_notes = $_POST['negotiation_notes'];
                    $id = $_POST['id_change'];
                    $order_number = rand(1, 9999999999);


                    if ($final_cost > 0) {
                        $sql = "UPDATE `stock_request` SET `negotiation_note` = ?, `final_cost` = ?, `status` = ?, delivery_commitment = ?, payment_method = ?, order_number = ? WHERE id = '" . $id . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("sdssss", $negotiation_notes, $final_cost, $_POST['negotiation'], $delivery_commitment, $payment_method, $order_number);
                        if ($stmt->execute()) {
                            if ($_POST['negotiation'] == 'Contract Approved') {
                                $sql = "SELECT * FROM stock_request WHERE id = " . $id;
                                $query = $conn->query($sql);
                                $req_info = $query->fetch_object();

                                $email_body = "
                                    <p>A purchase order has been finalized after negotiation:</p>
                                    <ul>
                                        <li><strong>PO Number:</strong> {$order_number}</li>
                                        <li><strong>Supplier:</strong> {$req_info->supplier_name}</li>
                                        <li><strong>Items:</strong> {$req_info->items}</li>
                                        <li><strong>Final Cost:</strong> ₱" . number_format($final_cost, 2) . "</li>
                                        <li><strong>Delivery Commitment:</strong> {$delivery_commitment}</li>
                                    </ul>
                                ";
                                notify_inventory_team($conn, 'Purchase Order Finalized — PO-' . $order_number, $email_body);
                            }

                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Negotiation Updated!',
                                            text: '',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('requisitions.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                        }
                    } else {
                        echo <<<HTML
                            <script>
                                $(document).ready(function() {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Invalid Input!',
                                        text: 'Make sure that final value if more than 0',
                                        background: '#112240',
                                        color: '#CCD6F6',
                                        confirmButtonColor: '#e60000',
                                        heightAuto: false
                                    }).then((result) => {
                                        if(result.isConfirmed) {
                                            location.assign('requisitions.php');
                                        }});
                                })
                                
                            </script> 
                        HTML;
                    }
                }

                if (isset($_POST['received'])) {
                    $id = $_POST['id'];
                    $delivery_recipient = $result->first_name . " " . $result->last_name;


                    $sql = "UPDATE `stock_request` SET `status` = ?, delivery_recipient = ?, date_received = CURDATE() WHERE id = '" . $id . "'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ss", $_POST['received'], $delivery_recipient);
                    if ($stmt->execute()) {
                        $sql = "SELECT * FROM stock_request WHERE id = " . $id;
                        $query = $conn->query($sql);
                        $req_info = $query->fetch_object();

                        $email_body = "
                            <p>Goods have been received and confirmed:</p>
                            <ul>
                                <li><strong>PO Number:</strong> {$req_info->order_number}</li>
                                <li><strong>Supplier:</strong> {$req_info->supplier_name}</li>
                                <li><strong>Items:</strong> {$req_info->items}</li>
                                <li><strong>Received By:</strong> {$delivery_recipient}</li>
                                <li><strong>Date Received:</strong> " . date('Y-m-d') . "</li>
                            </ul>
                        ";
                        notify_inventory_team($conn, 'Goods Received — PO-' . $req_info->order_number, $email_body);

                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Negotiation Updated!',
                                            text: '',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('requisitions.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                    }
                }

                if (isset($_POST['rate'])) {
                    $id = $_POST['id'];
                    $rating = $_POST['rating'];

                    $sql = "UPDATE `stock_request` SET `status` = ?, rating_star = ? WHERE id = '" . $id . "'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ss", $_POST['rate'], $rating);
                    if ($stmt->execute()) {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Service Rated!',
                                            text: '',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#00E676',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('requisitions.php');
                                            }});
                                    })
                                    
                                </script> 
                            HTML;
                    }
                }
            }

            ?>

        </section>
    </main>
    </div>

    <script>
        //Prevents from typing/copying 'e' and '-' from final unit input
        $(document).ready(function() {
            $('#negotiateFinalCost').on('keydown', function(e) {
                // Block 'e', 'E', '-', and '+' keypresses
                if (['e', 'E', '-', '+'].includes(e.key)) {
                    e.preventDefault();
                }
            });

            $('#negotiateFinalCost').on('paste', function(e) {
                // Get pasted text from clipboard
                var pastedData = e.originalEvent.clipboardData.getData('text');

                // Prevent paste if it contains 'e', 'E', '-', or '+'
                if (/[eE\-+]/.test(pastedData)) {
                    e.preventDefault();
                }
            });
        });
        $(document).ready(function() {

            $('.category-select').on('change', function() {
                var selectedValue = $(this).val();

                for (i = 0; i < selection_array.length; i++) {
                    $('.' + selection_array[i]).attr('hidden', false);
                }
                for (i = 0; i < selection_array.length; i++) {
                    //console.log(selection_array[i]);
                    if (selectedValue != selection_array[i]) {
                        $('.' + selection_array[i]).attr('hidden', true);
                    }

                }
            });

            $('.req-qty').on('keydown', function(e) {
                // List of keys to block
                var blockedKeys = ['-', 'e'];

                if (blockedKeys.includes(e.key)) {
                    e.preventDefault(); // Prevents the character from appearing in the input
                }
            });

            $('#btnNewRequest').click(function() {
                $('#newRequestModal').modal('show');
            });

            $('.btn-view').click(function() {
                $('#viewReqId').text($(this).data('id'));
                $('#viewRequestModal-' + $(this).data('number')).modal('show');

            });

            $(document).on('click', '.btn-confirm-receipt', function() {
                var $btn = $(this);
                var reqId = $btn.data('id');
                var $orderBtn = $('.btn-order-received[data-id="' + reqId + '"]');
                var $row = $orderBtn.closest('tr');
                var $confirmModal = $btn.closest('.modal');
                var goodsReceivedTarget = $btn.data('target');
                var supplier = $orderBtn.data('supplier');

                $row.find('td').eq(7)
                    .html('<span class="status-badge status-received">Goods Received</span>');

                $row.find('td').eq(8).html(
                    '<div class="d-flex flex-column gap-2 align-items-center">' +
                    '<button class="btn btn-edit btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="' + goodsReceivedTarget + '">' +
                    '<i class="bi bi-box-seam me-1"></i>View Goods Received</button>' +
                    '<button class="btn btn-confirm btn-sm rounded-pill px-3 btn-rate-supplier" ' +
                    'data-id="' + reqId + '" data-supplier="' + supplier + '">' +
                    '<i class="bi bi-star me-1"></i>Rate Supplier</button>' +
                    '</div>'
                );

                $confirmModal.modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Goods Receipt Confirmed',
                    text: reqId + ' has been marked as received. Finance can proceed with invoice matching.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            // ---- Supplier Performance Rating ----
            var $activeRatingRow = null;
            var ratingValues = {
                quality: 0,
                delivery: 0,
                pricing: 0,
                communication: 0
            };

            function renderStars(category, value) {
                $('.star-rating[data-category="' + category + '"]').find('i').each(function() {
                    var starVal = $(this).data('value');
                    $(this)
                        .toggleClass('bi-star-fill', starVal <= value)
                        .toggleClass('bi-star', starVal > value);
                });
            }

            $(document).on('click', '.btn-rate-supplier', function() {
                $activeRatingRow = $(this).closest('tr');
                var $btn = $(this);

                $('#ratingReqId').text($btn.data('id'));
                $('#ratingReqIdDisplay').text($btn.data('id'));
                $('#ratingSupplier').text($btn.data('supplier'));
                $('#ratingComments').val('');
                $('.idNumber').val($btn.data('number'));


                ratingValues = {
                    quality: 0,
                    delivery: 0,
                    pricing: 0,
                    communication: 0
                };
                $.each(ratingValues, function(cat) {
                    renderStars(cat, 0);
                });

                $('#supplierRatingModal').modal('show');
            });

            $(document).on('click', '.star-rating i', function() {
                var category = $(this).closest('.star-rating').data('category');
                var value = $(this).data('value');

                ratingValues[category] = value;
                renderStars(category, value);
            });

            $('#btnSubmitRating').click(function() {
                /*if (!$activeRatingRow) return;

                var allRated = Object.keys(ratingValues).every(function(cat) {
                    return ratingValues[cat] > 0;
                });

                var total = ratingValues.quality + ratingValues.delivery + ratingValues.pricing + ratingValues.communication;
                var average = (total / 4).toFixed(1);
                var supplier = $('#ratingSupplier').text();
                var reqId = $('#ratingReqId').text();

                $activeRatingRow.find('td').eq(7)
                    .html('<span class="status-badge status-rated">Rated</span>');

                $activeRatingRow.find('.btn-rate-supplier')
                    .removeClass('btn-confirm btn-rate-supplier')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .attr('title', supplier + ' rated ' + average + ' / 5')
                    .html('<i class="bi bi-star-fill me-1"></i>Rated ' + average + '/5');

                $('#supplierRatingModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Rating Submitted',
                    text: supplier + ' was rated ' + average + '/5 for ' + reqId + '.',
                    background: '#112240',
                    color: '#CCD6F6',
                    //timer: 2200,
                    showConfirmButton: false,
                    heightAuto: false
                });*/
            });

            var $activeRecommendRow = null;

            function applySupplierCategoryFilter(category) {
                var $cards = $('#supplierOptionsList .supplier-option-card');
                var $visible;

                if (!category || category === 'all') {
                    $cards.removeClass('d-none');
                    $visible = $cards;
                } else {
                    $cards.each(function() {
                        var match = $(this).data('category') === category;
                        $(this).toggleClass('d-none', !match);
                    });
                    $visible = $cards.filter('[data-category="' + category + '"]');
                }

                $('#supplierNoResults').toggleClass('d-none', $visible.length > 0);
            }

            $(document).on('click', '.btn-recommend-supplier', function() {
                $activeRecommendRow = $(this).closest('tr');

                $('#recommendReqId').text($(this).data('id'));
                $('input[name="recommendSupplierChoice"]').prop('checked', false);
                $('#btnConfirmRecommend').prop('disabled', true);
                $('#id_change').val($(this).data('number'));
                $('#recommendSupplierModal').data('reqCategory', $(this).data('category') || 'all');

                $('#recommendSupplierModal').modal('show');
            });

            $('input[name="recommendSupplierChoice"]').on('change', function() {
                $('#btnConfirmRecommend').prop('disabled', false);
            });

            // Show only suppliers matching the request's own category
            $('#recommendSupplierModal').on('show.bs.modal', function() {
                applySupplierCategoryFilter($(this).data('reqCategory') || 'all');
            });

            $('#btnConfirmRecommend').click(function() {
                var supplierName = $('input[name="recommendSupplierChoice"]:checked').val();
                if (!$activeRecommendRow || !supplierName) return;

                // Recommendation submitted — now awaiting Finance's approval of the supplier
                $activeRecommendRow.find('td').eq(7)
                    .html('<span class="status-badge status-pending">Supplier Pending</span>');

                $activeRecommendRow.find('.btn-recommend-supplier')
                    .removeClass('btn-confirm')
                    .addClass('btn-edit')
                    .prop('disabled', true)
                    .html('<i class="bi bi-hourglass-split me-1"></i>Recommended: ' + supplierName);

                $('#recommendSupplierModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Supplier Recommended',
                    text: supplierName + ' has been recommended for this request. Awaiting Finance approval.',
                    background: '#112240',
                    color: '#CCD6F6',
                    //timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            var $activeNegotiateRow = null;

            // Negotiate enabled once Finance has approved the recommended supplier
            $(document).on('click', '.btn-negotiate', function() {
                $activeNegotiateRow = $(this).closest('tr');

                $('#negotiateReqId').text($(this).data('id'));
                $('#negotiateSupplierName').text($(this).data('supplier'));
                $('#negotiateCategory').text($(this).data('category'));
                $('#negotiateApprovedRange').text($(this).data('range'));

                // Reset form fields
                $('#negotiateFinalCost').val('');
                $('#negotiatePaymentTerms').val('');
                $('#negotiateSla').val('');
                $('#negotiateContractType').val('One-time');
                $('#negotiateValidUntilRow').addClass('d-none');
                $('#negotiateValidUntil').val('');
                $('#negotiateNotes').val('');
                $('#negotiateFinalCostDisplay').text('₱0.00');
                $('.id_change').val($(this).data('number'));

                $('#negotiateModal').modal('show');
            });

            $('#negotiateContractType').on('change', function() {
                $('#negotiateValidUntilRow').toggleClass('d-none', $(this).val() !== 'Framework');
            });

            $('#negotiateFinalCost').on('input', function() {
                var val = parseFloat($(this).val()) || 0;
                $('#negotiateFinalCostDisplay').text('₱' + val.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }));
            });

            $('#btnCancelNegotiation').click(function() {
                $('#negotiateModal').modal('hide');

                Swal.fire({
                    icon: 'warning',
                    title: 'Negotiation Cancelled',
                    text: 'The approved supplier remains on record. You can restart negotiation later.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });
            });

            $('#btnFinalizeContract').click(function() {
                /*if (!$activeNegotiateRow) return;

                var finalCost = parseFloat($('#negotiateFinalCost').val()) || 0;
                var paymentTerms = $('#negotiatePaymentTerms').val();

                if (!finalCost || !paymentTerms) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Missing Information',
                        text: 'Please enter the final cost and payment terms before finalizing.',
                        background: '#112240',
                        color: '#CCD6F6',
                        heightAuto: false
                    });
                    return;
                }

                var contractData = {
                    id: $('#negotiateReqId').text(),
                    supplier: $('#negotiateSupplierName').text(),
                    category: $('#negotiateCategory').text(),
                    finalCost: finalCost,
                    paymentTerms: paymentTerms,
                    sla: $('#negotiateSla').val() || '—',
                    contractType: $('#negotiateContractType').val() === 'Framework' ? 'Framework / Standing Agreement' : 'One-time Purchase',
                    validUntil: $('#negotiateValidUntil').val() || '',
                    notes: $('#negotiateNotes').val() || ''
                };

                $activeNegotiateRow.find('td').eq(7)
                    .html('<span class="status-badge status-contracted">Contracted</span>');

                $activeNegotiateRow.find('.btn-negotiate')
                    .removeClass('btn-negotiate btn-confirm')
                    .addClass('btn-edit btn-view-contract')
                    .prop('disabled', false)
                    .data('contract', contractData)
                    .html('<i class="bi bi-eye me-1"></i>View Contract');

                $('#negotiateModal').modal('hide');

                Swal.fire({
                    icon: 'success',
                    title: 'Contract Created',
                    text: 'Final terms locked in with ' + $('#negotiateSupplierName').text() + '.',
                    background: '#112240',
                    color: '#CCD6F6',
                    timer: 1800,
                    showConfirmButton: false,
                    heightAuto: false
                });*/
            });

            // View Contract
            $(document).on('click', '.btn-view-contract', function() {
                var c = $(this).data('contract');
                if (!c) return;

                $('#contractReqId').text(c.id);
                $('#contractSupplierName').text(c.supplier);
                $('#contractCategory').text(c.category);
                $('#contractPaymentTerms').text(c.paymentTerms === 'COD' ? 'Cash on Delivery' : c.paymentTerms);
                $('#contractSla').text(c.sla);
                $('#contractType').text(c.contractType);
                $('#contractNotes').val(c.notes || 'No additional notes.');
                $('#contractFinalCost').text('₱' + c.finalCost.toLocaleString('en-PH', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }));

                if (c.validUntil) {
                    $('#contractValidUntilRow').show();
                    $('#contractValidUntil').text(c.validUntil);
                } else {
                    $('#contractValidUntilRow').hide();
                }

                $('#viewContractModal').modal('show');
            });


            // Add another item row
            $('#btnAddItemRow').click(function() {
                var row = $('.req-item-row').first().clone();
                row.find('select').val('');
                row.find('input').val('');
                row.find('.req-subtotal').val('₱0.00');
                $('#reqItemsContainer').append(row);
            });

            // Block typing '-' or 'e'/'E' in existing and cloned rows
            $('#reqItemsContainer').on('keydown', '.req-qty, .req-cost', function(e) {
                if (['e', 'E', '-'].includes(e.key)) {
                    e.preventDefault();
                }
            });

            // Strip '-' or 'e'/'E' on paste or auto-fill
            $('#reqItemsContainer').on('input', '.req-qty, .req-cost', function() {
                this.value = this.value.replace(/[-eE]/g, '');
            });

            // Remove item row
            $(document).on('click', '.req-item-remove', function() {
                if ($('.req-item-row').length > 1) {
                    $(this).closest('.req-item-row').remove();
                    calcTotal();
                }
            });

            // Recalculate subtotal per row + running total
            $(document).on('change keyup', '.req-qty, select[name="item[]"]', function() {
                var row = $(this).closest('.req-item-row');
                var qty = parseFloat(row.find('.req-qty').val()) || 0;
                var cost = parseFloat(row.find('select[name="item[]"] option:selected').data('cost')) || 0;
                var subtotal = qty * cost;
                row.find('.req-subtotal').val('₱' + subtotal.toFixed(2));
                calcTotal();
            });

            function calcTotal() {
                var total = 0;

                var subtotal_array = [];
                var item_array = [];
                var quantity_array = [];
                var overall_aray = [];
                $('.req-subtotal').each(function() {
                    total += parseFloat($(this).val().replace('₱', '')) || 0;

                    //Array price
                    var value = parseFloat($(this).val().replace('₱', '')) || 0;
                    subtotal_array.push(value);
                });

                $('.req-item-array').each(function() {

                    //Array item name
                    var name = $(this).val();
                    item_array.push(name);
                });

                $('.req-qty').each(function() {

                    //Array item name
                    var quantity = $(this).val();
                    quantity_array.push(quantity);
                });

                overall_array = []; //Resets value of array
                for (i = 0; i < subtotal_array.length; i++) {
                    overall_array.push(item_array[i] + " " + "x" + quantity_array[i] + " P" + subtotal_array[i] + ",");
                }
                //Loads hidden input for databse insert
                $("#items_complete").val(overall_array.join(' '));

                $('#total_value').val(total.toFixed(2));
                $('#reqEstTotal').text('₱' + total.toFixed(2));
            }

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Inventory Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>