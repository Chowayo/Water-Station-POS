<?php

include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    /* Search Input Styles */
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">


            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Products Management</h1>

                </div>
            </header>


            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Products</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Product Directory</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Product" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap">+ Add New Product</button>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#product_list').DataTable({
                                    paging: true, // Paginate once the list grows
                                    pageLength: 10, // Rows per page before a new page is added
                                    lengthChange: false,
                                    searching: true, // Enable search functionality
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>' // Table scrolls in its own box; info + pagination sit below it
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw(); //Sets the input box as the new search bar
                                });


                            });
                        </script>
                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="product_list">
                            <thead>

                                <tr>
                                    <th>Image</th>
                                    <th>Id</th>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Measurement</th>
                                    <th>Unit</th>
                                    <th>Stock</th>
                                    <th>Price</th>
                                    <th>Tax %</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //Loading employee list
                                $sql = "SELECT * FROM product WHERE deleted = 'False'";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo "
                                            <tr>
                                                <td>
                                                    <img src='../images/$set->image' alt='Round Gallon' style='width: 50px; height: 50px; object-fit: contain; background: #ffffff; border-radius: 8px; padding: 2px;'>
                                                </td>
                                                <td>$set->id</td>
                                                <td>$set->product_name</td>
                                                <td>$set->category</td>
                                                <td>$set->measurement</td>
                                                <td>$set->unit</td>
                                                <td>$set->stock</td>
                                                <td>₱$set->price</td>
                                                <td>$set->tax_percentage%</td>
                                                <td>
                                                    <button class='btn btn-edit btn-sm rounded-pill px-3 me-1'
                                                            data-image='{$set->image}'
                                                            data-id='{$set->id}' 
                                                            data-name='{$set->product_name}'
                                                            data-category='{$set->category}'
                                                            data-measurement='{$set->measurement}'
                                                            data-unit='{$set->unit}'
                                                            data-price='{$set->price}'
                                                            data-tax='{$set->tax_percentage}'
                                                            data-stock='{$set->stock}'>
                                                        <i class='bi bi-pencil-square me-1'></i>Edit
                                                        </button>
                                                    <button class='btn btn-remove btn-sm rounded-pill px-3' data-id='{$set->id}'><i class='bi bi-trash-fill me-1'></i>Remove</button>
                                                </td>
                                            ";
                                }

                                echo <<<HTML
                                                <script>
                                                    $('.btn-remove').click(function() {
                                                        //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                                        id = $(this).data('id');

                                                        Swal.fire({
                                                            title: 'Remove Product?',
                                                            text: "It will be deleted in the database",
                                                            icon: 'warning',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showCancelButton: true,
                                                            showConfirmButton: false,
                                                            cancelButtonColor: '#8892B0',
                                                            html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
                                                            heightAuto: false
                                                        });
                                                    });
                                                </script>
                                                HTML;

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                    //Remove Account
                                    if (isset($_POST['deleter'])) {
                                        $sql = "UPDATE `product` SET `deleted` = 'True' WHERE id = " . $_POST['deleter'];
                                        if ($conn->query($sql) === TRUE) {
                                            echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Product Removed!',
                                                                            text: 'The product has been removed.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('products.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                        }
                                    }

                                    if (isset($_POST['adder'])) {
                                        $name = $_POST['name'];
                                        $tax = $_POST['tax'];
                                        $price = $_POST['price'];
                                        $stock = $_POST['stock'];
                                        $container_price = $_POST['container_price'];
                                        $measurement = $_POST['measurement'];
                                        $unit = $_POST['unit'];
                                        $image = $_POST['image'];
                                        $overall_price = 0;


                                        if ($name  && $image && $unit) {
                                            //Product name and category repetition checker
                                            $sql = "SELECT product_name, category FROM product WHERE `deleted` = 'False'";
                                            $query = $conn->query($sql);
                                            $product_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->product_name == $name && $set->category == $category) {
                                                    $product_checked = False;
                                                    break;
                                                }
                                            }



                                            //Price/Stock/Measurement/tax prevents "-" and "e" and Price/stock/Measurement must be atleast 1
                                            $number_checked = True;
                                            if (strpbrk($price, 'e-') !== false || strpbrk($container_price, 'e-') !== false || strpbrk($stock, 'e-.') !== false || strpbrk($measurement, 'e-') !== false || strpbrk($tax, 'e-') !== false || !$tax || !$price || !$measurement || $tax <= 0 || $tax > 100 || $price <= 0 || $measurement <= 0) { 
                                                $number_checked = false; 
                                            }

                                            if ($number_checked) {
                                                if ($product_checked) {
                                                    $categories = array("New Container", "Refill");
                                                    foreach ($categories as $cats) {
                                                        $sql = "INSERT INTO `product` (`image`, `product_name`, `category`, `measurement`, `unit`, `stock`, `price`, `tax_percentage`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                                                        $stmt = $conn->prepare($sql);
                                                        
                                                        if($cats=="New Container"){
                                                            $overall_price = $price + $container_price;
                                                        }else{
                                                            $overall_price = $price;
                                                            $stock = 1000;
                                                        }
                                                        $stmt->bind_param("sssdsidd", $image, $name, $cats, $measurement, $unit, $stock, $overall_price, $tax);
                                                        if ($stmt->execute()) {}
                                                    }
                                                    //Adds to stocks
                                                    $sql = "INSERT INTO `stocks` (`name`, `category`, `cost`, `current_stock`, `date_added`) VALUES (?, 'container', ?, ?, CURDATE())";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("sdi", $name, $container_price, $stock);
                                                    if ($stmt->execute()) {
                                                        echo <<<HTML
                                                            <script>
                                                                $(document).ready(function() {
                                                                    Swal.fire({
                                                                        icon: 'success',
                                                                        title: 'Product Added!',
                                                                        text: 'The new product has been registered.',
                                                                        background: '#112240',
                                                                        color: '#CCD6F6',
                                                                        confirmButtonColor: '#00E676',
                                                                        heightAuto: false
                                                                    }).then((result) => {
                                                                        if(result.isConfirmed) {
                                                                            location.assign('products.php');
                                                                        }});
                                                                })
                                                                
                                                            </script> 
                                                        HTML;
                                                    }
                                                } else {
                                                    //Product repeated
                                                    echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Product Already Exists!',
                                                                    text: 'Enter a new product and category',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addProductModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                                }
                                            } else {
                                                //Number not verified
                                                echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Invalid Value!',
                                                                text: 'Ensure that the Price, Tax %, and Measurement are greater than 0, the Tax is less than 100, and the stock is a whole number.',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                confirmButtonColor: '#e60000',
                                                                heightAuto: false
                                                            }).then((result) => {
                                                                if(result.isConfirmed) {
                                                                    $('#addProductModal').modal('show');
                                                                }});
                                                        })
                                                        </script> 
                                                HTML;
                                            }
                                        }
                                    }

                                    if (isset($_POST['editer'])) {
                                        $id =  $_POST['id'];
                                        $name = $_POST['name'];
                                        $price = $_POST['price'];
                                        $tax = $_POST['tax'];
                                        $stock = $_POST['stock'];
                                        $category = $_POST['category'];
                                        $measurement = $_POST['measurement'];
                                        $unit = $_POST['unit'];

                                        if ($name && $category && $unit) {
                                            $sql = "SELECT product_name, category FROM product WHERE `deleted` = 'False' AND id != " . $id;
                                            $query = $conn->query($sql);
                                            $product_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->product_name == $name && $set->category == $category) {
                                                    $product_checked = False;
                                                    break;
                                                }
                                            }

                                            //Price/Stock/Measurement/tax prevents "-" and "e" and Price/stock/Measurement must be atleast 1
                                            $number_checked = True;
                                            if (strpbrk($price, 'e-') !== false || strpbrk($stock, 'e-.') !== false || strpbrk($measurement, 'e-') !== false || strpbrk($tax, 'e-') || !$tax || !$price || !$measurement || $tax <= 0 || $tax > 100 || $price <= 0 || $measurement <= 0) {
                                                $number_checked = False;
                                            }


                                            if ($number_checked) {
                                                if ($product_checked) {
                                                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                    if ($_POST['image'] != "") {
                                                        //UPDATE WITH PHOTO
                                                        $image = $_POST['image'];
                                                        $sql = "UPDATE `product` SET `image` = ?, `product_name` = ?, `category` = ?, `measurement` = ?, `unit` = ?, `price` = ?, `tax_percentage` = ?, `stock` = ? WHERE id = '" . $id . "'";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("sssdsddi", $image, $name, $category, $measurement, $unit, $price, $tax, $stock);
                                                    } else {
                                                        //UPLOAD WITHOUT PHOTO
                                                        $sql = "UPDATE `product` SET `product_name` = ?, `category` = ?, `measurement` = ?, `unit` = ?, `price` = ?, `tax_percentage` = ?, `stock` = ? WHERE id = '" . $id . "'";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("ssdsddi", $name, $category, $measurement, $unit, $price, $tax, $stock);
                                                    }

                                                    if ($stmt->execute()) {
                                                        echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Product Added!',
                                                                            text: 'The new product has been registered.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('products.php');
                                                                            }});
                                                                    })
                                                                    
                                                                </script> 
                                                            HTML;
                                                    }
                                                } else {
                                                    //Product repeated
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Product Already Exists!',
                                                                            text: 'Enter a new product and category',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('products.php');
                                                                            }});
                                                                    })
                                                                    </script> 
                                                            HTML;
                                                }
                                            } else {
                                                //Invalid Price
                                                echo <<<HTML
                                                            <script>
                                                                $(document).ready(function() {
                                                                    Swal.fire({
                                                                        icon: 'error',
                                                                        title: 'Invalid Value!',
                                                                        text: 'Ensure that the Price, Tax %, and Measurement are greater than 0, the Tax is less than 100, and the stock is a whole number.',
                                                                        background: '#112240',
                                                                        color: '#CCD6F6',
                                                                        confirmButtonColor: '#e60000',
                                                                        heightAuto: false
                                                                    }).then((result) => {
                                                                        if(result.isConfirmed) {
                                                                            location.assign('products.php');
                                                                        }});
                                                                })
                                                                </script> 
                                                        HTML;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Add New Product</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="addProductForm" method="POST">

                                <div class="mb-3">
                                    <label class="form-label">Product Name</label>
                                    <input type="text" class="form-control" name="name" required placeholder="e.g. 10L Gallon">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Refill Price</label>
                                    <input type="number" class="form-control" name="price" required placeholder="e.g. 100">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Tax %</label>
                                    <input type="number" class="form-control" name="tax" required placeholder="e.g. 12">
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Measurement</label>
                                        <input type="number" step="0.01" class="form-control" name="measurement" required placeholder="e.g. 5">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Unit</label>
                                        <select class="form-select" name="unit" required>
                                            <option value="" disabled selected>Select a unit...</option>
                                            <option value="L">Liters</option>
                                            <option value="ML">Milliliters</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Stock</label>
                                    <input type="number" class="form-control" name="stock" required placeholder="e.g. 25">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit Price</label>
                                    <input type="number" class="form-control" name="container_price" required placeholder="e.g. 25">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Image</label>
                                    <input type="file" class="form-control" name="image" id="productImage" accept="image/*" required>
                                </div>

                                <div class="mb-2 text-center d-none" id="imagePreviewContainer">
                                    <img id="imagePreview" src="" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="addProductBtn">Add Product</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>



            <div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Edit Product</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form id="addProductForm" method="POST">

                                <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                                <input type="number" name="id" id="edit-id" hidden>

                                <div class="mb-3">
                                    <label class="form-label">Product Name</label>
                                    <input type="text" class="form-control" name="name" required placeholder="e.g. 10L Gallon" id="edit-name">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Price</label>
                                    <input type="number" class="form-control" name="price" required placeholder="e.g. 100" id="edit-price">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Tax %</label>
                                    <input type="number" class="form-control" name="tax" required placeholder="e.g. 12" id="edit-tax">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category">
                                        <option value="" id="edit-category" selected></option>
                                        <option value="Refill">Refill</option>
                                        <option value="New Container">New Container</option>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label class="form-label">Measurement</label>
                                        <input type="number" class="form-control" name="measurement" id="edit-measurement" required placeholder="e.g. 5">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">Unit</label>
                                        <select class="form-select" name="unit" required>
                                            <option value="" id="edit-unit" selected></option>
                                            <option value="L">L</option>
                                            <option value="ML">ML</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Stock</label>
                                    <input type="number" class="form-control" name="stock" required placeholder="e.g. 25" id="edit-stock">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Product Image</label>
                                    <input type="file" name="image" class="form-control" id="productImageEdit" accept="image/*">
                                </div>

                                <div class="mb-2 text-center" id="imagePreviewContainerEdit">
                                    <img id="imagePreviewEdit" value="" class="edit-image" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="editProductBtn">Edit Product</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>
    <script>
        $(document).ready(function() {

            $('.btn-edit').click(function() {

                //Used to pre-load the edit section since it's not connected to PHP
                id = $(this).data('id');
                image = $(this).data('image');
                name = $(this).data('name');
                category = $(this).data('category');
                measurement = $(this).data('measurement');
                unit = $(this).data('unit');
                stock = $(this).data('stock');
                price = $(this).data('price');
                tax = $(this).data('tax');

                //Resets the value of file if cancelled
                $("#productImageEdit").val("");

                $("#edit-id").val(id);
                $("#imagePreviewEdit").attr("src", "../Images/" + image);
                $("#edit-name").val(name);
                $("#edit-category").text(category);
                $("#edit-category").attr("value", category);
                $("#edit-measurement").val(measurement);
                $("#edit-unit").text(unit);
                $("#edit-unit").attr("value", unit);
                $("#edit-stock").val(stock);
                $("#edit-price").val(price);
                $("#edit-tax").val(tax);

            });



            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false

                });
            });



            $(".btn-add").click(function() {
                $('#addProductModal').modal('show');
                //Dito ko nalang nilagay toh since nag r-reset din naman sya before pa mag open yung modal
                $('#imagePreviewContainer').addClass('d-none');
                $('#imagePreview').attr('src', '');
            });

            $(".btn-edit").click(function() {
                $('#editProductModal').modal('show');
            });

        });

        // Image Preview Logic for Add Product Modal
        $('#productImage').change(function(e) {
            let reader = new FileReader();

            // When the file is read, put it in the image tag and show the container
            reader.onload = function(e) {
                $('#imagePreview').attr('src', e.target.result);
                $('#imagePreviewContainer').removeClass('d-none');
            }

            // Read the file the user selected
            if (this.files[0]) {
                reader.readAsDataURL(this.files[0]);
            }
        });

        $('#productImageEdit').change(function(e) {
            let reader = new FileReader();

            // When the file is read, put it in the image tag and show the container
            reader.onload = function(e) {
                $('#imagePreviewEdit').attr('src', e.target.result);
                //$('#imagePreviewContainer').removeClass('d-none');
            }

            // Read the file the user selected
            if (this.files[0]) {
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>