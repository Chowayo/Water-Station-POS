<style>
    .profile-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background-color: rgba(100, 255, 218, 0.12);
        color: #64FFDA;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        font-weight: 700;
        flex-shrink: 0;
        border: 1px solid rgba(100, 255, 218, 0.35);
    }

    .profile-tabs {
        display: flex;
        gap: 20px;
        border-bottom: 1px solid #233554;
        margin-bottom: 1.5rem;
    }

    .profile-tab-btn {
        background: transparent;
        border: none;
        color: #8892B0;
        font-weight: 600;
        font-size: 14px;
        padding: 0 2px 12px 2px;
        margin-bottom: -1px;
        border-bottom: 2px solid transparent;
        cursor: pointer;
        transition: 0.2s;
    }

    .profile-tab-btn:hover {
        color: #CCD6F6;
    }

    .profile-tab-btn.active {
        color: #64FFDA;
        border-bottom-color: #64FFDA;
    }

    .profile-tab-panel {
        display: none;
    }

    .profile-tab-panel.active {
        display: block;
    }

    .profile-info-item {
        background-color: #0A192F;
        border: 1px solid #233554;
        border-radius: 10px;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        height: 100%;
    }

    .profile-info-icon {
        width: 34px;
        height: 34px;
        border-radius: 8px;
        background: rgba(100, 255, 218, 0.1);
        color: #64FFDA;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 16px;
    }

    .password-field-wrap {
        position: relative;
    }

    .password-toggle-btn {
        position: absolute;
        right: 12px;
        top: 37px;
        background: none;
        border: none;
        color: #8892B0;
        cursor: pointer;
        padding: 0;
        font-size: 15px;
    }

    .password-toggle-btn:hover {
        color: #64FFDA;
    }
</style>

<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">

            <div class="modal-header pb-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="profile-avatar">
                        <?php
                        $pf_first_name = (isset($admin_profile) && $admin_profile->first_name) ? $admin_profile->first_name : (isset($result) ? $result->first_name : 'A');
                        echo strtoupper(substr($pf_first_name, 0, 1));
                        ?>
                    </div>
                    <div>
                        <h5 class="modal-title m-0">Admin Profile</h5>
                        <p class="small mb-0" style="color: #8892B0;"><?php echo isset($admin_profile) ? $admin_profile->email : (isset($result) ? $result->email : 'Admin@gmail.com'); ?></p>
                    </div>
                </div>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">

                <!-- Tabs -->
                <div class="profile-tabs" id="profileTabs">
                    <button type="button" class="profile-tab-btn active" id="profileTabInfoBtn" data-tab="info"><i class="bi bi-person-badge me-1"></i>Account Info</button>
                    <button type="button" class="profile-tab-btn" id="profileTabSecurityBtn" data-tab="security"><i class="bi bi-shield-lock me-1"></i>Security</button>
                </div>

                <!-- Account Info Panel -->
                <div class="profile-tab-panel active" id="profile-panel-info">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <div class="profile-info-item">
                                <div class="profile-info-icon"><i class="bi bi-hash"></i></div>
                                <div>
                                    <p class="small mb-0" style="color: #8892B0;">ID</p>
                                    <p class="fw-bold profile-info-text mb-0"><?php echo isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : '1'); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <div class="profile-info-item">
                                <div class="profile-info-icon"><i class="bi bi-person"></i></div>
                                <div>
                                    <p class="small mb-0" style="color: #8892B0;">Full Name</p>
                                    <p class="fw-bold profile-info-text mb-0"><?php echo (isset($admin_profile) && $admin_profile->first_name) ? ($admin_profile->first_name . " " . $admin_profile->last_name) : (isset($result) ? ($result->first_name . " " . $result->last_name) : 'Admin'); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="profile-info-item">
                                <div class="profile-info-icon"><i class="bi bi-envelope"></i></div>
                                <div>
                                    <p class="small mb-0" style="color: #8892B0;">Email Address</p>
                                    <p class="fw-bold profile-info-text mb-0"><?php echo isset($admin_profile) ? $admin_profile->email : (isset($result) ? $result->email : 'Admin@gmail.com'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Change Password Panel -->
                <div class="profile-tab-panel" id="profile-panel-security">
                    <form id="adminChangePasswordForm" method="POST">
                        <input type="hidden" name="admin_id" value="<?php echo isset($admin_profile) ? $admin_profile->role : (isset($result) ? $result->role : ''); ?>">

                        <div class="mb-3 password-field-wrap">
                            <label for="adminCurrentPassword" class="profile-label small">Current Password</label>
                            <input type="password" class="form-control profile-input" id="adminCurrentPassword" name="current_password" required>
                            <button type="button" class="password-toggle-btn" data-target="adminCurrentPassword"><i class="bi bi-eye"></i></button>
                        </div>
                        <div class="mb-3 password-field-wrap">
                            <label for="adminNewPassword" class="profile-label small">New Password</label>
                            <input type="password" class="form-control profile-input" id="adminNewPassword" name="new_password" required>
                            <button type="button" class="password-toggle-btn" data-target="adminNewPassword"><i class="bi bi-eye"></i></button>
                        </div>
                        <div class="mb-4 password-field-wrap">
                            <label for="adminConfirmPassword" class="profile-label small">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="adminConfirmPassword" name="confirm_password" required>
                            <button type="button" class="password-toggle-btn" data-target="adminConfirmPassword"><i class="bi bi-eye"></i></button>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" name="changePass" class="btn px-4 fw-bold rounded-pill" style="background-color: #64FFDA; color: #0A192F;"><i class="bi bi-check2-circle me-1"></i>Save Changes</button>
                        </div>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        //Remove Account
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];
                            $role = $_POST['admin_id'];

                            //Checking if current password matched
                            if (password_verify($current_pass, $result->password)) {
                                //Password must be atleast 8 characters
                                if (strlen($new_pass) >= 8) {
                                    //Confirm pass and new pass mathes
                                    if ($new_pass == $confirm_pass) {
                                        //New pass must not match current pass
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process

                                            if ($role == "Admin") {
                                                $sql = "UPDATE `admin` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            } else if ($role == "HR" || $role == "Financer") {
                                                $sql = "UPDATE `employees` SET `password` = ? WHERE id = '" . $result->id . "' AND role = '" . $result->role . "'";
                                            }

                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); document.getElementById('profileTabSecurityBtn').click();">Ok</a>`
                                                            })
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); document.getElementById('profileTabSecurityBtn').click();">Ok</a>`
                                                        })
                                                    })
                                                </script> 
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',  
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); document.getElementById('profileTabSecurityBtn').click();">Ok</a>`
                                                        })
                                                    });
                                                </script> 
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',  
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); document.getElementById('profileTabSecurityBtn').click();">Ok</a>`
                                                })
                                            });
                                        </script> 
                                    HTML;
                            }
                        }
                    }
                    ?>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#profileTabs .profile-tab-btn').on('click', function() {
            $('#profileTabs .profile-tab-btn').removeClass('active');
            $(this).addClass('active');

            var tab = $(this).data('tab');
            $('.profile-tab-panel').removeClass('active');
            $('#profile-panel-' + tab).addClass('active');
        });

        $('.password-toggle-btn').on('click', function() {
            var target = $(this).data('target');
            var input = $('#' + target);
            var icon = $(this).find('i');

            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });
    });
</script>