<?php
require('dbConn.php');

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory"){
    header('location: /Inventory/stocks.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier"){
    header('location: /Supplier/orders.php');
    exit;
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#1e1e1e">
    <title>Eco Hydrate Hub - Home & Careers</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="landing-page">
    <main class="site-shell">
        <nav class="site-nav" aria-label="Main navigation">
            <a class="brand" href="#home" aria-label="Eco Hydrate Hub home">
                <img src="Images/logo.png" alt="Eco Hydrate Hub">
            </a>
            <button class="menu-toggle" type="button" aria-label="Toggle menu" aria-expanded="false">
                <i class="bi bi-list"></i>
            </button>
            <div class="nav-content">
                <div class="nav-links">
                    <a class="active" href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#products">Products</a>
                    <a href="#expertise">Expertise</a>
                    <a href="#contact">Contact</a>
                    <a href="#careers">Careers</a>

                </div>
                <a class="login-btn" href="login.php">Login</a>
            </div>
        </nav>

        <section class="hero-panel" id="home">
            <div class="hero-copy">
                <h1>Thirst<br>for more</h1>
                <p>Eco Hydrate Hub integrates smart monitoring with eco-friendly water distribution. Track consumption, manage station status, and ensure pure, safe drinking water through a single, real-time management platform.</p>
                <a class="start-btn" href="Customer/registration.php">Get Started</a>
            </div>

            <div class="brand-showcase">
                <div class="gallon-stage" aria-hidden="true">
                    <div class="gallon-glow"></div>
                    <img src="Images/Landing%20Page/gallon.png" alt="">
                </div>
                <p class="wordmark"><span>Eco</span> Hydrate</p>
            </div>
        </section>

        <section class="stats-bar" aria-label="Eco Hydrate Hub statistics">
            <div class="stat-item reveal" style="--reveal-delay: 0s">
                <i class="bi bi-person-heart" aria-hidden="true"></i>
                <p><strong>10,000+</strong><span>Happy Customers</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.1s">
                <i class="bi bi-shop-window" aria-hidden="true"></i>
                <p><strong>10</strong><span>Branches</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.2s">
                <i class="bi bi-truck" aria-hidden="true"></i>
                <p><strong>20,000+</strong><span>Total Services</span></p>
            </div>
            <div class="stat-item reveal" style="--reveal-delay: 0.3s">
                <i class="bi bi-people" aria-hidden="true"></i>
                <p><strong>100+</strong><span>Employees</span></p>
            </div>
        </section>

        <!-- ABOUT -->
        <section class="about-section" id="about" aria-labelledby="about-title">
            <div class="about-glow"></div>
            <div class="about-heading reveal">
                <h2 id="about-title">About Us</h2>
            </div>

            <div class="about-grid">
                <div class="about-column">
                    <div class="about-card reveal">
                        <span class="about-badge">Better Water. Better Living.</span>
                        <div class="about-panel">
                            <p>Welcome to Eco Hydrate Water Refilling Station, your trusted source of clean, safe, and affordable drinking water. We are committed to providing high-quality purified water that families, businesses, and communities can rely on every day.</p>
                            <p>Our water goes through a careful purification and filtration process to help ensure cleanliness, freshness, and quality. We maintain proper sanitation and regularly monitor our equipment to provide water that meets our quality standards.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.1s">
                        <span class="about-badge">What We Offer?</span>
                        <div class="about-panel">
                            <ul class="about-list">
                                <li>Purified Drinking Water</li>
                                <li>Water Delivery Service</li>
                                <li>Clean and Sanitized Containers</li>
                                <li>Bulk Water or Container Orders</li>
                                <li>Fast and Reliable Service</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="about-column">
                    <div class="about-card reveal">
                        <span class="about-badge">Our Mission</span>
                        <div class="about-panel">
                            <p>To provide safe, clean, and affordable drinking water while delivering friendly, reliable, and convenient service to every customer.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.1s">
                        <span class="about-badge">Our Vision</span>
                        <div class="about-panel">
                            <p>To become a trusted water refilling station in the community, known for quality water, excellent service, and customer satisfaction.</p>
                        </div>
                    </div>

                    <div class="about-card reveal" style="--reveal-delay: 0.2s">
                        <span class="about-badge">Our Commitment</span>
                        <div class="about-panel">
                            <p>Your health and satisfaction are important to us. We continuously strive to maintain cleanliness, quality, and dependable service so you can enjoy safe and refreshing drinking water every day.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="products-section" id="products" aria-labelledby="products-title">
            <div class="products-heading reveal">
                <h2 id="products-title">Our products</h2>
                <p>Eco Hydrate tackles the crisis of single-use plastic waste by offering communities a convenient, affordable way to access safe, multi-stage purified drinking water. Driven by a mission to make sustainable living effortless, Eco Hydrate allows customers to refill their existing containers at purchase, durable, reusable ones directly in-store. By replacing single-use plastic with a practical, zero-waste alternative, the store reduces localized pollution and cuts carbon emissions—empowering individuals to protect the planet, one refill at a time.</p>
            </div>
            <div class="product-grid">
                <article class="product-card featured reveal">
                    <div class="product-icon"><i class="bi bi-droplet-fill" aria-hidden="true"></i></div>
                    <h3>Refill</h3>
                    <p style="font-size: medium;"> Bring your own bottles or jugs and top up with fresh, multi-stage purified water for a fast, affordable, zero-waste fix.</p>
                    <a href="login.php">Order now</a>
                </article>
                <article class="product-card reveal" style="--reveal-delay: 0.1s">
                    <div class="product-icon"><i class="bi bi-journal-bookmark-fill" aria-hidden="true"></i></div>
                    <h3>Containers</h3>
                    <p style="font-size: medium;">Don't have a bottle? Pick from our durable,
                        BPA-free jugs and stainless steel flasks built for long-lasting, zero-waste hydration.</p>
                    <a href="login.php">Order now</a>
                </article>
            </div>
        </section>

        <!-- EXPERTISE -->
        <section class="expertise-section" id="expertise" aria-labelledby="expertise-title">
            <div class="expertise-heading reveal">
                <h2 id="expertise-title">OUR EXPERTISE</h2>
                <p>We provide clean, purified, and quality drinking water for your home, school, or business.</p>
            </div>

            <div class="expertise-content">
                <!-- Left Column Features -->
                <div class="expertise-column left">
                    <div class="expertise-card reveal reveal--left">
                        <div class="exp-icon"><i class="bi bi-droplet-fill"></i></div>
                        <div class="exp-text">
                            <h4>Custom Refills</h4>
                            <p>Fast, affordable refills for any container size—from personal flasks to 5-gallon home dispensers.</p>
                        </div>
                    </div>

                    <div class="expertise-card reveal reveal--left" style="margin-top: 1rem; --reveal-delay: 0.1s">
                        <div class="exp-icon"><i class="bi bi-truck"></i></div>
                        <div class="exp-text">
                            <h4>Bulk Delivery</h4>
                            <p>Scheduled refills and dispenser setups for homes, offices, and local events.</p>
                        </div>
                    </div>
                </div>

                <!-- Water 3D Drop -->
                <div class="expertise-center reveal reveal--scale">
                    <div class="water-drop-3d"></div>
                </div>

                <!-- Right Column Features -->
                <div class="expertise-column right">
                    <div class="expertise-card reveal reveal--right">
                        <div class="exp-icon"><i class="bi bi-ui-checks"></i></div>
                        <div class="exp-text">
                            <h4>Multi-Stage Purification</h4>
                            <p>Don't have a bottle? Pick from our durable, BPA-free jugs and stainless steel flasks built for long-lasting, zero-waste hydration.</p>
                        </div>
                    </div>

                    <div class="expertise-card reveal reveal--right" style="margin-top: 1rem; --reveal-delay: 0.1s">
                        <div class="exp-icon"><i class="bi bi-shield-fill-check"></i></div>
                        <div class="exp-text">
                            <h4>Sanitation Services</h4>
                            <p>Professional washing and UV-sterilizing for your bottles to ensure safe, highest hydration every time.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- CONTACT US -->
        <section class="contact-section" id="contact" aria-labelledby="contact-title">
            <div class="contact-heading reveal">
                <h2 id="contact-title">Contact Us</h2>
                <p>For inquiries, orders, and delivery requests, please contact us through the information provided.</p>
            </div>

            <div class="contact-grid">
                <!-- Left Column -->
                <div class="contact-left reveal reveal--left">
                    <h3 class="contact-brand-title"><span>Eco</span><br>Hydrate</h3>
                    <div class="contact-image-wrapper">
                        <img src="Images/Landing%20Page/gallon.png" alt="Eco Hydrate Gallon">
                    </div>
                </div>

                <!-- Right Column (Panel) -->
                <div class="contact-panel reveal reveal--right">
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-telephone-fill"></i></div>
                        <div class="contact-text">+63 9123 456 7895</div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-envelope-fill"></i></div>
                        <div class="contact-text">
                            <a href="mailto:EcoHydrate@gmail.com">EcoHydrate@gmail.com</a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-clock-fill"></i></div>
                        <div class="contact-text">[Opening Time] – [Closing Time]</div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon"><i class="bi bi-geo-alt-fill"></i></div>
                        <div class="contact-text">Amafel Building, Aguinaldo Highway, Dasmarinas, Cavite 4114</div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- CAREERS -->
    <section class="careers-section" id="careers" aria-labelledby="careers-title">
        <div class="careers-heading reveal">
            <h2 id="careers-title">Join Our Team</h2>
            <p>Help us revolutionize eco-friendly water distribution. Discover open roles below and apply to become part of the growing Eco Hydrate Hub family.</p>
        </div>

        <div class="job-grid">
            <!-- Job Card 1 -->
            <article class="job-card reveal">
                <div class="job-dept">Operations</div>
                <h3>Delivery Rider</h3>
                <div class="job-meta">
                    <span><i class="bi bi-geo-alt"></i> Dasmariñas, Cavite</span>
                    <span><i class="bi bi-clock"></i> Full-time</span>
                    <span><i class="bi bi-cash-stack"></i> ₱15,000 - ₱18,000</span>
                </div>
                <p class="job-desc">Responsible for timely delivery of water containers to residential and commercial customers within the assigned area. Must have a valid driver's license.</p>
                <button class="btn-apply-job" onclick="openApplicationModal('Delivery Rider')">
                    <i class="bi bi-send-fill me-2"></i>Apply Now
                </button>
            </article>

            <!-- Job Card 2 -->
            <article class="job-card reveal" style="--reveal-delay: 0.1s">
                <div class="job-dept">Human Resources</div>
                <h3>HR Assistant</h3>
                <div class="job-meta">
                    <span><i class="bi bi-geo-alt"></i> Head Office</span>
                    <span><i class="bi bi-clock"></i> Full-time</span>
                    <span><i class="bi bi-cash-stack"></i> ₱18,000 - ₱22,000</span>
                </div>
                <p class="job-desc">Support day-to-day HR operations including recruitment coordination, maintaining employee records, and monitoring attendance.</p>
                <button class="btn-apply-job" onclick="openApplicationModal('HR Assistant')">
                    <i class="bi bi-send-fill me-2"></i>Apply Now
                </button>
            </article>

            <!-- Job Card 3 -->
            <article class="job-card reveal" style="--reveal-delay: 0.2s">
                <div class="job-dept">Logistics</div>
                <h3>Warehouse Staff</h3>
                <div class="job-meta">
                    <span><i class="bi bi-geo-alt"></i> Main Warehouse</span>
                    <span><i class="bi bi-clock"></i> Full-time</span>
                    <span><i class="bi bi-cash-stack"></i> ₱14,000 - ₱16,000</span>
                </div>
                <p class="job-desc">Assist with inventory handling, safe loading and unloading of stock, and maintaining general warehouse organization and cleanliness.</p>
                <button class="btn-apply-job" onclick="openApplicationModal('Warehouse Staff')">
                    <i class="bi bi-send-fill me-2"></i>Apply Now
                </button>
            </article>
        </div>
    </section>

    <!-- Job Application Modal -->
    <div id="applicationModalOverlay" class="custom-overlay">
        <div class="custom-modal">
            <button class="btn-modal-close" onclick="closeApplicationModal()">&times;</button>
            <h3 style="color: #fff; margin-top: 0; font-size: 1.5rem; font-weight: 700;">Apply for <span id="modalTargetJob" style="color: #64FFDA;">Role</span></h3>
            <p style="color: #8892B0; font-size: 0.9rem; margin-bottom: 1.5rem;">Take the next step in your career with Eco Hydrate Hub.</p>

            <div id="appSuccessMsg">
                <i class="bi bi-check-circle-fill me-2"></i> Application submitted successfully! We will review your profile shortly.
            </div>

            <form id="jobAppForm">
                <input type="hidden" id="appliedPosition" name="appliedPosition">

                <label class="form-label-custom">Full Name</label>
                <input type="text" class="form-input-custom" required placeholder="Juan Dela Cruz">

                <label class="form-label-custom">Email Address</label>
                <input type="email" class="form-input-custom" required placeholder="juan@example.com">

                <label class="form-label-custom">Contact Number</label>
                <input type="tel" class="form-input-custom" required placeholder="09XX XXX XXXX">

                <label class="form-label-custom">Upload Resume (PDF/DOCX)</label>
                <input type="file" class="form-input-custom" accept=".pdf,.doc,.docx" required>

                <button type="submit" class="btn-submit-app" id="submitAppBtn">
                    Submit Application <i class="bi bi-arrow-right ms-1"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="footer-top">
            <div class="footer-brand">
                <a class="footer-logo" href="#home">
                    <img src="Images/logo.png" alt="Eco Hydrate Hub">
                    <span><em>Eco</em> Hydrate</span>
                </a>
                <p>Smart, eco-friendly water refilling and delivery — bringing clean, purified water to homes and businesses while cutting down on single-use plastic waste.</p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook"><i class="bi bi-facebook"></i></a>
                    <a href="#" aria-label="Instagram"><i class="bi bi-instagram"></i></a>
                    <a href="#" aria-label="Messenger"><i class="bi bi-messenger"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#products">Products</a></li>
                    <li><a href="#expertise">Expertise</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Company</h4>
                <ul>
                    <li><a href="#careers">Careers</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="Customer/registration.php">Get Started</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4>Contact</h4>
                <ul class="footer-contact">
                    <li><i class="bi bi-telephone-fill"></i><span>+63 9123 456 7895</span></li>
                    <li><i class="bi bi-envelope-fill"></i><span><a href="mailto:EcoHydrate@gmail.com" style="color:inherit;">EcoHydrate@gmail.com</a></span></li>
                    <li><i class="bi bi-geo-alt-fill"></i><span>Amafel Building, Aguinaldo Highway, Dasmariñas, Cavite 4114</span></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Eco Hydrate Hub. All rights reserved.</p>
            <div class="footer-legal">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
            </div>
        </div>
    </footer>

    <script>
        /* Scroll Reveal */
        (function() {
            if (window.CSS && CSS.supports && CSS.supports('animation-timeline: view()')) {
                return;
            }
            const revealEls = document.querySelectorAll('.reveal');
            if (!revealEls.length) return;
            const revealObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        revealObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.15,
                rootMargin: '0px 0px -10% 0px'
            });
            revealEls.forEach(el => revealObserver.observe(el));
        })();

        const toggle = document.querySelector('.menu-toggle');
        const nav = document.querySelector('.site-nav');
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('menu-open');
            toggle.setAttribute('aria-expanded', open);
        });

        window.addEventListener('scroll', () => {
            nav.classList.toggle('scrolled', window.scrollY > 8);
        });

        // Highlight the nav link
        const navLinks = document.querySelectorAll('.nav-links a');
        const sections = [...navLinks]
            .map(link => {
                if (!link.getAttribute('href').startsWith('#')) return null;
                return document.querySelector(link.getAttribute('href'));
            })
            .filter(Boolean);

        const spyObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                navLinks.forEach(link => {
                    if (link.getAttribute('href').startsWith('#')) {
                        link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
                    }
                });
            });
        }, {
            rootMargin: '-40% 0px -55% 0px',
            threshold: 0
        });

        sections.forEach(section => spyObserver.observe(section));

        const overlay = document.getElementById('applicationModalOverlay');
        const appForm = document.getElementById('jobAppForm');
        const successMsg = document.getElementById('appSuccessMsg');
        const submitBtn = document.getElementById('submitAppBtn');

        function openApplicationModal(jobTitle) {
            appForm.reset();
            appForm.style.display = 'block';
            successMsg.style.display = 'none';
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Submit Application <i class="bi bi-arrow-right ms-1"></i>';
            submitBtn.style.opacity = '1';

            document.getElementById('modalTargetJob').innerText = jobTitle;
            document.getElementById('appliedPosition').value = jobTitle;

            overlay.classList.add('active');
        }

        function closeApplicationModal() {
            overlay.classList.remove('active');
        }

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closeApplicationModal();
            }
        });

        appForm.addEventListener('submit', function(e) {
            e.preventDefault();

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Sending...';
            submitBtn.style.opacity = '0.7';

            setTimeout(() => {
                appForm.style.display = 'none';
                successMsg.style.display = 'block';

            }, 1000);
        });
    </script>
</body>

</html>