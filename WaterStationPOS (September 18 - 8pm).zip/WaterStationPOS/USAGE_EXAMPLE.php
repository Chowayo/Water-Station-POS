<?php
/**
 * Example: how to send an email from any page in the app.
 *
 * Drop the mailer/ folder into your project root, next to your
 * phpmailer/ (Composer) folder:
 *
 *   your-project/
 *   ├── phpmailer/                 ← already exists (Composer)
 *   │   └── vendor/autoload.php
 *   ├── mailer/
 *   │   ├── config/mail_config.php
 *   │   └── includes/send_mail.php
 *   ├── orders.php
 *   ├── invoices.php
 *   └── ...
 *
 * If your phpmailer/ folder lives somewhere else relative to mailer/,
 * open mailer/includes/send_mail.php and adjust this line near the top:
 *
 *   require_once __DIR__ . '/../../phpmailer/vendor/autoload.php';
 */

require_once __DIR__ . '/mailer/includes/send_mail.php';

$result = send_email(
    'recipient@example.com',
    'Invoice INV-1024 Approved',
    '<p>Hi,</p><p>Invoice <strong>INV-1024</strong> has been approved and is cleared for payment.</p>'
);

if ($result['success']) {
    echo "Email sent!";
} else {
    echo "Failed to send email: " . htmlspecialchars($result['error']);
}

// --- With CC/BCC and an attachment ---
/*
send_email(
    ['finance@example.com', 'ap@example.com'],
    'Weekly Invoice Summary',
    '<p>Attached is this week\'s invoice summary.</p>',
    [
        'cc'          => ['manager@example.com'],
        'attachments' => ['/mnt/user-data/outputs/summary.pdf'],
        'from_name'   => 'Finance Team',
    ]
);
*/
