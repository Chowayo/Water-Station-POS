<?php 

    //include __DIR__ . '/../components/header.php'; 
    include 'header.php'; 
    $sql = "SELECT * FROM employees WHERE id = " . $user->id;
    $query = $conn->query($sql);
    $result = $query->fetch_object();
?>

<link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

<style>
    .search-container {
        position: relative;
    }

    .search-container .bi-search {
        position: absolute;
        top: 50%;
        left: 12px;
        transform: translateY(-50%);
        color: #8892B0;
        pointer-events: none;
    }

    .search-container input {
        padding-left: 35px !important;
    }

    .table-scroll-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: auto;
        border-radius: 12px;
    }

    .table-scroll-wrap thead th {
        position: sticky;
        top: 0;
        background-color: #112240;
        z-index: 1;
    }

    .dataTables_wrapper {
        color: #CCD6F6;
    }

    .dataTables_wrapper .dataTables_info {
        color: #8892B0;
        font-size: 0.85rem;
        padding-top: 14px;
    }

    .dataTables_wrapper .dataTables_paginate {
        padding-top: 10px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
        color: #CCD6F6 !important;
        border: 1px solid #233554 !important;
        background: transparent !important;
        border-radius: 8px;
        margin-left: 4px;
        padding: 4px 12px;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
        color: #4d5f82 !important;
        cursor: not-allowed;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
        background: rgba(100, 255, 218, 0.1) !important;
        border-color: #64FFDA !important;
        color: #64FFDA !important;
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current {
        background: #64FFDA !important;
        border-color: #64FFDA !important;
        color: #0A192F !important;
        font-weight: 700;
    }

    .dataTables_wrapper .d-flex.justify-content-between {
        flex-wrap: wrap;
        align-items: center;
    }

    /* Stock status badges */
    .status-instock {
        background-color: rgba(0, 230, 118, 0.1);
        color: #00e676;
        border: 1px solid #00e676;
    }

    .status-lowstock {
        background-color: rgba(255, 193, 7, 0.1);
        color: #ffc107;
        border: 1px solid #ffc107;
    }

    .status-outofstock {
        background-color: rgba(255, 82, 82, 0.1);
        color: #ff5252;
        border: 1px solid #ff5252;
    }
</style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Inventory Management</h1>
                    <h6>Track stock levels for containers, cap, filters, and supplies</h6>
                </div>
            </header>

            <!-- KPI Summary Cards (static placeholder numbers) -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Total Items</div>
                        <div class="dash-value">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stocks WHERE deleted ='False'";
                                $query = $conn->query($sql);
                                $currents_stock = $query->fetch_object();

                                if ($currents_stock != "") {
                                    echo $currents_stock->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Low Stock</div>
                        <div class="dash-value" style="color:#ffc107;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stocks WHERE deleted ='False' AND current_stock > 0 AND current_stock < 15";
                                $query = $conn->query($sql);
                                $low_stock = $query->fetch_object();

                                if ($low_stock != "") {
                                    echo $low_stock->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Out of Stock</div>
                        <div class="dash-value" style="color:#ff5252;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM stocks WHERE deleted ='False' AND current_stock = 0";
                                $query = $conn->query($sql);
                                $no_stock = $query->fetch_object();

                                if ($no_stock != "") {
                                    echo $no_stock->total;
                                } else {
                                    echo "0";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card">
                        <div class="dash-title">Inventory Value</div>
                        <div class="dash-value">
                            <?php
                                $inventory_value = 0;
                                $sql = "SELECT * FROM stocks WHERE deleted = 'False' AND current_stock >0";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    $inventory_value += round($set->current_stock * $set->cost, 2);
                                }
                                echo "₱".number_format($inventory_value, 2);
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">All Supply Items</div>
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">Stock Directory</h5>
                            <div class="d-flex flex-wrap gap-2">

                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Item" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap">+ Add New Item</button>
                            </div>
                        </div>

                        <script>
                            $(document).ready(function() {
                                var table = $('#inventory_list').DataTable({
                                    paging: true,
                                    pageLength: 10,
                                    lengthChange: false,
                                    searching: true,
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>',
                                    "order": [[ 0, "desc" ]]
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw();
                                });

                                $('#categoryFilter').on('change', function() {
                                    table.column(1).search(this.value).draw();
                                });
                            });
                        </script>

                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="inventory_list">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Category</th>
                                    <th>Item Name</th>
                                    <th>Current Stock</th>
                                    <th>Unit Cost</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Static sample rows for UI preview only -->
                                <?php
                                    $sql = "SELECT * FROM stocks WHERE deleted = 'False' ORDER BY id DESC";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo'
                                            <tr>
                                                <td>'.$set->id.'</td>
                                                <td>'.$set->category.'</td>
                                                <td>'.$set->name.'</td>
                                                <td>'.$set->current_stock.'</td>
                                                <td>₱'.$set->cost.'</td>';
                                        if($set->current_stock<=15 && $set->current_stock>0){
                                            echo '  <td><span class="status-badge status-lowstock">Low Stock</span></td>';
                                        }
                                        else if($set->current_stock>0){
                                            echo '  <td><span class="status-badge status-instock">In Stock</span></td>';
                                        }
                                        else if($set->current_stock<=0){
                                            echo '  <td><span class="status-badge status-outofstock">Out of Stock</span></td>';
                                        }
                                        echo '  <td>                                                    
                                                    <button class="btn btn-remove btn-sm rounded-pill px-3" data-id="'.$set->id.'">
                                                        <i class="bi bi-trash-fill me-1"></i>Remove
                                                    </button>
                                                </td>
                                            </tr>
                                        ';
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add Item Modal -->
            <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Add New Supply Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form method="POST" id="addInventoryForm">

                                <div class="mb-3">
                                    <label class="form-label">Item Name</label>
                                    <input type="text" class="form-control" name="name" required placeholder="e.g. 5-Gallon Container">
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Category</label>
                                    <select class="form-select" name="category" required>
                                        <option value="" disabled selected>Select a Category...</option>
                                        <option value="container">Container</option>
                                        <option value="chemicals">Chemicals</option>
                                        <option value="cap">Caps</option>
                                        <option value="filter">Filter</option>
                                        <option value="others">Others</option>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col">
                                        <label class="form-label">Current Stock</label>
                                        <input type="number" class="form-control" name="current_stock" required placeholder="e.g. 50">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit Cost</label>
                                    <input type="number" step="0.01" class="form-control" name="cost" required placeholder="e.g. 45.00">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="addInventoryBtn">Add Item</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Item Modal -->
            <div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content shadow-lg">

                        <div class="modal-header">
                            <h5 class="modal-title">Edit Supply Item</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <div class="modal-body p-4">
                            <form method="POST" id="editInventoryForm">

                                <input type="number" name="id" id="edit-id" hidden>

                                <div class="mb-3">
                                    <label class="form-label">Item Name</label>
                                    <input type="text" class="form-control" name="name" required id="edit-name">
                                </div>


                                <div class="mb-3">
                                    <label class="form-label">Unit</label>
                                    <select class="form-select" name="category" id="edit-category-select" required>
                                        <option value="" disabled selected>Select a Category...</option>
                                        <option value="container">Container</option>
                                        <option value="chemicals">Chemicals</option>
                                        <option value="cap">Caps</option>
                                        <option value="filter">Filter</option>
                                        <option value="others">Others</option>
                                    </select>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-">
                                        <label class="form-label">Current Stock</label>
                                        <input type="number" class="form-control" name="current_stock" required id="edit-stock">
                                    </div>

                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Unit Cost</label>
                                    <input type="number" step="0.01" class="form-control" name="cost" required id="edit-cost">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="editInventoryBtn">Save Changes</button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                    // Add Inventory Item
                    if (isset($_POST['adder'])) {
                        $name = trim($_POST['name']);
                        $category = $_POST['category'];
                        $current_stock = $_POST['current_stock'];
                        $cost = $_POST['cost'];

                        $number_checked = True;
                        if (strpbrk($current_stock, 'e-') !== false || strpbrk($cost, 'e-.') !== false) {
                            $number_checked = False;
                        }

                        if($name && $category && $cost && $number_checked){
                            $sql = "INSERT INTO `stocks` (`name`, `category`, `current_stock`, `cost`) VALUES (?, ?, ?, ?)";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("ssid", $name, $category, $current_stock, $cost);
                            
                            if ($stmt->execute()) {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Stock Added!',
                                                text: 'The new stock has been registered.',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('stocks.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                            } 
                            $stmt->close();
                        }else {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Invalid Input!',
                                                text: 'Make sure that every input if valid',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#e60000',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('stocks.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                        }
                    }

                    /*if (isset($_POST['editer'])) {
                        $id = (int)$_POST['id'];
                        $name = trim($_POST['name']);
                        $category = $_POST['category'];
                        $current_stock = (int)$_POST['current_stock'];
                        $cost = (float)$_POST['cost'];

                        $number_checked = true;
                        if (strpbrk($current_stock, 'e-') !== false || strpbrk($cost, 'e-.') !== false) {
                            $number_checked = false;
                        }

                        if ($id && $name && $category && $cost && $number_checked) {
                            $sql = "UPDATE `stocks` SET `name` = ?, `category` = ?, `current_stock` = ?, `cost` = ? WHERE `id` = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("ssidi", $name, $category, $current_stock, $cost, $id);
                            
                            if ($stmt->execute()) {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Stock Updated!',
                                                text: 'The stock details have been updated.',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('stocks.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                            } 
                            $stmt->close();
                        } else {
                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Invalid Input!',
                                            text: 'Make sure that every input is valid',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            confirmButtonColor: '#e60000',
                                            heightAuto: false
                                        }).then((result) => {
                                            if(result.isConfirmed) {
                                                location.assign('stocks.php');
                                            }});
                                    })
                                </script> 
                            HTML;
                        }
                    }*/

                    if (isset($_POST['deleter'])) {
                        $id = (int)$_POST['deleter'];

                        if ($id) {
                            $sql = "UPDATE `stocks` SET `deleted` = 'True' WHERE `id` = ?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("i", $id);

                            if ($stmt->execute()) {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Stock Removed!',
                                                text: 'The stock has been removed.',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                confirmButtonColor: '#00E676',
                                                heightAuto: false
                                            }).then((result) => {
                                                if(result.isConfirmed) {
                                                    location.assign('stocks.php');
                                                }});
                                        })
                                    </script> 
                                HTML;
                            }
                            $stmt->close();
                        }
                    }
                }
            ?>

        </section>
    </main>
    </div>

    
    <script>
        $(document).ready(function() {

            $('.btn-edit').click(function() {
                id = $(this).data('id');
                name = $(this).data('name');
                category = $(this).data('category');
                stock = $(this).data('stock');
                cost = $(this).data('cost');

                $("#edit-id").val(id);
                $("#edit-name").val(name);
                $("#edit-category-select").val(category);
                $("#edit-stock").val(stock);
                $("#edit-cost").val(cost);

                $('#editProductModal').modal('show');
            });

            $(".btn-add").click(function() {
                $('#addProductModal').modal('show');
            });

            $('.btn-remove').click(function() {
                id = $(this).data('id');
                Swal.fire({
                    title: 'Remove Item?',
                    text: "It will be deleted from inventory",
                    icon: 'warning',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',
                    heightAuto: false
                });
            });

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

        });
    </script>