<?php
include 'header.php';

$sql = "SELECT * FROM customers WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

$sql = "SELECT * FROM orders WHERE id = '".$_GET['id']."'";
$query = $conn->query($sql);
$order_info = $query->fetch_object();

?>

<style>
    body {
        background: #0a192f !important;
        display: block !important;
        overflow-y: auto !important;
        padding: 0 !important;
        min-height: 100vh;
    }

    .checkout-container {
        max-width: 1100px;
        margin: 0 auto;
    }

    /* Card Styling */
    .checkout-card {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15);
    }

    .text-primary-accent {
        color: #00e676 !important;
    }

    .btn-primary-accent {
        background-color: #00fc9e;
        color: #000000;
        font-weight: 700;
        border: none;
        border-radius: 25px;
        padding: 14px;
        width: 100%;
        transition: 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }

    .btn-primary-accent:hover {
        background-color: #00e676;
    }

    /* Secondary Accent Button */
    .btn-secondary-accent {
        background-color: transparent;
        color: #1a1a1a;
        font-weight: 700;
        border: 2px solid #00e676;
        /* Green border */
        border-radius: 25px;
        padding: 12px;
        width: 100%;
        transition: 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
    }

    .btn-secondary-accent:hover {
        background-color: rgba(0, 230, 118, 0.1);
        border-color: #00e676;
    }

    .btn-edit-outline {
        background-color: transparent;
        color: #64ffda;
        font-size: 14px;
        text-decoration: none;
        transition: 0.2s;
    }

    .btn-edit-outline:hover {
        color: #00e676;
    }

    /* Form Inputs & Checkboxes */
    .form-control {
        background-color: #0d1b2e !important;
        border: 1px solid #233554 !important;
        color: #ccd6f6 !important;
    }

    .form-control:focus {
        background-color: #0a192f !important;
        border-color: #00e676 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 230, 118, 0.25) !important;
    }

    .form-control::placeholder {
        color: #8892b0 !important;
    }

    .form-check-input {
        background-color: #0d1b2e;
        border: 1px solid #233554;
    }

    .form-check-input:checked {
        background-color: #00e676;
        border-color: #00e676;
    }

    .delivery-option-box,
    .payment-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: 0.2s;
    }

    .payment-box {
        display: block;
    }

    /* When checked */
    .delivery-option-box:has(input:checked),
    .payment-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    h2,
    h4,
    h6,
    .text-white {
        color: #ffffff !important;
    }

    .text-muted {
        color: #8892b0 !important;
    }

    .custom-link {
        color: #64ffda;
        text-decoration: none;
        font-weight: 600;
        transition: 0.2s;
    }

    .custom-link:hover {
        color: #00e676;
    }

    .divider {
        border-color: #233554;
        opacity: 1;
    }

    .icon-box {
        background-color: #112240;
        border: 1px solid #233554;
    }

    .modal-content {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 15px;
    }

    .modal-header {
        border-bottom: 1px solid #233554;
    }

    .btn-close-white {
        filter: invert(1) grayscale(100%) brightness(200%);
    }

    /* Address Box styling */
    .address-box {
        border: 1px solid #233554;
        background-color: #0d1b2e;
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        transition: 0.2s;
    }

    .address-box:has(input:checked) {
        border: 2px solid #00e676;
        padding: 15px;
        background-color: rgba(0, 230, 118, 0.05);
    }

    .address-box:has(input:checked) .bi-geo-alt {
        color: #00e676 !important;
    }

    .address-actions .btn-icon {
        background: transparent;
        border: none;
        color: #8892b0;
        padding: 4px;
        transition: 0.2s;
        font-size: 18px;
    }

    .address-actions .btn-icon:hover {
        color: #00e676;
    }


    /* Label Buttons */
    .label-btn {
        background-color: #0d1b2e;
        color: #ccd6f6;
        border: 1px solid #233554;
        border-radius: 20px;
        padding: 6px 16px;
        font-size: 14px;
        font-weight: 600;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    .label-btn:hover,
    .label-btn.active {
        background-color: rgba(0, 230, 118, 0.1);
        border-color: #00e676;
        color: #00e676;
    }

    /* Add Address Custom Input */
    .address-search-wrapper {
        position: relative;
        margin-bottom: 20px;
    }

    .address-search-wrapper label {
        position: absolute;
        top: -9px;
        left: 12px;
        background-color: #112240;
        padding: 0 5px;
        font-size: 11px;
        color: #8892b0;
        z-index: 1;
    }

    .address-search-input {
        width: 100%;
        background-color: transparent !important;
        border: 1px solid #233554 !important;
        border-radius: 10px;
        color: #ccd6f6 !important;
        padding: 14px 40px 14px 15px;
        font-size: 14px;
    }

    .address-clear-btn {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #8892b0;
        padding: 0;
        font-size: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
    }


    /* Toggle Switch Styling */
    .order-type-toggle {
        display: inline-flex;
        background-color: #0d1b2e;
        border: 1px solid #233554;
        border-radius: 30px;
        padding: 4px;
        margin-bottom: 24px;
    }

    .toggle-btn {
        background: transparent;
        border: none;
        color: #8892b0;
        font-weight: 600;
        padding: 8px 32px;
        border-radius: 25px;
        transition: 0.3s ease;
    }

    .toggle-btn.active {
        background-color: #00e676;
        color: #000000;
    }

    /* Placing Order Modal Styles */
    .placing-modal-content {
        background-color: #daefff;
        /* Light blue background */
        border-radius: 24px;
        color: #1a1a1a;
        border: none;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    }

    .placing-progress-bg {
        background-color: rgba(0, 0, 0, 0.1);
        height: 6px;
        border-radius: 3px;
        width: 100%;
        overflow: hidden;
        position: relative;
    }

    .placing-progress-bar {
        background-color: #2c2c2c;
        height: 100%;
        width: 0%;
        border-radius: 3px;
    }

    @keyframes progressAnim {
        0% {
            width: 0%;
        }

        50% {
            width: 70%;
        }

        100% {
            width: 100%;
        }
    }

    .placing-route-container {
        position: relative;
    }

    .placing-route-line {
        position: absolute;
        left: 11px;
        top: 24px;
        bottom: 24px;
        border-left: 2px dotted #a0a0a0;
        z-index: 1;
    }

    .placing-icon-wrapper {
        background: #daefff;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2;
    }

    .placing-divider {
        border-color: #b0c4d6;
        margin: 16px 0;
        opacity: 1;
    }

    #map{
        height: 500px;
        width: 100%;
        border-radius: 8px;
    }

    
</style>

<div class="content d-flex flex-column flex-grow-1">
    <?php include 'topbar.php'; ?>

    <div class="checkout-container py-5 px-3 flex-grow-1">

        <!-- Page Title -->
        <h2 class="fw-bold mb-4" style="font-size: 28px;">Review and place your order</h2>

        <div class="row g-4">

            <!-- LEFT COLUMN: Delivery Details & Options -->
            <div class="col-lg-7">

                <!-- Order Type Toggle -->
                <div class="order-type-toggle">
                    <button class="toggle-btn active" id="btnDelivery" type="button">Delivery</button>
                    <button class="toggle-btn" id="btnPickup" type="button">Pick-up</button>
                </div>

                <!-- Wrapper for all delivery-specific sections -->
                <div id="deliverySections">
                    <!-- Delivery Address Card -->
                    <div class="checkout-card p-4 mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="fw-bold m-0">Delivery address</h4>
                            <a href="#" class="custom-link" data-bs-toggle="modal" data-bs-target="#addAddressModal">Custom Address</a>
                        </div>

                        <div class="d-flex mb-3 align-items-start">
                            <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                            <div>
                                <p class="m-0 text-white fw-semibold">Account Address</p>
                            </div>
                        </div>

                        <!-- Note to rider input -->
                        <textarea class="form-control mb-4 mt-3" placeholder="Address" id="address_setter" rows="2" style="resize: none;"><?php echo $result->address; ?></textarea>
                    </div>

                    <!-- Delivery Options Card -->
                    <div class="checkout-card p-4 mb-4">
                        <h4 class="fw-bold mb-4">Delivery options</h4>

                        <label class="delivery-option-box mb-3">
                            <div class="d-flex align-items-center gap-3" id="standard_delivery">
                                <input class="form-check-input fs-5 m-0" type="radio" name="delOption" checked>
                                <span class="fw-bold text-white">Standard <span class="fw-normal text-muted ms-2">10 - 25 mins</span></span>
                            </div>
                        </label>

                        <label class="delivery-option-box mb-3">
                            <div class="d-flex align-items-center gap-3" id="priority_delivery">
                                <input class="form-check-input fs-5 m-0" type="radio" name="delOption">
                                <span class="fw-bold text-white">Priority <span class="fw-normal text-muted ms-2">5 - 20 mins</span></span>
                            </div>
                            <span class="badge rounded-pill border border-secondary fw-normal text-muted bg-transparent">+ ₱ 49.00</span>
                        </label>


                    </div>
                </div> <!-- End of deliverySections -->

                <!-- Personal Details Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Personal details</h4>

                    </div>
                    <div>
                        <div class="modal-body p-4 pt-3">
                            <form id="orderConfirm" method="POST">
                                <div class="mb-3">
                                    <label class="form-label text-white fw-semibold">Full Name</label>
                                    <input type="text" class="form-control" value="<?php echo $result->full_name; ?>" name="customer_name">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-white fw-semibold">Email Address</label>
                                    <input type="email" class="form-control" value="<?php echo $result->email; ?>" name="customer_email">
                                </div>
                                <div class="mb-4">
                                    <label class="form-label text-white fw-semibold">Phone Number</label>
                                    <input type="tel" class="form-control" value="<?php echo $result->contact ?>" name="customer_contact">
                                </div>

                                <input type="text" id="visual_delivery_getter" hidden> <!--Only used to maintain visuals-->

                                <input type="number" id="total_amount_getter" name="total_amount" hidden>   <!--(/)New Total-->
                                <input type="text" id="delivery_type_getter" name="delivery_type" hidden>   <!--(/)Delivery Type-->
                                <input type="text" id="payment_method_getter" name="payment_method" hidden> <!--(/)Payment Method-->
                                <input type="text" id="order_type_getter" name="order_type" hidden>         <!--(/)Order Type-->
                                <input type="text" id="address_getter" name="address" hidden>               <!--(/)Address-->
                            </form>
                        </div>
                    </div>
                </div>
                

                <?php
                    

                ?>

                <!-- Payment Card -->
                <div class="checkout-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold m-0">Payment</h4>
                    </div>

                    <label class="payment-box mb-2" id="cash_payment">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption" checked>
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-cash fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Cash On Delivery</span>
                            <span class="badge rounded-pill" style="background-color: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35);">Primary</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Consider payment upon ordering for contactless delivery. You can't pay by a card to the rider upon delivery.
                        </div>
                    </label>

                    <label class="payment-box mb-0" id="card_payment">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <input class="form-check-input fs-5 m-0" type="radio" name="paymentOption">
                            <div class="icon-box rounded px-2 py-1">
                                <i class="bi bi-credit-card fs-5 text-primary-accent"></i>
                            </div>
                            <span class="fw-bold text-white flex-grow-1" style="font-size: 17px;">Gcash</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; margin-left: 45px;">
                            Pay Via Gcash
                        </div>
                    </label>
                </div>

                <button type="button" class="btn-primary-accent d-block d-lg-none mt-2 mb-5" data-bs-toggle="modal" data-bs-target="#placingOrderModal"><i class="bi bi-bag-check"></i> Place order</button>

            </div>

            <!-- RIGHT COLUMN: Sticky Order Summary -->
            <div class="col-lg-5">

                <div class="checkout-card p-4 position-sticky" style="top: 24px;">

                    <h4 class="fw-bold m-0">Your order from</h4>
                    <p class="text-muted mb-4 mt-1">Eco Hydrate - Dasmarinas</p>

                    <!-- Cart Items -->
                    <?php
                        // Deconstruct the whole order_list to load 
                        $order_list = [];

                        // Deconstruct the whole order_list to load 
                        $order_string = $order_info->order_content;
                        $orders = explode(',', $order_string);
                        foreach ($orders as $value) {
                            $input = $value;
                            $pattern = '/^(\d+)x\s*(.*?)\s*₱([\d.]+)\s*VAT:([\d.]+)/u';
                            //Inserts order informations to $carts[items] based on the value present in the order_list
                            if (preg_match('/^(\d+)x\s*(.*?)\s*(\d+(?:\.\d+)?\s*(?:L|ML))\s*\((.*?)\)\s*₱([\d.]+)\s*VAT:([\d.]+)/ui', $input, $matches)) {
                                $order_list[] = [
                                    'name'             => trim($matches[2]),
                                    'measurement'      => $matches[3],
                                    'category'         => $matches[4],
                                    'qty'              => (int)$matches[1],
                                    'price'            => (float)$matches[5]
                                ];
                            }
                        }

                        
                        foreach($order_list as $order_array){
                            echo '
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div class="fw-semibold text-white">'.$order_array["name"].' '.$order_array["measurement"].' ('.$order_array["category"].')</div>
                                        <div class="fw-bold text-primary-accent">₱'.$order_array["price"].'</div>
                                    </div>
                                
                                ';
                        }

                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            if (isset($_POST['confirmOrder'])) {


                                //Customer Information
                                $customer_name = $_POST['customer_name'];
                                $customer_email = $_POST['customer_email'];
                                $customer_contact = $_POST['customer_contact'];

                                //Order information
                                $order_type = $_POST['order_type'];
                                $total_amount = $_POST['total_amount'];
                                $payment_method = $_POST['payment_method'];
                                $status = "Submitted";
                                
                                //Date and time Information
                                date_default_timezone_set('Asia/Manila');
                                $time = date("h:iA");
                                $date = date('Y/m/d');


                                if($customer_name && $customer_email && $customer_contact && $order_type && $total_amount && $payment_method){
                                    if($order_type=="Delivery"){
                                        //Delivery Mode
                                        $delivery_type = $_POST['delivery_type'];
                                        $address = $_POST['address'];

                                        $sql = "UPDATE `orders` SET `customer_name` = ?, `customer_email` = ?, `customer_address` = ?, `customer_contact` = ?, `total_price` = ?, `payment_amount` = ?, `order_type` = ?,  `delivery_type` = ?, `payment_method` = ?, `status` = ?, `time` = ?, `date` = ?  WHERE `id` = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("ssssddssssssi", $customer_name,$customer_email,$address,$customer_contact,$total_amount,$total_amount,$order_type,$delivery_type,$payment_method,$status,$time,$date,$order_info->id);
                                    }
                                    
                                    else if($order_type=="Pickup"){
                                        //Pickup Mode
                                        $sql = "UPDATE `orders` SET `customer_name` = ?, `customer_email` = ?, `customer_contact` = ?, `total_price` = ?, `payment_amount` = ?, `order_type` = ?, `payment_method` = ?, `status` = ?, `time` = ?, `date` = ?  WHERE `id` = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("sssddsssssi", $customer_name,$customer_email,$customer_contact,$total_amount,$total_amount,$order_type,$payment_method,$status,$time,$date,$order_info->id);
                                    }

                                    if ($stmt->execute()) {
                                        foreach($order_list as $order_array){
                                            //Deducts stock value based on quantity
                                            $sql = "UPDATE `product` SET `stock` = `stock` - ? WHERE product_name = '" . $order_array["name"] . "' AND category = '" . $order_array["category"] . "'";
                                            $stmt = $conn->prepare($sql);
                                            $value = $order_array['qty'];
                                            $stmt->bind_param("i", $value);
                                            if ($stmt->execute()) {
                                                //Deducts stocks on stocks table value based on quantity
                                                if($order_array["category"]=="New Container"){
                                                    $sql = "UPDATE `stocks` SET `current_stock` = `current_stock` - ? WHERE name = '" . $order_array["name"] . "'";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("i", $order_array["qty"]);
                                                    if ($stmt->execute()) {}
                                                }
                                            }
                                        }
                                            

                                        echo <<<HTML
                                            <script>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Order Confirmed!',
                                                    text: 'Your order has been placed successfully.',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#00E676',
                                                    heightAuto: false
                                                }).then((result) => {
                                                    if (result.isConfirmed || result.isDismissed) {
                                                        window.location.href = 'home.php';
                                                    }
                                                });
                                            </script> 
                                            HTML;
                                    }
                                }

                            }
                            
                        }
                    ?>


                    




                    <hr class="divider">

                    <!-- Price Breakdown -->
                    <div class="d-flex justify-content-between text-muted mb-2 mt-3" style="font-size: 14px;">
                        <span>Subtotal</span>
                        <span>₱ 35.00</span>
                    </div>

                    <!-- Added ID for toggling delivery fee visibility -->
                    <div class="d-flex justify-content-between text-muted mb-2 d-none" style="font-size: 14px;" id="priorityFee">
                        <span style="color: #00e676;">Priority delivery</span>
                        <span>₱49.00</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;" id="standardFee">
                        <span style="color: #00e676;">Standard delivery</span>
                        <span>Free</span>
                    </div>
                    <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 14px;">
                        <span>VAT</span>
                        <span>₱ <?php echo $order_info->total_vat?></span>
                    </div>

                    <!-- Grand Total -->
                    <div class="d-flex justify-content-between align-items-end mb-4">
                        <div>
                            <h4 class="fw-bold m-0">Total</h4>
                            <span class="text-muted" style="font-size: 12px;">(incl. fees and tax)</span>
                        </div>
                        <div class="text-end">
                            <h4 class="fw-bold m-0 text-primary-accent" id="total_amount">₱ <?php echo $order_info->total_price?></h4>
                        </div>
                    </div>

                    <!-- Desktop Submit Button -->
                    <button type="button" class="btn-primary-accent d-none d-lg-flex" data-bs-toggle="modal" data-bs-target="#placingOrderModal"><i class="bi bi-bag-check"></i> Place order</button>

                </div>
            </div>

        </div>
    </div>


    <!-- Delivery Address Modal -->
    <div class="modal fade" id="addressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">
                    <h6 class="fw-bold text-white mb-3">Saved Addresses</h6>

                    <div class="d-flex flex-column gap-3 mb-4">
                        <!-- Address 1 -->
                        <label class="address-box m-0">
                            <input class="form-check-input flex-shrink-0 fs-5 mt-1" type="radio" name="savedAddress" checked>
                            <i class="bi bi-geo-alt fs-5 mt-1 text-muted transition"></i>
                            <div class="flex-grow-1 text-white">
                                <div class="fw-semibold" style="line-height: 1.4;">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio fugit saepe vitae repellendus dolore ipsa porro architecto aperiam libero, voluptate repellat laboriosam optio deleniti aut maiores natus maxime, soluta vero.</div>
                                <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                                
                            </div>
                            <div class="address-actions d-flex flex-column gap-2 flex-shrink-0">
                                <button type="button" class="btn-icon" data-bs-toggle="modal" data-bs-target="#editAddressModal"><i class="bi bi-pencil"></i></button>
                                <button type="button" class="btn-icon"><i class="bi bi-trash"></i></button>
                            </div>
                        </label>

                        
                    </div>

                    <!-- Add Address Button -->
                    <a href="#" class="custom-link d-inline-flex align-items-center gap-2 mb-2" data-bs-toggle="modal" data-bs-target="#addAddressModal">
                        <i class="bi bi-plus-lg fs-5"></i> Add address
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Address Modal -->
    <div class="modal fade" id="editAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">

                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2 d-flex justify-content-between align-items-center">
                    <h4 class="modal-title fw-bold text-white">Delivery address</h4>
                    <a href="#" class="text-muted text-decoration-none fw-semibold" data-bs-dismiss="modal">Cancel</a>
                </div>

                <div class="modal-body p-4 pt-3">

                    <!-- Map Placeholder -->
                    

                    <!-- Address Text & Edit Link -->
                    <div class="d-flex align-items-start mb-3">
                        <i class="bi bi-geo-alt fs-5 me-3 mt-1 text-primary-accent"></i>
                        <div class="flex-grow-1 text-white">
                            <div class="fw-semibold" style="line-height: 1.4;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Itaque consectetur ut explicabo ratione rem expedita, fugiat rerum necessitatibus harum ipsa, quae obcaecati deleniti architecto quisquam voluptatum aliquid saepe deserunt minima.</div>
                            <div class="text-muted mt-1" style="font-size: 13px;">Dasmariñas</div>
                        </div>
                        <a href="#" class="custom-link ms-2">Edit</a>
                    </div>

                    <hr class="divider mb-4">

                    <!-- Floor Input -->
                    <input type="text" class="form-control mb-3" placeholder="Floor">

                    <!-- Note to rider -->
                    <textarea class="form-control mb-4" placeholder="Note to rider - e.g. building, landmark" rows="3" style="resize: none;"></textarea>

                    <!-- Labels -->
                    <h6 class="text-white fw-bold mb-3">Add a Label</h6>
                    <div class="d-flex flex-wrap gap-2 mb-4">
                        <button type="button" class="btn label-btn"><i class="bi bi-house"></i> Home</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-briefcase"></i> Work</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-heart"></i> Partner</button>
                        <button type="button" class="btn label-btn"><i class="bi bi-plus-lg"></i> Other</button>
                    </div>

                    <!-- Submit Button -->
                    <button type="button" class="btn-primary-accent w-100" data-bs-dismiss="modal">SUBMIT</button>

                </div>
            </div>
        </div>
    </div>

    <!-- Add Address Modal -->
    <div class="modal fade" id="addAddressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <!-- Header -->
                <div class="modal-header border-bottom-0 pb-0 mt-2 mx-2">
                    <h4 class="modal-title fw-bold text-white d-flex align-items-center gap-2">
                        <i class="bi bi-geo-alt fs-4"></i> What's your exact location?
                    </h4>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 pt-3">

                    <p class="text-muted mb-4" style="font-size: 14.5px;">
                        Providing your location enables more accurate search and delivery ETA, seamless order tracking and personalised recommendations.
                    </p>

                    <!-- Custom Input Field
                    <div class="address-search-wrapper">
                        <label>Enter your address</label>
                        <input type="text" class="form-control address-search-input" value="addresssssssssssssssssssssssssssssssssssssssss">
                        <button class="address-clear-btn"><i class="bi bi-x-circle"></i></button>
                    </div>-->

                    <!-- Large Map Placeholder
                    <div class="map-placeholder-lg">

                        <div class="map-tooltip">We'll deliver here</div>
                        <i class="bi bi-geo-alt-fill text-primary-accent position-relative" style="font-size: 38px; z-index: 2; top: -5px;"></i>


                        <i class="bi bi-map text-muted position-absolute" style="font-size: 100px; opacity: 0.15; z-index: 0;"></i>
                    </div>-->

                    <div class="container border border-1 border-light p-3">
                        <div class="container w-100" id="map"></div>

                        <label class="mt-3 text-light" for="lat">Latitude</label>
                        <input type="text" id="lat" class="form-control mb-2">

                        <label class="text-light" for="lng">Longitude</label>
                        <input type="text" id="lng" class="form-control">
                    </div>

                    <!-- LEAFLET JS -->
                    <script>
                        $(document.ready).ready(function() {
                            // 1. Define custom icon
                            const customIcon = L.icon({
                                iconUrl: '../images/leaflet/location.png',
                                iconSize: [38, 38],
                                iconAnchor: [19, 50],  
                                popupAnchor: [0, -38]  
                            });

                            const defaultCoords = [14.3232, 120.9408];

                            // Set default form values
                            $("#lat").val(defaultCoords[0]);
                            $("#lng").val(defaultCoords[1]);

                            // 2. Initialize map instance
                            const map = L.map('map').setView(defaultCoords, 16);

                            // 3. Load OpenStreetMap tiles
                            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                maxZoom: 20,
                                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                            }).addTo(map);

                            // 4. Set initial marker
                            let currentMarker = L.marker(defaultCoords, { icon: customIcon }).addTo(map)
                                .bindPopup('<b>Water Station</b><br>Pick Up Point')
                                .openPopup();

                            // 5. FIX: Recalculate tile sizes when modal opens
                            $('#addAddressModal').on('shown.bs.modal', function () {
                                map.invalidateSize();
                            });

                            // 6. Map click handler
                            map.on('click', function(e) {
                                const lat = e.latlng.lat;
                                const lng = e.latlng.lng;


                                $("#address_setter").val(lat+", "+lng);
                                $("#address_getter").val(lat+", "+lng);
                                $("#lat").val(lat);
                                $("#lng").val(lng);

                                if (currentMarker) {
                                    currentMarker.setLatLng([lat, lng]);
                                } else {
                                    currentMarker = L.marker([lat, lng], { icon: customIcon }).addTo(map);
                                }

                                currentMarker.bindPopup(`<b>Selected Location</b><br>Lat: ${lat.toFixed(6)}<br>Lng: ${lng.toFixed(6)}`).openPopup();
                            });
                        });
                    </script>

                </div>
            </div>
        </div>
    </div>

    <!-- Placing Order Modal -->
    <div class="modal fade" id="placingOrderModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content placing-modal-content">
                <div class="modal-body p-4 p-sm-5">

                    <div class="text-center mb-4">
                        <img src="../Images/receipt.gif" alt="Receipt" style="width: 70px; margin-bottom: 16px; border: 2px solid #b0c4d6; border-radius: 12px; padding: 8px; background-color: #ffffff; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                        <h4 class="mb-4" style="color: #000000 !important; font-size: 24px; font-weight: 800;">Placing your order...</h4>

                        <div class="placing-progress-bg">
                            <div class="placing-progress-bar"></div>
                        </div>
                    </div>

                    <div class="placing-route-container mt-5 mb-4">
                        <div class="placing-route-line"></div>

                        <div class="position-relative mb-4 d-flex align-items-center">
                            <div class="placing-icon-wrapper flex-shrink-0 me-3">
                                <i class="bi bi-geo-alt text-dark fs-5"></i>
                            </div>
                            <span class="fw-bold" style="font-size: 15px; color: #1a1a1a;">Eco Hydrate - Dasmarinas</span>
                        </div>

                        <div class="position-relative d-flex align-items-center">
                            <div class="placing-icon-wrapper flex-shrink-0 me-3">
                                <i class="bi bi-geo-alt text-dark fs-5"></i>
                            </div>
                            <span class="fw-bold text-truncate" style="font-size: 15px; color: #1a1a1a;">Dasmariñas, Cavite</span>
                        </div>
                    </div>

                    <hr class="placing-divider">

                    <?php 

                        foreach($order_list as $order_array){
                            echo '
                                    <div class="d-flex align-items-center my-3">
                                        <span class="fw-bold me-3" style="font-size: 15px; color: #1a1a1a;">'.$order_array["qty"].'x</span>
                                        <span class="fw-bold" style="font-size: 15px; color: #1a1a1a;">'.$order_array["name"].'</span>
                                    </div>
                                ';
                        }

                    ?>

                    <hr class="placing-divider">

                    <div class="d-flex align-items-center mt-3">
                        <div class="d-flex justify-content-center align-items-center rounded bg-white flex-shrink-0 me-3" style="width: 42px; height: 28px; border: 1px solid #b0c4d6; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                            <i class="bi bi-cash" style="color: #00a859; font-size: 16px;"></i>
                        </div>
                        <div class="d-flex flex-column">
                            <span style="font-weight: 700; font-size: 14px; color: #000000;" id="modal_payment_method"></span>
                        </div>
                    </div>

                    <div class="d-flex gap-3 mt-4">
                        <button type="button" class="btn-secondary-accent" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn-primary-accent m-0" data-bs-dismiss="modal" id="btnLooksGood" form="orderConfirm" name="confirmOrder">Looks Good</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(document).ready(function() {


        //Delivery Type
        function deliveryMode(on, off, total_amount, delivery_type, visual_delivery){

            $("#standardFee").attr("class",on);
            $("#priorityFee").attr("class",off);
            $("#total_amount").text("₱"+total_amount);
            $("#total_amount_getter").val(total_amount);
            $("#delivery_type_getter").val(delivery_type);
            if(visual_delivery=="change"){
                $("#visual_delivery_getter").val(delivery_type);
            }
        }
        

        function paymentMethod(payment_method){
            $("#payment_method_getter").val(payment_method);
            if(payment_method=="Cash"){
                $("#modal_payment_method").text("Cash On Delivery");
            }else{
                $("#modal_payment_method").text("Online Payment");
            }                                      
        }

        function orderType(order_type){
            $("#order_type_getter").val(order_type);
        }

        //Default Values
        deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
        paymentMethod("Cash");
        orderType("Delivery");

        //Delivery type setter
        $("#standard_delivery").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
        });

        $("#priority_delivery").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2 d-none","d-flex justify-content-between text-muted mb-2",(parseFloat(<?php echo $order_info->total_price?>)+49).toFixed(1),"Priority", "change");
        });


        //Payment method setter
        $("#cash_payment").click(function(){
            paymentMethod("Cash");
        });

        $("#card_payment").click(function(){
            paymentMethod("Gcash");
        });


        //Order Type setter
        $("#btnDelivery").click(function(){
            if($("#visual_delivery_getter").val()=="Priority"){
                deliveryMode("d-flex justify-content-between text-muted mb-2 d-none","d-flex justify-content-between text-muted mb-2",(parseFloat(<?php echo $order_info->total_price?>)+49).toFixed(1),"Priority", "change");
            }else{
                deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","change");
            }
            orderType("Delivery");
        });

        $("#btnPickup").click(function(){
            deliveryMode("d-flex justify-content-between text-muted mb-2","d-flex justify-content-between text-muted mb-2 d-none",(<?php echo $order_info->total_price?>).toFixed(1),"Standard","not-change");
            orderType("Pickup");
        });

        //Address setter re-route for form convinience 
        $("#address_getter").val($("#address_setter").val());

        $("#address_setter").on("input", function() {
            $("#address_getter").val($("#address_setter").val());
            
        });
    });
    document.addEventListener('DOMContentLoaded', function() {
        const btnDelivery = document.getElementById('btnDelivery');
        const btnPickup = document.getElementById('btnPickup');
        const deliverySections = document.getElementById('deliverySections');
        const summaryDeliveryFee = document.getElementById('summaryDeliveryFee');

        btnDelivery.addEventListener('click', function() {
            btnDelivery.classList.add('active');
            btnPickup.classList.remove('active');

            // Show delivery address and options
            deliverySections.style.display = 'block';

            // Show delivery fee in summary
            if (summaryDeliveryFee) summaryDeliveryFee.style.display = 'flex';
        });

        btnPickup.addEventListener('click', function() {
            btnPickup.classList.add('active');
            btnDelivery.classList.remove('active');

            // Hide delivery address and options
            deliverySections.style.display = 'none';

            // Hide delivery fee in summary
            if (summaryDeliveryFee) summaryDeliveryFee.style.display = 'none';
        });

        const placingModal = document.getElementById('placingOrderModal');
        if (placingModal) {
            const progressBar = placingModal.querySelector('.placing-progress-bar');
            placingModal.addEventListener('show.bs.modal', function() {
                progressBar.style.animation = 'none';
                progressBar.offsetHeight;
                progressBar.style.animation = 'progressAnim 4s ease-in-out forwards';
            });
        }

    });


    
</script>