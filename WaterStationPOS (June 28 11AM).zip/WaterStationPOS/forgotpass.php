<div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 15px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.15);">

            <div class="modal-header border-0 pb-0 pt-4 px-4 text-center d-block position-relative">
                <button type="button" class="btn-close position-absolute top-0 end-0 m-3 shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>

                <div class="mx-auto mb-2" style="width: 50px; height: 50px;">
                    <img src="Images/resetpass.png" alt="Logo" class="img-fluid rounded-circle border border-primary">
                </div>

                <h5 class="modal-title fw-bold" style="color: #1A202C;">Reset Password</h5>
            </div>

            <div class="modal-body px-4 pt-2 pb-4">
                <p class="text-muted small text-center mb-4">
                    Enter the email address used in your account.
                </p>

                <form id="forgotPasswordForm" action="changepass.php" method="POST">


                    <div class="mb-4">
                        <label for="resetEmail" class="form-label fw-bold small mb-1" style="color: #4A5568;">Work Email</label>
                        <input type="email" class="form-control" id="resetEmail" name="email" placeholder="Enter your email" required
                            style="border-radius: 8px; border: 1px solid #CBD5E0; background-color: #F8FAFC; padding: 10px 15px; font-size: 14px;">
                    </div>

                    <button type="button" id="sendResetBtn" class="btn w-100 fw-bold" style="background-color: #0d6efd; color: white; border-radius: 8px; padding: 10px;">
                        Send Reset Link
                    </button>
                </form>


                <div class="text-center mt-3">
                    <a href="#" class="text-decoration-none small" data-bs-dismiss="modal" style="color: #6c757d; font-weight: 500;">Back to Login</a>
                </div>
            </div>

        </div>
    </div>
</div>