<!DOCTYPE html>
<html lang="en">

<?php
require('dbConn.php');

if (isset($_SESSION['users'])) {
    if (ucfirst(substr($_SESSION['users']->email, 0, 5)) == "Admin") {
        header('location:Admin/dashboard.php');
    } else {
        header('location:Employee/home.php');
    }
    exit;
}
?>


<script>
    //Ensures that arrows are not usable to accessed while logged in
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/sweetalert2@11.js"></script>

</head>

<body>
    <style>
        html,
        body {
            height: 100%;
        }

        body {
            background: url("Images/login-bg.png") no-repeat center center fixed;
            background-size: cover;
            overflow: hidden;
        }

        .page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .login-area {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .pos-footer {
            flex: 0 0 auto;
        }
    </style>

    <div class="page">
        <div class="login-area">
            <div class="card shadow-sm" style="width: 384px;">
                <div class="card-body p-4">

                    <div class="text-center mb-3">
                        <img src="Images/logo.png" alt="Logo" style="width: 64px; height: 64px; object-fit: contain;">
                    </div>
                    <h3 class="card-title text-center mb-4 fw-bold">Employee Login</h3>


                    <form id="loginForm" form method="POST" class="form-group">
                        <div class="mb-3">
                            <label for="username" class="form-label fw-semibold">Work Email</label>
                            <input type="email" class="form-control" id="username" placeholder="Enter your email" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label fw-semibold">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter your password" name="password" required>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4">

                            <button type="button" class="text-decoration-none small float-end bg-transparent border-0 p-0" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal" style="color: #0d6efd; font-weight: 600;">Forgot password?</button>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg fw-semibold">Login</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <?php
        //Login Logic
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $sql = "SELECT * FROM employees WHERE email = '$email'";
            $query = $conn->query($sql);
            $result = $query->fetch_object();

            if ($email && $password) {
                if ($result == NULL) {
                    //No Account with the same email for employess:

                    $sql = "SELECT * FROM admin WHERE email = '$email'";
                    $query = $conn->query($sql);
                    $result = $query->fetch_object();
                    if ($result == NULL) {
                        echo "<script>
                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Work Email!'});
                        </script>";
                    } else {
                        if (password_verify($password, $result->password)) {
                            header('location: admin/dashboard.php');
                            $_SESSION['users'] = $result;
                        } else {
                            //Wrong password
                            echo "<script>
                                Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                            </script>";
                        }
                    }
                } else {
                    if (password_verify($password, $result->password)) {
                        header('location: Employee/home.php');
                        $_SESSION['users'] = $result;
                    } else {
                        //Wrong password
                        echo "<script>
                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                        </script>";
                    }
                }
            } else {
                echo "<script>
                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Empty Input Fields'});
                    </script>";
            }
        }
        ?>

        <?php
        include 'footer.php';
        ?>
    </div>

    <script>
        $(document).ready(function() {

            $("#sendResetBtn").click(function() {
                let userEmail = $("#resetEmail").val();

                if (userEmail === "") {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Email Required',
                        text: 'Please enter your email address first.',
                        confirmButtonColor: '#0d6efd',
                        confirmButtonText: 'Okay',
                        background: '#FFFFFF',
                        color: '#1A202C'
                    });
                    return; // Stop here if empty
                }

                $("#hiddenResetEmail").val(userEmail);

                // Hide the Forgot Password
                $("#forgotPasswordModal").modal('hide');

                setTimeout(function() {
                    $("#changePassModal").modal('show');
                }, 500);
            });

        });
    </script>

    <?php
    include 'forgotpass.php';
    ?>
    <?php
    include 'changepass.php';
    ?>


</body>

</html>