<div class="modal fade" id="profileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Employee Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!--Read-Only-->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3 profile-section-title">Personal Information</h6>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <p class="small text-muted mb-0">Employee ID</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->id : 'EMP-000'; ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small text-muted mb-0">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->first_name . " " . $result->last_name : 'Luz Cantos'; ?></p>
                        </div>
                        <div class="col-12">
                            <p class="small text-muted mb-0">Email Address</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->email : 'user@hydrate.com'; ?></p>
                        </div>
                    </div>
                </div>

                <hr class="border-secondary mb-4">

                <!-- Change Password -->
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="changePasswordForm" action="change_password.php" method="POST">
                        <input type="hidden" name="employee_id" value="<?php echo isset($result) ? $result->id : ''; ?>">

                        <div class="mb-3">
                            <label for="currentPassword" class="profile-label small">Current Password</label>
                            <input type="password" class="form-control profile-input" id="currentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="newPassword" class="profile-label small">New Password</label>
                            <input type="password" class="form-control profile-input" id="newPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="confirmPassword" class="profile-label small">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="confirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-success px-4 rounded-pill fw-bold">Update Password</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>