<?php

include 'header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Employees - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="styles.css">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">

            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-3">
                <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;">ADMINISTRATOR</p>
            </div>

            <nav class="nav flex-column px-2">
                <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal">Profile</a>
                <?php
                include 'profile.php';
                ?>

                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="dashboard.php">Dashboard</a>
                <a class="menu-link active" href="employees.php">Employees</a>
                <a class="menu-link" href="products.php">Products</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <!-- MAIN DASHBOARD CONTENT -->
        <main class="flex-grow-1 d-flex flex-column content overflow-auto">

            <section class="p-4 flex-grow-1">

                <header class="top-text mb-5 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="first-title-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Employee & Staff Management</h6>
                    </div>
                </header>

                <div class="row">
                    <div class="col-12">
                        <div class="section-header">Employee Management</div>
                        <div class="box shadow-sm">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="mb-0 pt-1">All Employees</h5>
                                <button class="btn btn-add px-4 rounded-pill">+ Add Employee</button>
                            </div>
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Role</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    //Loading employee list
                                    $sql = "SELECT * FROM employees";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo "
                                            <tr>
                                            <td>$set->id</td>
                                            <td>$set->first_name $set->last_name </td>
                                            <td>$set->role</td>
                                            <td>$set->email</td>
                                            ";

                                        if ($set->status == "Active") {
                                            echo "<td><span class='status-badge status-active'>$set->status</span></td>";
                                        } else {
                                            echo "<td><span class='status-badge status-inactive'>$set->status</span></td>";
                                        }
                                        //Micheal: yung data-id is nag s-save ng specific points sa loop para ma-seperate sila 
                                        echo "
                                                    <td>
                                                        <button class='btn btn-edit btn-sm rounded-pill px-3 me-1' 
                                                            data-id='{$set->id}' 
                                                            data-fname='{$set->first_name}' 
                                                            data-lname='{$set->last_name}'
                                                            data-role='{$set->role}'
                                                            data-email='{$set->email}'
                                                            data-status='{$set->status}'>
                                                        Edit
                                                        </button>
                                                        <button class='btn btn-remove btn-sm rounded-pill px-3' 
                                                                data-id='{$set->id}'>
                                                            Remove
                                                        </button>
                                                    </td>
                                                    </tr>
                                                    ";
                                    }

                                    //Sweet Alert pop-up
                                    echo <<<HTML
                                                <script>
                                                    $('.btn-remove').click(function() {
                                                        //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id/email sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                                        id = $(this).data('id');

                                                        Swal.fire({
                                                            title: 'Remove Employee?',
                                                            text: 'They will be deleted from the database.',
                                                            icon: 'warning',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showCancelButton: true,
                                                            showConfirmButton: false,
                                                            cancelButtonColor: '#8892B0',
                                                            html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',

                                                            heightAuto: false
                                                        });
                                                    });
                                                </script>
                                                HTML;



                                    // ADD,REMOVE,EDIT Employee data
                                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                        //Remove Account
                                        if (isset($_POST['deleter'])) {
                                            $sql = "DELETE FROM employees WHERE id = " . $_POST['deleter'];
                                            if ($conn->query($sql) === TRUE) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Employee Deleted!',
                                                                            text: 'The has been removed.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676'
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        }

                                        //Add Account
                                        if (isset($_POST['adder'])) {

                                            $fname = $_POST['fname'];
                                            $lname = $_POST['lname'];
                                            $email = $_POST['email'];
                                            $role = $_POST['role'];
                                            $pass = $_POST['password'];

                                            if ($fname && $lname && $email && $role && $pass) {
                                                $sql = "SELECT email FROM employees";
                                                $query = $conn->query($sql);
                                                $email_checked = True;
                                                while ($set = $query->fetch_object()) {
                                                    if ($set->email == $email) {
                                                        $email_checked = False;
                                                        break;
                                                    }
                                                }
                                                if ($email_checked) {
                                                    $pass = password_hash($pass, PASSWORD_DEFAULT); //ENCRYPTS PASSOWRD BEFORE THROWING IT TO DATABASE
                                                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                    $sql = "INSERT INTO `employees` (`first_name`, `last_name`, `email`, `role`, `password`) VALUES (?, ?, ?, ?, ?)";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("sssss", $fname, $lname, $email, $role, $pass);
                                                    if ($stmt->execute()) {
                                                        echo <<<HTML
                                                                        <script>
                                                                            $(document).ready(function() {
                                                                                Swal.fire({
                                                                                    icon: 'success',
                                                                                    title: 'Employee Added!',
                                                                                    text: 'The new employee has been registered.',
                                                                                    background: '#112240',
                                                                                    color: '#CCD6F6',
                                                                                    confirmButtonColor: '#00E676'
                                                                                }).then((result) => {
                                                                                    if(result.isConfirmed) {
                                                                                        location.assign('employees.php');
                                                                                    }});
                                                                            })
                                                                        </script> 
                                                                    HTML;
                                                    }
                                                } else {
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Email Already in use!',
                                                                            text: 'Enter a new email',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000'
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                $('#addEmployeeModal').modal('show');
                                                                            }});
                                                                    })
                                                                    </script> 
                                                            HTML;
                                                }
                                            }
                                        }


                                        if (isset($_POST['editer'])) {

                                            $id = $_POST['id'];
                                            $fname = $_POST['fname'];
                                            $lname = $_POST['lname'];
                                            $email = $_POST['email'];
                                            $role = $_POST['role'];
                                            $status = $_POST['status'];
                                            $pass = isset($_POST['pass']) ? 1 : 0; //1 check, 0 unchecked

                                            echo <<<HTML
                                                            <script>
                                                                console.log("{$id} "+"{$fname} "+"{$lname} "+"{$email} "+"{$status} "+"{$role} "+"{$pass} ");
                                                            </script>
                                                    HTML;

                                            if ($id && $fname && $lname && $email && $role && $status) {
                                                $sql = "SELECT email FROM employees WHERE id !=" . $id; //Para di nya check yung sarili nya yung iba lang na email
                                                $query = $conn->query($sql);
                                                $email_checked = True;
                                                while ($set = $query->fetch_object()) {
                                                    if ($set->email == $email) {
                                                        $email_checked = False;
                                                        break;
                                                    }
                                                }
                                                if ($email_checked) {
                                                    if ($pass == 1) {
                                                        //Reset password process
                                                        $default = "12345678"; //Password after reset
                                                        $password = password_hash($default, PASSWORD_DEFAULT); //Encryp process
                                                        $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ?, `password` = ? WHERE id = '" . $id . "'";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("ssssss", $fname, $lname, $email, $role, $status, $password);
                                                    } else {
                                                        //Not reset
                                                        $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ? WHERE id = '" . $id . "'";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("sssss", $fname, $lname, $email, $role, $status);
                                                    }

                                                    if ($stmt->execute()) {
                                                        echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Employee Edited!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',

                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                                    }
                                                } else {
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Email Already in use!',
                                                                            text: 'Enter a new email',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000',

                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                            HTML;
                                                }
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>

    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role" required>
                                <option value="" disabled selected>Select a role...</option>
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery Driver">Delivery Driver</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Temporary Password</label>
                            <input type="password" class="form-control" name="password" value="12345678" required placeholder="Enter a default password">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn">Save Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Edit New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">

                        <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos" id="edit-fname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos" id="edit-lname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com" id="edit-email">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role">
                                <option id="edit-role" selected></option>
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery">Delivery Driver</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status">
                                <option id="edit-status" selected></option>
                                <option value="Active">Active</option>
                                <option value="Offline">Offline</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Reset Password</label>
                            <input type="checkbox" name="pass">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn">Update Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $('.btn-edit').click(function() {

            //Used to pre-load the edit section since it's not connected to PHP
            id = $(this).data('id');
            fname = $(this).data('fname');
            lname = $(this).data('lname');
            email = $(this).data('email');
            role = $(this).data('role');
            status = $(this).data('status');

            $("#edit-id").val(id);
            $("#edit-fname").val(fname);
            $("#edit-lname").val(lname);
            $("#edit-email").val(email);
            $("#edit-role").text(role);
            $("#edit-status").text(status);
        });

        $(document).ready(function() {

            $("#logout").click(function() {
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",

                    heightAuto: false
                });
            });


            $(".btn-edit").click(function() {
                $('#editEmployeeModal').modal('show');
            });

            $(".btn-add").click(function() {
                $('#addEmployeeModal').modal('show');
            });




        });
    </script>
    <?php
    include '../footer.php';
    ?>