<?php

include 'header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Admin Dashboard - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">

            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-3">
                <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;">ADMINISTRATOR</p>
            </div>

            <nav class="nav flex-column px-2">
                <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal">Profile</a>

                <?php
                include 'profile.php';
                ?>

                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link active" href="dashboard.php">Dashboard</a>
                <a class="menu-link" href="employees.php">Employees</a>
                <a class="menu-link" href="products.php">Products</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">

            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Admin Dashboard</h6>
                    </div>
                </header>

                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Daily Income</div>
                            <div class="dash-value green-text">₱ 1,000.00</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Total Orders Today</div>
                            <div class="dash-value">50</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Gallons Refilled</div>
                            <div class="dash-value cyan-text">100 L</div>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-12">
                        <div class="section-header">Recent Sales Report</div>
                        <div class="manage-box shadow-sm">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="mb-0 pt-1">Today's Transactions</h5>
                            </div>
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Time</th>
                                        <th>Cashier</th>
                                        <th>Qty</th>
                                        <th>Product Name</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="cyan-text fw-bold">1</td>
                                        <td>2:45 PM</td>
                                        <td>Chow Lu</td>
                                        <td>3</td>
                                        <td>Round Gallon Refill</td>
                                        <td class="green-text fw-bold">₱ 90.00</td>
                                        <td><span class="status-badge status-completed">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <td class="cyan-text fw-bold">2</td>
                                        <td>2:30 PM</td>
                                        <td>Chow Lu</td>
                                        <td>1</td>
                                        <td>New Slim Container</td>
                                        <td class="green-text fw-bold">₱ 150.00</td>
                                        <td><span class="status-badge status-completed">Completed</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>

    <script>
        $(document).ready(function() {
            // Logout SweetAlert
            $("#logout").click(function() {
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",

                    heightAuto: false
                });
            });
        });
    </script>
    <?php
    include '../footer.php';
    ?>