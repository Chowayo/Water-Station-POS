<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">

            <div class="modal-header pb-3">
                <h5 class="modal-title m-0">ADMIN PROFILE</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!-- Read-Only -->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3 profile-section-title">Account Details</h6>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <p class="small mb-0" style="color: #8892B0;">Admin ID</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : '1'); ?></p>

                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small mb-0" style="color: #8892B0;">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo (isset($admin_profile) && $admin_profile->first_name) ? ($admin_profile->first_name . " " . $admin_profile->last_name) : (isset($result) ? ($result->first_name . " " . $result->last_name) : 'Admin'); ?></p>

                        </div>
                        <div class="col-12">
                            <p class="small mb-0" style="color: #8892B0;">Email Address</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($admin_profile) ? $admin_profile->email : (isset($result) ? $result->email : 'Admin@gmail.com'); ?></p>

                        </div>
                    </div>
                </div>

                <hr style="border-color: #233554;" class="mb-4">

                <!-- Change Password Section -->
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="adminChangePasswordForm" action="admin_change_password.php" method="POST">
                        <input type="hidden" name="admin_id" value="<?php echo isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : ''); ?>">


                        <div class="mb-3">
                            <label for="adminCurrentPassword" class="profile-label small">Current Password</label>
                            <input type="password" class="form-control profile-input" id="adminCurrentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="adminNewPassword" class="profile-label small">New Password</label>
                            <input type="password" class="form-control profile-input" id="adminNewPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="adminConfirmPassword" class="profile-label small">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="adminConfirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" class="btn px-4 fw-bold" style="background-color: #64FFDA; color: #0A192F; border-radius: 8px;">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>