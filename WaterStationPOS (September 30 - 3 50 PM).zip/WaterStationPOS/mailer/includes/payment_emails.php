<?php
/**
 * Payment-success emails for ECO HYDRATE HUB.
 *
 * Built on send_email() (mailer/includes/send_mail.php). Call one of these ONLY after
 * PayMongo has confirmed the payment (paymongoIsPaid() returned true):
 *
 *   pe_customer_checkout_paid()  -> Customer/checkout.php   emails: customer, cashiers, finance
 *   pe_pos_sale_paid()           -> Employee/home.php       emails: customer (if an email was typed), the cashier, finance
 *   pe_supplier_invoice_paid()   -> Finance/invoices.php    emails: finance
 *
 * Emails are sent AFTER the page has been delivered (where the server supports it) and a
 * mail failure is only logged, so it can never break or delay a sale.
 */

require_once __DIR__ . '/send_mail.php';

function pe_esc($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

function pe_peso($n)
{
    return '₱' . number_format((float) $n, 2);
}

function pe_now()
{
    return (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('M j, Y g:i A');
}

function pe_method_label($method)
{
    return ($method === 'Gcash') ? 'Online (PayMongo: GCash / Maya / Card / QR Ph)' : (string) $method;
}

function pe_valid_email($email)
{
    $email = trim((string) $email);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
}

/** Valid, de-duplicated emails of staff (not deleted) with the given role, e.g. 'Cashier' or 'Financer'. */
function pe_role_emails($conn, $role)
{
    $emails = [];
    $roleEsc = $conn->real_escape_string($role);
    $q = $conn->query("SELECT email FROM employees WHERE role = '" . $roleEsc . "' AND deleted = 'False'");
    if ($q) {
        while ($row = $q->fetch_assoc()) {
            $e = pe_valid_email($row['email']);
            if ($e !== '') {
                $emails[strtolower($e)] = $e;
            }
        }
    }
    return array_values($emails);
}

/**
 * Shared HTML layout. Every value passed in is plain text and is escaped here.
 *
 * @param string $heading Big title in the header bar
 * @param string $intro   One or two sentences
 * @param array  $rows    label => value (rows with an empty value are skipped)
 * @param array  $items   list of ['label' => string, 'amount' => number]
 * @param string $footer  Small print at the bottom
 */
function pe_layout($heading, $intro, array $rows, array $items = [], $footer = '')
{
    $html  = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;color:#1f2937;">';
    $html .= '<div style="background:#0a192f;color:#ffffff;padding:18px 24px;border-radius:10px 10px 0 0;">';
    $html .= '<div style="font-size:12px;letter-spacing:1px;color:#00e676;">ECO HYDRATE HUB</div>';
    $html .= '<div style="font-size:20px;font-weight:bold;margin-top:4px;">' . pe_esc($heading) . '</div>';
    $html .= '</div>';
    $html .= '<div style="border:1px solid #e5e7eb;border-top:0;padding:24px;border-radius:0 0 10px 10px;">';
    $html .= '<p style="margin:0 0 16px;font-size:14px;">' . pe_esc($intro) . '</p>';

    $html .= '<table style="width:100%;border-collapse:collapse;font-size:14px;">';
    foreach ($rows as $label => $value) {
        if ($value === '' || $value === null) {
            continue;
        }
        $html .= '<tr><td style="padding:6px 0;color:#6b7280;width:38%;vertical-align:top;">' . pe_esc($label) . '</td>'
              .  '<td style="padding:6px 0;text-align:right;font-weight:bold;">' . pe_esc($value) . '</td></tr>';
    }
    $html .= '</table>';

    if ($items) {
        $html .= '<div style="margin:18px 0 6px;font-weight:bold;font-size:14px;">Items</div>';
        $html .= '<table style="width:100%;border-collapse:collapse;font-size:14px;border-top:1px solid #e5e7eb;">';
        foreach ($items as $it) {
            $html .= '<tr><td style="padding:6px 0;border-bottom:1px solid #f1f5f9;">' . pe_esc($it['label']) . '</td>'
                  .  '<td style="padding:6px 0;border-bottom:1px solid #f1f5f9;text-align:right;">' . pe_peso($it['amount']) . '</td></tr>';
        }
        $html .= '</table>';
    }

    if ($footer !== '') {
        $html .= '<p style="margin:20px 0 0;font-size:12px;color:#6b7280;">' . pe_esc($footer) . '</p>';
    }
    $html .= '</div></div>';
    return $html;
}

/**
 * Queue messages (each ['to' => string|array, 'subject' => string, 'body' => string]).
 * They are sent once the page is finished so the customer/cashier never waits on SMTP.
 */
function pe_dispatch(array $messages)
{
    $messages = array_values(array_filter($messages, function ($m) {
        return !empty($m['to']);
    }));
    if (!$messages) {
        return;
    }

    register_shutdown_function(function () use ($messages) {
        ignore_user_abort(true);
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();          // don't keep the session locked while SMTP runs
        }
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();       // response is already delivered to the browser
        }
        @set_time_limit(60);

        foreach ($messages as $m) {
            try {
                $r = send_email($m['to'], $m['subject'], $m['body']);
                if (empty($r['success'])) {
                    error_log('[payment email] "' . $m['subject'] . '" failed: ' . ($r['error'] ?? 'unknown error'));
                }
            } catch (\Throwable $e) {
                error_log('[payment email] "' . $m['subject'] . '" error: ' . $e->getMessage());
            }
        }
    });
}

/**
 * Customer paid an online order (Customer/checkout.php).
 *
 * $d: order_id, customer_name, customer_email, customer_contact, order_type, delivery_type,
 *     address, amount, method, ref (PayMongo session id), items [['label','amount'], ...]
 */
function pe_customer_checkout_paid($conn, array $d)
{
    $orderNo  = $d['order_id'];
    $amount   = pe_peso($d['amount']);
    $isDeliv  = ($d['order_type'] === 'Delivery');
    $typeText = $d['order_type'] . (($isDeliv && !empty($d['delivery_type'])) ? ' (' . $d['delivery_type'] . ')' : '');
    $messages = [];

    // 1) Customer
    $customerEmail = pe_valid_email($d['customer_email']);
    if ($customerEmail !== '') {
        $messages[] = [
            'to'      => $customerEmail,
            'subject' => 'Payment received - Order #' . $orderNo . ' | Eco Hydrate Hub',
            'body'    => pe_layout(
                'Payment successful',
                'Hi ' . $d['customer_name'] . ', we received your payment and your order is now being processed.',
                [
                    'Order #'        => $orderNo,
                    'Amount paid'    => $amount,
                    'Payment method' => pe_method_label($d['method']),
                    'Order type'     => $typeText,
                    'Delivery to'    => $isDeliv ? $d['address'] : '',
                    'Reference'      => $d['ref'],
                    'Date'           => pe_now(),
                ],
                $d['items'],
                'Thank you for choosing Eco Hydrate Hub.'
            ),
        ];
    }

    // 2) Cashiers (they prepare / hand over the order)
    $messages[] = [
        'to'      => pe_role_emails($conn, 'Cashier'),
        'subject' => 'Paid online order #' . $orderNo . ' - ' . $amount,
        'body'    => pe_layout(
            'New paid online order',
            'A customer paid online. The order is ready to be processed.',
            [
                'Order #'    => $orderNo,
                'Customer'   => $d['customer_name'],
                'Contact'    => $d['customer_contact'],
                'Email'      => $customerEmail,
                'Order type' => $typeText,
                'Address'    => $isDeliv ? $d['address'] : '',
                'Amount'     => $amount,
                'Reference'  => $d['ref'],
                'Date'       => pe_now(),
            ],
            $d['items']
        ),
    ];

    // 3) Finance
    $messages[] = [
        'to'      => pe_role_emails($conn, 'Financer'),
        'subject' => 'Payment received ' . $amount . ' - Order #' . $orderNo,
        'body'    => pe_layout(
            'Payment received',
            'An online payment was confirmed by PayMongo.',
            [
                'Source'         => 'Customer online checkout',
                'Order #'        => $orderNo,
                'Customer'       => $d['customer_name'],
                'Amount'         => $amount,
                'Payment method' => pe_method_label($d['method']),
                'Reference'      => $d['ref'],
                'Date'           => pe_now(),
            ]
        ),
    ];

    pe_dispatch($messages);
}

/**
 * Cashier POS sale paid through PayMongo (Employee/home.php).
 *
 * $d: order_id, customer_name, customer_email (optional), cashier_name, cashier_email,
 *     amount, method, ref, items [['label','amount'], ...]
 */
function pe_pos_sale_paid($conn, array $d)
{
    $orderNo  = $d['order_id'];
    $amount   = pe_peso($d['amount']);
    $messages = [];

    // 1) Customer (only if the cashier typed an email)
    $customerEmail = pe_valid_email($d['customer_email']);
    if ($customerEmail !== '') {
        $messages[] = [
            'to'      => $customerEmail,
            'subject' => 'Your receipt - Order #' . $orderNo . ' | Eco Hydrate Hub',
            'body'    => pe_layout(
                'Payment successful',
                'Hi ' . $d['customer_name'] . ', thank you for your purchase.',
                [
                    'Order #'        => $orderNo,
                    'Amount paid'    => $amount,
                    'Payment method' => pe_method_label($d['method']),
                    'Reference'      => $d['ref'],
                    'Date'           => pe_now(),
                ],
                $d['items'],
                'Thank you for choosing Eco Hydrate Hub.'
            ),
        ];
    }

    // 2) The cashier who rang the sale
    $messages[] = [
        'to'      => pe_valid_email($d['cashier_email']),
        'subject' => 'Sale recorded - Order #' . $orderNo . ' - ' . $amount,
        'body'    => pe_layout(
            'Payment confirmed',
            'PayMongo confirmed the payment and the sale was recorded.',
            [
                'Order #'        => $orderNo,
                'Customer'       => $d['customer_name'],
                'Amount'         => $amount,
                'Payment method' => pe_method_label($d['method']),
                'Reference'      => $d['ref'],
                'Date'           => pe_now(),
            ],
            $d['items']
        ),
    ];

    // 3) Finance
    $messages[] = [
        'to'      => pe_role_emails($conn, 'Financer'),
        'subject' => 'Payment received ' . $amount . ' - POS Order #' . $orderNo,
        'body'    => pe_layout(
            'Payment received',
            'A POS sale was paid online and confirmed by PayMongo.',
            [
                'Source'         => 'Cashier POS (' . $d['cashier_name'] . ')',
                'Order #'        => $orderNo,
                'Customer'       => $d['customer_name'],
                'Amount'         => $amount,
                'Payment method' => pe_method_label($d['method']),
                'Reference'      => $d['ref'],
                'Date'           => pe_now(),
            ]
        ),
    ];

    pe_dispatch($messages);
}

/**
 * Finance paid a supplier invoice through PayMongo (Finance/invoices.php).
 *
 * $d: payer_name, payer_email, request_id, invoice_number, order_number, supplier,
 *     category, amount, ref
 */
function pe_supplier_invoice_paid($conn, array $d)
{
    $amount = pe_peso($d['amount']);

    // Whole finance team, plus whoever pressed the button (in case their role differs)
    $to = pe_role_emails($conn, 'Financer');
    $payer = pe_valid_email($d['payer_email']);
    if ($payer !== '' && !in_array(strtolower($payer), array_map('strtolower', $to), true)) {
        $to[] = $payer;
    }

    pe_dispatch([[
        'to'      => $to,
        'subject' => 'Supplier payment sent ' . $amount . ' - REQ-' . $d['request_id'],
        'body'    => pe_layout(
            'Supplier payment successful',
            'PayMongo confirmed the payment to the supplier.',
            [
                'Supplier'   => $d['supplier'],
                'Invoice'    => ($d['invoice_number'] !== '' ? 'INV-' . $d['invoice_number'] : ''),
                'PO'         => ($d['order_number'] !== '' ? 'PO-' . $d['order_number'] : ''),
                'Request'    => 'REQ-' . $d['request_id'],
                'Category'   => ucfirst((string) $d['category']),
                'Amount'     => $amount,
                'Paid by'    => $d['payer_name'],
                'Reference'  => $d['ref'],
                'Date'       => pe_now(),
            ]
        ),
    ]]);
}
