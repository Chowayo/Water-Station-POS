<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content shadow-lg">

            <div class="modal-header pb-3 pt-3 px-4">
                <h5 class="modal-title m-0">Customer Profile</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">

                <ul class="nav nav-tabs profile-tabs mb-4" id="profileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="profTabInfo" data-bs-toggle="tab" data-bs-target="#profPaneInfo" type="button" role="tab"><i class="bi bi-person me-1"></i>Information</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profTabOrders" data-bs-toggle="tab" data-bs-target="#profPaneOrders" type="button" role="tab"><i class="bi bi-receipt me-1"></i>Order History</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profTabPass" data-bs-toggle="tab" data-bs-target="#profPanePass" type="button" role="tab"><i class="bi bi-shield-lock me-1"></i>Password</button>
                    </li>
                </ul>

                <div class="tab-content">

                <!-- INFORMATION TAB -->
                <div class="tab-pane fade show active" id="profPaneInfo" role="tabpanel">
                <div class="mb-2">
                    <h6 class="fw-bold mb-3 profile-section-title">Personal Information</h6>

                    <div class="row g-3">

                        <div class="col-12 col-md-6">
                            <p class="small mb-1" style="color: #8892B0;">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->full_name  : 'chow lu'; ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small mb-1" style="color: #8892B0;">Email Address</p>
                            <p class="fw-bold profile-info-text mb-0"><?php echo isset($result) ? $result->email : 'cashierlu@gmail.com'; ?></p>
                        </div>
                        <div class="col-6">
                            <p class="small mb-1" style="color: #8892B0;">Contact Number</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->contact : '1'; ?></p>
                        </div>
                        <div class="col-6">
                            <p class="small mb-1" style="color: #8892B0;">Address</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($result) ? $result->address : '1'; ?></p>
                        </div>
                    </div>
                </div>

                </div>

                <!-- ORDER HISTORY TAB -->
                <div class="tab-pane fade" id="profPaneOrders" role="tabpanel">
                    <h6 class="fw-bold mb-3 profile-section-title">Order History</h6>
                    <div class="order-history-list">
                    <?php
                    $history_count = 0;
                    if (isset($result, $conn)) {
                        $h_owner = 'USER ID:' . $result->id;
                        $h_stmt = $conn->prepare("SELECT * FROM orders WHERE cashier = ? AND deleted = 'False' AND status != 'Pending' ORDER BY id DESC");
                        $h_stmt->bind_param("s", $h_owner);
                        $h_stmt->execute();
                        $h_query = $h_stmt->get_result();

                        while ($h = $h_query->fetch_object()) {
                            $history_count++;

                            //Items of the order
                            $h_items = [];
                            foreach (explode(',', $h->order_content) as $h_line) {
                                if (preg_match('/^(\d+)x\s*(.*?)\s*(\d+(?:\.\d+)?\s*(?:L|ML))\s*\((.*?)\)\s*₱([\d.]+)/ui', $h_line, $hm)) {
                                    $h_items[] = $hm[1] . 'x ' . trim($hm[2]) . ' ' . $hm[3] . ' (' . $hm[4] . ') - ₱' . number_format((float)$hm[5], 2);
                                }
                            }

                            $h_done   = ($h->status === 'Received');
                            $h_badge  = $h_done ? 'Completed' : 'Order Placed';
                            $h_class  = $h_done ? 'oh-badge-done' : 'oh-badge-placed';
                            $h_pay    = ($h->payment_method === 'Gcash') ? 'Paid Online (PayMongo)' : 'Cash';
                            ?>
                            <div class="oh-card">
                                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                    <div>
                                        <div class="fw-bold" style="color:#64FFDA;">Order #<?php echo (int)$h->id; ?></div>
                                        <div class="small" style="color:#8892B0;"><?php echo htmlspecialchars($h->date . ' • ' . $h->time); ?></div>
                                    </div>
                                    <span class="oh-badge <?php echo $h_class; ?>"><?php echo $h_badge; ?></span>
                                </div>
                                <ul class="oh-items">
                                    <?php foreach ($h_items as $h_item): ?>
                                        <li><?php echo htmlspecialchars($h_item); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 small" style="color:#8892B0;">
                                    <span><?php echo htmlspecialchars($h->order_type); ?> • <?php echo $h_pay; ?></span>
                                    <span class="fw-bold" style="color:#CCD6F6; font-size:16px;">₱<?php echo number_format((float)$h->total_price, 2); ?></span>
                                </div>
                            </div>
                            <?php
                        }
                    }
                    if ($history_count === 0) {
                        echo '<p class="text-center py-4 mb-0" style="color:#8892B0;">No orders yet. Once you place an order it will show up here.</p>';
                    }
                    ?>
                    </div>
                </div>

                <!-- PASSWORD TAB -->
                <div class="tab-pane fade" id="profPanePass" role="tabpanel">
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="customerChangePasswordForm" method="POST">
                        <div class="mb-3">
                            <label for="customerCurrentPassword" class="profile-label mb-1">Current Password</label>
                            <input type="password" class="form-control profile-input" id="customerCurrentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="customerNewPassword" class="profile-label mb-1">New Password</label>
                            <input type="password" class="form-control profile-input" id="customerNewPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="customerConfirmPassword" class="profile-label mb-1">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="customerConfirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" name="changePass" class="btn btn-update-pass">Update Password</button>
                        </div>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($result, $conn)) {
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];

                            if (password_verify($current_pass, $result->password)) {
                                if (strlen($new_pass) >= 8) {
                                    if ($new_pass == $confirm_pass) {
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT);

                                            $sql = "UPDATE `customers` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'Your password has been updated!',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script>
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                            })
                                                        })
                                                    </script>
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                        })
                                                    })
                                                </script>
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                        })
                                                    });
                                                </script>
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close(); openProfilePassTab();">Ok</a>`
                                                })
                                            });
                                        </script>
                                    HTML;
                            }
                        }
                    }
                    ?>

                </div>
                </div><!-- /password pane -->

                </div><!-- /tab-content -->
            </div>

        </div>
    </div>
</div>

<style>
    .profile-tabs { border-bottom: 1px solid #233554; }
    .profile-tabs .nav-link { color: #8892B0; background: transparent; border: none; border-bottom: 2px solid transparent; font-weight: 600; }
    .profile-tabs .nav-link:hover { color: #64FFDA; }
    .profile-tabs .nav-link.active { color: #64FFDA; background: transparent; border-bottom: 2px solid #64FFDA; }
    .order-history-list { max-height: 420px; overflow-y: auto; padding-right: 4px; }
    .oh-card { background: #0a192f; border: 1px solid #233554; border-radius: 12px; padding: 14px 16px; margin-bottom: 12px; }
    .oh-items { list-style: none; padding: 0; margin: 10px 0; color: #CCD6F6; font-size: 14px; }
    .oh-items li { padding: 2px 0; }
    .oh-badge { font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 999px; }
    .oh-badge-placed { background: rgba(255, 193, 7, 0.12); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.35); }
    .oh-badge-done { background: rgba(0, 230, 118, 0.12); color: #00e676; border: 1px solid rgba(0, 230, 118, 0.35); }
</style>

<script>
    //After a password error popup, reopen the profile on the Password tab instead of Information
    function openProfilePassTab() {
        var el = document.getElementById('profTabPass');
        if (el && window.bootstrap) { bootstrap.Tab.getOrCreateInstance(el).show(); }
    }
</script>