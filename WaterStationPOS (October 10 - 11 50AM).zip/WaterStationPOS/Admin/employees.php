<?php

include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Employees - Eco Hydrate Hub</title>

    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">

    <style>
        /* Search Input Styles */
        .search-container {
            position: relative;
        }

        .search-container .bi-search {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: #8892B0;
            pointer-events: none;
        }

        .search-container input {
            padding-left: 35px !important;
        }

        .table-scroll-wrap {
            max-height: 520px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <!-- MAIN DASHBOARD CONTENT -->
    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php
        include __DIR__ . '/../components/topbar.php';
        ?>

        <section class="p-4 flex-grow-1">


            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Employee & Staff Management</h1>

                </div>
            </header>

            <div class="row">
                <div class="col-12">
                    <div class="section-header">Employee Management</div>
                    <div class="box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">All Employees</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="search-container">
                                    <i class="bi bi-search"></i>
                                    <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                                </div>
                                <button class="btn btn-add px-4 rounded-pill text-nowrap">+ Add Employee</button>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function() {
                                var table = $('#employee_list').DataTable({
                                    paging: true, // Paginate once the list grows
                                    pageLength: 10, // Rows per page before a new page is added
                                    lengthChange: false,
                                    searching: true, // Enable search functionality
                                    dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>' // Table scrolls in its own box; info + pagination sit below it
                                });

                                $('#searcher').on('keyup change clear', function() {
                                    table.search(this.value).draw(); //Sets the input box as the new search bar
                                });


                            });
                        </script>
                        <table class="table table-dark table-hover text-center mb-0 align-middle table-card-mobile" id="employee_list">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //Loading employee list for the currently selected branch
                                $sql = "SELECT * FROM employees WHERE deleted = 'False' AND branch_id = ?";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("i", $_SESSION['active_branch']);
                                $stmt->execute();
                                $query = $stmt->get_result();
                                while ($set = $query->fetch_object()) {
                                    echo "
                                            <tr>
                                            <td data-label='ID'>$set->id</td>
                                            <td data-label='Name'>$set->first_name $set->last_name </td>
                                            <td data-label='Role'>$set->role</td>
                                            <td data-label='Email'>$set->email</td>
                                            ";

                                    if ($set->status == "Active") {
                                        echo "<td data-label='Status'><span class='status-badge status-active'><i class='bi bi-circle-fill me-1' style='font-size: 0.6rem;'></i>$set->status</span></td>";
                                    } else {
                                        echo "<td data-label='Status'><span class='status-badge status-inactive'><i class='bi bi-circle-fill me-1' style='font-size: 0.6rem;'></i>$set->status</span></td>";
                                    }
                                    //Micheal: yung data-id is nag s-save ng specific points sa loop para ma-seperate sila 
                                    echo "
                                                    <td data-label='Actions' class='card-actions-cell'>
                                                        <button class='btn btn-edit btn-sm rounded-pill px-3 me-1' 
                                                            data-id='{$set->id}' 
                                                            data-fname='{$set->first_name}' 
                                                            data-lname='{$set->last_name}'
                                                            data-role='{$set->role}'
                                                            data-email='{$set->email}'
                                                            data-status='{$set->status}'>
                                                        <i class='bi bi-pencil-square me-1'></i>Edit
                                                        </button>
                                                        <button class='btn btn-remove btn-sm rounded-pill px-3' 
                                                                data-id='{$set->id}'>
                                                        <i class='bi bi-trash-fill me-1'></i>Remove
                                                        </button>
                                                    </td>
                                                    </tr>
                                                    ";
                                }

                                //Sweet Alert pop-up
                                echo <<<HTML
                                    <script>
                                        //Delegated to the document so it still fires for rows on page 2+ of the DataTable
                                        $(document).on('click', '.btn-remove', function() {
                                            //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id/email sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                            id = $(this).data('id');

                                            Swal.fire({
                                                title: 'Remove Employee?',
                                                text: 'They will be deleted from the database.',
                                                icon: 'warning',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                showCancelButton: true,
                                                showConfirmButton: true,
                                                confirmButtonText: 'Confirm Delete',
                                                confirmButtonColor: '#e60000',
                                                cancelButtonColor: '#8892B0',
                                                heightAuto: false
                                            }).then((result) => {
                                                if (result.isConfirmed) {
                                                    showGlobalLoader(); $('<form method="POST"><input type="hidden" name="deleter" value="' + id + '"></form>').appendTo('body').submit();
                                                }
                                            });
                                        });
                                    </script>
                                HTML;

                                // ADD,REMOVE,EDIT Employee data
                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                    //Remove Account
                                    if (isset($_POST['deleter'])) {
                                        $sql = "UPDATE `employees` SET `deleted` = 'True' WHERE id = ? AND branch_id = ?";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("ii", $_POST['deleter'], $_SESSION['active_branch']);
                                        if ($stmt->execute()) {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Employee Deleted!',
                                                                    text: 'The employee has been removed.',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#00E676',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('employees.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                        }
                                    }

                                    //Add Account
                                    if (isset($_POST['adder'])) {

                                        $fname = $_POST['fname'];
                                        $lname = $_POST['lname'];
                                        $email = $_POST['email'];
                                        $role = $_POST['role'];
                                        $pass = $_POST['password'];

                                        if ($fname && $lname && $email && $role && $pass) {
                                            $sql = "SELECT email FROM employees WHERE deleted = 'False'";
                                            $query = $conn->query($sql);
                                            $email_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->email == $email) {
                                                    $email_checked = False;
                                                    break;
                                                }
                                            }
                                            if ($email_checked) {
                                                if (strlen($pass) >= 8) {
                                                    $pass = password_hash($pass, PASSWORD_DEFAULT); //ENCRYPTS PASSOWRD BEFORE THROWING IT TO DATABASE
                                                    //Eto yung ginamit ko na pang submit ng data para ok lang kahit may user error na "" and ''
                                                    //New hires are assigned to whichever branch the admin currently has selected
                                                    $sql = "INSERT INTO `employees` (`branch_id`, `first_name`, `last_name`, `email`, `role`, `password`) VALUES (?, ?, ?, ?, ?, ?)";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isssss", $_SESSION['active_branch'], $fname, $lname, $email, $role, $pass);
                                                    if ($stmt->execute()) {
                                                        //New Employee Notification
                                                        $role_list = array("Admin", "HR");
                                                        foreach ($role_list as $roles) {
                                                            if ($roles == "Admin") {
                                                                $sql = "SELECT * FROM admin";
                                                                $query = $conn->query($sql);
                                                            } elseif ($roles == "HR") {
                                                                //Only notify HR staff at the new hire's own branch
                                                                $sql = "SELECT * FROM employees WHERE role = 'HR' AND deleted = 'False' AND branch_id = ?";
                                                                $stmt = $conn->prepare($sql);
                                                                $stmt->bind_param("i", $_SESSION['active_branch']);
                                                                $stmt->execute();
                                                                $query = $stmt->get_result();
                                                            }
                                                            while ($emp_info = $query->fetch_object()) {
                                                                $notif_id = $emp_info->id;
                                                                $notif_role = $emp_info->role;
                                                                $notif_category = "New Employee Added";
                                                                $notif_message = "New " . $role . " employee has been added";

                                                                if ($roles == "HR") {
                                                                    if ($role != "HR") {
                                                                        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                                                        $stmt = $conn->prepare($sql);
                                                                        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                                        $stmt->execute();
                                                                    }
                                                                } elseif ($roles == "Admin") {
                                                                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                                                    $stmt = $conn->prepare($sql);
                                                                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                                    $stmt->execute();
                                                                }
                                                            }
                                                        }
                                                        echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Employee Added!',
                                                                                text: 'The new employee has been registered.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',
                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('employees.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                                    }
                                                } else {
                                                    echo <<<HTML
                                                                <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Password!',
                                                                    text: 'Password must be atleast 8 characters long',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script>
                                                            HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Email Already in use!',
                                                                    text: 'Enter a new email',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                            }
                                        }
                                    }


                                    if (isset($_POST['editer'])) {

                                        $id = $_POST['id'];
                                        $fname = $_POST['fname'];
                                        $lname = $_POST['lname'];
                                        $email = $_POST['email'];
                                        $role = $_POST['role'];
                                        $status = $_POST['status'];
                                        $pass = isset($_POST['pass']) ? 1 : 0; //1 check, 0 unchecked

                                        if ($id && $fname && $lname && $email && $role && $status) {
                                            $sql = "SELECT email FROM employees WHERE deleted = 'False' AND id !=" . $id; //Para di nya check yung sarili nya yung iba lang na email
                                            $query = $conn->query($sql);
                                            $email_checked = True;
                                            while ($set = $query->fetch_object()) {
                                                if ($set->email == $email) {
                                                    $email_checked = False;
                                                    break;
                                                }
                                            }
                                            if ($email_checked) {
                                                if ($pass == 1) {
                                                    //Reset password process
                                                    $default = "12345678"; //Password after reset
                                                    $password = password_hash($default, PASSWORD_DEFAULT); //Encryp process
                                                    $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ?, `password` = ? WHERE id = ? AND branch_id = ?";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("ssssssii", $fname, $lname, $email, $role, $status, $password, $id, $_SESSION['active_branch']);
                                                } else {
                                                    //Not reset
                                                    $sql = "UPDATE `employees` SET `first_name` = ?, `last_name` = ?, `email` = ?, `role` = ?, `status` = ? WHERE id = ? AND branch_id = ?";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("sssssii", $fname, $lname, $email, $role, $status, $id, $_SESSION['active_branch']);
                                                }

                                                if ($stmt->execute()) {
                                                    echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Employee Edited!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                                HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'error',
                                                                            title: 'Email Already in use!',
                                                                            text: 'Enter a new email',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#e60000',
                                                                            heightAuto: false
                                                                        }).then((result) => {
                                                                            if(result.isConfirmed) {
                                                                                location.assign('employees.php');
                                                                            }});
                                                                    })
                                                                </script> 
                                                            HTML;
                                            }
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>
    </div>

    <div class="modal fade" id="addEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role" required>
                                <option value="" disabled selected>Select a role...</option>
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery">Delivery Driver</option>
                                <option value="HR">HR</option>
                                <option value="Financer">Financer</option>
                                <option value="Inventory">Inventory</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Temporary Password</label>
                            <input type="password" class="form-control" name="password" value="12345678" required placeholder="Enter a default password">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="adder" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn">Save Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Edit New Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addEmployeeForm" method="POST">

                        <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="fname" required placeholder="e.g. Luz Cantos" id="edit-fname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lname" required placeholder="e.g. Luz Cantos" id="edit-lname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required placeholder="name@gmail.com" id="edit-email">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="role" id="edit-role">
                                <option value="Cashier">Cashier</option>
                                <option value="Delivery">Delivery Driver</option>
                                <option value="HR">HR</option>
                                <option value="Financer">Financer</option>
                                <option value="Inventory">Inventory</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="edit-status">
                                <option value="Active">Active</option>
                                <option value="Offline">Offline</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Reset Password</label>
                            <input type="checkbox" name="pass">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="saveEmployeeBtn">Update Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {

            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
            });

            //Delegated to the document so it still fires for rows on page 2+ of the DataTable
            $(document).on('click', '.btn-edit', function() {

                //Used to pre-load the edit section since it's not connected to PHP
                var id = $(this).data('id');
                var fname = $(this).data('fname');
                var lname = $(this).data('lname');
                var email = $(this).data('email');
                var role = $(this).data('role');
                var status = $(this).data('status');

                $("#edit-id").val(id);
                $("#edit-fname").val(fname);
                $("#edit-lname").val(lname);
                $("#edit-email").val(email);
                $("#edit-role").val(role);
                $("#edit-status").val(status);

                $('#editEmployeeModal').modal('show');
            });

            $(".btn-add").click(function() {
                $('#addEmployeeModal').modal('show');
            });




        });
    </script>