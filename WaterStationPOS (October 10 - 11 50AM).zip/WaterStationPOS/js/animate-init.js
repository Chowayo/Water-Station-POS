/*!
 * animate-init.js  (v2)
 * Shared motion layer for every module. Builds on animate.css
 * (css/animate.min.css) and adds:
 *   - smoother, longer, gentler "soft" entrances (24-36px of travel instead of
 *     animate.css's 100%, with an ease-out-quint curve)
 *   - scroll-reveal: elements animate in as they enter the viewport
 *   - SweetAlert2 / Bootstrap modal / dropdown / alert / button motion
 *   - optional parallax via data-parallax="0.1"
 *
 * Soft keyframes animate the individual `translate` / `scale` properties, NOT
 * `transform`, so they never overwrite an element's own transforms (hover lifts,
 * translateY(-50%) centering, Popper positioning on dropdowns, etc.).
 *
 * Manual usage on any element:
 *   <div data-sr="up">          kinds: up | down | left | right | zoom | fade
 *   <div data-sr="left" data-sr-delay="0.2">
 */
(function () {
    "use strict";

    // Lets pages detect that this script loaded (landing page uses it as a fallback check).
    window.EcoMotion = true;

    // If the OS asks for reduced motion (Windows: "Animation effects" off), we still
    // fade things in gently but drop all sliding / zooming / parallax movement.
    var reduceMotion = window.matchMedia &&
        window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion && window.console) {
        console.info("[animate-init] reduced-motion is ON in this browser/OS: using fade-only animations.");
    }
    // Movement helper: returns "" in reduced-motion mode so keyframes become opacity-only.
    function mv(prop) { return reduceMotion ? "" : prop + ";"; }

    // ------------------------------------------------------------------
    // 1. Injected CSS: smoother timing, soft keyframes, hidden-until-revealed
    // ------------------------------------------------------------------
    var css = [
        ":root{--animate-duration:.9s;--ah-out:cubic-bezier(.22,1,.36,1);--ah-in:cubic-bezier(.4,0,.2,1);}",

        "@keyframes ah-fade-up{from{opacity:0;" + mv("translate:0 28px") + "}to{opacity:1;" + mv("translate:0 0") + "}}",
        "@keyframes ah-fade-down{from{opacity:0;" + mv("translate:0 -20px") + "}to{opacity:1;" + mv("translate:0 0") + "}}",
        "@keyframes ah-fade-left{from{opacity:0;" + mv("translate:-36px 0") + "}to{opacity:1;" + mv("translate:0 0") + "}}",
        "@keyframes ah-fade-right{from{opacity:0;" + mv("translate:36px 0") + "}to{opacity:1;" + mv("translate:0 0") + "}}",
        "@keyframes ah-zoom-in{from{opacity:0;" + mv("scale:.94") + "}to{opacity:1;" + mv("scale:1") + "}}",
        "@keyframes ah-zoom-out{from{opacity:1;" + mv("scale:1") + "}to{opacity:0;" + mv("scale:.96") + "}}",
        "@keyframes ah-modal-in{from{opacity:0;" + mv("translate:0 18px") + mv("scale:.97") + "}to{opacity:1;" + mv("translate:0 0") + mv("scale:1") + "}}",
        "@keyframes ah-modal-out{from{opacity:1;" + mv("translate:0 0") + mv("scale:1") + "}to{opacity:0;" + mv("translate:0 -12px") + mv("scale:.98") + "}}",
        "@keyframes ah-drop{from{opacity:0;" + mv("translate:0 -8px") + "}to{opacity:1;" + mv("translate:0 0") + "}}",

        ".ah-fade-up{animation-name:ah-fade-up;animation-timing-function:var(--ah-out)}",
        ".ah-fade-down{animation-name:ah-fade-down;animation-timing-function:var(--ah-out)}",
        ".ah-fade-left{animation-name:ah-fade-left;animation-timing-function:var(--ah-out)}",
        ".ah-fade-right{animation-name:ah-fade-right;animation-timing-function:var(--ah-out)}",
        ".ah-zoom-in{animation-name:ah-zoom-in;animation-timing-function:var(--ah-out)}",
        ".ah-zoom-out{animation-name:ah-zoom-out;animation-timing-function:var(--ah-in)}",
        ".ah-modal-in{animation-name:ah-modal-in;animation-timing-function:var(--ah-out)}",
        ".animate__animated.ah-modal-out{animation-name:ah-modal-out;animation-timing-function:var(--ah-in);animation-duration:.28s}",
        ".animate__animated.ah-drop{animation-name:ah-drop;animation-timing-function:var(--ah-out);animation-duration:.28s}",
        ".animate__animated[class*=' ah-'],.animate__animated[class^='ah-']{will-change:opacity,translate,scale}",

        // animate.css forces 1ms + !important under reduced-motion; override for our fade-only classes.
        reduceMotion ? ".animate__animated[class*=' ah-']{animation-duration:.6s!important}" : "",
        reduceMotion ? ".animate__animated.ah-modal-out,.animate__animated.ah-drop{animation-duration:.28s!important}" : "",

        // Hidden until revealed (JS adds data-sr; .sr-done is added when finished).
        "[data-sr]:not(.sr-done){opacity:0}",
        "@media print{[data-sr]{opacity:1!important}}",

        // Let Bootstrap wait for our exit animation instead of cutting it at 150ms,
        // and hand the dialog's motion entirely to the keyframes above.
        ".modal.fade{transition:opacity .3s ease}",
        ".modal-backdrop.fade{transition:opacity .3s ease}",
        ".modal.fade .modal-dialog{transition:none}"
    ].join("\n");

    var style = document.createElement("style");
    style.setAttribute("data-animate-init", "");
    style.textContent = css;
    document.head.appendChild(style);

    // ------------------------------------------------------------------
    // 2. Small helpers
    // ------------------------------------------------------------------
    var KINDS = {
        up: "ah-fade-up", down: "ah-fade-down", left: "ah-fade-left",
        right: "ah-fade-right", zoom: "ah-zoom-in", fade: "ah-fade-up"
    };

    function play(el, kind, delay) {
        var cls = KINDS[kind] || KINDS.up;
        var finished = false;

        function finish() {
            if (finished) return;
            finished = true;
            el.removeEventListener("animationend", onEnd);
            el.classList.add("sr-done");              // keep it visible...
            el.classList.remove("animate__animated", cls); // ...then drop the animation
            el.style.animationDelay = "";
        }
        function onEnd(ev) { if (ev.target === el) finish(); }

        el.style.animationDelay = (delay || 0) + "s";
        el.addEventListener("animationend", onEnd);
        el.classList.add("animate__animated", cls);
        setTimeout(finish, ((delay || 0) + 1.6) * 1000); // safety net
    }

    // ------------------------------------------------------------------
    // 3. Scroll reveal (IntersectionObserver)
    // ------------------------------------------------------------------
    var io = null;

    function kindOf(el) {
        var k = el.getAttribute("data-sr");
        if (k && KINDS[k]) return k;
        if (el.classList.contains("reveal--left")) return "left";
        if (el.classList.contains("reveal--right")) return "right";
        if (el.classList.contains("reveal--scale")) return "zoom";
        return "up";
    }

    function baseDelay(el) {
        var d = parseFloat(el.getAttribute("data-sr-delay"));
        if (!isNaN(d)) return d;
        // Landing page markup already staggers with --reveal-delay: 0.1s
        d = parseFloat(window.getComputedStyle(el).getPropertyValue("--reveal-delay"));
        return isNaN(d) ? 0 : d;
    }

    function onIntersect(entries) {
        var visible = entries.filter(function (e) { return e.isIntersecting; });
        // Reveal in reading order (top-to-bottom, left-to-right) with a gentle stagger.
        visible.sort(function (a, b) {
            return (a.boundingClientRect.top - b.boundingClientRect.top) ||
                   (a.boundingClientRect.left - b.boundingClientRect.left);
        });
        visible.forEach(function (entry, i) {
            io.unobserve(entry.target);
            play(entry.target, kindOf(entry.target), baseDelay(entry.target) + Math.min(i * 0.08, 0.4));
        });
    }

    function register(el, kind, delay) {
        if (!io || el.hasAttribute("data-sr-bound")) return;
        el.setAttribute("data-sr-bound", "");
        if (!el.hasAttribute("data-sr")) el.setAttribute("data-sr", kind);
        if (delay != null && !el.hasAttribute("data-sr-delay")) el.setAttribute("data-sr-delay", delay);
        io.observe(el);
    }

    if ("IntersectionObserver" in window) {
        io = new IntersectionObserver(onIntersect, { rootMargin: "0px 0px -6% 0px", threshold: 0 });
    }

    // ------------------------------------------------------------------
    // 4. SweetAlert2: every existing Swal.fire(...) gets a soft zoom
    // ------------------------------------------------------------------
    if (window.Swal && typeof window.Swal.mixin === "function") {
        window.Swal = window.Swal.mixin({
            showClass: { popup: "animate__animated ah-zoom-in animate__faster" },
            hideClass: { popup: "animate__animated ah-zoom-out animate__faster" }
        });
    }

    // ------------------------------------------------------------------
    // 5. Bootstrap modals + dropdowns (event delegation, no per-page code)
    // ------------------------------------------------------------------
    document.addEventListener("show.bs.modal", function (e) {
        var dlg = e.target.querySelector(".modal-dialog");
        if (!dlg) return;
        dlg.classList.remove("ah-modal-out");
        dlg.classList.add("animate__animated", "ah-modal-in", "animate__faster");
    });
    document.addEventListener("hide.bs.modal", function (e) {
        var dlg = e.target.querySelector(".modal-dialog");
        if (!dlg) return;
        dlg.classList.remove("ah-modal-in", "animate__faster");
        dlg.classList.add("animate__animated", "ah-modal-out");
    });
    document.addEventListener("hidden.bs.modal", function (e) {
        var dlg = e.target.querySelector(".modal-dialog");
        if (dlg) dlg.classList.remove("animate__animated", "ah-modal-in", "ah-modal-out", "animate__faster");
    });
    document.addEventListener("shown.bs.dropdown", function (e) {
        var wrap = e.target.parentElement;
        var menu = wrap && wrap.querySelector(".dropdown-menu.show");
        if (!menu) return;
        menu.classList.add("animate__animated", "ah-drop");
    });
    // One delegated cleanup for every "temporary" animation class set above.
    document.addEventListener("animationend", function (e) {
        var t = e.target, c = t.classList;
        if (c.contains("ah-modal-in")) c.remove("animate__animated", "ah-modal-in", "animate__faster");
        else if (c.contains("ah-drop")) c.remove("animate__animated", "ah-drop");
        else if (c.contains("animate__pulse")) c.remove("animate__animated", "animate__pulse", "animate__faster");
    });

    // Primary / confirm buttons: quick pulse on click (event delegation, cleaned up above).
    document.addEventListener("click", function (e) {
        var btn = e.target.closest && e.target.closest(".btn-primary, .btn-confirm");
        if (!btn || btn.disabled || reduceMotion) return;
        btn.classList.remove("animate__animated", "animate__pulse", "animate__faster");
        void btn.offsetWidth; // restart if clicked again quickly
        btn.classList.add("animate__animated", "animate__pulse", "animate__faster");
    });

    // ------------------------------------------------------------------
    // 6. On DOM ready: register auto-targets, parallax
    // ------------------------------------------------------------------
    var AUTO = ".card, .dash-card, .chart-card, .budget-card, .item-card, .product-card, " +
               ".job-card, .about-card, .expertise-card, .auth-card";
    var SKIP_INSIDE = ".modal, .swal2-container, .dropdown-menu, .offcanvas";

    function onReady(fn) {
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
        else fn();
    }

    onReady(function () {
        // a) Anything the page marked by hand (landing hero, etc.)
        document.querySelectorAll("[data-sr]").forEach(function (el) { register(el, kindOf(el)); });

        // b) Landing page's existing .reveal classes -> animate.css-driven reveal
        document.querySelectorAll(".reveal").forEach(function (el) { register(el, kindOf(el)); });

        // c) Alerts slide down into view
        document.querySelectorAll(".alert").forEach(function (el) {
            if (!el.closest(SKIP_INSIDE)) register(el, "down");
        });

        // d) Cards / tiles / panels fade up as they scroll into view
        document.querySelectorAll(AUTO).forEach(function (el) {
            if (el.classList.contains("reveal")) return;
            if (el.closest(SKIP_INSIDE)) return;
            if (el.parentElement && el.parentElement.closest(AUTO)) return; // don't double-animate nested cards
            register(el, "up");
        });

        // e) Parallax: <img data-parallax="0.1"> drifts slightly as you scroll
        var par = Array.prototype.slice.call(document.querySelectorAll("[data-parallax]"));
        if (par.length && !reduceMotion) {
            var ticking = false;
            var update = function () {
                ticking = false;
                var y = window.pageYOffset || document.documentElement.scrollTop || 0;
                par.forEach(function (el) {
                    var f = parseFloat(el.getAttribute("data-parallax")) || 0.1;
                    var v = Math.max(-90, Math.min(90, y * f));
                    el.style.translate = "0 " + v.toFixed(1) + "px";
                });
            };
            window.addEventListener("scroll", function () {
                if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
            }, { passive: true });
            update();
        }
    });
})();
