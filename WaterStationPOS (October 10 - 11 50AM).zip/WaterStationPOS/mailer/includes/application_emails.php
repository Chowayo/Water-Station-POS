<?php
/**
 * Job-application stage emails for ECO HYDRATE HUB.
 *
 * Built on send_email() (mailer/includes/send_mail.php), same pattern as payment_emails.php.
 * Call ae_application_stage_updated() whenever an HR user changes an applicant's stage
 * (Hr/jobapplications.php).
 *
 * Emails are sent AFTER the page has been delivered (where the server supports it) and a
 * mail failure is only logged, so it can never break or delay the stage update.
 */

require_once __DIR__ . '/send_mail.php';

function ae_esc($v)
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

function ae_now()
{
    return (new DateTime('now', new DateTimeZone('Asia/Manila')))->format('M j, Y g:i A');
}

function ae_valid_email($email)
{
    $email = trim((string) $email);
    return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
}

/**
 * Shared HTML layout - same look as the payment emails (pe_layout in payment_emails.php).
 *
 * @param string $heading Big title in the header bar
 * @param string $intro   One or two sentences
 * @param array  $rows    label => value (rows with an empty value are skipped)
 * @param string $footer  Small print at the bottom
 */
function ae_layout($heading, $intro, array $rows, $footer = '')
{
    $html  = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;color:#1f2937;">';
    $html .= '<div style="background:#0a192f;color:#ffffff;padding:18px 24px;border-radius:10px 10px 0 0;">';
    $html .= '<div style="font-size:12px;letter-spacing:1px;color:#00e676;">ECO HYDRATE HUB</div>';
    $html .= '<div style="font-size:20px;font-weight:bold;margin-top:4px;">' . ae_esc($heading) . '</div>';
    $html .= '</div>';
    $html .= '<div style="border:1px solid #e5e7eb;border-top:0;padding:24px;border-radius:0 0 10px 10px;">';
    $html .= '<p style="margin:0 0 16px;font-size:14px;">' . ae_esc($intro) . '</p>';

    $html .= '<table style="width:100%;border-collapse:collapse;font-size:14px;">';
    foreach ($rows as $label => $value) {
        if ($value === '' || $value === null) {
            continue;
        }
        $html .= '<tr><td style="padding:6px 0;color:#6b7280;width:34%;vertical-align:top;">' . ae_esc($label) . '</td>'
              .  '<td style="padding:6px 0;text-align:right;font-weight:bold;">' . ae_esc($value) . '</td></tr>';
    }
    $html .= '</table>';

    if ($footer !== '') {
        $html .= '<p style="margin:20px 0 0;font-size:12px;color:#6b7280;">' . ae_esc($footer) . '</p>';
    }
    $html .= '</div></div>';
    return $html;
}

/**
 * Subject / heading / intro / footer copy for each stage. Kept in one place so the wording
 * is easy to tweak without touching the sending logic.
 */
function ae_stage_copy($stage, $name, $position)
{
    switch ($stage) {
        case 'Shortlisted':
            return [
                'subject' => 'You have been shortlisted - ' . $position . ' | Eco Hydrate Hub',
                'heading' => "You've been shortlisted!",
                'intro'   => 'Hi ' . $name . ', good news - your application for ' . $position . ' has been shortlisted. Our HR team will reach out about next steps.',
                'footer'  => 'If you have any questions in the meantime, just reply to this email.',
            ];
        case 'Initial Interview':
            return [
                'subject' => 'Initial interview - ' . $position . ' | Eco Hydrate Hub',
                'heading' => 'Initial interview',
                'intro'   => 'Hi ' . $name . ', you are being invited for an initial interview for ' . $position . '. Our HR team will contact you shortly to schedule it.',
                'footer'  => 'Please keep an eye on your phone and email for the schedule.',
            ];
        case 'Final Interview':
            return [
                'subject' => 'Final interview - ' . $position . ' | Eco Hydrate Hub',
                'heading' => 'Final interview',
                'intro'   => 'Hi ' . $name . ', congratulations on making it to the final interview round for ' . $position . '. Our HR team will contact you shortly to schedule it.',
                'footer'  => 'Please keep an eye on your phone and email for the schedule.',
            ];
        case 'Hired':
            return [
                'subject' => 'Congratulations - ' . $position . ' | Eco Hydrate Hub',
                'heading' => 'Welcome to the team!',
                'intro'   => 'Hi ' . $name . ', congratulations! We are happy to offer you the position of ' . $position . '. Our HR team will reach out with next steps and documentation.',
                'footer'  => 'We look forward to working with you.',
            ];
        case 'Rejected':
            return [
                'subject' => 'Update on your application - ' . $position . ' | Eco Hydrate Hub',
                'heading' => 'Application update',
                'intro'   => 'Hi ' . $name . ', thank you for your interest in ' . $position . ' and for taking the time to apply. After careful review, we have decided not to move forward with your application at this time.',
                'footer'  => 'We encourage you to apply again for future openings that match your skills.',
            ];
        case 'Pending':
        default:
            return [
                'subject' => 'Application update - ' . $position . ' | Eco Hydrate Hub',
                'heading' => 'Application status',
                'intro'   => 'Hi ' . $name . ', your application for ' . $position . ' is now marked as "' . $stage . '". We will notify you as it progresses.',
                'footer'  => 'Thank you for your patience.',
            ];
    }
}

/**
 * Queue a single message, sent after the page is finished (same technique as pe_dispatch()
 * in payment_emails.php) so the HR user never waits on SMTP and a mail failure can't break
 * the stage update.
 */
function ae_dispatch(array $message)
{
    if (empty($message['to'])) {
        return;
    }

    register_shutdown_function(function () use ($message) {
        ignore_user_abort(true);
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();          // don't keep the session locked while SMTP runs
        }
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();       // response is already delivered to the browser
        }
        @set_time_limit(60);

        try {
            $r = send_email($message['to'], $message['subject'], $message['body']);
            if (empty($r['success'])) {
                error_log('[application email] "' . $message['subject'] . '" failed: ' . ($r['error'] ?? 'unknown error'));
            }
        } catch (\Throwable $e) {
            error_log('[application email] "' . $message['subject'] . '" error: ' . $e->getMessage());
        }
    });
}

/**
 * Notify an applicant that their application stage changed.
 *
 * $d: applicant_name, applicant_email, position, stage, date (optional, defaults to now)
 */
function ae_application_stage_updated(array $d)
{
    $to = ae_valid_email($d['applicant_email'] ?? '');
    if ($to === '') {
        return; // no valid email on file - nothing to send
    }

    $name     = $d['applicant_name'] ?? 'Applicant';
    $position = $d['position'] ?? '';
    $stage    = $d['stage'] ?? '';
    $copy     = ae_stage_copy($stage, $name, $position);

    ae_dispatch([
        'to'      => $to,
        'subject' => $copy['subject'],
        'body'    => ae_layout(
            $copy['heading'],
            $copy['intro'],
            [
                'Position' => $position,
                'Stage'    => $stage,
                'Date'     => $d['date'] ?? ae_now(),
            ],
            $copy['footer']
        ),
    ]);
}
