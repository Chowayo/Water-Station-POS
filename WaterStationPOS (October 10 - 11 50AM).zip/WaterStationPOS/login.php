<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<?php
require('dbConn.php');
require_once __DIR__ . '/mailer/includes/send_mail.php';


//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
    exit;
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory") {
    header('location: /Inventory/stocks.php');
    exit;
}


//Sends supplier back to supplier page if the role is supplier 
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier") {
    header('location: /Supplier/orders.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier") {
    header('location: /Supplier/orders.php');
    exit;
}

?>


<script>
    //Ensures that arrows are not usable to accessed while logged in
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <script src="js/jquery-3.6.0.min.js"></script>

    <!-- Global loading overlay: shown while a form submits or an action is processing -->
    <style>
        #wsGlobalLoader {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 10000;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 18px;
            background: rgba(6, 32, 58, 0.78);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
        }

        #wsGlobalLoader.active {
            display: flex;
        }

        #wsGlobalLoader .ws-drop-wrap {
            position: relative;
            width: 76px;
            height: 92px;
        }

        #wsGlobalLoader .ws-drop {
            position: absolute;
            left: 50%;
            top: 0;
            width: 40px;
            height: 40px;
            transform: translateX(-50%);
            animation: wsDropFall 1.2s cubic-bezier(.55, 0, 1, .45) infinite;
        }

        #wsGlobalLoader .ws-drop svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 4px 8px rgba(41, 197, 246, 0.45));
        }

        #wsGlobalLoader .ws-ripple {
            position: absolute;
            left: 50%;
            bottom: 2px;
            width: 54px;
            height: 14px;
            border-radius: 50%;
            transform: translateX(-50%) scale(0);
            border: 2px solid var(--ws-aqua, #29c5f6);
            opacity: 0;
            animation: wsRipple 1.2s cubic-bezier(.2, .6, .35, 1) infinite;
        }

        #wsGlobalLoader .ws-ripple.ws-ripple-2 {
            animation-delay: 0.6s;
        }

        @keyframes wsDropFall {
            0% {
                top: 0;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            70% {
                top: 48px;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            85% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }

            100% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }
        }

        @keyframes wsRipple {
            0% {
                transform: translateX(-50%) scale(0.2);
                opacity: 0;
            }

            30% {
                opacity: 0.8;
            }

            100% {
                transform: translateX(-50%) scale(1.6);
                opacity: 0;
            }
        }

        #wsGlobalLoader .ws-loader-text {
            color: var(--ws-text, #CCD6F6);
            font-weight: 600;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
        }

        #wsGlobalLoader .ws-loader-text::after {
            content: '';
            display: inline-block;
            width: 1.2em;
            text-align: left;
            animation: wsDots 1.2s steps(4, end) infinite;
        }

        @keyframes wsDots {

            0%,
            20% {
                content: '';
            }

            40% {
                content: '.';
            }

            60% {
                content: '..';
            }

            80%,
            100% {
                content: '...';
            }
        }
    </style>
    <div id="wsGlobalLoader" aria-live="polite" aria-busy="true">
        <div class="ws-drop-wrap">
            <div class="ws-drop">
                <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="wsDropGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#6fe3ff" />
                            <stop offset="100%" stop-color="#1e88e5" />
                        </linearGradient>
                    </defs>
                    <path d="M20 2 C20 2 6 20 6 29 a14 14 0 0 0 28 0 C34 20 20 2 20 2 Z" fill="url(#wsDropGrad)" />
                </svg>
            </div>
            <div class="ws-ripple"></div>
            <div class="ws-ripple ws-ripple-2"></div>
        </div>
        <div class="ws-loader-text">Please wait</div>
    </div>
    <script>
        function showGlobalLoader() {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.add('active');
        }
        window.showGlobalLoader = showGlobalLoader;

        // Show the overlay the moment any form on the page is submitted
        // (covers add/edit/submit/approve/reject forms app-wide).
        $(document).on('submit', 'form', function() {
            showGlobalLoader();
        });

        // Forms built dynamically and submitted via JS (delete/toggle confirms)
        // call form.submit() directly, which does NOT fire the 'submit' event,
        // so those call showGlobalLoader() explicitly right before submitting.

        // Hide the overlay again if the page is restored from bfcache
        // (e.g. the user hits Back after a submit).
        window.addEventListener('pageshow', function(e) {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.remove('active');
        });
    </script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/sweetalert2@11.js"></script>
    <script src="js/animate-init.js"></script>

</head>

<?php
//This will generate daily attendance list 
//Gets the date of the highest value id and compares it to the Current date and if it detects that it doesn't match it will genereta new attendance row based on the day
$sql = "SELECT date FROM attendance ORDER BY id DESC LIMIT 1";
$query = $conn->query($sql);
$time = $query->fetch_object();

date_default_timezone_set('Asia/Manila');
$current_time = date('H:i:s');

//If attendance is empty then uses the date yesterday to generate new attendance and the loop will start itself again
if ($time) {
    $yesterday = $time->date;
} else {
    $yesterday = date('Y-m-d', strtotime('yesterday'));
}

if ($yesterday < date('Y-m-d')) {
    $sql = "SELECT * FROM employees WHERE deleted = 'False'";
    $query = $conn->query($sql);
    while ($set = $query->fetch_object()) {
        $name = $set->first_name . " " . $set->last_name;
        $id = $set->id;
        $role = $set->role;
        $time_in = "00:00:00";
        $time_out = "00:00:00";
        $status = 'Absent';

        if (strtotime($current_time) > strtotime("07:00:00")) {
            //Clocks in all of the employee before the shift starts allowing them to login again
            $clocked = "in";
            $sql = "UPDATE `employees` SET `clocked` = ? WHERE `id` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $clocked, $id);
            if ($stmt->execute()) {
            }
        }

        //Generates the actual rows of attendance
        $sql = "INSERT INTO `attendance` (`branch_id`, `employee_name`, `employee_id`, `role`, `init_in`, `last_out`, `status`) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $daily_branch_id = (int) $set->branch_id;
        $stmt->bind_param("isissss", $daily_branch_id, $name, $id, $role, $time_in, $time_out, $status);
        if ($stmt->execute()) {
        }
    }
}

//Payroll Generator
//This will only run if it detects that it's the first day of the current month
if (date('d') === '01') {
    $month_num = (int)date('m');
    $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    $month_year = $months[$month_num - 1] . " " . date('Y');
    $sql = "SELECT * FROM payroll WHERE month_year ='" . $month_year . "'";
    $query = $conn->query($sql);
    $one_run = $query->fetch_object();

    if (!$one_run) {
        //Only active staff whose role is on payroll (no HR, no Supplier account, no deleted employees)
        $sql = "SELECT * FROM employees WHERE deleted = 'False' AND role IN ('" . implode("','", array_keys(payroll_daily_rates())) . "')";
        $query = $conn->query($sql);
        $payroll_branch_ids = []; //branches that actually got a payroll row generated this run
        while ($set = $query->fetch_object()) {
            $name = $set->last_name;
            $id = $set->id;
            $role = $set->role;
            $daily = payroll_daily_rate($role);

            $month_num = (int)date('m');
            $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            $month_year = $months[$month_num - 1] . " " . date('Y');

            $sql = "INSERT INTO `payroll` (`employee_id`, `employee_name`, `employee_role`, `max_day_pay`, `month_year`) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issds", $id, $name, $role, $daily, $month_year);
            if ($stmt->execute()) {
                $payroll_branch_ids[(int) $set->branch_id] = true;
            }
        }

        //Payroll Notification — one per branch that got payroll generated, to that branch's HR only.
        //The branch name goes in the message so same-day dedupe (which matches on message text)
        //doesn't swallow branch B's alert just because branch A's already went out today.
        foreach (array_keys($payroll_branch_ids) as $payroll_branch_id) {
            $branch_name_sql = "SELECT name FROM branches WHERE id = " . (int) $payroll_branch_id;
            $branch_name_row = $conn->query($branch_name_sql)->fetch_object();
            $payroll_branch_name = $branch_name_row ? $branch_name_row->name : ('Branch #' . $payroll_branch_id);

            $sql = "SELECT * FROM employees WHERE role = 'HR' AND deleted = 'False' AND branch_id = " . (int) $payroll_branch_id;
            $query = $conn->query($sql);
            while ($emp_info = $query->fetch_object()) {
                $notif_id = $emp_info->id;
                $notif_role = $emp_info->role;

                $notif_category = "Payroll Due";
                $notif_message = "Employees wages from last month are ready to be given (" . $payroll_branch_name . ")";

                //No repeation ON THE SAME DAY checker
                $sql = "SELECT * FROM notification WHERE message = '" . $conn->real_escape_string($notif_message) . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                $checker_query = $conn->query($sql);
                $check = $checker_query->fetch_object();

                if (!$check) {
                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                    if ($stmt->execute()) {
                    }
                }
            }
        }
    }
}

//Absent but no leave Notification
if ($current_time > "10:00:00") {
    $sql = "SELECT * FROM attendance WHERE status = 'Absent' AND date = CURDATE() and role != 'HR'";
    $query = $conn->query($sql);
    while ($absents = $query->fetch_object()) {
        $absent_with_leave = FALSE;
        $sql = "SELECT * FROM leave_request WHERE status = 'Approved' AND start_date <= CURDATE() AND employee_id = " . $absents->employee_id;
        $querys = $conn->query($sql);
        while ($leave_list = $querys->fetch_object()) {
            // Set start date to today and end date to next Monday
            $startDate = new DateTime($leave_list->start_date);
            $endDate   = new DateTime($leave_list->end_date);
            while ($startDate <= $endDate) {
                if ($startDate->format('Y-m-d') == $absents->date) {
                    //Employee is on a leave
                    $absent_with_leave = TRUE;
                }
                $startDate->modify('+1 day');
            }
        }
        if (!$absent_with_leave) {
            //Absent but no leave Notification (only HR in the absent employee's own branch)
            $sql = "SELECT * FROM employees WHERE role = 'HR' AND branch_id = " . (int) $absents->branch_id;
            $notif_query = $conn->query($sql);
            while ($emp_info = $notif_query->fetch_object()) {
                $notif_id = $emp_info->id;
                $notif_role = $emp_info->role;
                $notif_category = "Absent Employee";
                $notif_message = "Employee " . $absents->employee_id . " is absent today";

                //No repeation ON THE SAME DAY checker
                $sql = "SELECT * FROM notification WHERE message = '" . $conn->real_escape_string($notif_message) . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                $checker_query = $conn->query($sql);
                $check = $checker_query->fetch_object();

                if (!$check) {
                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                    if ($stmt->execute()) {
                    }
                }
            }
        }
    }
}

//Absent for the last 3 days without leave
if ($current_time > "10:00:00") {
    $absent_list = [];
    $absent_branch_by_name = []; //last attendance row seen for that name decides its branch, same grouping limit the existing name-only counting already has
    for ($i = 0; $i < 3; $i++) {
        $past_days = date('Y-m-d', strtotime('today - ' . $i . ' day'));

        $sql = "SELECT * FROM attendance WHERE status = 'Absent' AND date = '" . $past_days . "' and role != 'HR'";
        $query = $conn->query($sql);
        while ($absents = $query->fetch_object()) {
            $absent_with_leave = FALSE;
            $sql = "SELECT * FROM leave_request WHERE status = 'Approved' AND start_date <= '" . $past_days . "' AND employee_id = " . $absents->employee_id;
            $querys = $conn->query($sql);
            while ($leave_list = $querys->fetch_object()) {
                // Set start date to today and end date to next Monday
                $startDate = new DateTime($leave_list->start_date);
                $endDate   = new DateTime($leave_list->end_date);
                while ($startDate <= $endDate) {
                    if ($startDate->format('Y-m-d') == $absents->date) {
                        //Employee is on a leave
                        $absent_with_leave = TRUE;
                    }
                    $startDate->modify('+1 day');
                }
            }
            if (!$absent_with_leave) {
                $absent_list[] = $absents->employee_name;
                $absent_branch_by_name[$absents->employee_name] = (int) $absents->branch_id;
            }
        }

        //Counting absent count in the past 3 days
        $absent_complete_list = array_unique($absent_list);
        foreach ($absent_complete_list as $emp_name) {
            $count = count(array_keys($absent_list, $emp_name));
            if ($count == 3) {
                //Absent with no leave for 3 consecutive days Notification
                //Admins see every branch; HR only sees it for the absent employee's own branch
                $emp_name_branch_id = $absent_branch_by_name[$emp_name] ?? null;
                $role_list = array("Admin", "HR");
                foreach ($role_list as $role) {
                    if ($role == "Admin") {
                        $sql = "SELECT * FROM admin";
                    } elseif ($role == "HR") {
                        $sql = "SELECT * FROM employees WHERE role = '" . $role . "' AND deleted = 'False' AND branch_id = " . (int) $emp_name_branch_id;
                    }

                    $query = $conn->query($sql);
                    while ($emp_info = $query->fetch_object()) {
                        $notif_id = $emp_info->id;
                        $notif_role = $emp_info->role;
                        $notif_category = "Absent Employee in the Last 3 days";
                        $notif_message = "Employee " . $emp_name . " has been absent for 3 condecutive days";

                        //No repeation ON THE SAME DAY checker
                        $sql = "SELECT * FROM notification WHERE message = '" . $conn->real_escape_string($notif_message) . "' AND date = CURDATE() AND role = '" . $emp_info->role . "' AND emp_id = " . $emp_info->id;
                        $checker_querys = $conn->query($sql);
                        $check = $checker_querys->fetch_object();

                        if (!$check) {
                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                            if ($stmt->execute()) {
                            }
                        }
                    }
                }
            }
        }
    }
}

?>

<body>
    <style>
        /* ===== Simple page transition between index.php and login.php ===== */
        body {
            opacity: 0;
            transform: translateY(6px);
            transition: opacity .35s ease, transform .35s ease;
        }
        body.page-ready {
            opacity: 1;
            transform: none;
        }
        body.page-leave {
            opacity: 0;
            transform: translateY(-6px);
            transition: opacity .25s ease, transform .25s ease;
        }
        @media (prefers-reduced-motion: reduce) {
            body,
            body.page-ready,
            body.page-leave {
                opacity: 1;
                transform: none;
                transition: none;
            }
        }
    </style>
    <script>
        (function() {
            var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            requestAnimationFrame(function() { document.body.classList.add('page-ready'); });
            var leaving = false;
            window.addEventListener('DOMContentLoaded', function() {
                document.querySelectorAll('a[href="index.php"], a.btn-back-home').forEach(function(link) {
                    link.addEventListener('click', function(e) {
                        if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button !== 0) return;
                        if (leaving) { e.preventDefault(); return; }
                        if (reduce) return;
                        e.preventDefault();
                        leaving = true;
                        document.body.classList.remove('page-ready');
                        document.body.classList.add('page-leave');
                        setTimeout(function() { window.location.href = link.getAttribute('href'); }, 250);
                    });
                });
            });
            window.addEventListener('pageshow', function(e) {
                if (e.persisted) {
                    leaving = false;
                    document.body.classList.remove('page-leave');
                    document.body.classList.add('page-ready');
                }
            });
        })();
    </script>

    <style>
        html,
        body {
            height: 100%;
        }

        body {
            background:
                radial-gradient(circle at 18% 15%, rgba(130, 210, 255, 0.28), transparent 42%),
                radial-gradient(circle at 88% 88%, rgba(46, 154, 204, 0.16), transparent 45%),
                url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='80' viewBox='0 0 160 80'><path d='M0 40 Q20 20 40 40 T80 40 T120 40 T160 40' fill='none' stroke='%2329c5f6' stroke-opacity='0.08' stroke-width='2'/></svg>"),
                linear-gradient(160deg, #0b3a66 0%, #06203a 55%, #041729 100%);
            overflow: hidden;
        }

        .page {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .page>.site-nav {
            background: #1e1e1e;
        }

        .login-area {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .pos-footer {
            flex: 0 0 auto;
        }


        .login-book {
            display: flex;
            width: 1080px;
            max-width: 100%;
            border-radius: 28px;
            overflow: hidden;
            box-shadow: 0 30px 70px rgba(0, 20, 50, 0.35);
            background-color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.4);
        }

        .book-left {
            flex: 1;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 65px 50px;
            background-color: #ffffff;
            overflow: hidden;
        }

        .book-left .brand-logo {
            width: 130px;
            height: 130px;
            object-fit: contain;
            border-radius: 50%;
            border: 3px solid #64B5F6;
            background-color: #ffffff;
            margin-bottom: 26px;
            position: relative;
            z-index: 1;
        }

        .book-left h2 {
            font-family: Georgia, 'Times New Roman', serif;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #003366;
            text-align: center;
            margin-bottom: 8px;
            position: relative;
            z-index: 1;
        }

        .book-left .brand-accent {
            color: #28a745;
        }

        .book-left p.tagline {
            color: #64748B;
            text-align: center;
            font-size: 15px;
            max-width: 300px;
            margin: 0;
            position: relative;
            z-index: 1;
        }

        .book-divider {
            width: 2px;
            background: linear-gradient(to bottom, transparent 0%, rgba(0, 51, 102, 0.15) 50%, transparent 100%);
        }

        .book-right {
            flex: 1;
            background-color: #cfe9fb;
            padding: 65px 56px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .book-right h1 {
            font-family: Georgia, 'Times New Roman', serif;
            font-weight: 700;
            font-size: 34px;
            color: #0d2b4e;
            text-align: center;
            margin-bottom: 34px;
        }

        .book-right .form-label {
            font-weight: 600;
            color: #0d2b4e;
            margin-bottom: 6px;
        }

        .book-right .form-control {
            border-radius: 10px;
            border: none;
            padding: 14px 18px;
            font-size: 16px;
            background-color: #ffffff;
        }

        .book-right .form-control:focus {
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.25);
        }

        .book-right .form-check-label {
            color: #0d2b4e;
            font-size: 14px;
        }

        .btn-book-login {
            background-color: #00e676;
            border: none;
            color: #ffffff;
            font-weight: 700;
            letter-spacing: 1px;
            padding: 16px;
            font-size: 16px;
            border-radius: 10px;
            transition: 0.2s;
        }

        .btn-book-login:hover {
            background-color: #28a745;
            color: #ffffff;
        }

        .signup-text {
            font-size: 14px;
            color: #0d2b4e;
        }

        .signup-link {
            color: #0d6efd;
            font-weight: 600;
            text-decoration: none;
        }

        .signup-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 767.98px) {
            .login-book {
                flex-direction: column;
                border-radius: 20px;
            }

            .book-divider {
                width: 100%;
                height: 2px;
                background: linear-gradient(to right, transparent 0%, rgba(0, 51, 102, 0.15) 50%, transparent 100%);
            }

            .book-left {
                padding: 35px 30px 25px;
            }

            .book-left .brand-logo {
                width: 85px;
                height: 85px;
            }

            .book-right {
                padding: 30px 30px 35px;
            }
        }

        /* Back to landing page */
        .login-back {
            padding: 20px 24px 0;
        }

        .btn-back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(130, 210, 255, 0.35);
            color: #e6f6ff;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            backdrop-filter: blur(4px);
            transition: background 0.15s ease, color 0.15s ease, transform 0.15s ease;
        }

        .btn-back-home:hover {
            background: rgba(41, 197, 246, 0.2);
            color: #fff;
            transform: translateX(-2px);
        }

        .btn-back-home:focus-visible {
            outline: 2px solid #29c5f6;
            outline-offset: 2px;
        }

        /* ---------- Water loading overlay ---------- */
        .water-loader {
            position: fixed;
            inset: 0;
            z-index: 3000;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(4, 23, 41, 0.55);
            backdrop-filter: blur(3px);
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.25s ease, visibility 0.25s ease;
        }

        .water-loader.show {
            opacity: 1;
            visibility: visible;
        }

        /* the popup itself */
        .water-loader-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 22px;
            padding: 34px 48px 30px;
            border-radius: 24px;
            background: linear-gradient(160deg, #0b3a66 0%, #06203a 100%);
            border: 1px solid rgba(130, 210, 255, 0.3);
            box-shadow: 0 25px 60px rgba(0, 20, 50, 0.5);
            transform: scale(0.92);
            transition: transform 0.25s ease;
        }

        .water-loader.show .water-loader-card {
            transform: scale(1);
        }

        .water-drop-ring {
            position: relative;
            width: 120px;
            height: 120px;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid rgba(130, 210, 255, 0.7);
            background: rgba(255, 255, 255, 0.06);
            box-shadow: 0 0 0 8px rgba(41, 197, 246, 0.12), 0 0 40px rgba(41, 197, 246, 0.35);
            isolation: isolate;
        }

        /* the water level rises, then the whole thing repeats */
        .water-level {
            position: absolute;
            left: 0;
            width: 100%;
            height: 100%;
            top: 100%;
            animation: waterRise 2.4s ease-in-out infinite;
        }

        .water-wave {
            position: absolute;
            left: 50%;
            top: -58px;
            width: 180px;
            height: 180px;
            margin-left: -90px;
            border-radius: 42%;
            background: rgba(41, 197, 246, 0.85);
            animation: waveSpin 4s linear infinite;
        }

        .water-wave.back {
            background: rgba(130, 210, 255, 0.45);
            border-radius: 38%;
            animation-duration: 6s;
            top: -62px;
        }

        .water-wave.front {
            background: linear-gradient(180deg, #29c5f6, #1e88e5);
        }

        .water-icon {
            position: absolute;
            inset: 0;
            z-index: 2;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 44px;
            color: #ffffff;
            text-shadow: 0 2px 10px rgba(0, 40, 80, 0.45);
            animation: dropFloat 2.4s ease-in-out infinite;
        }

        .water-loader-text {
            color: #e6f6ff;
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .water-loader-text .dots span {
            animation: dotBlink 1.2s infinite;
        }

        .water-loader-text .dots span:nth-child(2) { animation-delay: 0.2s; }
        .water-loader-text .dots span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes waterRise {
            0%   { top: 100%; }
            70%  { top: 18%; }
            100% { top: 18%; }
        }

        @keyframes waveSpin {
            to { transform: rotate(360deg); }
        }

        @keyframes dropFloat {
            0%, 100% { transform: translateY(0); }
            50%      { transform: translateY(-6px); }
        }

        @keyframes dotBlink {
            0%, 80%, 100% { opacity: 0.2; }
            40%           { opacity: 1; }
        }

        @media (prefers-reduced-motion: reduce) {
            .water-wave, .water-icon, .water-level { animation-duration: 12s; }
        }
    </style>

    <!-- Water loading popup (shown on login submit / success) -->
    <div class="water-loader" id="waterLoader" role="status" aria-live="polite">
        <div class="water-loader-card">
            <div class="water-drop-ring">
                <div class="water-level">
                    <div class="water-wave back"></div>
                    <div class="water-wave front"></div>
                </div>
                <div class="water-icon"><i class="bi bi-droplet-fill"></i></div>
            </div>
            <div class="water-loader-text">Logging in<span class="dots"><span>.</span><span>.</span><span>.</span></span></div>
        </div>
    </div>

    <script>
        function showLoginLoader() {
            var l = document.getElementById('waterLoader');
            if (l) l.classList.add('show');
        }

        // Show right away when the form is submitted (runs after browser validation passes)
        document.addEventListener('DOMContentLoaded', function() {
            var f = document.getElementById('loginForm');
            if (f) f.addEventListener('submit', showLoginLoader);
        });
    </script>

    <div class="page">
        <div class="login-back">
            <a href="index.php" class="btn-back-home"><i class="bi bi-arrow-left"></i> Back</a>
        </div>

        <div class="login-area">
            <div class="login-book">

                <!-- LEFT SIDE -->
                <div class="book-left">
                    <img src="Images/logo.png" alt="Logo" class="brand-logo">
                    <h2><span class="brand-accent">ECO</span> HYDRATE HUB</h2>
                    <p class="tagline">Mineral Water Refill & <br>
                        POS Management System</p>
                </div>

                <div class="book-divider"></div>

                <!-- RIGHT SIDE LOGIN -->
                <div class="book-right">
                    <h1>Login</h1>

                    <form id="loginForm" form method="POST" class="form-group">
                        <div class="mb-3">
                            <label for="username" class="form-label">Email</label>
                            <input type="email" class="form-control" id="username" placeholder="✉︎ example@email.com" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="🔒︎ Your Password" name="password" required>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="rememberMe" name="remember">
                                <label class="form-check-label" for="rememberMe">Remember me</label>
                            </div>

                            <button type="button" class="text-decoration-none small bg-transparent border-0 p-0 fw-semibold" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal" style="color: #0d6efd;">Forgot password?</button>
                        </div>

                        <div class="d-grid">
                            <button type="submit" name="login" class="btn btn-book-login btn-lg">LOGIN</button>
                        </div>

                        <p class="signup-text text-center mt-3 mb-0">
                            Don't have an account yet? <a href="Customer/registration.php" class="signup-link">Sign up here</a>
                        </p>

                    </form>
                </div>

            </div>
        </div>



        <?php
        include 'forgotpass.php';
        ?>


        <?php
        //Login Logic
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $forgot_email = "DUMMY";
            if (isset($_POST['login'])) {
                $email = $_POST['email'];
                $password = $_POST['password'];

                $sql = "SELECT * FROM employees WHERE email = ? AND deleted = 'False'";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_object();

                if ($email && $password) {
                    if ($result == NULL) { //Starts Admin login
                        //No Account with the same email for employess:
                        $sql = "SELECT * FROM admin WHERE email = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $email);
                        $stmt->execute();
                        $result = $stmt->get_result()->fetch_object();
                        if ($result == NULL) {
                            //Customer Login Logic

                            $sql = "SELECT * FROM customers WHERE email = ? AND deleted = 'False'";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $email);
                            $stmt->execute();
                            $result = $stmt->get_result()->fetch_object();

                            if (!$result) {
                                //Email does not exist in the 3 tables
                                echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Email!'});
                                    </script>";
                            } else {
                                if (password_verify($password, $result->password)) {
                                    $_SESSION['users'] = $result;
                                    echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                showLoginLoader();
                                                setTimeout(function() {
                                                    if("{$result->role}"=="Customer"){
                                                        location.assign('Customer/home.php');
                                                    }
                                                }, 2000);
                                            });
                                        </script> 
                                    HTML;
                                } else {
                                    //Wrong Customer Password
                                    echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                                    </script>";
                                }
                            }
                        } else {
                            if (password_verify($password, $result->password)) {
                                $_SESSION['users'] = $result;
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            showLoginLoader();
                                            setTimeout(function() {
                                                if("{$result->role}"=="Admin"){
                                                    location.assign('Admin/dashboard.php');
                                                }
                                            }, 2000);
                                        });
                                    </script> 
                                    HTML;
                            } else {
                                //Wrong password
                                echo "<script>
                                    Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                                </script>";
                            }
                        }
                        //Employee login logic
                    } else {
                        if (password_verify($password, $result->password)) {
                            if ($result->status == "Active") {
                                //Checks if the user has already clocked-out
                                if ($result->clocked == "in") {
                                    $sql = "SELECT * FROM attendance WHERE employee_id = " . $result->id . " AND date = CURDATE()";
                                    $query = $conn->query($sql);
                                    $check = $query->fetch_object();

                                    // No attendance row exists for this employee today yet — create one now
                                    // so the checks below always have a real record to read.
                                    if (!$check) {
                                        $sql = "INSERT INTO `attendance` (`branch_id`, `employee_name`, `employee_id`, `role`, `init_in`, `last_out`, `status`) VALUES (?, ?, ?, ?, '00:00:00', '00:00:00', 'Absent')";
                                        $stmt = $conn->prepare($sql);
                                        $emp_name = $result->first_name . " " . $result->last_name;
                                        $login_branch_id = (int) $result->branch_id;
                                        $stmt->bind_param("isis", $login_branch_id, $emp_name, $result->id, $result->role);
                                        $stmt->execute();

                                        $sql = "SELECT * FROM attendance WHERE employee_id = " . $result->id . " AND date = CURDATE()";
                                        $query = $conn->query($sql);
                                        $check = $query->fetch_object();
                                    }

                                    $last_entry_time = "23:59:00";
                                    //Hindi na pwedeng mag log in after 10AM kapag and status mo pa is ABSENT
                                    if ($current_time <= $last_entry_time || $check->status != "Absent" || $check->role == "HR") {
                                        $_SESSION['users'] = $result;
                                        //Attendance Logic
                                        if ($result->role != "HR") {
                                            if ($check->status == "Absent") {
                                                date_default_timezone_set('Asia/Manila');
                                                $time_in = date('H:i:s');
                                                $employee_id = $result->id;
                                                $scheduled_time = "08:00:00";

                                                //Status Checker
                                                if ($time_in > $scheduled_time) {
                                                    $status = "Late";

                                                    //Late HR Notification (only HR in the same branch as the late employee)
                                                    $sql = "SELECT * FROM employees WHERE role = 'HR' AND deleted = 'False' AND branch_id = " . (int) $result->branch_id;
                                                    $query = $conn->query($sql);
                                                    while ($emp_info = $query->fetch_object()) {
                                                        $notif_id = $emp_info->id;
                                                        $notif_role = $emp_info->role;
                                                        $notif_category = "Employee Late";
                                                        $notif_message = "Employee #" . $result->id . " is late for today";

                                                        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                        $stmt = $conn->prepare($sql);
                                                        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                        if ($stmt->execute()) {
                                                        }
                                                    }
                                                } else {
                                                    $status = "On Time";
                                                }

                                                $sql = "UPDATE `attendance` SET `init_in` = ?, `status` = ? WHERE `employee_id` = ? AND `branch_id` = ? AND date = CURDATE()";
                                                $stmt = $conn->prepare($sql);
                                                $attendance_branch_id = (int) $result->branch_id;
                                                $stmt->bind_param("ssii", $time_in, $status, $employee_id, $attendance_branch_id);
                                                if ($stmt->execute()) {
                                                }
                                            }

                                            //Notification (only HR in the same branch as the employee who logged in)
                                            $sql = "SELECT * FROM employees WHERE role = 'HR' AND branch_id = " . (int) $result->branch_id;
                                            $query = $conn->query($sql);
                                            while ($emp_info = $query->fetch_object()) {
                                                $notif_id = $emp_info->id;
                                                $notif_role = $emp_info->role;
                                                $notif_category = "Employee Logged In";
                                                $notif_message = "Employee #" . $result->id . " has logged in their account ";

                                                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                if ($stmt->execute()) {
                                                }
                                            }
                                        }

                                        //Re-route to different dashboards 
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        showLoginLoader();
                                                        setTimeout(function() {
                                                            if("{$result->role}"=="Delivery"){
                                                                location.assign('Employee/confirmation.php');
                                                            }
                                                            else if("{$result->role}"=="Cashier"){
                                                                location.assign('Employee/home.php');
                                                            }
                                                            else if("{$result->role}"=="HR"){
                                                                location.assign('Hr/dashboard.php');
                                                            }
                                                            else if("{$result->role}"=="Financer"){
                                                                location.assign('Finance/dashboard.php');
                                                            }
                                                            else if("{$result->role}"=="Inventory"){
                                                                location.assign('Inventory/requisitions.php');
                                                            }
                                                            else if("{$result->role}"=="Supplier"){
                                                                location.assign('Supplier/orders.php');
                                                            }
                                                        }, 2000);
                                                    });
                                                </script> 
                                                HTML;
                                    } else {
                                        //DI NA PWEDENG MAG LOGIN KASI LATE
                                        echo "<script>
                                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Time Passed Grace Period!'});
                                        </script>";
                                    }
                                } else {
                                    //Already clocked out
                                    echo "<script>
                                        Swal.fire({icon: 'error',title: 'Login Error..',text: 'Employee Already clocked out for the day!'});
                                    </script>";
                                }
                            } else {
                                //Offline Account
                                echo "<script>
                                    Swal.fire({icon: 'error',title: 'Login Error..',text: 'Deactivated Account!'});
                                </script>";
                            }
                        } else {
                            //Wrong password
                            echo "<script>
                                Swal.fire({icon: 'error',title: 'Login Error..',text: 'Invalid Password!'});
                            </script>";
                        }
                    }
                } else {
                    echo "<script>
                            Swal.fire({icon: 'error',title: 'Login Error..',text: 'Empty Input Fields'});
                        </script>";
                }
            }

            if (isset($_POST['forgot'])) {
                $forgot_email = $_POST['forgot_email'];

                //Checks if the email exist in the system (checks admin, then employees)
                $email_checked = email_is_admin($conn, $forgot_email);
                if (!$email_checked) {
                    $sql = "SELECT email FROM employees WHERE email = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $forgot_email);
                    $stmt->execute();
                    $email_checked = (bool) $stmt->get_result()->fetch_object();
                }

                if ($email_checked) {
                    // Generate a 6-digit one-time code and store only its hash, with a 10-minute expiry
                    $otp = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                    $otp_hash = hash('sha256', $otp);
                    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

                    // Invalidate any earlier unused codes for this email first
                    $sql = "UPDATE password_resets SET used = 1 WHERE email = ? AND used = 0";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $forgot_email);
                    $stmt->execute();

                    $sql = "INSERT INTO password_resets (email, otp_hash, expires_at) VALUES (?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("sss", $forgot_email, $otp_hash, $expires_at);
                    $stmt->execute();

                    $mail_body = "<p>Your Eco Hydrate Hub password reset code is:</p>
                        <h2 style='letter-spacing:4px;'>{$otp}</h2>
                        <p>This code expires in 10 minutes. If you didn't request this, you can ignore this email.</p>";

                    $mail_result = send_email($forgot_email, 'Your Password Reset Code', $mail_body);

                    if (!$mail_result['success']) {
                        // Logs the REAL PHPMailer error so you can see why it failed
                        // (check your server's PHP error log for a line starting with "Forgot-password mail error:")
                        error_log('Forgot-password mail error: ' . $mail_result['error']);
                    }

                    if ($mail_result['success']) {
                        echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                //Load the reset pass
                                $('#hiddenResetEmail').val('{$forgot_email}');
                                $('#changePassModal').modal('show');
                            });
                        
                        </script>
                        HTML;
                    } else {
                        echo <<<HTML
                                <script>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Could Not Send Email',
                                        text: 'Please try again in a moment.',
                                        confirmButtonColor: '#0d6efd',
                                        confirmButtonText: 'Okay',
                                        background: '#112240',
                                        color: '#CCD6F6'
                                    });
                                </script>
                            HTML;
                    }
                } else {
                    echo <<<HTML
                            <script>
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Invalid Email',
                                    text: 'Please enter your work email',
                                    confirmButtonColor: '#0d6efd',
                                    confirmButtonText: 'Okay',
                                    background: '#112240',
                                    color: '#CCD6F6'
                                });
                            </script>
                        HTML;
                }
            }

            if (isset($_POST['change'])) {

                $new_pass = $_POST['new_password'];
                $confirm_pass = $_POST['confirm_password'];
                $forgot_email = $_POST['hidden_email'];
                $otp_entered = $_POST['otp_code'] ?? '';

                // Verify the emailed code before anything else can happen
                $reset_row = null;
                $sql = "SELECT id, otp_hash FROM password_resets WHERE email = ? AND used = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $forgot_email);
                $stmt->execute();
                $reset_row = $stmt->get_result()->fetch_object();

                $otp_valid = $reset_row && $otp_entered !== '' && hash_equals($reset_row->otp_hash, hash('sha256', $otp_entered));

                if (!$otp_valid) {
                    echo <<<HTML
                        <script>
                            $(document).ready(function() {
                                $('#hiddenResetEmail').val('{$forgot_email}');
                                var modal = new bootstrap.Modal(document.getElementById('changePassModal'));
                                modal.show();
                                if (window.resetOtpBoxes) { window.resetOtpBoxes(); }

                                Swal.fire({
                                    icon: 'error',
                                    title: 'Incorrect Code',
                                    text: 'That code is invalid or has expired. Please try again.',
                                    background: '#112240',
                                    color: '#CCD6F6',
                                    confirmButtonColor: '#0d6efd',
                                    confirmButtonText: 'Try Again'
                                });
                            });
                        </script>
                    HTML;
                } else if ($new_pass && $confirm_pass) {
                    if (strlen($new_pass) >= 8) {
                        //Confirm pass and new pass mathes
                        if ($new_pass == $confirm_pass && $forgot_email != "DUMMY") {
                            //New pass must not match current pass
                            $forgot_is_admin = email_is_admin($conn, $forgot_email);
                            if ($forgot_is_admin) {
                                $sql = "SELECT password FROM admin WHERE email = ?";
                            } else {
                                $sql = "SELECT password FROM employees WHERE email = ?";
                            }
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("s", $forgot_email);
                            $stmt->execute();
                            $result = $stmt->get_result()->fetch_object();
                            if (!password_verify($new_pass, $result->password)) {
                                $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process
                                if ($forgot_is_admin) {
                                    $sql = "UPDATE `admin` SET `password` = ? WHERE email = ?";
                                } else {
                                    $sql = "UPDATE `employees` SET `password` = ? WHERE email = ?";
                                }
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("ss", $password, $forgot_email);
                                if ($stmt->execute()) {
                                    // Mark this code as used so it can't be replayed
                                    $sql = "UPDATE password_resets SET used = 1 WHERE id = ?";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("i", $reset_row->id);
                                    $stmt->execute();

                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: 'Password Updated!',
                                                            text: 'Account password has been updated!.',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            confirmButtonColor: '#00E676',
                                                            heightAuto: false
                                                        });
                                                    })
                                                </script> 
                                                HTML;
                                }
                            } else {
                                echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            $('#hiddenResetEmail').val('{$forgot_email}');
                                            if (window.resetOtpBoxes) { window.resetOtpBoxes(); }
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Password Re-used!',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                showConfirmButton: false,
                                                html:`
                                                    <p>New password must not match with current password!</p>
                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                            })
                                        })
                                    </script> 
                                HTML;
                            }
                        } else {
                            echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        $('#hiddenResetEmail').val('{$forgot_email}');
                                        if (window.resetOtpBoxes) { window.resetOtpBoxes(); }
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Password Unmatched!',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            showConfirmButton: false,
                                            html:`
                                                <p>New password must match with confirm password!</p>
                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                        })
                                    })
                                </script> 
                            HTML;
                        }
                    } else {
                        echo <<<HTML
                                <script>
                                    $(document).ready(function() {
                                        $('#hiddenResetEmail').val('{$forgot_email}');
                                        if (window.resetOtpBoxes) { window.resetOtpBoxes(); }
                                        Swal.fire({
                                            icon: 'error',  
                                            title: 'Invalid New Password!',
                                            background: '#112240',
                                            color: '#CCD6F6',
                                            showConfirmButton: false,
                                            html:`
                                                <p>New password must be atleast 8 characters long</p>
                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#changePassModal" onclick="Swal.close()">Ok</a>`
                                        })
                                    });
                                </script> 
                            HTML;
                    }
                }
            }
        }
        ?>

        <?php
        include 'changepass.php';
        ?>

    </div>




    <script>
        const toggle = document.querySelector('.menu-toggle');
        const nav = document.querySelector('.site-nav');
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('menu-open');
            toggle.setAttribute('aria-expanded', open);
        });

        $(document).ready(function() {

            $("#sendResetBtn").click(function() {
                let userEmail = $("#resetEmail").val();

                if (userEmail === "") {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Email Required',
                        text: 'Please enter your email address first.',
                        confirmButtonColor: '#0d6efd',
                        confirmButtonText: 'Okay',
                        background: '#112240',
                        color: '#CCD6F6'
                    });
                    return; // Stop here if empty
                }

                $("#hiddenResetEmail").val(userEmail);

                // Hide the Forgot Password
                $("#forgotPasswordModal").modal('hide');

                setTimeout(function() {
                    $("#changePassModal").modal('show');
                }, 500);
            });

        });
    </script>



</body>

</html>