<?php
// ---- Profile data (same approach the HR/Admin profile modal uses) ----
$pf_id    = isset($result) ? $result->id : '';
$pf_first = isset($result) ? $result->first_name : '';
$pf_last  = isset($result) ? $result->last_name : '';
$pf_name  = trim($pf_first . ' ' . $pf_last);
$pf_email = isset($result) ? $result->email : '';
$pf_role  = isset($result) ? $result->role : 'Employee';

// Initials for the avatar (first + last word of the name)
preg_match_all('/\p{L}+/u', $pf_name, $pf_words);
$pf_words = $pf_words[0];
$pf_initials = '';
if (count($pf_words) > 0) {
    $pf_initials = mb_substr($pf_words[0], 0, 1, 'UTF-8');
    if (count($pf_words) > 1) {
        $pf_initials .= mb_substr($pf_words[count($pf_words) - 1], 0, 1, 'UTF-8');
    }
    $pf_initials = mb_strtoupper($pf_initials, 'UTF-8');
} else {
    $pf_initials = 'E';
}
?>
<div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="empPfName" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content pf-modal">

            <!-- HERO -->
            <header class="pf-hero">
                <svg class="pf-waves" viewBox="0 0 2400 120" preserveAspectRatio="none" aria-hidden="true">
                    <path class="pf-wave pf-wave-back" d="M0 52 q150 -44 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                    <path class="pf-wave pf-wave-front" d="M0 78 q150 -34 300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 t300 0 V120 H0 Z"/>
                </svg>

                <button type="button" class="pf-close" data-bs-dismiss="modal" aria-label="Close profile"><i class="bi bi-x-lg"></i></button>

                <div class="pf-identity">
                    <div class="pf-avatar" aria-hidden="true"><?php echo htmlspecialchars($pf_initials); ?></div>
                    <div class="pf-identity-text">
                        <h5 class="pf-name" id="empPfName"><?php echo htmlspecialchars($pf_name); ?></h5>
                        <?php if ($pf_email !== ''): ?>
                            <div class="pf-email"><i class="bi bi-envelope"></i><span class="pf-email-text"><?php echo htmlspecialchars($pf_email); ?></span></div>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <div class="pf-body">

                <ul class="nav pf-tabs" id="empProfileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="empProfTabInfo" data-bs-toggle="tab" data-bs-target="#empProfPaneInfo" type="button" role="tab"><i class="bi bi-person-badge"></i>Account Info</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="empProfTabSecurity" data-bs-toggle="tab" data-bs-target="#empProfPaneSecurity" type="button" role="tab"><i class="bi bi-shield-lock"></i>Security</button>
                    </li>
                </ul>

                <div class="tab-content">

                    <!-- ACCOUNT INFO TAB -->
                    <div class="tab-pane fade show active" id="empProfPaneInfo" role="tabpanel">
                        <div class="pf-fields">
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-hash"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">ID</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_id); ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-person"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Full name</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_name); ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-envelope"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Email address</span>
                                    <span class="pf-field-value"><?php echo $pf_email !== '' ? htmlspecialchars($pf_email) : '<span class="pf-empty">Not provided</span>'; ?></span>
                                </div>
                            </div>
                            <div class="pf-field">
                                <span class="pf-field-icon"><i class="bi bi-briefcase"></i></span>
                                <div class="pf-field-text">
                                    <span class="pf-field-label">Role</span>
                                    <span class="pf-field-value"><?php echo htmlspecialchars($pf_role); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- SECURITY TAB -->
                    <div class="tab-pane fade" id="empProfPaneSecurity" role="tabpanel">
                        <div class="pf-pass">

                            <form id="changePasswordForm" method="POST" class="pf-pass-form">

                                <div class="pf-input-group">
                                    <label for="currentPassword" class="pf-label">Current password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-lock pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="currentPassword" name="current_password" autocomplete="current-password" required>
                                        <button type="button" class="pf-eye" data-target="currentPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>
                                <div class="pf-input-group">
                                    <label for="newPassword" class="pf-label">New password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-key pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="newPassword" name="new_password" autocomplete="new-password" required>
                                        <button type="button" class="pf-eye" data-target="newPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>
                                <div class="pf-input-group">
                                    <label for="confirmPassword" class="pf-label">Confirm new password</label>
                                    <div class="pf-input-wrap">
                                        <i class="bi bi-key-fill pf-input-icon"></i>
                                        <input type="password" class="form-control profile-input pf-input" id="confirmPassword" name="confirm_password" autocomplete="new-password" required>
                                        <button type="button" class="pf-eye" data-target="confirmPassword" aria-label="Show password"><i class="bi bi-eye"></i></button>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end pt-2">
                                    <button type="submit" name="changePass" class="pf-btn pf-btn-primary"><i class="bi bi-shield-check"></i>Update password</button>
                                </div>
                            </form>

                            <aside class="pf-checklist" aria-live="polite">
                                <p class="pf-checklist-title">Your new password needs to</p>
                                <ul>
                                    <li id="empPfRuleLen"><i class="bi bi-circle"></i>Be at least 8 characters long</li>
                                    <li id="empPfRuleMatch"><i class="bi bi-circle"></i>Match the confirmation</li>
                                    <li id="empPfRuleDiff"><i class="bi bi-circle"></i>Differ from your current password</li>
                                </ul>
                            </aside>
                        </div>

                        <?php
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            //Change Password
                            if (isset($_POST['changePass'])) {
                                $current_pass = $_POST['current_password'];
                                $new_pass = $_POST['new_password'];
                                $confirm_pass = $_POST['confirm_password'];

                                //Checking if current password matched
                                if (password_verify($current_pass, $result->password)) {
                                    //Password must be atleast 8 characters
                                    if (strlen($new_pass) >= 8) {
                                        //Confirm pass and new pass mathes
                                        if ($new_pass == $confirm_pass) {
                                            //New pass must not match current pass
                                            if (!password_verify($new_pass, $result->password)) {
                                                $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process
                                                $sql = "UPDATE `employees` SET `password` = ? WHERE id = '" . $result->id . "'";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("s", $password);
                                                if ($stmt->execute()) {
                                                    echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Password Updated!',
                                                                                text: 'The employee information has been updated!.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',
                                                                                heightAuto: false
                                                                            });
                                                                        })
                                                                    </script> 
                                                                    HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Password Re-used!',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    showConfirmButton: false,
                                                                    html:`
                                                                        <p>New password must not match with current password!</p>
                                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close(); openEmpProfileSecurityTab();">Ok</a>`
                                                                })
                                                            })
                                                        </script> 
                                                    HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Unmatched!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must match with confirm password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close(); openEmpProfileSecurityTab();">Ok</a>`
                                                            })
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',  
                                                                title: 'Invalid New Password!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must be atleast 8 characters long</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close(); openEmpProfileSecurityTab();">Ok</a>`
                                                            })
                                                        });
                                                    </script> 
                                                HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'error',  
                                                        title: 'Incorrect Password!',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        showConfirmButton: false,
                                                        html:`
                                                            <p>Re-enter current password</p>
                                                            <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close(); openEmpProfileSecurityTab();">Ok</a>`
                                                    })
                                                });
                                            </script> 
                                        HTML;
                                }
                            }
                        }
                        ?>

                    </div><!-- /security pane -->

                </div><!-- /tab-content -->
            </div><!-- /pf-body -->

        </div>
    </div>
</div>

<style>
    /* ===== Employee/Cashier profile modal -- same visual language as the HR/Admin profile modal ===== */
    #profileModal .pf-modal {
        background: var(--ws-panel-2, #0b3054);
        border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 30px 70px rgba(0, 0, 0, .55);
    }

    /* Hero */
    #profileModal .pf-hero {
        position: relative;
        padding: 34px 32px;
        background:
            radial-gradient(circle at 12% 0%, rgba(111, 227, 255, .34), transparent 55%),
            linear-gradient(135deg, #12609b 0%, #0b3f6e 55%, #08305a 100%);
        overflow: hidden;
    }
    #profileModal .pf-waves {
        position: absolute; left: 0; bottom: -1px; width: 100%; height: 64px; pointer-events: none;
    }
    #profileModal .pf-wave { fill: #0b3054; }
    #profileModal .pf-wave-back { opacity: .4; }
    #profileModal .pf-wave-front { opacity: 1; }
    #profileModal .pf-waves { width: 200%; animation: empPfDrift 22s linear infinite; }
    @keyframes empPfDrift { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    #profileModal .pf-close {
        position: absolute; top: 16px; right: 16px; z-index: 2;
        width: 36px; height: 36px; border-radius: 12px;
        display: inline-flex; align-items: center; justify-content: center;
        background: rgba(4, 23, 41, .35); border: 1px solid rgba(255, 255, 255, .18);
        color: #fff; font-size: 14px; cursor: pointer; transition: background .15s, transform .15s;
    }
    #profileModal .pf-close:hover { background: rgba(255, 107, 122, .35); }
    #profileModal .pf-close:active { transform: scale(.94); }

    #profileModal .pf-identity { position: relative; z-index: 1; display: flex; align-items: center; gap: 20px; }
    #profileModal .pf-avatar {
        flex: 0 0 auto; width: 88px; height: 88px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 32px; font-weight: 800; letter-spacing: 1px; color: #04213b;
        background: linear-gradient(145deg, #8cecff, #29c5f6 60%, #1e88e5);
        box-shadow: 0 0 0 4px rgba(4, 23, 41, .35), 0 0 0 6px rgba(111, 227, 255, .55), 0 14px 28px rgba(0, 0, 0, .35);
    }
    #profileModal .pf-identity-text { min-width: 0; overflow: hidden; }
    #profileModal .pf-name { padding-right: 44px; margin: 0 0 6px; color: #fff; font-size: 26px; font-weight: 800; line-height: 1.15; overflow-wrap: anywhere; }
    #profileModal .pf-email { display: flex; align-items: center; gap: 8px; color: rgba(230, 246, 255, .85); font-size: 14px; white-space: nowrap; }
    #profileModal .pf-email i { flex: 0 0 auto; }
    #profileModal .pf-email-text { min-width: 0; overflow: hidden; text-overflow: ellipsis; }

    /* Body + tabs */
    #profileModal .pf-body { padding: 22px 32px 30px; }
    #profileModal .pf-tabs {
        display: flex; gap: 6px; padding: 5px; margin-bottom: 22px; flex-wrap: nowrap;
        background: #06203a; border: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); border-radius: 14px;
    }
    #profileModal .pf-tabs .nav-item { flex: 1 1 0; }
    #profileModal .pf-tabs .nav-link {
        width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px;
        padding: 10px 12px; border: none; border-radius: 10px;
        background: transparent; color: var(--ws-muted, #8fb4cf);
        font-size: 14px; font-weight: 700; white-space: nowrap; transition: background .15s, color .15s;
    }
    #profileModal .pf-tabs .nav-link:hover { color: #fff; background: rgba(41, 197, 246, .08); }
    #profileModal .pf-tabs .nav-link.active { color: #04213b; background: linear-gradient(135deg, #6fe3ff, #29c5f6); }

    /* Account info */
    #profileModal .pf-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 0 28px; }
    #profileModal .pf-field {
        display: flex; align-items: center; gap: 14px; padding: 16px 0;
        border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #profileModal .pf-field:nth-last-child(-n+2) { border-bottom: none; }
    #profileModal .pf-field-icon {
        flex: 0 0 auto; width: 42px; height: 42px; border-radius: 13px;
        display: flex; align-items: center; justify-content: center; font-size: 18px;
        color: var(--ws-aqua-2, #6fe3ff); background: rgba(41, 197, 246, .12); border: 1px solid rgba(41, 197, 246, .25);
    }
    #profileModal .pf-field-text { display: flex; flex-direction: column; min-width: 0; }
    #profileModal .pf-field-label { color: var(--ws-muted, #8fb4cf); font-size: 12.5px; font-weight: 600; }
    #profileModal .pf-field-value { color: #fff; font-size: 15.5px; font-weight: 600; overflow-wrap: anywhere; }
    #profileModal .pf-empty { color: var(--ws-muted, #8fb4cf); font-weight: 500; font-style: italic; }

    /* Buttons */
    #profileModal .pf-btn {
        display: inline-flex; align-items: center; justify-content: center; gap: 8px;
        padding: 11px 22px; border-radius: 14px; font-size: 14.5px; font-weight: 800; border: none; cursor: pointer;
        transition: transform .12s, filter .15s, background .15s;
    }
    #profileModal .pf-btn:active { transform: scale(.97); }
    #profileModal .pf-btn-primary { color: #032a1e; background: linear-gradient(135deg, #2ee6a6, #12b886); box-shadow: 0 10px 22px rgba(46, 230, 166, .25); }
    #profileModal .pf-btn-primary:hover { filter: brightness(1.08); }

    /* Password */
    #profileModal .pf-pass { display: grid; grid-template-columns: minmax(0, 1.5fr) minmax(0, 1fr); gap: 28px; align-items: start; }
    #profileModal .pf-input-group { margin-bottom: 16px; }
    #profileModal .pf-label { display: block; margin-bottom: 6px; color: var(--ws-text, #e6f6ff); font-size: 13.5px; font-weight: 700; }
    #profileModal .pf-input-wrap { position: relative; }
    #profileModal .pf-input-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: var(--ws-muted, #8fb4cf); pointer-events: none; }
    #profileModal .pf-input { height: 48px; padding: 0 46px 0 42px; border-radius: 14px; font-size: 15px; }
    #profileModal .pf-input:focus { border-color: var(--ws-aqua, #29c5f6) !important; box-shadow: 0 0 0 .25rem rgba(41, 197, 246, .22) !important; }
    #profileModal .pf-eye {
        position: absolute; right: 6px; top: 50%; transform: translateY(-50%);
        width: 36px; height: 36px; border: none; border-radius: 10px; background: transparent;
        color: var(--ws-muted, #8fb4cf); cursor: pointer;
    }
    #profileModal .pf-eye:hover { color: #fff; background: rgba(41, 197, 246, .14); }

    #profileModal .pf-checklist {
        padding: 18px; border-radius: 16px; background: rgba(4, 23, 41, .55); border: 1px solid var(--ws-line, rgba(140, 214, 255, .16));
    }
    #profileModal .pf-checklist-title { margin: 0 0 12px; color: #fff; font-size: 14px; font-weight: 800; }
    #profileModal .pf-checklist ul { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 10px; }
    #profileModal .pf-checklist li { display: flex; align-items: center; gap: 10px; color: var(--ws-muted, #8fb4cf); font-size: 13.5px; transition: color .15s; }
    #profileModal .pf-checklist li.ok { color: var(--ws-green, #2ee6a6); }

    /* Keyboard focus */
    #profileModal .pf-close:focus-visible,
    #profileModal .pf-eye:focus-visible,
    #profileModal .pf-btn:focus-visible,
    #profileModal .pf-tabs .nav-link:focus-visible { outline: 2px solid var(--ws-aqua-2, #6fe3ff); outline-offset: 2px; }

    /* Responsive */
    @media (max-width: 767.98px) {
        #profileModal .pf-hero { padding: 28px 20px; }
        #profileModal .pf-avatar { width: 68px; height: 68px; font-size: 24px; }
        #profileModal .pf-name { font-size: 21px; }
        #profileModal .pf-body { padding: 18px 16px 24px; }
        #profileModal .pf-fields { grid-template-columns: 1fr; }
        #profileModal .pf-field:nth-last-child(2) { border-bottom: 1px solid var(--ws-line, rgba(140, 214, 255, .16)); }
        #profileModal .pf-tabs .nav-link { font-size: 12.5px; padding: 9px 6px; gap: 5px; }
        #profileModal .pf-tabs .nav-link i { display: none; }
        #profileModal .pf-pass { grid-template-columns: 1fr; gap: 18px; }
        #profileModal .pf-checklist { order: -1; }
    }

    @media (prefers-reduced-motion: reduce) {
        #profileModal .pf-waves { animation: none; }
    }
</style>

<script>
    //After a password error popup, reopen the profile on the Security tab instead of Account Info
    function openEmpProfileSecurityTab() {
        var el = document.getElementById('empProfTabSecurity');
        if (el && window.bootstrap) { bootstrap.Tab.getOrCreateInstance(el).show(); }
    }

    (function () {
        //Show / hide password buttons
        document.querySelectorAll('#profileModal .pf-eye').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(btn.getAttribute('data-target'));
                var icon = btn.querySelector('i');
                var show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                icon.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
                btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            });
        });

        //Live password checklist (the server still does the real validation)
        var cur = document.getElementById('currentPassword');
        var nw  = document.getElementById('newPassword');
        var cf  = document.getElementById('confirmPassword');
        var rules = {
            len:   document.getElementById('empPfRuleLen'),
            match: document.getElementById('empPfRuleMatch'),
            diff:  document.getElementById('empPfRuleDiff')
        };
        function mark(li, ok) {
            li.classList.toggle('ok', ok);
            li.querySelector('i').className = ok ? 'bi bi-check-circle-fill' : 'bi bi-circle';
        }
        function refresh() {
            mark(rules.len, nw.value.length >= 8);
            mark(rules.match, nw.value.length > 0 && nw.value === cf.value);
            mark(rules.diff, nw.value.length > 0 && cur.value.length > 0 && nw.value !== cur.value);
        }
        [cur, nw, cf].forEach(function (el) { el.addEventListener('input', refresh); });
    })();
</script>
