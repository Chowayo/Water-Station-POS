<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

// Scoped to this Delivery/Cashier user's own branch
$branch_id = (int) $result->branch_id;

echo <<<HTML
        <script>
            $(document).ready(function() {
                 //Sends the Delivery back if it tries to access pages that it does not have persmission to access
                if("{$result->role}"=="Delivery"){
                    //Empty since delivery can access this page
                }

                //Sends the Cashier back if it tries to access pages that it does not have persmission to access
                else if("{$result->role}"=="Delivery"){
                    //Empty since cashier can access every present page in the system
                }
            });
        </script>
    HTML;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Confirmation</title>


    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <style>
        /* ===== Scrollable table container ===== */
        .table-scroll-wrap {
            max-height: 480px;
            overflow-y: auto;
            overflow-x: auto;
            border-radius: 12px;
        }

        .table-scroll-wrap thead th {
            position: sticky;
            top: 0;
            background-color: #112240;
            z-index: 1;
        }

        /* ===== DataTables pagination (dark theme override) ===== */
        .dataTables_wrapper {
            color: #CCD6F6;
        }

        .dataTables_wrapper .dataTables_info {
            color: #8892B0;
            font-size: 0.85rem;
            padding-top: 14px;
        }

        .dataTables_wrapper .dataTables_paginate {
            padding-top: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: #CCD6F6 !important;
            border: 1px solid #233554 !important;
            background: transparent !important;
            border-radius: 8px;
            margin-left: 4px;
            padding: 4px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
            color: #4d5f82 !important;
            cursor: not-allowed;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover:not(.disabled) {
            background: rgba(100, 255, 218, 0.1) !important;
            border-color: #64FFDA !important;
            color: #64FFDA !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #64FFDA !important;
            border-color: #64FFDA !important;
            color: #0A192F !important;
            font-weight: 700;
        }

        .dataTables_wrapper .d-flex.justify-content-between {
            flex-wrap: wrap;
            align-items: center;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include 'navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include 'topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-center align-items-center gap-3">
                <div class="text-center">
                    <h1>Delivery & Order Confirmation</h1>
                </div>
            </header>

            <div class="box mt-2">
                <div class="d-flex flex-wrap gap-2 justify-content-between mb-3 align-items-center">
                    <h5 class="mb-0 fw-bold">Active Deliveries</h5>

                    <div class="table-search-input search-icon-wrap">
                        <i class="bi bi-search search-icon-inside"></i>
                        <input type="text" class="form-control" placeholder="Search Order" id="searcher">
                    </div>
                </div>
                <script>
                    $(document).ready(function() {
                        var table = $('#order_list').DataTable({
                            paging: true, // Enable pagination
                            pageLength: 8,
                            lengthChange: false,
                            searching: true, // Enable search functionality
                            ordering: false,
                            dom: '<"table-scroll-wrap"t><"d-flex justify-content-between align-items-center"ip>'
                        });

                        $('#searcher').on('keyup change clear', function() {
                            table.search(this.value).draw(); //Sets the input box as the new search bar
                        });


                    });
                </script>

                <table class="table table-dark table-hover text-center mb-0 align-middle" id="order_list">
                    <thead>
                        <tr>
                            <th>Order Number</th>
                            <th>Customer Name</th>
                            <th>Order Content</th>
                            <th>Total</th>
                            <th>Payment Method</th>
                            <th>Order Type</th>
                            <th>Time</th>
                            <th>Date</th>
                            <th>Actions</th>
                            <th>View Receipt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rc = null;       //order whose receipt is being opened
                        $rc_items = [];

                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                            //CONFIRM DELIVERY / PICKUP
                            if (isset($_POST['confirm'])) {
                                $confirm_id = (int) $_POST['confirm'];

                                $stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND deleted = 'False' AND branch_id = ?");
                                $stmt->bind_param("ii", $confirm_id, $branch_id);
                                $stmt->execute();
                                $order = $stmt->get_result()->fetch_object();

                                //Only orders that are still waiting can be confirmed (stops double confirmation / duplicate income)
                                if ($order && in_array($order->status, ['Submitted', 'Not received'])) {

                                    $stmt = $conn->prepare("UPDATE `orders` SET `status` = 'Received' WHERE id = ? AND branch_id = ?");
                                    $stmt->bind_param("ii", $confirm_id, $branch_id);
                                    if ($stmt->execute() && $stmt->affected_rows > 0) {

                                        //Income is recorded here for web orders (POS sales are already recorded at the register)
                                        $description = "Order #" . $order->id . " Payment";
                                        $category = "Sales";
                                        $type = "Income";
                                        $sql = "INSERT INTO `transactions` (`branch_id`, `date`, `description`, `category`, `type`, `payment_method`, `amount`) VALUES (?, CURDATE(), ?, ?, ?, ?, ?)";
                                        $stmt = $conn->prepare($sql);
                                        $stmt->bind_param("issssd", $branch_id, $description, $category, $type, $order->payment_method, $order->total_price);
                                        $stmt->execute();

                                        //Notify staff
                                        $sql = "SELECT * FROM employees WHERE (role = 'Cashier' OR role = 'Delivery' OR role = 'Finance') AND deleted = 'False' AND branch_id = " . $branch_id;
                                        $query = $conn->query($sql);
                                        while ($emp_info = $query->fetch_object()) {
                                            $notif_id = $emp_info->id;
                                            $notif_role = $emp_info->role;
                                            $notif_category = "Order Confirmed";
                                            $notif_message = "Order #" . $order->id . " has been confirmed for " . $order->order_type;
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            $stmt->execute();
                                        }

                                        //Notify the customer who placed the order online
                                        if (strpos($order->cashier, 'USER ID:') === 0) {
                                            $cust_id = (int) substr($order->cashier, 8);
                                            $cust_role = "Customer";
                                            $cust_category = "Order Update";
                                            $cust_message = ($order->order_type == "Delivery")
                                                ? "Order #" . $order->id . " has been delivered. Thank you for ordering!"
                                                : "Order #" . $order->id . " has been picked up. Thank you for ordering!";
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $cust_id, $cust_role, $cust_category, $cust_message);
                                            $stmt->execute();
                                        }

                                        echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Order Received!',
                                                        text: 'The order has been completed.',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#00E676',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        location.assign('confirmation.php');
                                                    });
                                                })
                                            </script>
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'info',
                                                    title: 'Already confirmed',
                                                    text: 'This order was already confirmed or is no longer active.',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#00E676',
                                                    heightAuto: false
                                                }).then((result) => {
                                                    location.assign('confirmation.php');
                                                });
                                            })
                                        </script>
                                        HTML;
                                }
                            }

                            //OPEN RECEIPT
                            if (isset($_POST['receipt'])) {
                                $receipt_id = (int) $_POST['receipt'];
                                $stmt = $conn->prepare("SELECT * FROM orders WHERE id = ? AND branch_id = ?");
                                $stmt->bind_param("ii", $receipt_id, $branch_id);
                                $stmt->execute();
                                $rc = $stmt->get_result()->fetch_object();

                                if ($rc) {
                                    foreach (explode(",", $rc->order_content) as $line) {
                                        if (preg_match('/^\s*(\d+)x\s*(.*?)\s*₱([\d.]+)\s*VAT:([\d.]+)/u', $line, $m)) {
                                            $rc_items[] = [
                                                'text'  => $m[1] . 'x ' . trim($m[2]),
                                                'price' => (float) $m[3],
                                                'vat'   => (float) $m[4] * (float) $m[3]
                                            ];
                                        }
                                    }
                                    echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                $('#receiptModal').modal('show');
                                            });
                                        </script>
                                        HTML;
                                }
                            }
                        }

                        //ROWS: waiting orders first, then the earliest/oldest. Carts a customer hasn't submitted yet are not deliveries, so they are left out.
                        $sql = "SELECT * FROM orders WHERE deleted = 'False' AND status != 'Pending' AND branch_id = " . $branch_id . " ORDER BY (status IN ('Submitted','Not received')) DESC, id ASC";
                        $query = $conn->query($sql);
                        while ($set = $query->fetch_object()) {
                            $waiting = in_array($set->status, ['Submitted', 'Not received']);
                            $pay_label = ($set->payment_method === 'Gcash') ? 'PayMongo (Paid)' : htmlspecialchars($set->payment_method);
                            $total_fmt = number_format((float) $set->total_price, 2);

                            echo '<tr>
                                <td class="cyan-text fw-bold">#' . $set->id . '</td>
                                <td style="overflow-wrap: break-word; max-width: 320px;"><strong class="d-block">' . htmlspecialchars($set->customer_name) . '</strong></td>
                                <td style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 250px;"><b>' . htmlspecialchars($set->order_content) . '</b></td>
                                <td class="green-text fw-bold fs-5">₱' . $total_fmt . '</td>
                                <td><span class="badge bg-' . htmlspecialchars($set->payment_method) . '">' . $pay_label . '</span></td>
                                <td>' . htmlspecialchars($set->order_type) . '</td>
                                <td>' . htmlspecialchars($set->time) . '</td>
                                <td>' . htmlspecialchars($set->date) . '</td>';

                            if ($waiting) {
                                $btn_label = ($set->order_type === 'Pickup') ? 'Confirm Pickup' : 'Confirm Delivery';
                                echo '<td>
                                    <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn" data-id="' . $set->id . '" data-type="' . htmlspecialchars($set->order_type) . '" data-method="' . htmlspecialchars($set->payment_method) . '" data-total="' . $total_fmt . '"><i class="bi bi-hourglass-split me-1"></i>' . $btn_label . '</button>
                                </td>';
                            } else {
                                echo '<td>
                                    <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn"><i class="bi bi-check-circle me-1"></i>Order Received</button>
                                </td>';
                            }

                            echo '<td>
                                    <form method="POST"><button type="submit" name="receipt" value="' . $set->id . '" class="btn btn-dark btn-sm rounded-pill px-3"><i class="bi bi-receipt me-1"></i>Open</button></form>
                                </td>
                            </tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>

        </section>
    </main>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $(document).ready(function() {
            //Confirming Delivery / Pickup (delegated so it also works on page 2, 3... of the table)
            $(document).on('click', '.confirm-btn', function() {
                var id = $(this).data('id');
                var isPickup = ($(this).data('type') === 'Pickup');
                var paidOnline = ($(this).data('method') === 'Gcash');
                var total = $(this).data('total');

                var question = isPickup ? 'Has the customer picked up the order?' : 'Has the customer received the water?';
                var payNote = paidOnline
                    ? 'Already paid online via PayMongo. <b>No cash to collect.</b>'
                    : 'Payment method: Cash. <b>Collect ₱' + total + '</b> from the customer.';

                Swal.fire({
                    title: isPickup ? 'Confirm Pickup?' : 'Confirm Delivery?',
                    icon: 'question',
                    background: '#112240',
                    color: '#CCD6F6',
                    html: '<p>' + question + '</p><p class="small">' + payNote + '</p>',
                    showCancelButton: true,
                    showConfirmButton: true,
                    confirmButtonText: 'Confirm Order',
                    confirmButtonColor: '#00E676',
                    cancelButtonColor: '#8892B0',
                    heightAuto: false
                }).then(function(result) {
                    if (result.isConfirmed) {
                        var $form = $('<form method="POST"></form>');
                        $form.append($('<input>').attr({ type: 'hidden', name: 'confirm', value: id }));
                        $('body').append($form);
                        $form.trigger('submit');
                    }
                });
            });

            $(document).on('click', '.done-btn', function() {
                Swal.fire({
                    title: 'Order Complete',
                    text: "The order has been received",
                    icon: 'success',
                    background: '#112240',
                    confirmButtonColor: '#00E676',
                    color: '#CCD6F6',
                    showConfirmButton: true,
                    heightAuto: false
                });
            });

            //Logout
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of POS?",
                    html: `
                        <p class="text-muted small mb-4">This will count as you clocking out and you won't be able to log in until your next shift tommorow.</p>
                        <a href='` + logoutUrl + `' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>`,
                    heightAuto: false
                });
            });
        });
    </script>

    <!-- Receipt -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>#<?php echo $rc->id ?? ''; ?></strong></p>
                            <p>Date: <?php echo htmlspecialchars($rc->date ?? ''); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>Time: <?php echo htmlspecialchars($rc->time ?? ''); ?></p>
                            <p>
                                <?php
                                $rc_cashier = $rc->cashier ?? '';
                                echo 'Cashier: ' . htmlspecialchars(strpos($rc_cashier, 'USER ID:') === 0 ? 'Online Order' : $rc_cashier);
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold"><?php echo (($rc->order_type ?? '') === 'Pickup') ? 'PICKUP DETAILS' : 'DELIVERY DETAILS'; ?></p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Name: <?php echo htmlspecialchars($rc->customer_name ?? ''); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($rc->customer_contact ?? ''); ?></p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Address: <?php echo htmlspecialchars($rc->customer_address ?? ''); ?></p>
                        <p>Payment Method: <?php echo (($rc->payment_method ?? '') === 'Gcash') ? 'PayMongo (Paid Online)' : htmlspecialchars($rc->payment_method ?? ''); ?></p>
                        <p>Order Type: <?php echo htmlspecialchars($rc->order_type ?? ''); ?></p>

                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>
                        <div id="bill-list">
                            <?php foreach ($rc_items as $it): ?>
                                <div class="receipt-grid mb-2" style="display: grid; grid-template-columns: 4fr auto; align-items: start; gap: 15px; max-width: 450px; width: 100%;">
                                    <p><?php echo htmlspecialchars($it['text']); ?></p>
                                    <p class="price">₱<?php echo number_format($it['price'], 2); ?></p>
                                    <p>VAT: <?php echo number_format($it['vat'], 2); ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="receipt-divider"></div>
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>VAT TOTAL:</p>
                            <p>₱<?php echo number_format((float) ($rc->total_vat ?? 0), 2); ?></p>
                        </div>
                        <div class="receipt-divider"></div>
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱<?php echo number_format((float) ($rc->total_price ?? 0), 2); ?></p>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print Receipt</button>
                </div>

            </div>
        </div>
    </div>
</body>

</html>