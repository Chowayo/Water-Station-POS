<?php


$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'pos';

/*

$dbhost = 'sql301.infinityfree.com';
$dbuser = 'if0_43120155';
$dbpass = 'fxL7oSKPuwKf';
$dbname = 'if0_43120155_pos';

    */

$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
    die('Could not connect to database');
}

session_start();

// How far (in km, straight-line) a branch is willing to deliver. Past this,
// nearest_branch_id() still returns the closest branch (useful for catalog
// auto-detect), but callers placing an actual order should treat it as
// out-of-range -- see $out_of_range in checkout.php. Adjust to match the
// real service area.
define('MAX_DELIVERY_RADIUS_KM', 15);

// Returns the id of the branches row closest to ($lat, $lng) using the
// Haversine formula, or null if no branch has coordinates set.
// Used by Customer pages to auto-detect which branch a customer belongs to.
// Pass $distance_km by reference to also get the distance to that branch,
// so a caller can decide whether it's actually within delivery range.
function nearest_branch_id($conn, $lat, $lng, &$distance_km = null)
{
    $sql = "SELECT id, latitude, longitude FROM branches WHERE status = 'Active' AND latitude IS NOT NULL AND longitude IS NOT NULL";
    $result = $conn->query($sql);
    $best_id = null;
    $best_distance = null;
    while ($branch = $result->fetch_object()) {
        $earth_radius_km = 6371;
        $lat_delta = deg2rad($branch->latitude - $lat);
        $lng_delta = deg2rad($branch->longitude - $lng);
        $a = sin($lat_delta / 2) * sin($lat_delta / 2)
            + cos(deg2rad($lat)) * cos(deg2rad($branch->latitude))
            * sin($lng_delta / 2) * sin($lng_delta / 2);
        $distance = $earth_radius_km * 2 * atan2(sqrt($a), sqrt(1 - $a));
        if ($best_distance === null || $distance < $best_distance) {
            $best_distance = $distance;
            $best_id = (int) $branch->id;
        }
    }
    $distance_km = $best_distance;
    return $best_id;
}

// Daily pay rate (in pesos) for each role that is on payroll. This is the ONE place to edit rates;
// login.php (monthly payroll generator) and Hr/payroll.php (manual add) both read it.
// Roles that are not listed here are NOT on payroll (HR is paid outside this system, and the
// Supplier account is an external vendor, not staff).
// Daily rates below. Edit this list to change anyone's pay.
function payroll_daily_rates()
{
    return [
        'Cashier'   => 500.00,
        'Delivery'  => 600.00,
        'Financer'  => 600.00,
        'Inventory' => 600.00,
    ];
}

// Daily rate for one role, or null if that role is not on payroll.
function payroll_daily_rate($role)
{
    $rates = payroll_daily_rates();
    return array_key_exists($role, $rates) ? $rates[$role] : null;
}

// Small "which branch is this?" badge shown in every top bar.
// $extra_class lets the caller position it (e.g. 'me-auto' to push it to the left).
function branch_badge_html($conn, $branch_id, $extra_class = '')
{
    $branch_id = (int) $branch_id;
    if ($branch_id <= 0) {
        return '';
    }
    $stmt = $conn->prepare("SELECT name FROM branches WHERE id = ?");
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_object();
    if (!$row) {
        return '';
    }
    return '<span class="branch-badge ' . htmlspecialchars($extra_class, ENT_QUOTES, 'UTF-8') . '" title="Branch" '
        . 'style="display:inline-flex;align-items:center;gap:6px;background:#0A192F;border:1px solid #233554;color:#64FFDA;'
        . 'border-radius:8px;padding:6px 12px;font-size:13px;font-weight:700;white-space:nowrap;">'
        . '<i class="bi bi-geo-alt-fill"></i>' . htmlspecialchars($row->name, ENT_QUOTES, 'UTF-8') . '</span>';
}

// Returns true if $email belongs to a row in the admin table.
// Used instead of guessing admin-vs-employee from the email text itself
// (e.g. an employee email starting with "admin" would be misrouted by that).
function email_is_admin($conn, $email)
{
    $stmt = $conn->prepare("SELECT 1 FROM admin WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    return (bool) $stmt->get_result()->fetch_object();
}

// Fallback branch id to use when geolocation hasn't run yet or failed
// (first active branch by id).
function default_branch_id($conn)
{
    $sql = "SELECT id FROM branches WHERE status = 'Active' ORDER BY id ASC LIMIT 1";
    $result = $conn->query($sql);
    $row = $result->fetch_object();
    return $row ? (int) $row->id : 1;
}
