<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Eco Hydrate Hub</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>

    <style>
        body {
            background-color: #0A192F;
            color: #CCD6F6;
        }

        .app {
            background-color: #0A192F;
            overflow: hidden;
        }

        .left-menu {
            width: 250px;
            background-color: #020C1B;
            border-right: 2px solid #112240;
        }

        .logo {
            margin: 20px auto;
        }

        .menu-link {
            color: #8892B0;
            font-weight: 700;
            text-align: center;
            margin-bottom: 15px;
            font-size: 15px;
            text-decoration: none;
            display: block;
            transition: 0.3s;
        }

        .menu-link:hover,
        .menu-link.active {
            color: #64FFDA;
        }

        .content {
            background-color: #0A192F;
        }

        .top-text h1 {
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0px;
            color: #FFFFFF;
        }

        .green-text {
            color: #00E676;
        }

        .cyan-text {
            color: #64FFDA;
        }

        .top-text h6 {
            font-weight: 600;
            font-size: 14px;
            margin-top: 5px;
            color: #8892B0;
        }

        .dash-card {
            background-color: #112240;
            border: 1px solid #233554;
            border-radius: 20px;
            padding: 20px;
            height: 100%;
            box-shadow: 0 10px 30px -15px rgba(2, 12, 27, 0.7);
            transition: all 0.2s ease;
        }

        .dash-card:hover {
            transform: translateY(-5px);
            border-color: #64FFDA;
        }

        .dash-title {
            font-size: 16px;
            font-weight: 600;
            color: #8892B0;
            margin-bottom: 10px;
        }

        .dash-value {
            font-size: 32px;
            font-weight: 800;
            color: #FFFFFF;
        }

        .section-header {
            font-size: 20px;
            font-weight: 700;
            color: #CCD6F6;
            border-bottom: 2px solid #233554;
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 20px;
        }

        .manage-box {
            background-color: #112240;
            border-radius: 15px;
            padding: 20px;
        }

        .table-dark {
            background-color: transparent;
            color: #CCD6F6;
        }

        .table-dark th {
            border-bottom: 2px solid #233554;
            color: #8892B0;
        }

        .table-dark td {
            border-bottom: 1px solid #233554;
            vertical-align: middle;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .status-completed {
            background-color: rgba(0, 230, 118, 0.1);
            color: #00E676;
            border: 1px solid #00E676;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <nav class="nav flex-column mt-4 px-2">
                <p class="text-center fw-bold text-muted small mb-4">ADMINISTRATOR</p>

                <?php
                $current_page = basename($_SERVER['PHP_SELF']);
                ?>

                <a class="menu-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">
                    Dashboard
                </a>

                <a class="menu-link <?php echo ($current_page == 'employees.php') ? 'active' : ''; ?>" href="employees.php">
                    Employees
                </a>

                <a class="menu-link <?php echo ($current_page == 'products.php') ? 'active' : ''; ?>" href="products.php">
                    Products
                </a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="#" id="logout">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">

            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Admin Dashboard</h6>
                    </div>
                </header>

                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Daily Income</div>
                            <div class="dash-value green-text">₱ 1,000.00</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Total Orders Today</div>
                            <div class="dash-value">50</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card">
                            <div class="dash-title">Gallons Refilled</div>
                            <div class="dash-value cyan-text">100 L</div>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-12">
                        <div class="section-header">Recent Sales Report</div>
                        <div class="manage-box shadow-sm">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="mb-0 pt-1">Today's Transactions</h5>
                            </div>
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Time</th>
                                        <th>Cashier</th>
                                        <th>Qty</th>
                                        <th>Product Name</th>
                                        <th>Total Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="cyan-text fw-bold">1</td>
                                        <td>2:45 PM</td>
                                        <td>Chow Lu</td>
                                        <td>3</td>
                                        <td>Round Gallon Refill</td>
                                        <td class="green-text fw-bold">₱ 90.00</td>
                                        <td><span class="status-badge status-completed">Completed</span></td>
                                    </tr>
                                    <tr>
                                        <td class="cyan-text fw-bold">2</td>
                                        <td>2:30 PM</td>
                                        <td>Chow Lu</td>
                                        <td>1</td>
                                        <td>New Slim Container</td>
                                        <td class="green-text fw-bold">₱ 150.00</td>
                                        <td><span class="status-badge status-completed">Completed</span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>

    <script>
        $(document).ready(function() {
            // Logout SweetAlert
            $("#logout").click(function() {
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>"
                });
            });
        });
    </script>
</body>

</html>