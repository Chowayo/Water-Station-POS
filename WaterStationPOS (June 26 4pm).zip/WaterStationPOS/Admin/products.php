<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Eco Hydrate Hub</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>

    <style>
        body {
            background-color: #0A192F;
            color: #CCD6F6;
        }

        .app {
            background-color: #0A192F;
            overflow: hidden;
        }

        .left-menu {
            width: 250px;
            background-color: #020C1B;
            border-right: 2px solid #112240;
        }

        .logo {
            margin: 20px auto;
        }

        .menu-link {
            color: #8892B0;
            font-weight: 700;
            text-align: center;
            margin-bottom: 15px;
            font-size: 15px;
            text-decoration: none;
            display: block;
            transition: 0.3s;
        }

        .menu-link:hover,
        .menu-link.active {
            color: #64FFDA;
        }

        .content {
            background-color: #0A192F;
        }

        .top-text h1 {
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0px;
            color: #FFFFFF;
        }

        .green-text {
            color: #00E676;
        }

        .cyan-text {
            color: #64FFDA;
        }

        .top-text h6 {
            font-weight: 600;
            font-size: 14px;
            margin-top: 5px;
            color: #8892B0;
        }

        .section-header {
            font-size: 20px;
            font-weight: 700;
            color: #CCD6F6;
            border-bottom: 2px solid #233554;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        .manage-box {
            background-color: #112240;
            border-radius: 15px;
            padding: 20px;
        }

        .btn-add {
            background-color: #00E676;
            color: #0A192F;
            font-weight: bold;
            border: none;
        }

        .btn-add:hover {
            background-color: #00C853;
            color: #0A192F;
        }

        .btn-edit {
            background-color: #64FFDA;
            color: #0A192F;
            font-weight: bold;
            border: none;
        }

        .btn-edit:hover {
            background-color: #1DE9B6;
            color: #0A192F;
        }

        .btn-remove {
            background-color: #FF5252;
            color: #FFFFFF;
            font-weight: bold;
            border: none;
        }

        .btn-remove:hover {
            background-color: #D50000;
            color: #FFFFFF;
        }

        .table-dark {
            background-color: transparent;
            color: #CCD6F6;
        }

        .table-dark th {
            border-bottom: 2px solid #233554;
            color: #8892B0;
        }

        .table-dark td {
            border-bottom: 1px solid #233554;
            vertical-align: middle;
        }

        /* Add products pop up form */
        .modal-content {
            background-color: #112240;
            color: #CCD6F6;
            border: 1px solid #64FFDA;
            border-radius: 15px;
        }

        .modal-header {
            border-bottom: 1px solid #233554;
        }

        .modal-footer {
            border-top: 1px solid #233554;
        }

        .modal-title {
            color: #FFFFFF;
            font-weight: 700;
        }

        .form-control,
        .form-select {
            background-color: #0A192F;
            border: 1px solid #233554;
            color: #CCD6F6;
        }

        .form-control:focus,
        .form-select:focus {
            background-color: #0A192F;
            border-color: #64FFDA;
            color: #FFFFFF;
            box-shadow: 0 0 0 0.25rem rgba(100, 255, 218, 0.25);
        }

        .form-label {
            font-weight: 600;
            color: #8892B0;
        }

        .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <nav class="nav flex-column mt-4 px-2">
                <p class="text-center fw-bold text-muted small mb-4">ADMINISTRATOR</p>

                <?php
                $current_page = basename($_SERVER['PHP_SELF']);
                ?>

                <a class="menu-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">
                    Dashboard
                </a>

                <a class="menu-link <?php echo ($current_page == 'employees.php') ? 'active' : ''; ?>" href="employees.php">
                    Employees
                </a>

                <a class="menu-link <?php echo ($current_page == 'products.php') ? 'active' : ''; ?>" href="products.php">
                    Products
                </a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="#" id="logout">Logout</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">

            <section class="p-4 flex-grow-1">

                <header class="top-text mb-5 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Products & Inventory Management</h6>
                    </div>
                </header>

                <div class="row">
                    <div class="col-12">
                        <div class="section-header">All Products</div>
                        <div class="manage-box shadow-sm">
                            <div class="d-flex justify-content-between mb-3">
                                <h5 class="mb-0 pt-1">Product Directory</h5>
                                <button class="btn btn-add px-4 rounded-pill">+ Add New Product</button>
                            </div>
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>ID</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <img src="../Images/18.9L.png" alt="Round Gallon" style="width: 50px; height: 50px; object-fit: contain; background: #ffffff; border-radius: 8px; padding: 2px;">
                                        </td>
                                        <td>1</td>
                                        <td class="fw-bold">Round Gallon Refill</td>
                                        <td>Refill</td>
                                        <td class="green-text fw-bold">₱ 30.00</td>
                                        <td>
                                            <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">Edit</button>
                                            <button class="btn btn-remove btn-sm rounded-pill px-3">Remove</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img src="../Images/10L.png" alt="Slim Container" style="width: 50px; height: 50px; object-fit: contain; background: #ffffff; border-radius: 8px; padding: 2px;">
                                        </td>
                                        <td>2</td>
                                        <td class="fw-bold">New Slim Container</td>
                                        <td>New Container</td>
                                        <td class="green-text fw-bold">₱ 150.00</td>
                                        <td>
                                            <button class="btn btn-edit btn-sm rounded-pill px-3 me-1">Edit</button>
                                            <button class="btn btn-remove btn-sm rounded-pill px-3">Remove</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content shadow-lg">

                            <div class="modal-header">
                                <h5 class="modal-title">Add New Product</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body p-4">
                                <form id="addProductForm" enctype="multipart/form-data">

                                    <div class="mb-3">
                                        <label class="form-label">Product Name</label>
                                        <input type="text" class="form-control" name="name" required placeholder="e.g. 10L Gallon">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Price</label>
                                        <input type="number" class="form-control" name="price" required placeholder="e.g. 100">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Category</label>
                                        <select class="form-select" name="category" required>
                                            <option value="" disabled selected>Select a category...</option>
                                            <option value="Refill">Refill</option>
                                            <option value="New Container">New Container</option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Product Image</label>
                                        <input type="file" class="form-control" name="image" id="productImage" accept="image/*" required>
                                    </div>

                                    <div class="mb-2 text-center d-none" id="imagePreviewContainer">
                                        <img id="imagePreview" src="" alt="Preview" style="max-width: 100px; height: 100px; object-fit: cover; border-radius: 10px; border: 2px solid #64FFDA;">
                                    </div>

                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-outline-light rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-add rounded-pill px-4" id="addProductBtn">Add Product</button>
                            </div>

                        </div>
                    </div>
                </div>

            </section>
        </main>
    </div>
    <script>
        $(document).ready(function() {

            $("#logout").click(function() {
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>"
                });
            });

            $(".btn-remove").click(function() {
                Swal.fire({
                    title: 'Remove Product?',
                    text: "They will be deleted in the database",
                    icon: 'warning',
                    background: '#112240',
                    color: '#CCD6F6',
                    showCancelButton: true,
                    confirmButtonColor: '#FF5252',
                    cancelButtonColor: '#8892B0',
                    confirmButtonText: 'Yes, remove them!'
                });
            });

            $(".btn-add").click(function() {
                $('#addProductModal').modal('show');
            });

            $("#addProductBtn").click(function() {

                Swal.fire({
                    icon: 'success',
                    title: 'Product Added!',
                    text: 'The new product has been registered.',
                    background: '#112240',
                    color: '#CCD6F6',
                    confirmButtonColor: '#00E676'
                });

                // Clear field
                $('#addProductForm')[0].reset();
            });
        });

        // Image Preview Logic for Add Product Modal
        $('#productImage').change(function(e) {
            let reader = new FileReader();

            // When the file is read, put it in the image tag and show the container
            reader.onload = function(e) {
                $('#imagePreview').attr('src', e.target.result);
                $('#imagePreviewContainer').removeClass('d-none');
            }

            // Read the file the user selected
            if (this.files[0]) {
                reader.readAsDataURL(this.files[0]);
            }
        });

        // Reset the image preview when the modal is closed or saved
        $('#addProductBtn').click(function() {
            // Your save logic here...

            // Reset form and hide image preview
            $('#addProductForm')[0].reset();
            $('#imagePreviewContainer').addClass('d-none');
            $('#imagePreview').attr('src', '');
        });
    </script>
</body>

</html>