<?php
require 'dbConn.php';
session_destroy();
header('location: ../index.php');
