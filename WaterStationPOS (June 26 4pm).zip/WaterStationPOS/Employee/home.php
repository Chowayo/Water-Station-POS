<?php

include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eco Hydrate Hub POS</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f0f8ff;
        }

        .app {
            background-color: #f0f8ff;
        }

        .left-menu {
            width: 220px;
            background-color: #ffffff;
            border-right: 2px solid #dce4ec;
        }

        .logo {
            width: 130px;
            height: 130px;
            border: 3px solid #007BFF;
            border-radius: 50%;
            margin: 20px auto;
            background-color: #e6f2ff;
        }

        .menu-link {
            color: #333333;
            font-weight: 700;
            text-align: center;
            margin-bottom: 15px;
            font-size: 15px;
            text-decoration: none;
            display: block;
        }

        .menu-link:hover {
            color: #007BFF;
        }

        .content {
            background-color: #f0f8ff;
        }

        .top-text h1 {
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 0px;
            color: #003366;
        }

        .green-text {
            color: #28a745;
        }

        .top-text h6 {
            font-weight: 600;
            font-size: 14px;
            margin-top: 5px;
            color: #555555;
        }

        .item-card {
            background-color: #ffffff;
            border: 2px solid #b8daff;
            /* Light Blue Border */
            border-radius: 20px;
            height: 100%;
            width: 100%;
            font-weight: 700;
            color: #003366;
            transition: all 0.2s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 15px 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.03);
        }

        .item-card:hover {
            border-color: #28a745;
            transform: translateY(-3px);
            box-shadow: 0 8px 15px rgba(40, 167, 69, 0.1);
        }

        .price {
            font-size: 15px;
            font-weight: 700;
            color: #28a745;
            margin-bottom: 10px;
        }

        .qty-box {
            display: flex;
            justify-content: center;
            align-items: center;
            column-gap: 5px;
            row-gap: 5px;
            margin-bottom: 8px;
        }

        .btn-qty {
            background-color: #e6f2ff;
            border: none;
            border-radius: 5px;
            width: 28px;
            height: 28px;
            font-weight: bold;
            color: #007BFF;
            transition: background-color 0.2s;
        }

        .btn-qty :hover {
            background-color: #b8daff;
        }

        .input-num {
            width: 40px;
            height: 28px;
            text-align: center;
            border: 1px solid #b8daff;
            border-radius: 5px;
            font-weight: bold;
            color: #003366;
        }

        .input-num::-webkit-outer-spin-button,
        .input-num::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .btn-add {
            background-color: #007BFF;
            color: #ffffff;
            border: none;
            border-radius: 10px;
            width: 100%;
            font-weight: bold;
            padding: 5px 0;
            font-size: 14px;
            transition: background-color 0.2s;
        }

        .btn-add:hover {
            background-color: #28a745;
            color: #ffffff;
        }

        .right-panel {
            width: 280px;
            background-color: #e3f2fd;
            border: 2px solid #bbdefb;
            border-radius: 30px;
            margin: 20px;
            padding: 20px;
            box-shadow: -2px 0px 10px rgba(0, 0, 0, 0.02);
        }

        .btn-order {
            background-color: #ffffff;
            color: #007BFF;
            border: 2px solid #007BFF;
            border-radius: 25px;
            font-weight: 800;
            width: 100%;
            padding: 8px 0;
            margin-bottom: 15px;
        }

        .btn-pay {
            background-color: #28a745;
            color: #ffffff;
            border: none;
            border-radius: 25px;
            font-weight: 700;
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            transition: background-color 0.2s;
        }

        .btn-pay:hover {
            background-color: #218838;
        }

        .product-img {
            width: 200px;
            height: 200px;
            object-fit: contain;

        }

        .btn-clear {
            background-color: #ff4d4d;
            color: #ffffff;
            border: none;
            border-radius: 25px;
            font-weight: 700;
            padding: 8px 15px;
            font-size: 12px;
        }

        .cart-item {
            background-color: #ffffff;
            border: 1px solid #b8daff;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .cart-name {
            font-weight: 700;
            color: #003366;
            font-size: 14px;
        }

        .cart-calc {
            color: #555555;
            font-size: 12px;
            font-weight: 600;
        }

        .item-actions {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cart-line-total {
            font-weight: 800;
            color: #28a745;
            font-size: 14px;
        }

        .btn-remove {
            background-color: #ffe6e6;
            color: #ff4d4d;
            border: none;
            border-radius: 5px;
            width: 25px;
            height: 25px;
            font-weight: bold;
            font-size: 12px;
        }

        .totals-box {
            background-color: #ffffff;
            border: 2px solid #b8daff;
            border-radius: 15px;
            padding: 15px;
            margin-top: 10px;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            font-weight: 700;
            color: #003366;
            font-size: 14px;
        }

        .grand-total {
            font-size: 18px;
            font-weight: 800;
            color: #28a745;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo"><img src="../Images/logo.png" alt="Logo" style="width:100%;height:100%;object-fit:contain;border-radius:50%;"></div>

            <nav class="nav flex-column mt-4 px-2">
                <p class="text-center fw-bold text-muted small">EMPLOYEE DETAILS</p>
                <a class="menu-link" href="#">ID: <?php echo isset($result) ? $result->id : ''; ?></a>
                <a class="menu-link" href="#">Email: <?php echo isset($result) ? $result->email : ''; ?></a>
                <a class="menu-link" href="#">Name: <?php echo isset($result) ? $result->first_name . " " . $result->last_name : ''; ?></a>

                <hr class="mx-3 border-secondary">

                <a class="menu-link" href="#">POS</a>
                <a class="menu-link" href="#">Confirmation</a>
                <a class="menu-link" href="#">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="#" id="logout">Logout</a>

            <script>
                $("#logout").click(function() {
                    Swal.fire({
                        showConfirmButton: false,
                        icon: "question",
                        title: "Do you want to Log out?",
                        html: " <a href='logout.php' class='btn btn-outline-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-success'>Cancel</button>"
                    });
                });
            </script>
        </aside>

        <main class="flex-grow-1 d-flex content">

            <section class="flex-grow-1 d-flex flex-column p-4">

                <header class="top-text text-center mb-4">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Mineral Water Refill & POS management System</h6>
                </header>

                <div class="row g-4 mt-1 flex-grow-1 align-content-start">

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/20L.png" alt="20L Slimline" class="product-img">
                                </div>
                                <div>20L Slimline Gallon with Faucet</div>
                                <div class="price">₱35.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty
                                    ">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty
                                    ">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/10L.png" alt="10L Slim Gallon" class="product-img">
                                </div>
                                <div>10L Slim Gallon with Faucet</div>
                                <div class="price">₱15.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty
                                    ">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty
                                    ">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div class="product-image">
                                    <img src="../Images/18.9L.png" alt="18.9L Round Gallon" class="product-img">
                                </div>
                                <div>18.9L Round Gallon</div>
                                <div class="price">₱35.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty
                                    ">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty
                                    ">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱150.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty
                                    ">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty
                                    ">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="item-card">
                            <div class="info">
                                <div>Gallon</div>
                                <div class="price">₱15.00</div>
                            </div>
                            <div class="actions">
                                <div class="qty-box">
                                    <button class="btn-qty
                                    ">-</button>
                                    <input type="number" class="input-num" value="1" min="1">
                                    <button class="btn-qty
                                    ">+</button>
                                </div>
                                <button class="btn-add">Add</button>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            <aside class="right-panel d-flex flex-column shadow-sm">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <button class="btn-order flex-grow-1 m-0">ORDERS</button>
                    <!-- clear button -->
                    <button class="btn-clear ms-2">Clear</button>
                </div>

                <div class="flex-grow-1 overflow-auto cart-list pe-2">

                    <!-- Example -->
                    <div class="cart-item">
                        <div class="item-details">
                            <div class="cart-name">Round Gallon Refill</div>
                            <div class="cart-calc">2 x ₱30.00</div>
                        </div>
                        <div class="item-actions">
                            <div class="cart-line-total">₱60.00</div>
                            <button class="btn-remove">X</button>
                        </div>
                    </div>

                </div>

                <!-- Total -->
                <div class="totals-box">
                    <div class="total-row">
                        <span>Subtotal</span>
                        <span>₱60.00</span>
                    </div>
                    <hr class="my-2 border-secondary">
                    <div class="total-row grand-total">
                        <span>Total</span>
                        <span>₱60.00</span>
                    </div>
                </div>

                <!-- checkout -->
                <button class="btn-pay mt-3 shadow-sm">Checkout</button>

            </aside>

        </main>
    </div>

    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>


    <?php
    include 'footer.php';
    ?>