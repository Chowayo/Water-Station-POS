<?php

include 'header.php';


$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

<style>
    .section-divider {
        display: flex;
        align-items: center;
        gap: 14px;
        width: 100%;
        margin: 6px 0 2px;
    }

    .section-divider .label {
        font-weight: 700;
        font-size: 13px;
        letter-spacing: 0.5px;
        color: #0d2b4e;
        white-space: nowrap;
        text-transform: uppercase;
    }

    .section-divider .line {
        flex: 1;
        height: 2px;
        background-color: #0d2b4e;
        border-radius: 1px;
    }
</style>

</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include 'navigation.php';
    ?>

    <!-- MAIN POS CONTENT -->
    <main class="flex-grow-1 d-flex content">
        <section class="flex-grow-1 d-flex flex-column p-4">

            <header class="top-text mb-4 d-flex justify-content-center align-items-center gap-3">
                <img src="../Images/logo.png" alt="Logo" class="header-logo">
                <div class="text-center">
                    <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                    <h6>Mineral Water Refill & POS management System</h6>
                </div>
            </header>

            <div class="row g-4 mt-1 flex-grow-1 align-content-start product-container">

                <div class="col-12">
                    <div class="section-divider">
                        <span class="label">Refill</span>
                        <span class="line"></span>
                    </div>
                </div>

                <!-- Product 1 -->

                <?php
                $sql = "SELECT * FROM product";
                $query = $conn->query($sql);
                $counter = 0;
                while ($set = $query->fetch_object()) {
                    $counter += 1;
                    echo '<div class="col-6 col-md-4">
                                    <div class="item-card">
                                        <div class="info">
                                            <div class="product-image">
                                                <img src="../Images/' . $set->image . '" class="product-img">
                                            </div>
                                            <div>' . $set->product_name . ' ' . $set->category . '</div>
                                            <div class="price">₱' . $set->price . '</div>
                                        </div>
                                        <div class="actions">
                                            <button class="btn-add" id="' . $set->id . '-submit">Add</button>
                                        </div>
                                    </div>
                                </div>';
                    echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            //clear button
                                            total = 0; //Total amount
                                            $("#clear").click(function() {
                                                if($("#{$set->id}-submit").css("background-color")==="rgb(40, 167, 69)"){
                                                    $("#{$set->id}-submit").css("background-color", "#007BFF");
                                                }
                                                if($("#{$set->id}-submit").prop("disabled")===true){
                                                    $("#{$set->id}-submit").attr("disabled", false);
                                                }
                                                if($("#{$set->id}-submit").text()==="Added"){
                                                    $("#{$set->id}-submit").text("Add");
                                                }
                                                //Wipes all of the side div inside of order_queue
                                                $("#order_queue").empty();
                                                $("#bill-list").empty();
                                                total = 0; //Total resets
                                                $("#total-amount").text("₱"+total+".00");
                                                $("#grand-total").text("₱"+total+".00");
                                                $("#checkout").attr("hidden", true);   


                                            });

                                            $("#{$set->id}-submit").click(function() {
                                                $("#checkout").attr("hidden", false);
                                                $("#{$set->id}-submit").css("background-color", "#28a745");
                                                $("#{$set->id}-submit").attr("disabled", true);
                                                $("#{$set->id}-submit").text("Added");

                                                
                                                //Receipt editor
                                                $("#bill-list").prepend(`
                                                    <div class="receipt-grid" id="{$set->id}-bill">
                                                        <p id="{$set->id}-quantity"></p>
                                                        <p id="{$set->id}-product_name"></p>
                                                        <p id="{$set->id}-price" class="price"></p>
                                                    </div>
                                                `);

                                                $("#order_queue").prepend(`
                                                    <div class="overflow-auto cart-list pe-2" id="{$set->id}-whole">
                                                        <div class="cart-item">
                                                            <div class="item-details">

                                                                
                                                                <input type="text" name="product_name-{$counter}" value="{$set->product_name}" hidden>
                                                                <input type="text" name="product_category-{$counter}" value="{$set->category}" hidden>
                                                                <input type="number" name="product_quantity-{$counter}" value="1" id="{$set->id}-totalQuantity" hidden>
                                                                <input type="number" name="total_price-{$counter}" value="{$set->price}" id="{$set->id}-totalPrice" hidden>

                                                                <div class="cart-name">{$set->product_name} {$set->category}</div>
                                                                <div class="cart-calc" id="{$set->id}-calc">1 x ₱{$set->price}</div>
                                                                <div class="qty-box">
                                                                    <button type="button" class="btn-qty" id="{$set->id}-minus">-</button>
                                                                        <input type="number" class="input-num" min="1" max="20" id="{$set->id}-value" value="1" disabled>
                                                                    <button type="button" class="btn-qty" id="{$set->id}-add">+</button>
                                                                </div>
                                                            </div>
                                                            <div class="item-actions">
                                                                <div class="cart-line-total" id="{$set->id}-total">₱{$set->price}</div>
                                                                <button class="btn-remove" id="{$set->id}-remove">X</button>
                                                            </div>
                                                            
                                                        </div>
                                                    
                                                    
                                                    <script>
                                                        
                                                        total += {$set->price};
                                                        $("#total-amount").text("₱"+total+".00");
                                                        $("#grand-total").text("₱"+total+".00");
                                                        

                                                        $("#{$set->id}-quantity").text(1+"x");
                                                        $("#{$set->id}-product_name").text("{$set->product_name}");
                                                        $("#{$set->id}-price").text("₱{$set->price}");                                                        

                                                        $("#{$set->id}-add").click(function() {
                                                            if( $("#{$set->id}-value").val()<=19){
                                                                $("#{$set->id}-value").val(function(index, value) {
                                                                    return (parseInt(value) || 0) + 1;
                                                                });
                                                            }else{
                                                                $("#{$set->id}-value").val(20);
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                            total += {$set->price};
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                            $("#{$set->id}-totalQuantity").val(quantity);

                                                            
                                                            

                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });

                                                        $("#{$set->id}-minus").click(function() {
                                                            if( $("#{$set->id}-value").val()>1){
                                                                $("#{$set->id}-value").val($("#{$set->id}-value").val()-1);
                                                            }else{
                                                                $("#{$set->id}-value").val(1);
                                                            }
                                                            quantity = $("#{$set->id}-value").val();
                                                            $("#{$set->id}-calc").text(quantity+" x ₱{$set->price}");
                                                            $("#{$set->id}-total").text("₱"+(quantity*{$set->price})+".00");
                                                            total -= {$set->price};
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-totalPrice").val((quantity*{$set->price})+".00");
                                                            $("#{$set->id}-totalQuantity").val(quantity);
                                                            

                                                            //Receipt
                                                            $("#{$set->id}-quantity").text(quantity+"x");
                                                            $("#{$set->id}-product_name").text("{$set->product_name}");
                                                            $("#{$set->id}-price").text("₱"+({$set->price}*quantity)+".00");
                                                        });


                                                        $("#{$set->id}-remove").click(function() {
                                                            $("#{$set->id}-submit").css("background-color", "#007BFF");
                                                            $("#{$set->id}-submit").attr("disabled", false);
                                                            $("#{$set->id}-submit").text("Add");
                                                            total -= ($("#{$set->id}-value").val()*{$set->price});
                                                            $("#total-amount").text("₱"+total+".00");
                                                            $("#grand-total").text("₱"+total+".00");
                                                            $("#{$set->id}-whole").remove();
                                                            $("#{$set->id}-sub").remove();
                                                            $("#{$set->id}-bill").remove();

                                                            if ($(".order_queue").children().length === 0) {
                                                                $("#checkout").attr("hidden", true);
                                                            }
                                                        });
                                                    <\/script>
                                                    </div>
                                                `)
                                            });
                                        })
                                        
                                    </script>
                                    HTML;
                }

                ?>

                <div class="col-12">
                    <div class="section-divider">
                        <span class="label">New Container</span>
                        <span class="line"></span>
                    </div>
                </div>
            </div>
        </section>

        <!-- RIGHT CART PANEL -->
        <aside class="right-panel d-flex flex-column shadow-sm">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <button class="btn-order flex-grow-1 m-0">Orders</button>
                <button class="btn-clear ms-2" id="clear">Clear</button>
            </div>
            <!-- SAVE POINT-->
            <!-- Dito binabato lahat ng additions na product -->
            <div class="order_queue flex-grow-1 overflow-auto">
                <form id="order_queue" method="POST">
                    <div class="modal fade" id="checkoutCustomerModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
                        <div class="modal-dialog modal-dialog-centered modal-xl">
                            <div class="modal-content custom-modal-content">

                                <div class="modal-header border-0 pb-0">
                                    <h5 class="modal-title fw-bold text-navy">Checkout Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>

                                <div class="modal-body p-4">
                                    <div class="row g-4">

                                        <!-- Search & Table -->
                                        <div class="col-md-6 d-flex flex-column gap-3">

                                            <div class="input-group mb-3 custom-search-group" id="search_div" hidden>
                                                <input type="text" class="form-control custom-search-input" placeholder="Search Customer..." id="searcher">
                                            </div>

                                            <div class="customer-table-area flex-grow-1 border rounded p-3 bg-white" id="table_div" hidden>
                                                <div class="table-responsive">
                                                    <script>
                                                        $(document).ready(function() {
                                                            var table = $('#customer_list').DataTable({
                                                                paging: false, // Enable pagination
                                                                searching: true, // Enable search functionality
                                                                dom: 't' //Removes the built in search from datatables
                                                            });

                                                            $('#searcher').on('keyup change clear', function() {
                                                                table.search(this.value).draw(); //Sets the input box as the new search bar
                                                            });

                                                            $(".btn-order").click(function() {
                                                                location.assign('confirmation.php');
                                                            });

                                                            //Hides elements based on order type
                                                            $('#receive').change(function() {
                                                                var leftColumn = $("#search_div").closest('.col-md-6');
                                                                var rightColumn = $("#customer_name").closest('div[class*="col-"]');

                                                                if ($('#receive').val() == "Pickup" || $('#receive').val() == null) {
                                                                    $("#search_div").attr("hidden", true);
                                                                    $("#table_div").attr("hidden", true);
                                                                    $("#customer_contact, #customer_address").prop("hidden", true)
                                                                    $("#customer_contact, #customer_address").prop("required", false);
                                                                    $("#savingInfo").attr("hidden", true);

                                                                    leftColumn.hide();
                                                                    rightColumn.removeClass('col-md-6').addClass('col-md-8 mx-auto');
                                                                } else {
                                                                    $("#search_div").attr("hidden", false);
                                                                    $("#table_div").attr("hidden", false);
                                                                    $("#customer_contact, #customer_address").prop("hidden", false)
                                                                    $("#customer_contact, #customer_address").prop("required", true);
                                                                    $("#savingInfo").attr("hidden", false);

                                                                    leftColumn.show();
                                                                    rightColumn.removeClass('col-md-8 mx-auto').addClass('col-md-6');
                                                                }
                                                            });

                                                            $('#receive').trigger('change');
                                                        });
                                                    </script>
                                                    <table class="table table-sm table-borderless text-center align-middle mb-0 customer-table" id="customer_list">
                                                        <thead class="text-navy border-bottom" style="font-size: 0.9rem;">
                                                            <tr>
                                                                <th>Full Name</th>
                                                                <th>Contact</th>
                                                                <th>Address</th>
                                                                <th>action</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-muted" style="font-size: 0.85rem;">
                                                            <?php
                                                            $sql = "SELECT * FROM customers";
                                                            $query = $conn->query($sql);
                                                            while ($set = $query->fetch_object()) {
                                                                echo <<<HTML
                                                                            <tr>
                                                                                <td id="{$set->id}-name">$set->full_name</td>
                                                                                <td id="{$set->id}-contact">$set->contact</td>
                                                                                <td class="truncate-text" id="{$set->id}-address">$set->address</td>
                                                                                <td><button id="{$set->id}-useInfo" class="btn btn-dark" type="button">Use</button></td>
                                                                            </tr>
                                                                            <script>
                                                                                $(document).ready(function() {
                                                                                    $("#{$set->id}-useInfo").click(function() {
                                                                                        $("#customer_name").val("{$set->full_name}");
                                                                                        $("#customer_contact").val("{$set->contact}");
                                                                                        $("#customer_address").val("{$set->address}");
                                                                                    });
                                                                                });
                                                                            </script>
                                                                        HTML;
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Customer Inputs -->
                                        <div class="col-md-6 d-flex flex-column gap-3 justify-content-center">
                                            <input type="text" class="form-control custom-input text-center" name="customer_name" id="customer_name" placeholder="Customer Full Name" required>
                                            <input type="text" class="form-control custom-input text-center" name="customer_contact" id="customer_contact" placeholder="Contact Number" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}" required>
                                            <input type="text" class="form-control custom-input text-center" name="customer_address" id="customer_address" placeholder="Address" required>

                                            <label class="form-label">Order Type</label>
                                            <select class="form-select custom-input" name="order_type" id="receive" required>
                                                <option value="Pickup">Pick Up</option>
                                                <option value="Delivery">Delivery</option>
                                            </select>

                                            <label class="form-label">Payment Method</label>
                                            <select class="form-select custom-input" name="payment_method" required>
                                                <option value="Cash">Cash</option>
                                                <option value="Gcash">GCash</option>
                                            </select>

                                            <label id="savingInfo">Save information to customer list: <input class="ml-3" type="checkbox" name="save"></label>


                                            <div class="d-flex justify-content-center gap-3 mt-3">
                                                <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>

                                                <!--<button type="submit" name="checkout" class="btn btn-primary rounded-pill px-5 fw-bold" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#receiptModal">Confirm Checkout</button>-->
                                                <button type="submit" name="checkout" id="confirmCheckoutBtn" class="btn btn-primary rounded-pill px-5 fw-bold">Confirm Checkout</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                        //Remove Account
                        if (isset($_POST['checkout'])) {
                            $customer_name = $_POST['customer_name'];
                            $order_type = $_POST['order_type']; //Order Type
                            $payment_method = $_POST['payment_method'];

                            //EXPERIMENTAL


                            if ($customer_name && $order_type && $payment_method) {
                                if ($order_type === "Delivery") {
                                    //If delivery is chosen
                                    $status = "Not received";
                                    $customer_contact = $_POST['customer_contact'];
                                    $customer_address = $_POST['customer_address'];
                                } else {
                                    //if pickup is chosen
                                    $status = "Received";
                                    $customer_contact = "NO INFO";
                                    $customer_address = "NO INFO";
                                }
                                $grand_total = 0.00;

                                // NOTE: eto yung bagong lister ng orders na gagawin
                                $order_content = "";


                                for ($i = 1; $i <= $counter; $i++) {
                                    if (isset($_POST['product_name-' . $i])) {

                                        //Variables to be submitted
                                        $product_name = $_POST['product_name-' . $i];
                                        $product_categoty = $_POST['product_category-' . $i];
                                        $product_quantity = $_POST['product_quantity-' . $i];

                                        //Total Price
                                        $total_price = $_POST['total_price-' . $i];
                                        $grand_total += $total_price;

                                        //Order content will replace order name para maging 1 row lang per order
                                        $order_content .= "" . $product_quantity . "x " . $product_name . "(" . $product_categoty . ")₱" . $total_price . ",";

                                        //Used for receipt printing only
                                        $receipt = "" . $product_quantity . "x " . $product_name . "(" . $product_categoty . ")";

                                        //Date and time Information
                                        date_default_timezone_set('Asia/Manila');
                                        $time = date("h:iA");
                                        $date = date('m/d/Y');

                                        //Loads the receipt with information
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        $("#bill-list").prepend(`
                                                            <div class="receipt-grid mb-2" style="display: grid; grid-template-columns: 4fr auto; align-items: start; gap: 15px; max-width: 450px; width: 100%;" id="{$counter}-bill" >
                                                                <p id="{$counter}-order_content"></p>
                                                                <p id="{$counter}-price" class="price"></p>
                                                            </div>
                                                        `);
                                                        $("#{$counter}-order_content").text("{$receipt}");
                                                        $("#{$counter}-price").text("₱{$total_price}");
                                                    });
                                                </script>
                                            HTML;
                                    }
                                }

                                //Removes the last , for propper loading in receipt
                                $order_content = substr_replace($order_content, '', -1);

                                //Upload Data
                                $sql = "INSERT INTO `orders` (`customer_name`, `customer_contact`, `customer_address`, `order_content`, `total_price`, `order_type`, `payment_method`, `status`, `time`, `date`, `cashier`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("ssssdssssss", $customer_name, $customer_contact, $customer_address, $order_content, $grand_total, $order_type, $payment_method, $status, $time, $date, $result->first_name);
                                if ($stmt->execute()) {
                                }

                                //Receipt loader after process
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                //Shows Receipt after of loop
                                                $('#receiptModal').modal('show');    
                                            });
                                        </script>
                                        HTML;
                            }
                            if (isset($_POST['save'])) {
                                //Saving the customers information on the database if it does not exist
                                $sql = "SELECT * FROM customers";
                                $query = $conn->query($sql);
                                $customer_checked = true;
                                while ($set = $query->fetch_object()) {
                                    if ($set->full_name == $customer_name && $set->contact == $customer_contact) {
                                        $customer_checked = false;
                                        break;
                                    }
                                }
                                if ($customer_checked) {
                                    $sql = "INSERT INTO `customers` (`full_name`, `contact`, `address`) VALUES (?, ?, ?)";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("sss", $customer_name, $customer_contact, $customer_address);
                                    if ($stmt->execute()) {
                                    }
                                }
                            }
                        }
                    }
                    ?>

                    <!-- DITO NATAPOS YUNG FORM-->
                </form>
            </div>

            <div class="totals-box mt-5">
                <hr class="my-2 border-secondary">
                <div class="total-row grand-total">
                    <span>Total</span>
                    <span id="total-amount">₱0.00</span>
                </div>
            </div>

            <button type="button" class="btn-pay mt-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#checkoutCustomerModal" id="checkout" hidden>Checkout</button>
        </aside>
    </main>
    </div>

    <!-- Receipt -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong>
                                    <?php
                                    $sql = "SELECT MAX(id) AS id FROM orders";
                                    $query = $conn->query($sql);
                                    $highest = $query->fetch_object();

                                    echo ("#" . $highest->id);
                                    ?></strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>
                                <?php
                                date_default_timezone_set('Asia/Manila');
                                echo "Time:" . date("h:iA"); ?>
                            </p>
                            <p>
                                <?php
                                echo "Cashier:" . $result->first_name;
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Name: <?php echo $customer_name; ?></p>
                        <p>Phone: <?php echo $customer_contact; ?></p>
                        <p class="receipt-address" style="overflow-wrap: break-word; max-width: 320px;">Address: <?php echo $customer_address; ?></p>
                        <p>Payment Method: <?php echo $payment_method; ?> </p>
                        <p>Order Type: <?php echo $order_type; ?> </p>

                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>
                        <!--Dito naka lagay yung mga custom part ng receipt-->
                        <div id="bill-list">

                        </div>
                        <div class="receipt-divider"></div>
                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱<?php echo $grand_total; ?>.00</p>
                        </div>


                    </div>

                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()">Print Receipt</button>
                </div>

            </div>
        </div>
    </div>


    <!-- CUSTOMER CHECKOUT -->
    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    title: "Do you want to Log out?",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    html: "<a href='../logout.php' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>