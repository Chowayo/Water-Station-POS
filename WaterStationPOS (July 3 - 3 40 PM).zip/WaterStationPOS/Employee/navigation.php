<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">
        <div class="profile-avatar-wrap text-center">
            <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="#profileModal" aria-label="Open profile">
                <img>
            </button>
        </div>

        <div class="px-3 mb-4">

            <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

        </div>

        <?php
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>

        <nav class="nav flex-column px-2">
            <hr class="mx-3 border-secondary mt-0">

            <a class="menu-link <?php echo $current_page === 'home.php' ? 'active' : ''; ?>" href="home.php">POS</a>
            <a class="menu-link <?php echo $current_page === 'confirmation.php' ? 'active' : ''; ?>" href="confirmation.php">Order Confirmation</a>
            <a class="menu-link <?php echo $current_page === 'customerInfo.php' ? 'active' : ''; ?>" href="customerInfo.php">Customer Information</a>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout ➜]</a>
    </aside>

    <?php include 'profile.php'; ?>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }
    </script>