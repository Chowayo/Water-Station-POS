<div class="modal fade" id="profileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">Employee Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!--Read-Only-->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3 profile-section-title">Personal Information</h6>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <p class="small text-muted mb-0">Employee ID</p>
                            <p class="fw-bold profile-info-text"><?php echo $result->id; ?></p>
                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small text-muted mb-0">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo $result->first_name . " " . $result->last_name; ?></p>
                        </div>
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-end gap-3">
                                <div class="flex-grow-1">
                                    <p class="small text-muted mb-0">Email Address</p>
                                    <p class="fw-bold profile-info-text mb-0"><?php echo $result->email; ?></p>
                                </div>
                                <div class="flex-shrink-0">
                                    <label for="profilePicUpload" class="btn btn-outline-success btn-sm rounded-pill px-3 d-inline-flex align-items-center gap-2 mb-0">
                                        [◉°] Upload Photo
                                    </label>
                                    <input type="file" id="profilePicUpload" name="profile_picture" accept="image/*" hidden>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="border-secondary mb-4">

                <!-- Change Password -->
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="changePasswordForm" method="POST">
                        <div class="mb-3">
                            <label for="currentPassword" class="profile-label small">Current Password</label>
                            <input type="password" class="form-control profile-input" id="currentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="newPassword" class="profile-label small">New Password</label>
                            <input type="password" class="form-control profile-input" id="newPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="confirmPassword" class="profile-label small">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="confirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end">
                            <button type="submit" name="changePass" class="btn btn-success px-4 rounded-pill fw-bold">Update Password</button>
                        </div>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        //Remove Account
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];

                            //Checking if current password matched
                            if (password_verify($current_pass, $result->password)) {
                                //Password must be atleast 8 characters
                                if (strlen($new_pass) >= 8) {
                                    //Confirm pass and new pass mathes
                                    if ($new_pass == $confirm_pass) {
                                        //New pass must not match current pass
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process
                                            $sql = "UPDATE `employees` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close()">Ok</a>`
                                                            })
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    })
                                                </script> 
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',  
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    });
                                                </script> 
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',  
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#profileModal" onclick="Swal.close()">Ok</a>`
                                                })
                                            });
                                        </script> 
                                    HTML;
                            }
                        }
                    }
                    ?>
                </div>
            </div>


        </div>
    </div>
</div>