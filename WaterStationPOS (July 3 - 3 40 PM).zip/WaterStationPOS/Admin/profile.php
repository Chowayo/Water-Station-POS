<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">

            <div class="modal-header pb-3">
                <h5 class="modal-title m-0">ADMIN PROFILE</h5>
                <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
                <!-- Read-Only -->
                <div class="mb-4">
                    <h6 class="fw-bold mb-3 profile-section-title">Account Details</h6>

                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <p class="small mb-0" style="color: #8892B0;">Admin ID</p>
                            <p class="fw-bold profile-info-text"><?php echo isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : '1'); ?></p>

                        </div>
                        <div class="col-12 col-md-6">
                            <p class="small mb-0" style="color: #8892B0;">Full Name</p>
                            <p class="fw-bold profile-info-text"><?php echo (isset($admin_profile) && $admin_profile->first_name) ? ($admin_profile->first_name . " " . $admin_profile->last_name) : (isset($result) ? ($result->first_name . " " . $result->last_name) : 'Admin'); ?></p>

                        </div>
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-end gap-3">
                                <div class="flex-grow-1">
                                    <p class="small mb-0" style="color: #8892B0;">Email Address</p>
                                    <p class="fw-bold profile-info-text mb-0"><?php echo isset($admin_profile) ? $admin_profile->email : (isset($result) ? $result->email : 'Admin@gmail.com'); ?></p>
                                </div>
                                <div class="flex-shrink-0">
                                    <label for="adminProfilePicUpload" class="btn btn-sm rounded-pill px-3 d-inline-flex align-items-center gap-2 mb-0" style="background-color: #64FFDA; color: #0A192F; border: none;">
                                        [◉°] Upload Photo
                                    </label>
                                    <input type="file" id="adminProfilePicUpload" name="profile_picture" accept="image/*" hidden>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr style="border-color: #233554;" class="mb-4">

                <!-- Change Password Section -->
                <div>
                    <h6 class="fw-bold mb-3 profile-section-title">Change Password</h6>

                    <form id="adminChangePasswordForm" method="POST">
                        <input type="hidden" name="admin_id" value="<?php echo isset($admin_profile) ? $admin_profile->id : (isset($result) ? $result->id : ''); ?>">


                        <div class="mb-3">
                            <label for="adminCurrentPassword" class="profile-label small">Current Password</label>
                            <input type="password" class="form-control profile-input" id="adminCurrentPassword" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="adminNewPassword" class="profile-label small">New Password</label>
                            <input type="password" class="form-control profile-input" id="adminNewPassword" name="new_password" required>
                        </div>
                        <div class="mb-4">
                            <label for="adminConfirmPassword" class="profile-label small">Confirm New Password</label>
                            <input type="password" class="form-control profile-input" id="adminConfirmPassword" name="confirm_password" required>
                        </div>

                        <div class="d-flex justify-content-end mt-4">
                            <button type="submit" name="changePass" class="btn px-4 fw-bold" style="background-color: #64FFDA; color: #0A192F; border-radius: 8px;">Save Changes</button>
                        </div>
                    </form>

                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        //Remove Account
                        if (isset($_POST['changePass'])) {
                            $current_pass = $_POST['current_password'];
                            $new_pass = $_POST['new_password'];
                            $confirm_pass = $_POST['confirm_password'];

                            //Checking if current password matched
                            if (password_verify($current_pass, $result->password)) {
                                //Password must be atleast 8 characters
                                if (strlen($new_pass) >= 8) {
                                    //Confirm pass and new pass mathes
                                    if ($new_pass == $confirm_pass) {
                                        //New pass must not match current pass
                                        if (!password_verify($new_pass, $result->password)) {
                                            $password = password_hash($new_pass, PASSWORD_DEFAULT); //Encryp process
                                            $sql = "UPDATE `admin` SET `password` = ? WHERE id = '" . $result->id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("s", $password);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                <script>
                                                                    $(document).ready(function() {
                                                                        Swal.fire({
                                                                            icon: 'success',
                                                                            title: 'Password Updated!',
                                                                            text: 'The employee information has been updated!.',
                                                                            background: '#112240',
                                                                            color: '#CCD6F6',
                                                                            confirmButtonColor: '#00E676',
                                                                            heightAuto: false
                                                                        });
                                                                    })
                                                                </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Password Re-used!',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showConfirmButton: false,
                                                                html:`
                                                                    <p>New password must not match with current password!</p>
                                                                    <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                            })
                                                        })
                                                    </script> 
                                                HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',
                                                            title: 'Password Unmatched!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must match with confirm password!</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    })
                                                </script> 
                                            HTML;
                                    }
                                } else {
                                    echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        Swal.fire({
                                                            icon: 'error',  
                                                            title: 'Invalid New Password!',
                                                            background: '#112240',
                                                            color: '#CCD6F6',
                                                            showConfirmButton: false,
                                                            html:`
                                                                <p>New password must be atleast 8 characters long</p>
                                                                <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                        })
                                                    });
                                                </script> 
                                            HTML;
                                }
                            } else {
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',  
                                                    title: 'Incorrect Password!',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    showConfirmButton: false,
                                                    html:`
                                                        <p>Re-enter current password</p>
                                                        <a class="btn btn-danger" href="#" data-bs-toggle="modal" data-bs-target="#adminProfileModal" onclick="Swal.close()">Ok</a>`
                                                })
                                            });
                                        </script> 
                                    HTML;
                            }
                        }
                    }
                    ?>


                </div>
            </div>

        </div>
    </div>
</div>