<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

    

<link rel="stylesheet" href="styles.css">


<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-4">

                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

            </div>

            <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#profileModal">Profile</a>
            <?php
            include 'profile.php';
            ?>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="home.php">POS</a>
                <a class="menu-link" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link active" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout ➜]</a>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="flex-grow-1 d-flex flex-column content overflow-auto">
            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Customer Information Directory</h6>
                    </div>
                </header>

                <div class="box mt-2">
                    <div class="d-flex justify-content-between mb-3 align-items-center">
                        <h5 class="mb-0 fw-bold">Registered Customers</h5>

                        <div class="d-flex gap-2">
                            <!-- Increased width to 300px for a better fit -->
                            <div class="input-group" style="width: 300px;">
                                <input type="text" class="form-control" placeholder="Search customer" id="searcher">
                            </div>

                            <!-- Added the 'w-auto' class here! -->
                            <button type="button" class="btn btn-add w-auto rounded-pill px-4" data-toggle="modal" id="openAddCustomerBtn" data-target="#addCustomerModal">+Add Customer</button>
                        </div>
                    </div>
                </div>
                <script>
                    $(document).ready(function() {
                        var table = $('#customer_list').DataTable({
                            paging: false, // Enable pagination
                            searching: true, // Enable search functionality
                            dom: 't' //Removes the built in search from datatables
                        });

                        $('#searcher').on('keyup change clear', function() {
                            table.search(this.value).draw(); //Sets the input box as the new search bar
                        });

                        
                    });
                </script>

                

                <table class="table table-hover text-center mb-0 align-middle" id="customer_list">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Contact Number</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        //Loading employee list
                        $sql = "SELECT * FROM customers";
                        $query = $conn->query($sql);
                        while ($set = $query->fetch_object()) {
                            echo "
                                    <tr>
                                    <td class='fw-bold' style='overflow-wrap: break-word; max-width: 320px;'>$set->full_name</td>
                                    <td>$set->contact</td>
                                    <td style='overflow-wrap: break-word; max-width: 320px;'>$set->address</td>
                                    ";

                            //Micheal: yung data-id is nag s-save ng specific points sa loop para ma-seperate sila 
                            echo "
                                <td>
                                    <button class='btn btn-edit btn-sm rounded-pill px-4' data-id='{$set->id}' data-fname='{$set->full_name}' data-contact='{$set->contact}' data-address='{$set->address}' >Edit</button>
                                    <button class='btn btn-danger btn-sm rounded-pill px-3'
                                                    data-id='{$set->id}'>
                                                Remove
                                            </button>
                                    
                                </td>
                                </tr>
                                ";

                            //Sweet Alert pop-up
                            echo <<<HTML
                                    <script>
                                        $('.btn-danger').click(function() {
                                            //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id/email sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                            id = $(this).data('id');

                                            Swal.fire({
                                                title: 'Remove Customer?',
                                                text: 'They will be deleted from the database.',
                                                icon: 'warning',
                                                background: '#112240',
                                                color: '#CCD6F6',
                                                showCancelButton: true,
                                                showConfirmButton: false,
                                                cancelButtonColor: '#8892B0',
                                                html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',

                                                heightAuto: false
                                            });
                                        });
                                    </script>
                                HTML;
                        }



                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                            //Add customer
                            if (isset($_POST['adder'])) {
                                $full_name = $_POST['full_name'];
                                $contact = $_POST['contact_number'];
                                $address = $_POST['address'];

                                if ($full_name && $contact && $address) {
                                    $contact_checked = True;
                                    if (!is_numeric($contact)) {
                                        $contact_checked = False;
                                    }

                                    //No repeat customer checker
                                    $sql = "SELECT full_name FROM customers";
                                    $query = $conn->query($sql);
                                    $customer_checked = True;
                                    while ($set = $query->fetch_object()) {
                                        if ($set->full_name == $full_name) {
                                            $customer_checked = False;
                                            break;
                                        }
                                    }


                                    if ($contact_checked) {
                                        if ($customer_checked) {
                                            $sql = "INSERT INTO `customers` (`full_name`, `contact`, `address`) VALUES (?, ?, ?)";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sss", $full_name, $contact, $address);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Customer Saved!',
                                                                                text: 'The new customer has been added.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',

                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('customerInfo.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Name!',
                                                                    text: 'Customer is present in the list',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Contact!',
                                                                    text: 'Enter a contact number',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                    }
                                }
                            }

                            if (isset($_POST['editer'])) {
                                $id = $_POST['id'];
                                $full_name = $_POST['full_name'];
                                $contact = $_POST['contact_number'];
                                $address = $_POST['address'];

                                if ($full_name && $contact && $address && $id) {
                                    $contact_checked = True;
                                    if (!is_numeric($contact)) {
                                        $contact_checked = False;
                                    }

                                    //No repeat customer checker
                                    $sql = "SELECT full_name FROM customers WHERE id !=" . $id;
                                    $query = $conn->query($sql);
                                    $customer_checked = True;
                                    while ($set = $query->fetch_object()) {
                                        if ($set->full_name == $full_name) {
                                            $customer_checked = False;
                                            break;
                                        }
                                    }

                                    if ($contact_checked) {
                                        if ($customer_checked) {
                                            $sql = "UPDATE `customers` SET `full_name` = ?, `contact` = ?, `address` = ? WHERE id = '" . $id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sss", $full_name, $contact, $address);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Customer Edited!',
                                                                                text: 'The customer information has been updated.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',

                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('customerInfo.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Name!',
                                                                    text: 'Customer is present in the list',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Contact!',
                                                                    text: 'Enter a contact number',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                    }
                                }
                            }

                            if (isset($_POST['deleter'])) {
                                $sql = "DELETE FROM customers WHERE id = " . $_POST['deleter'];
                                if ($conn->query($sql) === TRUE) {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Customer Deleted!',
                                                        text: 'The customer has been removed.',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#00E676'
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('home.php');
                                                        }});
                                                })
                                            </script> 
                                            HTML;
                                }
                            }
                        }

                        ?>


                    </tbody>
                </table>
    </div>

    </section>
    </main>
    </div>

    <!-- ADD CUSTOMER MODAL -->
    <div class="modal fade" id="addCustomerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Add New Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addCustomerForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}" placeholder="e.g. 09123456789" required>
                        </div>

                        <div class=" mb-4">
                            <label class="form-label">Complete Address</label>
                            <textarea class="form-control" name="address" rows="3" required placeholder="House No., Street, Barangay, City..."></textarea>
                        </div>

                        <div class="modal-footer d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="adder" class="btn btn-primary rounded-pill px-4">Save Customer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editCustomerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title">Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addCustomerForm" method="POST">
                        <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="full_name" required placeholder="e.g. Luz Cantos" id="edit-fname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}" placeholder="e.g. 09123456789" id="edit-contact">
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Complete Address</label>
                            <textarea class="form-control" name="address" rows="3" required placeholder="House No., Street, Barangay, City..." id="edit-address"></textarea>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" name="editer" class="btn btn-add rounded-pill px-4" id="saveCustomerBtn">Save Customer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $('.btn-edit').click(function() {
            //Used to pre-load the edit section since it's not connected to PHP
            id = $(this).data('id');
            full_name = $(this).data('fname');
            contact = $(this).data('contact');
            address = $(this).data('address');

            $("#edit-id").val(id);
            $("#edit-fname").val(full_name);
            $("#edit-contact").val(contact);
            $("#edit-address").val(address);
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });

        });

        $(".btn-edit").click(function() {
            $('#editCustomerModal').modal('show');
        })

        document.getElementById('openAddCustomerBtn').addEventListener('click', function(e) {
            e.preventDefault();
            var modalEl = document.getElementById('addCustomerModal');
            if (!modalEl) return;

            if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
                console.error('Bootstrap is not loaded. Include bootstrap.bundle.min.js');
                return;
            }

            var myModal = bootstrap.Modal.getOrCreateInstance(modalEl);
            myModal.show();
        });
    </script>
</body>

</html>