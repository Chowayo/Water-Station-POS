<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Confirmation</title>


    <link rel="stylesheet" href="styles.css">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <div class="container-fluid p-0 app d-flex flex-grow-1">

        <!-- LEFT MENU -->
        <aside class="left-menu d-flex flex-column py-4">
            <div class="logo text-center">
                <img src="../Images/logo.png" alt="Logo" style="width:130px;height:130px;object-fit:contain;border-radius:50%; border: 3px solid #64FFDA;">
            </div>

            <div class="px-3 mb-4">

                <p class="text-center fw-bold text-muted small mb-2">EMPLOYEE POS</p>

            </div>

            <a class="menu-link" href="#" data-bs-toggle="modal" data-bs-target="#profileModal">Profile</a>
            <?php
            include 'profile.php';
            ?>

            <nav class="nav flex-column px-2">
                <hr class="mx-3 border-secondary mt-0">

                <a class="menu-link" href="home.php">POS</a>
                <a class="menu-link active" href="confirmation.php">Order Confirmation</a>
                <a class="menu-link" href="customerInfo.php">Customer Information</a>
            </nav>

            <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">Logout ➜]</a>
        </aside>

        <main class="flex-grow-1 d-flex flex-column content overflow-auto">
            <section class="p-4 flex-grow-1">

                <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                    <div>
                        <h1><span class="green-text">ECO</span> HYDRATE HUB</h1>
                        <h6>Delivery & Order Confirmation</h6>
                    </div>
                </header>

                <div class="box mt-2">
                    <div class="d-flex justify-content-between mb-3 align-items-center">
                        <h5 class="mb-0 fw-bold">Active Deliveries</h5>

                        <div class="input-group w-25">
                            <input type="text" class="form-control" placeholder="Search Order" id="searcher">
                        </div>
                    </div>
                    <script>
                        $(document).ready(function() {
                            var table = $('#order_list').DataTable({
                                paging: false, // Enable pagination
                                searching: true, // Enable search functionality
                                dom: 't' //Removes the built in search from datatables
                            });

                            $('#searcher').on('keyup change clear', function() {
                                table.search(this.value).draw(); //Sets the input box as the new search bar
                            });

                            
                        });
                    </script>

                    <table class="table table-hover text-center mb-0 align-middle" id="order_list">
                        <thead>
                            <tr>
                                <th>Order Number</th>
                                <th>Customer Name</th>
                                <th>Produt Name</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Payment Method</th>
                                <th>Order Type</th>
                                <th>Time</th>
                                <th>Date</th>
                                <th>Actions</th>
                                <th>View Receipt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Row 1: Pending Order -->
                            <?php
                                //Loading employee list
                                $sql = "SELECT * FROM orders";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                        <tr>
                                            <td class="cyan-text fw-bold">' . $set->order_number . '</td>
                                            <td style="overflow-wrap: break-word; max-width: 320px;"><strong class="d-block">' . $set->customer_name . '</strong></td>
                                            <td>' . $set->product_name . '</td>
                                            <td>' . $set->quantity . '</td>
                                            <td class="green-text fw-bold fs-5">₱' . $set->total_price . '</td>
                                            <td><span class="badge bg-' . $set->payment_method . '">' . $set->payment_method . '</span></td>
                                            <td>' . $set->order_type . '</td>
                                            <td>' . $set->time . '</td>
                                            <td>' . $set->date . '</td>
                                        ';
                                    if($set->status=="Not received"){
                                        echo '
                                            <td>
                                                <button class="btn btn-closed btn-sm rounded-pill px-3 confirm-btn" data-id="'.$set->order_number.'" id="btn-confirm">Order Pending</button>
                                            </td>';
                                    }
                                    else{
                                        echo '
                                            <td>
                                                <button class="btn btn-confirm btn-sm rounded-pill px-3 done-btn">Order Received</button>
                                            </td>';
                                    }
                                    echo '
                                        <td>
                                            <form method="POST"><button type="submit" name="receipt" value="'.$set->order_number.'" class="btn btn-dark btn-sm rounded-pill px-3">Open</button></form>
                                        </td>
                                    </tr>';

                                }

                                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                        //Remove Account
                                        if (isset($_POST['confirm'])) {
                                            $sql = "UPDATE `orders` SET `status` = 'Received' WHERE order_number = " . $_POST['confirm'];
                                            if ($conn->query($sql) === TRUE) {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Order Received!',
                                                                    text: 'The order has been completed.',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#00A859',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('confirmation.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                        HTML;
                                            }
                                        }
                                        if (isset($_POST['receipt'])) {
                                            $sql = "SELECT * FROM orders WHERE order_number=".$_POST['receipt'];
                                            $query = $conn->query($sql);
                                            $total_amount = 0;
                                            while ($set = $query->fetch_object()) {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                $("#bill-list").prepend(`
                                                                    <div class="receipt-grid">
                                                                        <p>{$set->quantity}</p>
                                                                        <p>{$set->product_name}</p>
                                                                        <p class="price">{$set->total_price}</p>
                                                                    </div>
                                                                `);


                                                            });
                                                        </script>
                                                    HTML;
                                                $total_amount += $set->total_price;
                                            }

                                            $sql = "SELECT * FROM orders WHERE order_number=".$_POST['receipt'];
                                            $query = $conn->query($sql);
                                            $result = $query->fetch_object();

                                            echo <<<HTML
                                                <script>
                                                    $(document).ready(function() {
                                                        //Shows Receipt after of loop
                                                        $('#receiptModal').modal('show');    
                                                    });
                                                </script>
                                                HTML;
                                        }
                                }

                            ?>
                        </tbody>
                    </table>
                </div>

            </section>
        </main>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $(document).ready(function() {
            //Confirming Delivery
            $(".confirm-btn").click(function() {
                order_number = $(this).data('id');
                Swal.fire({
                    title: 'Confirm Delivery?',
                    text: "Has the customer received the water and settled the payment?",
                    icon: 'question',
                    background: '#FFFFFF',
                    color: '#2D3748',
                    showCancelButton: true,
                    showConfirmButton: false,
                    cancelButtonColor: '#8892B0',
                    html: '<form method="POST"><button type="submit" name="confirm" value="' + order_number + '" class="btn btn-confirm">Confirm Order</button></form>',
                    heightAuto: false
                })
            });

            $(".done-btn").click(function() {
                Swal.fire({
                    title: 'Order Complete',
                    text: "The order has been received",
                    icon: 'success',
                    background: '#FFFFFF',
                    confirmButtonColor: '#00A859',
                    color: '#2D3748',
                    showConfirmButton: true,
                    heightAuto: false
                })
            });

            //Logout
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: "<a href='" + logoutUrl + "' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>",
                    heightAuto: false
                });
            });
        });
    </script>






    <!-- Receipt -->
    <div class="modal fade" id="receiptModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-4">
                    <div class="receipt-paper" id="printableReceipt">
                        <div class="text-center">
                            <h5 class="fw-bold m-0">ECO HYDRATE HUB</h5>
                            <p>Mineral Water Refill</p>
                            <p>Tel: 0912-345-6789</p>
                        </div>

                        <div class="receipt-divider"></div>

                        <!-- Order Info -->
                        <div class="receipt-flex">
                            <p>Order: <strong><?php echo $result->order_number; ?></strong></p>
                            <p>Date: <?php echo date('m/d/Y'); ?></p>
                        </div>
                        <div class="receipt-flex">
                            <p>
                                <?php
                                date_default_timezone_set('Asia/Manila');
                                echo "Time:" . date("h:iA"); ?>
                            </p>
                            <p>
                                <?php
                                echo "Cashier:" . $result->cashier;
                                ?>
                            </p>
                        </div>

                        <div class="receipt-divider"></div>

                        <p class="text-center fw-bold">DELIVERY DETAILS</p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Name: <?php echo $result->customer_name; ?></p>
                        <p>Phone: <?php echo $result->customer_contact; ?></p>
                        <p style="overflow-wrap: break-word; max-width: 320px;">Address: <?php echo $result->customer_address; ?></p>
                        <p>Payment Method: <?php echo $result->payment_method; ?> </p>
                        <p>Order Type: <?php echo $result->order_type; ?> </p>

                        <div class="receipt-divider"></div>
                        <p class="text-center fw-bold mb-2">ORDER SUMMARY</p>
                        <div class="receipt-grid fw-bold" id="receipt-top">
                            <div>QTY</div>
                            <div>ITEM</div>
                            <div class="price">AMOUNT</div>
                        </div>
                        <!--Dito naka lagay yung mga custom part ng receipt-->
                        <div id="bill-list">

                        </div>
                        <div class="receipt-divider"></div>
                        <!-- Total -->
                        <div class="receipt-flex fw-bold mt-2" style="font-size: 16px;">
                            <p>GRAND TOTAL:</p>
                            <p>₱<?php echo $total_amount; ?></p>
                        </div>


                    </div>

                </div>

                <div class="modal-footer border-0 pt-0 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4 rounded-pill" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success px-4 rounded-pill fw-bold" onclick="window.print()">Print Receipt</button>
                </div>

            </div>
        </div>
    </div>
</body>

</html>