<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">

<?php
require(__DIR__ . '/../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../login.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Cashier") {
    header('location: /Employee/home.php');
    exit;
}

//Sends employee back to employee/dashboard if the user uses a Cashier/Delivery role
if ($_SESSION['users']->role == "Delivery") {
    header('location: /Employee/confirmation.php');
    exit;
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Inventory"){
    header('location: /Inventory/stocks.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends customer back to home if role is customer
if ($_SESSION['users']->role == "Customer") {
    header('location: /Customer/home.php');
    exit;
}

//Sends user back to Inventory page if the role is Inventory
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Supplier"){
    header('location: /Supplier/orders.php');
    exit;
}



// Branch of the logged-in Financer: the alerts below are generated from this branch's data only
$hdr_branch = 0;
if (isset($_SESSION['users']->id)) {
    $hdr_q = $conn->query("SELECT branch_id FROM employees WHERE id = " . (int) $_SESSION['users']->id);
    $hdr_row = $hdr_q ? $hdr_q->fetch_object() : null;
    $hdr_branch = $hdr_row ? (int) $hdr_row->branch_id : 0;
}

// Branch name, used only to label the alerts below for Admin (who sees every branch's bills)
$hdr_branch_name = '';
if ($hdr_branch > 0) {
    $hdr_bn_q = $conn->query("SELECT name FROM branches WHERE id = " . $hdr_branch);
    $hdr_bn_row = $hdr_bn_q ? $hdr_bn_q->fetch_object() : null;
    $hdr_branch_name = $hdr_bn_row ? $hdr_bn_row->name : '';
}

date_default_timezone_set('Asia/Manila');
$cur_time = new DateTime(date('G:i:s'));
$scheduled_time = new DateTime("16:45:00");

if($cur_time>$scheduled_time){
    //Settlement Notification
    $sql = "SELECT * FROM employees WHERE role = 'Financer' AND deleted = 'False' AND branch_id = " . $hdr_branch;
    $query = $conn->query($sql);
    while ($emp_info = $query->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        //Getting TODAY'S settlement
        $sql = "SELECT * FROM settlement_records WHERE date = CURDATE() AND branch_id = " . $hdr_branch;
        $settle_q = $conn->query($sql);
        $settlement = $settle_q->fetch_object();
        if($settlement!=NULL){
            $notif_category = "Settlement For Today";
            $notif_message = "Todays system cash is ₱".$settlement->system_cash." and the physical cash is ₱".$settlement->physical_cash;

            //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }

        }
        
    }

    //Net Profit Notification
    $sql = "SELECT * FROM employees WHERE role = 'Financer' AND deleted = 'False' AND branch_id = " . $hdr_branch;
    $query = $conn->query($sql);
    while ($emp_info = $query->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        //Getting TODAY'S settlement
        $sql = "SELECT SUM(amount) as expenses FROM transactions WHERE date = CURDATE() AND type = 'Expense' AND branch_id = " . $hdr_branch;
        $exp_q = $conn->query($sql);
        $expense = $exp_q->fetch_object();

        $sql = "SELECT SUM(amount) as incomes FROM transactions WHERE date = CURDATE() AND type = 'Income' AND branch_id = " . $hdr_branch;
        $inc_q = $conn->query($sql);
        $income = $inc_q->fetch_object();

        $net  = ($income->incomes-$expense->expenses);

        $notif_category = "Net Money For Today";
        $notif_message = "Todays net money is ₱".$net;


        //No repeation ON THE SAME DAY checker
        $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
        $checker_query = $conn->query($sql);
        $check = $checker_query->fetch_object();

        if(!$check){
            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {}
        }
    }

}


//Installment Due TODAY notification
$sql = "SELECT * FROM bills WHERE due_date = CURDATE() AND status = 'Unpaid' AND branch_id = " . $hdr_branch;
$query = $conn->query($sql);
while ($bill_due = $query->fetch_object()) {
    $role_list = array("Admin", "Financer");
    foreach ($role_list as $role){
        if($role=="Admin"){
        $sql = "SELECT * FROM admin";
        }
        elseif($role=="Financer"){
        $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False' AND branch_id = " . $hdr_branch;
        }

        $querys = $conn->query($sql);
        while ($emp_info = $querys->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;
            $notif_category = "Bill Due Today";
            $notif_message = "Bill #".$bill_due->id." is due today" . (($role == "Admin" && $hdr_branch_name) ? " (" . $conn->real_escape_string($hdr_branch_name) . ")" : "");

           //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }
        }
    }
}


//Installment Due TODAY notification
$sql = "SELECT * FROM bills WHERE due_date < CURDATE() AND status = 'Unpaid' AND branch_id = " . $hdr_branch;
$query = $conn->query($sql);
while ($bill_due = $query->fetch_object()) {
    $role_list = array("Admin", "Financer");
    foreach ($role_list as $role){
        if($role=="Admin"){
        $sql = "SELECT * FROM admin";
        }
        elseif($role=="Financer"){
        $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False' AND branch_id = " . $hdr_branch;
        }

        $querys = $conn->query($sql);
        while ($emp_info = $querys->fetch_object()) {
            $notif_id = $emp_info->id;
            $notif_role = $emp_info->role;
            $notif_category = "Bill Passed Due Date";

            $current_date = new DateTime(date('Y-m-d')); 
            $due_date = new DateTime($bill_due->due_date); 

            // Calculate the difference
            $interval = $current_date->diff($due_date);
            $notif_message = "Bill #".$bill_due->id." has been due for ".$interval->days." day(s)" . (($role == "Admin" && $hdr_branch_name) ? " (" . $conn->real_escape_string($hdr_branch_name) . ")" : "");

            //No repeation ON THE SAME DAY checker
            $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
            $checker_query = $conn->query($sql);
            $check = $checker_query->fetch_object();

            if(!$check){
                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                if ($stmt->execute()) {}
            }
        }
    }
}



$user = $_SESSION['users'];

?>

<script>
    window.addEventListener('pageshow', function(events) {
        if (events.persisted) {
            window.location.reload();
        }
    });
</script>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>

    <!-- Global loading overlay: shown while a form submits or an action is processing -->
    <style>
        #wsGlobalLoader {
            display: none;
            position: fixed;
            inset: 0;
            z-index: 10000;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 18px;
            background: rgba(6, 32, 58, 0.78);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
        }

        #wsGlobalLoader.active {
            display: flex;
        }

        #wsGlobalLoader .ws-drop-wrap {
            position: relative;
            width: 76px;
            height: 92px;
        }

        #wsGlobalLoader .ws-drop {
            position: absolute;
            left: 50%;
            top: 0;
            width: 40px;
            height: 40px;
            transform: translateX(-50%);
            animation: wsDropFall 1.2s cubic-bezier(.55, 0, 1, .45) infinite;
        }

        #wsGlobalLoader .ws-drop svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 4px 8px rgba(41, 197, 246, 0.45));
        }

        #wsGlobalLoader .ws-ripple {
            position: absolute;
            left: 50%;
            bottom: 2px;
            width: 54px;
            height: 14px;
            border-radius: 50%;
            transform: translateX(-50%) scale(0);
            border: 2px solid var(--ws-aqua, #29c5f6);
            opacity: 0;
            animation: wsRipple 1.2s cubic-bezier(.2, .6, .35, 1) infinite;
        }

        #wsGlobalLoader .ws-ripple.ws-ripple-2 {
            animation-delay: 0.6s;
        }

        @keyframes wsDropFall {
            0% {
                top: 0;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            70% {
                top: 48px;
                transform: translateX(-50%) scale(1);
                opacity: 1;
            }

            85% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }

            100% {
                top: 52px;
                transform: translateX(-50%) scale(0.65);
                opacity: 0;
            }
        }

        @keyframes wsRipple {
            0% {
                transform: translateX(-50%) scale(0.2);
                opacity: 0;
            }

            30% {
                opacity: 0.8;
            }

            100% {
                transform: translateX(-50%) scale(1.6);
                opacity: 0;
            }
        }

        #wsGlobalLoader .ws-loader-text {
            color: var(--ws-text, #CCD6F6);
            font-weight: 600;
            font-size: 0.95rem;
            letter-spacing: 0.3px;
        }

        #wsGlobalLoader .ws-loader-text::after {
            content: '';
            display: inline-block;
            width: 1.2em;
            text-align: left;
            animation: wsDots 1.2s steps(4, end) infinite;
        }

        @keyframes wsDots {

            0%,
            20% {
                content: '';
            }

            40% {
                content: '.';
            }

            60% {
                content: '..';
            }

            80%,
            100% {
                content: '...';
            }
        }
    </style>
    <div id="wsGlobalLoader" aria-live="polite" aria-busy="true">
        <div class="ws-drop-wrap">
            <div class="ws-drop">
                <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                    <defs>
                        <linearGradient id="wsDropGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stop-color="#6fe3ff" />
                            <stop offset="100%" stop-color="#1e88e5" />
                        </linearGradient>
                    </defs>
                    <path d="M20 2 C20 2 6 20 6 29 a14 14 0 0 0 28 0 C34 20 20 2 20 2 Z" fill="url(#wsDropGrad)" />
                </svg>
            </div>
            <div class="ws-ripple"></div>
            <div class="ws-ripple ws-ripple-2"></div>
        </div>
        <div class="ws-loader-text">Please wait</div>
    </div>
    <script>
        function showGlobalLoader() {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.add('active');
        }
        window.showGlobalLoader = showGlobalLoader;

        // Show the overlay the moment any form on the page is submitted
        // (covers add/edit/submit/approve/reject forms app-wide).
        $(document).on('submit', 'form', function() {
            showGlobalLoader();
        });

        // Forms built dynamically and submitted via JS (delete/toggle confirms)
        // call form.submit() directly, which does NOT fire the 'submit' event,
        // so those call showGlobalLoader() explicitly right before submitting.

        // Hide the overlay again if the page is restored from bfcache
        // (e.g. the user hits Back after a submit).
        window.addEventListener('pageshow', function(e) {
            var el = document.getElementById('wsGlobalLoader');
            if (el) el.classList.remove('active');
        });
    </script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <?php include __DIR__ . '/../components/force_password_modal.php'; ?>
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/animate-init.js"></script>
    <link href="../css/ws-mascot.css" rel="stylesheet">
    <link href="../css/ws-motion.css" rel="stylesheet">
    <script src="../js/ws-motion.js"></script>
    <script src="../js/ws-mascot.js" data-helper></script>
    <script src="../js/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">

    <script>
        // Auto-refresh every Finance page so new requests/invoices/notifications show up
        // without the user manually reloading. Skips the reload while it would be disruptive:
        // a Bootstrap modal or SweetAlert is open, or the user is mid-typing in a text field.
        (function() {
            var WS_FINANCE_AUTO_REFRESH_MS = 30000; // 30s

            function wsCanAutoRefresh() {
                if (document.querySelector('.modal.show')) return false;
                if (document.querySelector('.swal2-container')) return false;

                var active = document.activeElement;
                if (active && (active.tagName === 'TEXTAREA' ||
                        (active.tagName === 'INPUT' && /^(text|number|search|email|tel|url|date)$/i.test(active.type)))) {
                    if (active.value && active.value.trim() !== '') return false;
                }
                return true;
            }

            setInterval(function() {
                if (wsCanAutoRefresh()) {
                    location.reload();
                }
            }, WS_FINANCE_AUTO_REFRESH_MS);
        })();
    </script>

</head>