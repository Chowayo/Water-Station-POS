<?php

$topbar_section = basename(dirname($_SERVER['SCRIPT_NAME']));
$topbar_profile_target = ($topbar_section === 'Hr') ? '#adminProfileModal' : '#adminProfileModal';
?>

<style>
    .top-nav {
        background-color: #112240;
        border-bottom: 1px solid #233554;
    }

    .notif-btn {
        position: relative;
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #8892B0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: 0.2s;
    }

    .notif-btn:hover {
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .notif-badge {
        position: absolute;
        top: -4px;
        right: -4px;
        background-color: #FF5252;
        color: #fff;
        font-size: 10px;
        font-weight: 700;
        min-width: 18px;
        height: 18px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 4px;
    }

    .notif-dropdown {
        background-color: #112240;
        border: 1px solid #233554;
        border-radius: 12px;
        min-width: 320px;
        overflow: hidden;
    }

    .notif-scroll {
        max-height: 320px;
        overflow-y: auto;
    }

    .notif-scroll::-webkit-scrollbar {
        width: 6px;
    }

    .notif-scroll::-webkit-scrollbar-thumb {
        background-color: rgba(100, 255, 218, 0.35);
        border-radius: 10px;
    }

    .notif-scroll::-webkit-scrollbar-track {
        background: transparent;
    }

    .notif-header {
        padding: 12px 16px;
        font-weight: 700;
        font-size: 13px;
        color: #CCD6F6;
        border-bottom: 1px solid #233554;
        background-color: #112240;
    }

    .notif-icon-btn {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        background-color: #0A192F;
        border: 1px solid #233554;
        color: #8892B0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        cursor: pointer;
        transition: 0.2s;
    }

    .notif-icon-btn:hover {
        border-color: #64FFDA;
        color: #64FFDA;
    }

    .notif-item {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px 16px;
        color: #CCD6F6;
        white-space: normal;
        border-bottom: 1px solid #233554;
    }

    .notif-item:hover {
        background-color: #0A192F;
        color: #CCD6F6;
    }

    .notif-item p {
        color: #CCD6F6;
    }

    .notif-item .text-muted {
        color: #8892B0 !important;
    }

    .notif-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-top: 6px;
        flex-shrink: 0;
    }

    .notif-dot-amber {
        background-color: #FFC107;
    }

    .notif-dot-green {
        background-color: #00E676;
    }

    .notif-dot-blue {
        background-color: #64FFDA;
    }

    .notif-dropdown .dropdown-divider {
        border-color: #233554;
    }

    .top-nav .profile-avatar-btn {
        width: 42px;
        height: 42px;
        margin: 0;
    }

    .top-nav .profile-avatar-btn svg {
        width: 20px;
        height: 20px;
    }
</style>

<div class="top-nav d-flex justify-content-end align-items-center gap-3 px-4 py-2">

    <!-- Notification bell ADMIN/HR -->
    <div class="dropdown">
        <button class="notif-btn" type="button" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
            <i class="bi bi-bell-fill"></i>

        </button>
        <div class="dropdown-menu dropdown-menu-end notif-dropdown p-0" aria-labelledby="notifDropdown">
            <div class="notif-header d-flex justify-content-between align-items-center">
                <span>Notifications</span>
                <span class="d-flex gap-2">
                    <form method="POST">
                        <button type="submit" name="read" class="notif-icon-btn" title="Mark all as read" aria-label="Mark all as read">
                            <i class="bi bi-check2-all"></i>
                        </button>
                    </form>
                    <form method="POST">
                        <button type="submit" name="deleter" class="notif-icon-btn" title="Clear all" aria-label="Clear all">
                            <i class="bi bi-trash3"></i>
                        </button>
                    </form>
                </span>
            </div>
            <div class="notif-scroll">
                <?php
                $sql = "SELECT * FROM notification WHERE role = '" . $result->role . "' AND emp_id = '" . $result->id . "' AND deleted = 'False'  ORDER BY id DESC";
                $query = $conn->query($sql);
                $counter = 0;

                while ($notif_info = $query->fetch_object()) {

                    echo '
                            <form method="POST">
                            <button type="submit" name="single_read" value="' . $notif_info->id . '" class="dropdown-item notif-item">
                        ';

                    if ($notif_info->status == "Unread") {
                        echo '<span class="notif-dot notif-dot-blue"></span>';
                        $counter += 1;
                    }

                    echo <<< HTML
                                    <div>
                                        <p class="mb-0 fw-semibold">$notif_info->category</p>
                                        <p class="mb-0 small text-muted">$notif_info->message</p>
                                        <p class="mb-0 small text-muted">$notif_info->date</p>
                                    </div>
                                </button>
                                </form>
                        HTML;
                }
                if ($counter > 0) {
                    echo <<< HTML
                        <script>
                            $(document).ready(function() {
                                $(".notif-btn").append('<span class="notif-badge">{$counter}</span>'); 
                            })
                        </script>
                        HTML;
                }


                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $read = "read";
                    $delete = "True";
                    //Remove Account
                    if (isset($_POST['read'])) {
                        $sql = "UPDATE `notification` SET `status` = ? WHERE role = '" . $result->role . "' AND emp_id = '" . $result->id . "' AND status = 'Unread'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $read);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                    if (isset($_POST['single_read'])) {
                        $sql = "UPDATE `notification` SET `status` = ? WHERE id = '" . $_POST['single_read'] . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $read);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                    if (isset($_POST['deleter'])) {
                        $sql = "UPDATE `notification` SET `deleted` = ? WHERE role = '" . $result->role . "' AND emp_id = '" . $result->id . "' AND deleted = 'False'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $delete);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                }

                ?>
            </div>
            <hr class="dropdown-divider m-0">
            <form method="POST"><button type="submit" name="read" class="dropdown-item text-center small fw-semibold" style="color: #64FFDA;">Mark All As Read</button></form>
        </div>
    </div>


    <!-- Profile avatar -->
    <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="<?php echo $topbar_profile_target; ?>" aria-label="Open profile">
        <i class="bi bi-person"></i>
    </button>

</div>

<?php include __DIR__ . '/profile.php'; ?>