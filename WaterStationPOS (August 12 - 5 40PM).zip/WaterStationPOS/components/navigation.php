<?php
$current_section = basename(dirname($_SERVER['SCRIPT_NAME']));

if ($current_section === 'Hr') {
    $nav_items = [
        'dashboard.php'          => ['label' => 'Dashboard',      'icon' => 'bi-speedometer2'],
        'employees.php' => ['label' => 'Accounts',       'icon' => 'bi-people'],
        'attendance.php'         => ['label' => 'Attendance',     'icon' => 'bi-calendar-check'],
        'leave.php'               => ['label' => 'Leave Requests', 'icon' => 'bi-calendar2-x'],
        'payroll.php'             => ['label' => 'Payroll',        'icon' => 'bi-cash-coin'],
    ];
    $sidebar_label   = 'HR DEPARTMENT';
} elseif ($current_section === 'Finance') {
    $nav_items = [
        'dashboard.php'     => ['label' => 'Dashboard',     'icon' => 'bi-speedometer2'],
        'transactions.php'  => ['label' => 'Transactions',  'icon' => 'bi-arrow-left-right'],
        'expenses.php'      => ['label' => 'Expenses',      'icon' => 'bi-receipt'],
        'reports.php'       => ['label' => 'Reports',       'icon' => 'bi-bar-chart-line'],
    ];
    $sidebar_label   = 'FINANCE DEPARTMENT';
} else {
    // Default / Admin section
    $nav_items = [
        'dashboard.php' => ['label' => 'Dashboard', 'icon' => 'bi-speedometer2'],
        'employees.php' => ['label' => 'Employees', 'icon' => 'bi-people'],
        'hr.php'         => ['label' => 'HR',         'icon' => 'bi-person-badge'],
        'finance.php'    => ['label' => 'Finance',    'icon' => 'bi-cash-coin'],
        'products.php'  => ['label' => 'Products',  'icon' => 'bi-box-seam'],
    ];
    $sidebar_label  = 'ADMINISTRATOR';
}

$current_page = basename($_SERVER['PHP_SELF']);
?>

<style>
    .sidebar-brand-logo {
        width: 52px;
        height: 52px;
        object-fit: contain;
        border-radius: 50%;
        border: 2px solid #64FFDA;
        background-color: #0A192F;
    }

    .sidebar-brand-name {
        font-weight: 800;
        font-size: 14px;
        letter-spacing: 0.5px;
        color: #FFFFFF;
    }

    .menu-link-icon {
        display: inline-block;
        width: 20px;
        margin-right: 10px;
        text-align: center;
        font-size: 15px;
    }
</style>

<!-- hamburger toggle -->
<button class="hamburger-btn d-flex d-lg-none" id="menuToggle" aria-label="Toggle menu">
    <span></span>
    <span></span>
    <span></span>
</button>

<div class="menu-overlay" id="menuOverlay"></div>

<div class="container-fluid p-0 app d-flex flex-grow-1">

    <!-- LEFT MENU -->
    <aside class="left-menu d-flex flex-column py-4" id="leftMenu">

        <div class="sidebar-brand text-center px-3 mb-3">
            <img src="../Images/logo.png" alt="Logo" class="sidebar-brand-logo mb-2">
            <h6 class="sidebar-brand-name mb-0"><span class="green-text">ECO</span> HYDRATE HUB</h6>
        </div>

        <div class="px-3 mb-3">
            <p class="text-center fw-bold small mb-0" style="color: #8B7355; letter-spacing: 1px;"><?php echo $sidebar_label; ?></p>
        </div>

        <nav class="nav flex-column px-2">

            <hr class="mx-3 border-secondary mt-0">

            <?php foreach ($nav_items as $link => $item): ?>
                <a class="menu-link <?php echo $current_page === $link ? 'active' : ''; ?>" href="<?php echo $link; ?>">
                    <i class="bi <?php echo $item['icon']; ?> menu-link-icon"></i><?php echo $item['label']; ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <a class="menu-link mt-auto mb-3" href="../logout.php" id="logout">
            <i class="bi bi-box-arrow-right menu-link-icon"></i>Logout
        </a>
    </aside>

    <script>
        if (!window.__mobileNavInit) {
            window.__mobileNavInit = true;

            document.addEventListener('click', function(e) {
                var menu = document.getElementById('leftMenu');
                var overlay = document.getElementById('menuOverlay');
                var btn = document.getElementById('menuToggle');
                if (!menu || !overlay || !btn) return;

                if (e.target.closest('#menuToggle')) {
                    menu.classList.toggle('active');
                    overlay.classList.toggle('active');
                    btn.classList.toggle('active');
                } else if (e.target.closest('#menuOverlay') || e.target.closest('#leftMenu .menu-link')) {
                    menu.classList.remove('active');
                    overlay.classList.remove('active');
                    btn.classList.remove('active');
                }
            });
        }
    </script>