<?php
include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

?>

<head>
    <title>Finance Overview - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Finance Overview</h1>
                    <h6>Revenue, cash flow, and spending</h6>
                </div>
            </header>

            <!-- Revenue Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Revenue Today</div>
                        <div class="dash-value green-text">
                            <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date = CURDATE() AND type ='Income'";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                } else {
                                    echo "₱0.00";
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Revenue This Week</div>
                        <div class="dash-value cyan-text">
                            <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= CURDATE() - INTERVAL 7 DAY AND date <= CURDATE() AND type = 'Income';";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;

                                } else {
                                    echo "₱0.00";
                                    
                                }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center">
                        <div class="dash-title">Revenue This Month</div>
                        <div class="dash-value">
                            <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                    $month_income = $income->total;
                                } else {
                                    echo "₱0.00";
                                    $month_income = 0.00;
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Expenses + Net -->
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="dash-card text-center h-100 d-flex flex-column justify-content-center">
                        <div class="dash-title">Expenses This Month</div>
                        <div class="dash-value" style="color:#FF5252;">
                            <?php
                                //Getting monthly expenses from TRANSACTION table
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Expense'";
                                $query = $conn->query($sql);
                                $month_expense = $query->fetch_object();

                                //Getting monthly expenses from EXPENSE table
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01')";
                                $query = $conn->query($sql);
                                $extra_expense = $query->fetch_object();

                                if ($month_expense == "") {
                                    $month_expense = 0.00;
                                }

                                if ($extra_expense == "") {
                                    $extra_expense = 0.00;
                                }

                                $total_expense = ($month_expense->total + $extra_expense->total);
                                echo "₱" . $total_expense;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="dash-card text-center h-100 d-flex flex-column justify-content-center">
                        <div class="dash-title">Net Profit / Loss This Month</div>
                        <div class="dash-value" style="color:#FF5252;">
                            ₱<?php echo ($month_income - $total_expense); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <!-- Top Expenses -->
                <div class="col-12 col-lg-5">
                    <div class="section-header">Top Expenses</div>
                    <div class="manage-box shadow-sm">
                        <h5 class="mb-3">Biggest Outflows This Month</h5>

                        <?php
                            $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Payroll");
                            $expenses_total = array();

                            //Gets total of expenses
                            foreach ($expenses_category as $category) {
                                if ($category != "Payroll") {
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                                } else {
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Expense'";
                                }
                                $query = $conn->query($sql);
                                $total = $query->fetch_object();

                                //Adds total to array
                                $expenses_total[] = $total->total;
                            }

                            //gets the highest value in the expense array
                            $max_expense = max($expenses_total);
                            for ($i = 0; $i < 6; $i++) {
                                echo <<<HTML
                                        <div class="expense-row">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span>{$expenses_category[$i]}</span>
                                                <span class="fw-bold">₱{$expenses_total[$i]}</span>
                                            </div>
                                        </div>
                                    HTML;
                            }
                        ?>
                    </div>
                </div>

                <!-- Recent Transactions (read-only) -->
                <div class="col-12 col-lg-7">
                    <div class="section-header">Recent Transactions</div>
                    <div class="manage-box shadow-sm">
                        <div class="txn-list">
                            <?php
                                $sql = "SELECT * FROM transactions WHERE date = CURDATE()";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                        <div class="txn-row">
                                            ';
                                    if ($set->type == "Income") {
                                        echo '
                                                <div class="txn-icon in"><i class="bi bi-arrow-down-left-circle-fill"></i></div>
                                                <div class="txn-body">
                                            ';
                                    } else {
                                        echo '
                                                <div class="txn-icon in"><i class="bi bi-arrow-down-left-circle-fill text-danger"></i></div>
                                                <div class="txn-body">
                                            ';
                                    }

                                    date_default_timezone_set('Asia/Manila');
                                    $current_time = date('H:i:s');
                                    $trans_time = new DateTime($set->time);
                                    $current_time = new DateTime($current_time);

                                    //This will check if the time in is NOT past the the shift end
                                    if ($trans_time < $current_time) {

                                        //Gets the time difference between current time and time of transactions
                                        $interval_minutes = $trans_time->diff($current_time);

                                        //For hours
                                        $hour_difference = $interval_minutes->h;

                                        //For minutes
                                        $minute_difference = $interval_minutes->i;

                                        if ($hour_difference == 0) {
                                            $timeline = $minute_difference . " minute ago";
                                        } else {
                                            $timeline = $hour_difference . " hour ago";
                                        }
                                    }

                                    echo '
                                            <p class="txn-title">' . $set->description . '</p>
                                            <p class="txn-time">' . $timeline . '</p>
                                        </div>';

                                    if ($set->type == "Income") {
                                        echo '<div class="activity-amount green-text">+₱' . $set->amount . '</div>';
                                    } else {
                                        echo '<div class="activity-amount" style="color: #FF5252;">-₱' . $set->amount . '</div>';
                                    }


                                    echo '    
                                            </div>
                                        ';
                                }


                            ?>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>