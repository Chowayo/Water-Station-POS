<?php
include __DIR__ . '/../components/header.php';

$sql = "SELECT * FROM admin WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();

$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : date('Y-m-d');

?>

<head>
    <title>HR Overview - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../Admin/styles.css?v=<?php echo time(); ?>">

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php include __DIR__ . '/../components/navigation.php'; ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>HR Overview</h1>
                    <h6>All staff list</h6>
                </div>
            </header>

            <!-- Summary Cards -->
            <div class="row g-4 mb-4">
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center">
                        <div class="dash-title">Total Basic Employees</div>
                        <div class="dash-value">
                            <div class="dash-value green-text">
                                <?php
                                    $sql = "SELECT COUNT(id) AS total FROM employees    ";
                                    $query = $conn->query($sql);
                                    $set = $query->fetch_object();
                                    echo $set->total;
                                ?>
                            </div>
                        </div>
                        <div class="small mt-1" style="color:#8892B0;">Active: 
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM employees WHERE status = 'Active'";
                                $query = $conn->query($sql);
                                $act = $query->fetch_object();

                                $active = (int)$act->total;
                                $total_active = (int)$set->total;
                            
                                echo  $active;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center">
                        <div class="dash-title">Present Today</div>
                        <div class="dash-value cyan-text">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status != 'Absent' AND date = '" . $conn->real_escape_string($filter_date) . "'";
                                $query = $conn->query($sql);
                                $set = $query->fetch_object();
                                echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center">
                        <div class="dash-title">Absentees Today</div>
                        <div class="dash-value" style="color:#FF5252;">
                            <?php
                                $sql = "SELECT COUNT(id) AS total FROM attendance WHERE status = 'Absent' AND date = '" . $conn->real_escape_string($filter_date) . "'";
                                $query = $conn->query($sql);
                                $set = $query->fetch_object();
                                echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="dash-card text-center">
                        <div class="dash-title">Pending Leave Requests</div>
                        <div class="dash-value" style="color:#FFC107;">
                            <?php
                                $sql = "SELECT COUNT(status) AS total FROM leave_request WHERE status = 'Pending'";
                                $query = $conn->query($sql);
                                $set = $query->fetch_object();
                                echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Daily Attendance Log -->
            <div class="section-header">Attendance Tracking Overview</div>
            <div class="row g-4 mb-4">
                <div class="col-12">
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 pt-1">
                                Daily Attendance Log
                                <span class="small fw-normal" style="color: #8892B0;">
                                    (<?php echo date('M d, Y', strtotime($filter_date)); ?>)
                                </span>
                            </h5>

                            <div class="d-flex flex-wrap gap-2 align-items-center">
                                <form method="GET" class="d-flex gap-2 align-items-center mb-0">
                                    <input type="date" name="filter_date" class="form-control"
                                        value="<?php echo htmlspecialchars($filter_date); ?>"
                                        onchange="this.form.submit()" style="max-width: 180px;">
                                    <?php if ($filter_date !== date('Y-m-d')): ?>
                                        <a href="hr.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Today</a>
                                    <?php endif; ?>
                                </form>
                                <input type="text" class="form-control table-search-input" placeholder="Search Employee" id="searcher">
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-dark table-hover text-center mb-0 align-middle" id="attendance_list">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Employee ID</th>
                                        <th>Role</th>
                                        <th>Initial Login Time</th>
                                        <th>Last Log Out Time</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        //Loader of todays attendance
                                        $sql = "SELECT * FROM attendance WHERE date = '" . $conn->real_escape_string($filter_date) . "'";
                                        $query = $conn->query($sql);
                                        while ($set = $query->fetch_object()) {
                                            echo '
                                                    <tr>
                                                        <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                        <td><strong class="d-block">' . $set->employee_id . '</strong></td>
                                                        <td>' . $set->role . '</td>
                                                        <td>' . $set->init_in . '</td>
                                                        <td>' . $set->last_out . '</td>
                                                        ';
                                            //<td><span class="status-badge-attendance status-ontime">On Time</span></td>
                                            if ($set->status == "On Time") {
                                                echo '<td><span class="status-badge-attendance status-ontime">On Time</span></td>';
                                            } else if ($set->status == "Late") {
                                                echo '<td><span class="status-badge-attendance status-late">Late</span></td>';
                                            } else if ($set->status == "Absent") {
                                                echo '<td><span class="status-badge-attendance status-absent">Absent</span></td>';
                                            }
                                            echo '       
                                                        <td><strong class="d-block">' . $set->date . '</strong></td>
                                                    </tr>         
                                                ';
                                        }


                                    ?>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Leave Submissions -->
            <div class="section-header">Todays Leave Submissions</div>
            <div class="row g-4">
                <div class="col-12">
                    <div class="manage-box shadow-sm">
                        <div class="table-responsive">
                            <table class="table table-dark table-hover text-center mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Leave Type</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $sql = "SELECT * FROM leave_request WHERE submission_date = CURDATE()";
                                        $query = $conn->query($sql);
                                        while ($set = $query->fetch_object()) {
                                            echo '
                                                    <tr data-status="' . $set->status . '">
                                                        <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                        <td>' . $set->leave_type . '</td>
                                                        <td>' . $set->start_date . '</td>
                                                        <td>' . $set->end_date . '</td>';   
                                                        

                                            if ($set->status == "Pending") {
                                                echo '
                                                        <td><span class="badge" style="background-color: rgba(255, 193, 7, 0.15); color: #a17c00; border: 1px solid rgba(255, 193, 7, 0.4);">Pending</span></td>';
                                            } else if ($set->status == "Approved") {
                                                echo '
                                                    <td><span class="badge" style="background-color: rgba(40, 167, 69, 0.1); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.3);">Approved</span></td>';
                                            } else if ($set->status == "Rejected") {
                                                echo '<td><span class="badge" style="background-color: rgba(220, 53, 69, 0.1); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.3);">Rejected</span></td>';
                                            }

                                            echo '</tr>';
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            var table = $('#attendance_list').DataTable({
                paging: false,
                searching: true,
                dom: 't'
            });

            $('#searcher').on('keyup change clear', function() {
                table.search(this.value).draw();
            });
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Admin Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });
                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>