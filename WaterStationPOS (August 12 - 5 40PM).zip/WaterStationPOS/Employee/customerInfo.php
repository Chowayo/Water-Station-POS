<?php

include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();


echo <<<HTML
        <script>
            $(document).ready(function() {
                 //Sends the Delivery back if it tries to access pages that it does not have persmission to access
                if("{$result->role}"=="Delivery"){
                    location.assign('confirmation.php');
                }

                //Sends the Cashier back if it tries to access pages that it does not have persmission to access
                else if("{$result->role}"=="Delivery"){
                    //Empty since cashier can access every present page in the system
                }
            });
        </script>
    HTML;

?>



<link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">


<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include 'navigation.php';
    ?>

    <!-- MAIN CONTENT -->
    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include 'topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-center align-items-center gap-3">
                <div class="text-center">
                    <h1>Customer Information Directory</h1>
                </div>
            </header>


            <div class="box mt-2">
                <div class="d-flex flex-wrap gap-2 justify-content-between mb-3 align-items-center">
                    <h5 class="mb-0 fw-bold">Registered Customers</h5>

                    <div class="d-flex flex-wrap gap-2">
                        <!-- Increased width to 300px for a better fit -->
                        <div class="table-search-input search-icon-wrap">
                            <i class="bi bi-search search-icon-inside"></i>
                            <input type="text" class="form-control" placeholder="Search customer" id="searcher">
                        </div>

                        <!-- Added the 'w-auto' class here! -->
                        <button type="button" class="btn btn-add w-auto rounded-pill px-4" data-toggle="modal" id="openAddCustomerBtn" data-target="#addCustomerModal"><i class="bi bi-person-plus-fill me-1"></i>Add Customer</button>
                    </div>
                </div>
            </div>
            <script>
                $(document).ready(function() {
                    var table = $('#customer_list').DataTable({
                        paging: false, // Enable pagination
                        searching: true, // Enable search functionality
                        dom: 't' //Removes the built in search from datatables
                    });

                    $('#searcher').on('keyup change clear', function() {
                        table.search(this.value).draw(); //Sets the input box as the new search bar
                    });


                });
            </script>



            <div class="table-responsive">
                <table class="table table-hover text-center mb-0 align-middle" id="customer_list">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Contact Number</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        //Loading employee list
                        $sql = "SELECT * FROM customers WHERE deleted = 'False'";
                        $query = $conn->query($sql);
                        while ($set = $query->fetch_object()) {
                            echo "
                                    <tr>
                                    <td class='fw-bold' style='overflow-wrap: break-word; max-width: 320px;'>$set->full_name</td>
                                    <td>$set->contact</td>
                                    <td style='overflow-wrap: break-word; max-width: 320px;'>$set->address</td>
                                    ";

                            //Micheal: yung data-id is nag s-save ng specific points sa loop para ma-seperate sila 
                            echo "
                                <td>
                                    <button class='btn btn-edit btn-sm rounded-pill px-4' data-id='{$set->id}' data-fname='{$set->full_name}' data-contact='{$set->contact}' data-address='{$set->address}' ><i class='bi bi-pencil-square'></i> Edit</button>
                                    <button class='btn btn-danger btn-sm rounded-pill px-3'
                                                    data-id='{$set->id}'>
                                                <i class='bi bi-trash3'></i> Remove
                                            </button>
                                    
                                </td>
                                </tr>
                                ";

                            //Sweet Alert pop-up
                            echo <<<HTML
                                    <script>
                                        $('.btn-danger').click(function() {
                                            //Michael: Yung this ay nag r-retrieve ng data mula doon sa may data-id/email sa may buttons kanina (Also pwede naman to sa labas ng PHP pero sa loob nalang muna para organize yung functions)
                                            id = $(this).data('id');

                                            Swal.fire({
                                                title: 'Remove Customer?',
                                                text: 'They will be deleted from the database.',
                                                icon: 'warning',
                                                background: '#FFFFFF',
                                                color: '#2D3748',
                                                showCancelButton: true,
                                                showConfirmButton: false,
                                                cancelButtonColor: '#8892B0',
                                                html: '<form method="POST"><button type="submit" name="deleter" value="' + id + '" class="btn btn-danger">Confirm Delete</button></form>',

                                                heightAuto: false
                                            });
                                        });
                                    </script>
                                HTML;
                        }



                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                            //Add customer
                            if (isset($_POST['adder'])) {
                                $full_name = $_POST['full_name'];
                                $contact = $_POST['contact_number'];
                                $address = $_POST['address'];

                                if ($full_name && $contact && $address) {
                                    $contact_checked = True;
                                    if (!is_numeric($contact)) {
                                        $contact_checked = False;
                                    }

                                    //No repeat customer checker
                                    $sql = "SELECT full_name FROM customers WHERE deleted = 'False'";
                                    $query = $conn->query($sql);
                                    $customer_checked = True;
                                    while ($set = $query->fetch_object()) {
                                        if ($set->full_name == $full_name) {
                                            $customer_checked = False;
                                            break;
                                        }
                                    }


                                    if ($contact_checked) {
                                        if ($customer_checked) {
                                            $sql = "INSERT INTO `customers` (`full_name`, `contact`, `address`) VALUES (?, ?, ?)";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sss", $full_name, $contact, $address);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Customer Saved!',
                                                                    text: 'The new customer has been added.',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#00E676',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        location.assign('customerInfo.php');
                                                                    }});
                                                            })
                                                        </script> 
                                                    HTML;

                                                //Notification
                                                $sql = "SELECT * FROM employees WHERE role = 'Delivery' OR role='Cashier'";
                                                $query = $conn->query($sql);
                                                while ($emp_info = $query->fetch_object()) {
                                                    $notif_id = $emp_info->id;
                                                    $notif_role = $emp_info->role;
                                                    $notif_category = "Customer Information Added";
                                                    $notif_message = "New Customer information has been added on customer list ";

                                                    $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP())";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                    if ($stmt->execute()) {}
                                            }
                                            }
                                        } else {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Name!',
                                                                    text: 'Customer is present in the list',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Contact!',
                                                                    text: 'Enter a contact number',
                                                                    background: '#FFFFFF',
                                                                    color: '#2D3748',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                    }
                                }
                            }

                            if (isset($_POST['editer'])) {
                                $id = $_POST['id'];
                                $full_name = $_POST['full_name'];
                                $contact = $_POST['contact_number'];
                                $address = $_POST['address'];

                                if ($full_name && $contact && $address && $id) {
                                    $contact_checked = True;
                                    if (!is_numeric($contact)) {
                                        $contact_checked = False;
                                    }

                                    //No repeat customer checker
                                    $sql = "SELECT full_name FROM customers WHERE deleted = 'False' AND id !=" . $id;
                                    $query = $conn->query($sql);
                                    $customer_checked = True;
                                    while ($set = $query->fetch_object()) {
                                        if ($set->full_name == $full_name) {
                                            $customer_checked = False;
                                            break;
                                        }
                                    }

                                    if ($contact_checked) {
                                        if ($customer_checked) {
                                            $sql = "UPDATE `customers` SET `full_name` = ?, `contact` = ?, `address` = ? WHERE id = '" . $id . "'";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sss", $full_name, $contact, $address);
                                            if ($stmt->execute()) {
                                                echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Customer Edited!',
                                                                                text: 'The customer information has been updated.',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',

                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('customerInfo.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                            }
                                        } else {
                                            echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Name!',
                                                                    text: 'Customer is present in the list',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                        }
                                    } else {
                                        echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Invalid Contact!',
                                                                    text: 'Enter a contact number',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',

                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addEmployeeModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                    }
                                }
                            }

                            if (isset($_POST['deleter'])) {
                                $sql = "UPDATE `customers` SET `deleted` = 'True' WHERE id = ". $_POST['deleter'];
                                if ($conn->query($sql) === TRUE) {
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Customer Deleted!',
                                                        text: 'The customer has been removed.',
                                                        background: '#FFFFFF',
                                                        color: '#2D3748',
                                                        confirmButtonColor: '#00E676',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('customerInfo.php');
                                                        }});
                                                })
                                            </script> 
                                            HTML;
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            </div>

        </section>
    </main>
    </div>

    <!-- ADD CUSTOMER MODAL -->
    <div class="modal fade" id="addCustomerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-plus-fill me-2"></i>Add New Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addCustomerForm" method="POST">
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-person me-1"></i>Full Name</label>
                            <input type="text" class="form-control" name="full_name" required placeholder="e.g. Luz Cantos">
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-telephone me-1"></i>Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}" placeholder="e.g. 09123456789" required>
                        </div>

                        <div class=" mb-4">
                            <label class="form-label"><i class="bi bi-geo-alt me-1"></i>Complete Address</label>
                            <textarea class="form-control" name="address" rows="3" required placeholder="House No., Street, Barangay, City..."></textarea>
                        </div>

                        <div class="modal-footer d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" name="adder" class="btn btn-primary rounded-pill px-4"><i class="bi bi-check-circle me-1"></i>Save Customer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editCustomerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content shadow-lg">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Edit Customer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4">
                    <form id="addCustomerForm" method="POST">
                        <!-- Wag pansinin to, vessel lang to ng ID para ma-transfer sya sa PHP from JS-->
                        <input type="number" name="id" id="edit-id" hidden>

                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-person me-1"></i>Full Name</label>
                            <input type="text" class="form-control" name="full_name" required placeholder="e.g. Luz Cantos" id="edit-fname">
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-telephone me-1"></i>Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" inputmode="numeric" maxlength="11" pattern="09[0-9]{9}" placeholder="e.g. 09123456789" id="edit-contact">
                        </div>

                        <div class="mb-4">
                            <label class="form-label"><i class="bi bi-geo-alt me-1"></i>Complete Address</label>
                            <textarea class="form-control" name="address" rows="3" required placeholder="House No., Street, Barangay, City..." id="edit-address"></textarea>
                        </div>

                        <div class="modal-footer d-flex justify-content-end gap-2">
                            <button type="button" class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" name="editer" class="btn btn-primary rounded-pill px-4" id="saveCustomerBtn"><i class="bi bi-check-circle me-1"></i>Save Customer</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    include 'profile.php';
    ?>

    <script>
        $('.btn-edit').click(function() {
            //Used to pre-load the edit section since it's not connected to PHP
            id = $(this).data('id');
            full_name = $(this).data('fname');
            contact = $(this).data('contact');
            address = $(this).data('address');

            $("#edit-id").val(id);
            $("#edit-fname").val(full_name);
            $("#edit-contact").val(contact);
            $("#edit-address").val(address);
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();
                let logoutUrl = $(this).attr('href');

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#FFFFFF',
                    color: '#2D3748',
                    title: "Log out of POS?",
                    html: `
                        <p class="text-muted small mb-4">This will count as you clocking out and you won't be able to log in until your next shift tommorow.</p>
                        <a href='` + logoutUrl + `' class='btn btn-danger me-2'>Log Out</a> <button onclick='Swal.close()' class='btn btn-secondary'>Cancel</button>`,
                    heightAuto: false
                });
            });

        });

        $(".btn-edit").click(function() {
            $('#editCustomerModal').modal('show');
        })

        document.getElementById('openAddCustomerBtn').addEventListener('click', function(e) {
            e.preventDefault();
            var modalEl = document.getElementById('addCustomerModal');
            if (!modalEl) return;

            if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
                console.error('Bootstrap is not loaded. Include bootstrap.bundle.min.js');
                return;
            }

            var myModal = bootstrap.Modal.getOrCreateInstance(modalEl);
            myModal.show();
        });
    </script>
</body>

</html>