<!DOCTYPE html>
<html lang="en">

<?php
require('../dbConn.php');


if (!isset($_SESSION['users'])) {
    header('location:../index.php');
}

//Sends user back to Hr page if the role is HR
if (isset($_SESSION['users']) && $_SESSION['users']->role == "HR") {
    header('location: /Hr/dashboard.php');
    exit;
}

//Sends user back to admin page if the role is Admin
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Admin") {
    header('location: /Admin/dashboard.php');
    exit;
}

//Sends user back to finance page if the role is Financer
if (isset($_SESSION['users']) && $_SESSION['users']->role == "Financer") {
    header('location: /Finance/dashboard.php');
    exit;
}

//Low and No Stock Notification
$sql = "SELECT * FROM product WHERE stock <= 5 AND deleted = 'False'";
$query = $conn->query($sql);
while ($product = $query->fetch_object()) {

    $sql = "SELECT * FROM employees WHERE role = 'Cashier' and deleted = 'False'";
    $querys = $conn->query($sql);
    while ($emp_info = $querys->fetch_object()) {
        $notif_id = $emp_info->id;
        $notif_role = $emp_info->role;

        if($product->stock==0){
            $notif_category = "Product Out of Stock";
            $notif_message = $product->product_name . " is currently out of stock"; 
        }
        else if($product->stock>0){
            $notif_category = "Product Low on Stock";
            $notif_message = $product->product_name . " Only has ".$product->stock." stock left";
        }
        
        //No repeation ON THE SAME DAY checker
        $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
        $checker_query = $conn->query($sql);
        $check = $checker_query->fetch_object();

        if(!$check){
            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
            if ($stmt->execute()) {}
        }
    }
}


    
//End of shift reminder
date_default_timezone_set('Asia/Manila');
$cur_time = new DateTime(date('G:i:s'));
$scheduled_time = new DateTime("16:45:00");
if($cur_time>$scheduled_time){
    $sql = "SELECT * FROM employees WHERE id = ".$_SESSION['users']->id." AND deleted = 'False' AND role ='".$_SESSION['users']->role."'";
    $query = $conn->query($sql);
    $emp_info = $query->fetch_object();
    $notif_id = $emp_info->id;
    $notif_role = $emp_info->role;
    $notif_category = "Your Shift is Almost Over";
    $notif_message = "Make sure to log off at exactly 5:00PM";


    //No repeation ON THE SAME DAY checker
    $sql = "SELECT * FROM notification WHERE message = '".$notif_message."' AND date = CURDATE() AND role = '".$emp_info->role."' AND emp_id = ".$emp_info->id;
    $checker_query = $conn->query($sql);
    $check = $checker_query->fetch_object();

    if(!$check){
        $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date` ) VALUES (?, ?, ?, ?, CURDATE())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
        if ($stmt->execute()) {}
    }
}

$user = $_SESSION['users'];

?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee POS</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/jquery.dataTables.min.css" rel="sylesheet">
    <link href="../css/bootstrap-icons-1.13.1/bootstrap-icons.min.css" rel="stylesheet">
    <script src="../js/jquery-3.6.0.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <script src="../js/jquery.dataTables.min.js"></script>


    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>


<body>
    <script>
        window.addEventListener('pageshow', function(events) {
            if (events.persisted) {
                window.location.reload();
            }
        });
    </script>