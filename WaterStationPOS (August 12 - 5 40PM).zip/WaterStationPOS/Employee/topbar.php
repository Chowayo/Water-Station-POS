<div class="top-nav d-flex justify-content-end align-items-center gap-3 px-4 py-2">

    <!-- Notification bell EMPLOYEE -->
    <div class="dropdown">
        <button class="notif-btn" type="button" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
            <i class="bi bi-bell-fill"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-end notif-dropdown p-0" aria-labelledby="notifDropdown">
            <div class="notif-header d-flex justify-content-between align-items-center">
                <span>Notifications</span>
                <span class="d-flex gap-2">
                    <form method="POST">
                        <button type="submit" name="read" class="notif-icon-btn" title="Mark all as read" aria-label="Mark all as read">
                            <i class="bi bi-check2-all"></i>
                        </button>
                    </form>
                    <form method="POST">
                        <button type="submit" name="deleter" class="notif-icon-btn" title="Clear all" aria-label="Clear all">
                            <i class="bi bi-trash3"></i>
                        </button>
                    </form>
                </span>
            </div>
            <div class="notif-scroll">
                <?php
                //$sql = "SELECT * FROM notification WHERE role = '".$result->role."' AND emp_id = '".$result->id."'";
                $sql = "SELECT * FROM notification WHERE deleted = 'False' AND emp_id = '" . $result->id . "' ORDER BY id DESC";
                $query = $conn->query($sql);
                $counter = 0;

                while ($notif_info = $query->fetch_object()) {

                    echo '
                            <form method="POST">
                            <button type="submit" name="single_read" value="' . $notif_info->id . '" class="dropdown-item notif-item">
                        ';

                    if ($notif_info->status == "Unread") {
                        echo '<span class="notif-dot notif-dot-blue"></span>';
                        $counter += 1;
                    }

                    echo <<< HTML
                                    <div>
                                        <p class="mb-0 fw-semibold">$notif_info->category</p>
                                        <p class="mb-0 small text-muted">$notif_info->message</p>
                                        <p class="mb-0 small text-muted">$notif_info->date</p>
                                    </div>
                                </button>
                                </form>
                        HTML;
                }
                if ($counter > 0) {
                    echo <<< HTML
                        <script>
                            $(document).ready(function() {
                                $(".notif-btn").append('<span class="notif-badge">{$counter}</span>'); 
                            })
                        </script>
                        HTML;
                }


                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $read = "read";
                    $delete = "True";
                    //Remove Account
                    if (isset($_POST['read'])) {
                        $sql = "UPDATE `notification` SET `status` = ? WHERE role = '" . $result->role . "' AND emp_id = '" . $result->id . "' AND status = 'Unread'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $read);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                    if (isset($_POST['single_read'])) {
                        $sql = "UPDATE `notification` SET `status` = ? WHERE id = '" . $_POST['single_read'] . "'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $read);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                    if (isset($_POST['deleter'])) {
                        $sql = "UPDATE `notification` SET `deleted` = ? WHERE role = '" . $result->role . "' AND emp_id = '" . $result->id . "' AND deleted = 'False'";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $delete);
                        if ($stmt->execute()) {
                            echo <<< HTML
                                    <script>
                                        $(document).ready(function() {
                                            location.assign(window.location.href);
                                        })
                                    </script>
                                    HTML;
                        }
                    }
                }

                ?>
            </div>
            <hr class="dropdown-divider m-0">
            <form method="POST"><button type="submit" name="read" class="dropdown-item text-center small fw-semibold" style="color: #191ec3;">Mark All As Read</button></form>
        </div>
    </div>


    <button type="button" class="profile-avatar-btn" data-bs-toggle="modal" data-bs-target="#profileModal" aria-label="Open profile">
        <i class="bi bi-person"></i>
    </button>

</div>