<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();
?>

<head>
    <title>Reports</title>

    <style>

    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div>
                    <h1>Reports</h1>
                    <h6>Generate and review financial reports</h6>
                </div>
            </header>

            <!-- Report Type Tabs -->
            <ul class="txn-filter-tabs mb-4" id="reportTypeTabs">
                <li><button type="button" class="nav-link active" data-report="pnl"><i class="bi bi-graph-up-arrow me-1"></i>Profit &amp; Loss</button></li>
                <li><button type="button" class="nav-link" data-report="category"><i class="bi bi-pie-chart me-1"></i>Category Breakdown</button></li>
                <li><button type="button" class="nav-link" data-report="cash"><i class="bi bi-cash-stack me-1"></i>Cash Settlement</button></li>
            </ul>

            <!-- PROFIT & LOSS -->
            <div class="report-panel active" id="panel-pnl">
                <form method="POST">
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-3 justify-content-between align-items-end">
                            <div class="d-flex flex-wrap gap-3 align-items-end">
                                <div>
                                    <label class="form-label mb-1">From</label>
                                    <input type="date" name="start_date_prof" class="form-control form-control-sm" id="pnlFrom">
                                </div>
                                <div>
                                    <label class="form-label mb-1">To</label>
                                    <input type="date" name="end_date_prof" class="form-control form-control-sm" id="pnlTo">
                                </div>
                                <button type="submit" name="search_profit" class="btn btn-edit btn-sm rounded-pill px-3">
                                    <i class="bi bi-arrow-repeat me-1"></i>Search Report
                                </button>
                            </div>
                        </div>
                    </div>
                </form>



                <div class="row g-4 mb-4" id="info_bar">
                    <div class="col-md-4">
                        <div class="dash-card text-center" style="position: relative;">
                            <img src="../Images/Reports(Profits & Loss)/Total_Income.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                            <div class="dash-title">Total Income This Month</div>
                            <div class="dash-value green-text">
                                <?php
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                                $query = $conn->query($sql);
                                $income = $query->fetch_object();

                                if ($income != "") {
                                    echo "₱" . $income->total;
                                    $income = $income->total;
                                } else {
                                    echo "₱0.00";
                                    $income = 0.00;
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card text-center" style="position: relative;">
                            <img src="../Images/Reports(Profits & Loss)/Total_expenses.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                            <div class="dash-title">Total Expenses This Month</div>
                            <div class="dash-value" style="color: #FF5252;">
                                <?php
                                    $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Payroll", "Invoice");
                                    $expenses_total = 0;

                                    //Gets total of expenses
                                    foreach ($expenses_category as $category) {

                                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                                        $query = $conn->query($sql);
                                        $expense = $query->fetch_object();

                                        //Adds total to array
                                        $expenses_total += $expense->total;
                                    }

                                    if ($expenses_total == "") {
                                        $expenses_total = 0.00;
                                    }

                                    
                                    echo "₱" . $expenses_total;
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dash-card text-center" style="position: relative;">
                            <img src="../Images/Reports(Profits & Loss)/profit_loss.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                            <div class="dash-title">Net Profit / Loss This Month</div>
                            <div class="dash-value cyan-text">₱<?php echo ($income - $expenses_total); ?></div>
                        </div>
                    </div>
                </div>


                <div class="section-header"><i class="bi bi-calendar3 me-2"></i>Monthly Breakdown</div>
                <div class="manage-box shadow-sm">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="pnl_table">
                            <thead>
                                <tr>
                                    <th>Period</th>
                                    <th>Income</th>
                                    <th>Expenses</th>
                                    <th>Net</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $years_included = array();
                                $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                $looper = 0;
                                $sql = "SELECT DISTINCT YEAR(`date`) AS unique_year FROM `transactions` ORDER BY unique_year DESC;";
                                $query = $conn->query($sql);

                                //Gets all of the years present in DB of transactions
                                while ($years = $query->fetch_object()) {
                                    $years_included[] = $years->unique_year;
                                }

                                //Loops thru the present entries in DB
                                foreach ($years_included as $year) {
                                    for ($i = 0; $i < 12; $i++) {
                                        if ($looper < 12) {
                                            $looper += 1;
                                        } else {
                                            $looper = 1;
                                        }
                                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') AND date < DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') + INTERVAL 1 MONTH AND type ='Income'";
                                        $query = $conn->query($sql);
                                        $transaction_income = $query->fetch_object();

                                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') AND date < DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') + INTERVAL 1 MONTH AND type ='Expense'";
                                        $query = $conn->query($sql);
                                        $transaction_expense = $query->fetch_object();

                                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE date >= DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') AND date < DATE_FORMAT(CURDATE(), '" . $year . "-" . $looper . "-01') + INTERVAL 1 MONTH ";
                                        $query = $conn->query($sql);
                                        $expenses_expense = $query->fetch_object();

                                        $total_expense = ($transaction_expense->total + $expenses_expense->total);
                                        if ($transaction_income->total > 0 || $transaction_expense->total > 0 || $expenses_expense->total > 0) {

                                            echo '
                                                    <tr>
                                                        <td class="cyan-text fw-bold">' . $months[$i] . ' ' . $year . '</td>
                                                        <td class="green-text">₱' . $transaction_income->total . '</td>
                                                        <td style="color: #FF5252;">₱' . $transaction_expense->total . '</td>
                                                        <td class="fw-bold">₱' . ($transaction_income->total - $total_expense) . '</td>
                                                    </tr>
                                                ';
                                        }
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- CATEGORY  -->
            <div class="report-panel" id="panel-category">
                <form method="POST">
                    <div class="manage-box shadow-sm mb-4">
                        <div class="d-flex flex-wrap gap-3 justify-content-between align-items-end">
                            <div class="d-flex flex-wrap gap-3 align-items-end">
                                <div>
                                    <label class="form-label mb-1">From</label>
                                    <input type="date" name="start_date_cat" class="form-control form-control-sm" id="catFrom" required>
                                </div>
                                <div>
                                    <label class="form-label mb-1">To</label>
                                    <input type="date" name="end_date_cat" class="form-control form-control-sm" id="catTo">
                                </div>
                                <button type="submit" name="search_category" class="btn btn-edit btn-sm rounded-pill px-3">
                                    <i class="bi bi-arrow-repeat me-1"></i>Search Report
                                </button>
                            </div>
                        </div>
                    </div>
                </form>



                <div class="row g-4">
                    <div class="col-12 col-lg-6">
                        <div class="section-header"><i class="bi bi-graph-up-arrow me-2"></i>Income by Category For This Month</div>
                        <div class="manage-box shadow-sm" id="income_category">
                            <?php
                            //MICHEAL NOTE: Dagdagan nalang to if ever mag karoon ng bagong source ng income
                            $income_category = array("Sales");
                            $income_total = array();

                            //Gets total of Income
                            foreach ($income_category as $category) {
                                if ($category == "Sales") {
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND type ='Income'";
                                }

                                $query = $conn->query($sql);
                                $total = $query->fetch_object();

                                //Adds total to array
                                $income_total[] = $total->total;
                            }

                            //gets the highest value in the income array
                            $max_income = max($income_total);

                            for ($i = 0; $i < 1; $i++) {
                                if ($income_total[$i] != 0.00) {
                                    $income_percentage = ($income_total[$i] / $max_income) * 100;
                                } else {
                                    $income_percentage = 0;
                                }
                                echo <<<HTML
                                        <script>
                                            console.log("$income_total[$i]");
                                            console.log("$max_income");
                                        </script>
                                        <div class="expense-row">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span>{$income_category[$i]}</span>
                                                <span class="fw-bold">₱{$income_total[$i]}</span>
                                            </div>
                                            <div class="expense-bar-track">
                                                <div class="expense-bar-fill" style="width: {$income_percentage}%;"></div>
                                            </div>
                                        </div>
                                    HTML;
                            }

                            ?>
                        </div>
                    </div>

                    <div class="col-12 col-lg-6">
                        <div class="section-header"><i class="bi bi-graph-down-arrow me-2"></i>Expenses by Category For This Month</div>
                        <div class="manage-box shadow-sm" id="expenses_category">

                            <?php
                            //Gets total of expenses
                            $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Marketing", "Payroll", "Invoice");
                            $expenses_total = array();

                            //Gets total of expenses
                            foreach ($expenses_category as $category) {

                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                                $query = $conn->query($sql);
                                $expense = $query->fetch_object();

                                //Adds total to array
                                $expenses_total[] = $expense->total;
                            }

                            //gets the highest value in the expense array
                            $max_expense = max($expenses_total);
                            for ($i = 0; $i < 8; $i++) {
                                if ($expenses_total[$i] != 0.00) {
                                    $expense_percentage = ($expenses_total[$i] / $max_expense) * 100;
                                } else {
                                    $expense_percentage = 0;
                                }

                                echo <<<HTML
                                        <div class="expense-row">
                                            <div class="d-flex justify-content-between mb-1">
                                                <span>{$expenses_category[$i]}</span>
                                                <span class="fw-bold">₱{$expenses_total[$i]}</span>
                                            </div>
                                            <div class="expense-bar-track">
                                                <div class="expense-bar-fill" style="width: {$expense_percentage}%;"></div>
                                            </div>
                                        </div>
                                    HTML;
                            }

                            ?>

                        </div>
                    </div>
                </div>
            </div>

            <!--  CASH SETTLEMENT  -->
            <div class="report-panel" id="panel-cash">


                <form method="POST">
                    <div class="row g-4 mb-4">
                        <div class="col-md-4">
                            <div class="dash-card text-center" style="position: relative;">
                                <img src="../Images/Reports(Cash settlement)/system_recorded.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                <div class="dash-title">System Recorded Cash</div>
                                <div class="dash-value cyan-text" id="system_cash">
                                    <?php
                                    $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date = CURDATE() AND type ='Income'";
                                    $query = $conn->query($sql);
                                    $income = $query->fetch_object();

                                    if ($income != "") {
                                        echo "₱" . $income->total;
                                    } else {
                                        echo "₱0.00";
                                    }
                                    ?>
                                    <input type="number" step="0.01" name="system_cash" id="systemCash" hidden>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="dash-card text-center" style="position: relative;">
                                <img src="../Images/Reports(Cash settlement)/Physical_Drawer.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                <div class="dash-title mb-2">Physical Drawer Count</div>
                                <input type="number" step="0.01" name="physical_cash" id="physical_cash" class="form-control" id="drawerCountInput" placeholder="Enter counted amount">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="dash-card text-center" style="position: relative;">
                                <img src="../Images/Reports(Cash settlement)/variance.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                <div class="dash-title">Variance</div>
                                <div class="dash-value" id="variance">₱0.00</div>
                                <input type="number" step="0.01" name="variance" id="varianceValue" hidden>
                            </div>
                        </div>
                    </div>

                    <div class="row g-4 mb-4">
                        <div class="col-12">
                            <div class="section-header"><i class="bi bi-journal-text me-2"></i>Settlement Notes</div>
                            <div class="manage-box shadow-sm">
                                <textarea class="form-control" rows="3" name="note" placeholder="e.g. Short by ₱150 — likely change miscount during the 2PM shift change" required></textarea>
                                <div class="d-flex justify-content-end mt-3">
                                    <?php
                                    $sql = "SELECT * FROM settlement_records WHERE date = CURDATE()";
                                    $query = $conn->query($sql);
                                    $button_action = "";
                                    if ($set = $query->fetch_object() != NULL) {
                                        $button_action = "Disabled";
                                    }
                                    ?>
                                    <button type="submit" name="adder_settlement" class="btn btn-edit btn-sm rounded-pill px-4" <?php echo $button_action; ?>>
                                        <i class="bi bi-check2 me-1"></i>Save Settlement
                                    </button>

                                </div>
                            </div>
                        </div>
                    </div>
                </form>


                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    //Remove Account
                    if (isset($_POST['adder_settlement'])) {
                        $system_cash =  $_POST['system_cash'];
                        $physical_cash =  $_POST['physical_cash'];
                        $variance =  $_POST['variance'];
                        $note =  $_POST['note'];
                        $status = "";

                        //Amount prevents "-" and "e"
                        $number_checked = True;
                        if (strpbrk($system_cash, 'e-') !== false || strpbrk($physical_cash, 'e-') !== false || strpbrk($variance, 'e') !== false) {
                            $number_checked = False;
                        }
                        if ($variance < 0) {
                            $status = "Cash Short";
                        } else if ($variance > 0) {
                            $status = "Cash Over";
                        } else if ($variance == 0) {
                            $status = "Balance";
                        }

                        if ($physical_cash && $note) {
                            if ($number_checked) {
                                $sql = "INSERT INTO `settlement_records` (`date`, `system_cash`, `physical_cash`, `variance`, `note`, `status`) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                $stmt = $conn->prepare($sql);
                                $stmt->bind_param("dddss", $system_cash, $physical_cash, $variance, $note, $status);
                                if ($stmt->execute()) {
                                    //Short Balance Notification
                                    $role_list = array("Admin", "Financer");
                                    foreach ($role_list as $role){
                                        if($role=="Admin"){
                                            $sql = "SELECT * FROM admin";
                                        }
                                        elseif($role=="Financer"){
                                            $sql = "SELECT * FROM employees WHERE role = '".$role."' AND deleted = 'False'";
                                        }
                                        
                                        $query = $conn->query($sql);
                                        while ($emp_info = $query->fetch_object()) {
                                            $notif_id = $emp_info->id;
                                            $notif_role = $emp_info->role;
                                            $notif_category = "Cash Settlement Not Balanced";
                                            if($status=="Cash Short"){
                                                $notif_message = "Todays cash settlement is short by ₱".($variance * -1);

                                            }
                                            elseif($status=="Cash Over"){
                                                $notif_message = "Todays cash settlement is over by ₱".$variance;
                                            }
                                            $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURDATE())";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                            $stmt->execute();
                                        }
                                    }
                                    echo <<<HTML
                                            <script>
                                                $(document).ready(function() {
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Today Settlement Added!',
                                                        background: '#112240',
                                                        color: '#CCD6F6',
                                                        confirmButtonColor: '#00E676',
                                                        heightAuto: false
                                                    }).then((result) => {
                                                        if(result.isConfirmed) {
                                                            location.assign('reports.php');
                                                        }});
                                                })
                                            </script> 
                                        HTML;
                                }
                            } else {
                                //Number has e
                                echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Invalid Value!',
                                                    text: 'Make sure to only use numerical characters for physical cash and that it is a positive number',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#e60000',
                                                    heightAuto: false
                                                });
                                            })
                                            </script> 
                                    HTML;
                            }
                        } else {
                            //Number has e
                            echo <<<HTML
                                        <script>
                                            $(document).ready(function() {
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Incomplete Input!',
                                                    text: 'Make sure to fill all of the input boxes and also make sure that the variance has a value before submitting',
                                                    background: '#112240',
                                                    color: '#CCD6F6',
                                                    confirmButtonColor: '#e60000',
                                                    heightAuto: false
                                                });
                                            })
                                            </script> 
                                    HTML;
                        }
                    }

                    if (isset($_POST['search_profit'])) {
                        $start =  $_POST['start_date_prof'];
                        $end = $_POST['end_date_prof'];


                        //Searched Transaction Income
                        $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '" . $start . "') AND date < DATE_FORMAT(CURDATE(), '" . $end . "') + INTERVAL 1 MONTH AND type ='Income'";
                        $query = $conn->query($sql);
                        $transaction_income = $query->fetch_object();


                        $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Payroll", "Invoice");
                        $expenses_total = 0;

                        //Gets total of expenses
                        foreach ($expenses_category as $category) {

                            $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                            $query = $conn->query($sql);
                            $expense = $query->fetch_object();

                            //Adds total to array
                            $expenses_total += $expense->total;
                        }


                        if ($transaction_income == "") {
                            $transaction_income_number = 0.00;
                        } else {
                            $transaction_income_number = $transaction_income->total;
                        }

                        if ($expenses_total == "") {
                            $expenses_total_number = 0.00;
                        } else {
                            $expenses_total_number = $expenses_total;
                        }


                        $total_net = ($transaction_income_number - $expenses_total_number);

                        echo <<<HTML
                                <script>

                                    $(document).ready(function() {

                                        //Wipes current info bar
                                        $("#info_bar").empty();

                                        $("#info_bar").append(`
                                            <div class="col-md-4">
                                                <div class="dash-card text-center" style="position: relative;">
                                                    <img src="../Images/Reports(Profits & Loss)/Total_Income.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                                    <div class="dash-title">Total Income Based on Search</div>
                                                    <div class="dash-value green-text">{$transaction_income_number}</div>
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="dash-card text-center" style="position: relative;">
                                                    <img src="../Images/Reports(Profits & Loss)/Total_expenses.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                                    <div class="dash-title">Total Expenses Based on Search</div>
                                                    <div class="dash-value" style="color: #FF5252;">{$expenses_total}</div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="dash-card text-center" style="position: relative;">
                                                    <img src="../Images/Reports(Profits & Loss)/profit_loss.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                                                    <div class="dash-title">Net Profit / Loss This Based on Search</div>
                                                    <div class="dash-value cyan-text">₱{$total_net}</div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        `)
                                    });
                                </script>

                            HTML;
                    }

                    if (isset($_POST['search_category'])) {
                        $start =  $_POST['start_date_cat'];
                        $end = $_POST['end_date_cat'];

                        echo <<<HTML
                                <script>
                                    console.log("Start: {$start}");
                                    console.log("To: {$end}");
                                    $(document).ready(function() {
                                        //Forces the category panel to be loaded after submitting data
                                        $('.report-panel').removeClass('active');
                                        $('#panel-category').addClass('active');
                                        $('#reportTypeTabs .nav-link').removeClass('active');
                                        $('#reportTypeTabs .nav-link[data-report="category"]').addClass('active');


                                        //Removes everything from the current bars
                                        $("#expenses_category").empty();
                                        $("#income_category").empty();
                                    });
                                </script>

                            HTML;

                        //FOR INCOME BAR
                        //MICHEAL NOTE: Dagdagan nalang to if ever mag karoon ng bagong source ng income
                        $income_category = array("Sales");
                        $income_total = array();

                        //Gets total of Income
                        foreach ($income_category as $category) {
                            if ($category == "Sales") {
                                $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '" . $start . "') AND date < DATE_FORMAT(CURDATE(), '" . $end . "') + INTERVAL 1 MONTH AND type ='Income'";
                            }

                            $query = $conn->query($sql);
                            $total = $query->fetch_object();

                            //Adds total to array
                            $income_total[] = $total->total;
                        }
                        //gets the highest value in the income array
                        $max_income = max($income_total);
                        for ($i = 0; $i < 1; $i++) {
                            if ($income_total[$i] != 0.00) {
                                $income_percentage = ($income_total[$i] / $max_income) * 100;
                            } else {
                                $income_percentage = 0;
                            }
                            echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            $("#income_category").prepend(`
                                                <div class="expense-row">
                                                    <div class="d-flex justify-content-between mb-1">
                                                        <span>{$income_category[$i]}</span>
                                                        <span class="fw-bold">₱{$income_total[$i]}</span>
                                                    </div>
                                                    <div class="expense-bar-track">
                                                        <div class="expense-bar-fill" style="width: {$income_percentage}%;"></div>
                                                    </div>
                                                </div>
                                            `);
                                        });
                                    </script>
                                HTML;
                        }

                        //Gets total of expenses
                        $expenses_category = array("Supplies", "Maintenance", "Transport/Fuel", "Utilities", "Other", "Marketing", "Payroll", "Invoice");
                        $expenses_total = array();

                        //Gets total of expenses
                        foreach ($expenses_category as $category) {

                            $sql = "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date < DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01') AND category ='" . $category . "'";
                            $query = $conn->query($sql);
                            $expense = $query->fetch_object();

                            //Adds total to array
                            $expenses_total[] = $expense->total;
                        }

                        //gets the highest value in the expense array
                        $max_expense = max($expenses_total);
                        for ($i = 0; $i < 8; $i++) {
                            if ($expenses_total[$i] != 0.00) {
                                $expense_percentage = ($expenses_total[$i] / $max_expense) * 100;
                            } else {
                                $expense_percentage = 0;
                            }
                            echo <<<HTML
                                    <script>
                                        $(document).ready(function() {
                                            $("#expenses_category").prepend(`
                                                <div class="expense-row">
                                                    <div class="d-flex justify-content-between mb-1">
                                                        <span>{$expenses_category[$i]}</span>
                                                        <span class="fw-bold">₱{$expenses_total[$i]}</span>
                                                    </div>
                                                    <div class="expense-bar-track">
                                                        <div class="expense-bar-fill" style="width: {$expense_percentage}%;"></div>
                                                    </div>
                                                </div>
                                            `);
                                        });
                                    </script>
                                HTML;
                        }
                    }
                }
                ?>



                <div class="section-header"><i class="bi bi-clock-history me-2"></i>Settlement History</div>

                <div class="manage-box shadow-sm">
                    <div class="mb-4">
                        <label class="form-label mb-1">Settlement Date Search</label>
                        <input type="date" class="form-control form-control-sm" id="searcher" style="max-width: 220px;">
                    </div>

                    <div class="table-responsive">
                        <table class="table table-dark table-hover text-center mb-0 align-middle" id="settlement_table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>System Cash</th>
                                    <th>Counted Cash</th>
                                    <th>Variance</th>
                                    <th>Status</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM settlement_records";
                                $query = $conn->query($sql);
                                while ($set = $query->fetch_object()) {
                                    echo '
                                        <tr>
                                            <td>' . $set->date . '</td>
                                            <td>₱' . $set->system_cash . '</td>
                                            <td>₱' . $set->physical_cash . '</td>
                                            <td>₱' . $set->variance . '</td>
                                            <td><span class="settlement-status-badge" style="background: rgba(136,146,176,.2); color: #8892B0;">' . $set->status . '</span></td>
                                            <td class="text-secondary">' . $set->note . '</td>
                                        </tr>
                                    
                                    ';
                                }

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script>
        $(document).ready(function() {
            //VARIANCE LOGIC
            system_cash = $('#system_cash').text();
            const converter = system_cash.split("₱");
            system_cash_number = parseFloat(converter[1]);


            $("#physical_cash").change(function() {
                physical_cash = $('#physical_cash').val()

                if (physical_cash < 0) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Invalid Value',
                        text: 'Enter physical cash value',
                        background: '#112240',
                        color: '#CCD6F6',
                        confirmButtonColor: '#e60000',
                        heightAuto: false
                    });
                    $("#physical_cash").val(0);

                } else {
                    //Puts value on a 2 decimal point 
                    $("#variance").text("₱" + (system_cash_number - physical_cash).toFixed(2));

                    //For hidden Input for submission
                    $("#varianceValue").val((system_cash_number - physical_cash).toFixed(2));
                    $("#systemCash").val(system_cash_number);
                }
            });
            console.log(system_cash_number);


            var table = $('#settlement_table').DataTable({
                paging: false, // Enable pagination
                searching: true, // Enable search functionality
                dom: 't' //Removes the built in search from datatables
            });

            $('#searcher').on('change', function() {
                var val = $(this).val();
                if (val) {
                    table.column(0).search('^' + $.fn.dataTable.util.escapeRegex(val), true, false).draw();
                } else {
                    table.column(0).search('').draw();
                }
            });


            // Report type tab switching
            $('#reportTypeTabs .nav-link').on('click', function() {
                $('#reportTypeTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                var report = $(this).data('report');

                $('.report-panel').removeClass('active');
                $('#panel-' + report).addClass('active');
            });
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of Finance Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>
</body>