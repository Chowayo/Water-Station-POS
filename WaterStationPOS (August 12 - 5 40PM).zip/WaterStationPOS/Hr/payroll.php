<?php
include 'header.php';

$sql = "SELECT * FROM employees WHERE id = " . $user->id;
$query = $conn->query($sql);
$result = $query->fetch_object();



?>

<head>
    <title>Payroll - Eco Hydrate Hub</title>
    <link rel="stylesheet" href="../components/styles.css?v=<?php echo time(); ?>">


    <style>
        .payroll-status-icon {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            background-color: #00E676;
            color: #0A192F;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .payroll-filter-tabs {
            display: flex;
            gap: 10px;
            list-style: none;
            padding: 0;
            margin: 0;
            flex-wrap: wrap;
        }

        .payroll-filter-tabs .nav-link {
            border: none;
            font-weight: 700;
            font-size: 13px;
            padding: 8px 18px;
            border-radius: 20px;
            cursor: pointer;
            transition: 0.2s;
            opacity: 0.55;
        }

        .payroll-filter-tabs .nav-link.active {
            opacity: 1;
        }

        .tab-calculated {
            background-color: rgba(0, 230, 118, 0.15);
            color: #00E676;
        }

        .tab-processing {
            background-color: rgba(136, 146, 176, 0.2);
            color: #CCD6F6;
        }

        .tab-issues {
            background-color: rgba(255, 82, 82, 0.15);
            color: #FF5252;
        }

        .status-badge-payroll {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-calculated {
            background-color: rgba(0, 230, 118, 0.1);
            color: #00E676;
            border: 1px solid #00E676;
        }

        .badge-processing {
            background-color: rgba(136, 146, 176, 0.1);
            color: #8892B0;
            border: 1px solid #8892B0;
        }

        .badge-issues {
            background-color: rgba(255, 82, 82, 0.1);
            color: #FF5252;
            border: 1px solid #FF5252;
        }

        .payroll-tag {
            background-color: #0A192F;
            border: 1px solid #233554;
            color: #CCD6F6;
            font-size: 12px;
            font-weight: 600;
            padding: 5px 14px;
            border-radius: 8px;
            display: inline-block;
        }

        .payroll-controls-label {
            font-size: 13px;
            font-weight: 700;
            color: #8892B0;
            min-width: 50px;
        }
    </style>
</head>

<body class="d-flex flex-column vh-100 overflow-hidden">

    <?php
    include __DIR__ . '/../components/navigation.php';
    ?>

    <main class="flex-grow-1 d-flex flex-column content overflow-auto">

        <?php include __DIR__ . '/../components/topbar.php'; ?>

        <section class="p-4 flex-grow-1">

            <header class="top-text mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <h1>Payroll & Deduction Calculator</h1>
                    </div>
                </div>
            </header>

            <!-- Summary Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Payroll & Deduction Calculator/unpaid_payroll.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Unpaid Payroll Slip Count</div>
                        <div class="dash-value">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM payroll WHERE status = 'Unpaid'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Payroll & Deduction Calculator/paid_payroll.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Paid Payroll Slip Count</div>
                        <div class="dash-value" style="color: #FF5252;">
                            <?php
                            $sql = "SELECT COUNT(id) AS total FROM payroll WHERE status = 'Paid'";
                            $query = $conn->query($sql);
                            $set = $query->fetch_object();
                            echo $set->total;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="dash-card text-center" style="position: relative;">
                        <img src="../Images/Payroll & Deduction Calculator/current_my.png" alt="" style="position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;">
                        <div class="dash-title">Current Month and Year</div>
                        <div class="d-flex align-items-center justify-content-center gap-2 mt-1">

                            <span class="fs-5 fw-bold green-text">
                                <?php
                                $month_num = (int)date('m');
                                $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                $month_year = $months[$month_num - 1] . " " . date('Y');
                                echo $month_year;
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-header"><i class="bi bi-calculator me-2"></i>Payroll & Deduction Calculation - ( Date )</div>

            <!-- Payroll Log -->
            <div class="row g-4 mb-4">
                <div class="col-12">
                    <div class="manage-box shadow-sm">
                        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
                            <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i>Payroll Log</h5>
                            <button type="button" class="btn btn-add w-auto px-4 rounded-pill text-nowrap" data-bs-toggle="modal" data-bs-target="#addPayrollModal"><i class="bi bi-person-plus me-1"></i>Add Employee</button>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-dark table-hover text-center mb-0 align-middle" id="payroll_list">
                                <thead>
                                    <tr>
                                        <th>Employee ID</th>
                                        <th>Employee Name</th>
                                        <th>Maximum Daily Pay</th>
                                        <th>Gross Pay</th>
                                        <th>SSS</th>
                                        <th>Phil Health</th>
                                        <th>Pag-Ibig</th>
                                        <th>Net</th>
                                        <th>Last Updated</th>
                                        <th>Month Year</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $month_num = (int)date('m');
                                    $months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                                    $month_year = $months[$month_num - 1] . " " . date('Y');
                                    $sql = "SELECT * FROM payroll WHERE status = 'Unpaid'";
                                    $query = $conn->query($sql);
                                    while ($set = $query->fetch_object()) {
                                        echo '
                                                <tr data-status="calculated">
                                                    <td>' . $set->employee_id . '</td>
                                                    <td><strong class="d-block">' . $set->employee_name . '</strong></td>
                                                    <td>₱' . $set->max_day_pay . '</td>
                                                    <td>₱' . $set->gross_pay . '</td>
                                                    <td>₱' . $set->sss . '</td>
                                                    <td>₱' . $set->phil_health . '</td>
                                                    <td>₱' . $set->pag_ibig . '</td>
                                                    <td>₱' . $set->net_pay . '</td>
                                                    <td class="green-text fw-bold">' . $set->last_updated . '</td>
                                                    <td class="green-text fw-bold">' . $set->month_year . '</td>
                                                    <td>' . $set->status . '</td>
                                                    <td>
                                                        <form method="POST"><button type="submit" name="view_slip" value="' . $set->id . '" class="btn btn-edit btn-sm rounded-pill px-3 mb-1" data-bs-toggle="modal"><i class="bi bi-receipt me-1"></i>View Pay Slip</button></form>';

                                        if ($month_year != $set->month_year) {
                                            echo "
                                                    <button class='btn btn-edit btn-sm rounded-pill px-3' id='btn-confirm' data-getter='{$set->id}' data-id='{$set->employee_id}' data-date='{$set->month_year}'><i class='bi bi-check2-circle me-1'></i>Confirm Payment</button>
                                                </td>
                                            </tr>
                                            ";
                                        } else {
                                            echo '
                                                </td>
                                            </tr>
                                            ';
                                        }

                                        echo <<<HTML
                                                    <script>
                                                        $('#btn-confirm').click(function() {
                                                            id = $(this).data('id');
                                                            date = $(this).data('date');
                                                            getter = $(this).data('getter');

                                                            Swal.fire({
                                                                title: 'Confirm Employee Payment?',
                                                                icon: 'warning',
                                                                background: '#112240',
                                                                color: '#CCD6F6',
                                                                showCancelButton: true,
                                                                showConfirmButton: false,
                                                                cancelButtonColor: '#8892B0',
                                                                html: ` 
                                                                        <p class="small mb-4">Please make sure that the employee has been fully paid before confirming.</p>
                                                                        <form method="POST"><input type="text" name="month_year" value="`+date+`" hidden><input type="number" name="getter" value="`+getter+`" hidden><button type="submit" name="confirmer" value="` + id + `" class="btn btn-danger">Confirm Payment</button></form>`,
                                                                heightAuto: false
                                                            });
                                                        });
                                                    </script>
                                                HTML;
                                    }

                                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                                        //Confirms paycheck
                                        if (isset($_POST['confirmer'])) {
                                            $emp_id = $_POST['confirmer'];
                                            $set_month_year = $_POST['month_year'];
                                            $getter = $_POST['getter'];
                                            $status = "Paid";
                                            $sql = "UPDATE `payroll` SET `status` = ? WHERE employee_id = ? AND month_year = ?";
                                            $stmt = $conn->prepare($sql);
                                            $stmt->bind_param("sss", $status, $emp_id, $set_month_year);
                                            if ($stmt->execute()) {

                                                $sql = "SELECT * FROM payroll WHERE id = '" . $getter . "'";
                                                $query = $conn->query($sql);
                                                $pay = $query->fetch_object();

                                                //Will insert value into transactions
                                                $description = "Employee Wage Payment";
                                                $category = "Payroll";
                                                $type = "Expense";
                                                $payment_method = "Cash";
                                                $sql = "INSERT INTO `transactions` (`date`, `description`, `category`, `type`, `payment_method`, `amount`) VALUES (CURDATE(), ?, ?, ?, ?, ?)";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("ssssd", $description, $category, $type, $payment_method, $pay->net_pay);
                                                if ($stmt->execute()) {
                                                }

                                                //Notification
                                                $sql = "SELECT * FROM payroll WHERE employee_id = '" . $_POST['confirmer'] . "' AND month_year = '" . $set_month_year . "'";
                                                $query = $conn->query($sql);
                                                $pay_info = $query->fetch_object();

                                                $notif_id = $pay_info->employee_id;
                                                $notif_role = $pay_info->employee_role;
                                                $notif_category = "Wage ready to received";
                                                $notif_message = "Your payment of ₱" . $pay_info->net_pay . " for " . $pay_info->month_year . " is ready for pickup head to Human resource office";

                                                $sql = "INSERT INTO `notification` (`emp_id`, `role`, `category`, `message`, `date`) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP())";
                                                $stmt = $conn->prepare($sql);
                                                $stmt->bind_param("isss", $notif_id, $notif_role, $notif_category, $notif_message);
                                                if ($stmt->execute()) {
                                                }



                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                $('#payslipModal').modal('show');
                                                                $('#payslipModal').on('hidden.bs.modal', function () {
                                                                    location.assign('payroll.php');
                                                                });
                                                            })
                                                        </script>
                                                    HTML;
                                            }
                                        }

                                        //Adds employee to the payroll FOR NEW EMPLOYEES ONLY
                                        if (isset($_POST['adder'])) {
                                            $emp_id = $_POST['emp_id'];
                                            $exist_checker = TRUE;

                                            $sql = "SELECT * FROM payroll";
                                            $query = $conn->query($sql);
                                            while ($set = $query->fetch_object()) {
                                                if ($set->employee_id == $emp_id) {
                                                    $exist_checker = FALSE;
                                                    break;
                                                }
                                            }

                                            if ($exist_checker) {
                                                $sql = "SELECT * FROM employees WHERE id = '$emp_id'";
                                                $query = $conn->query($sql);
                                                $result = $query->fetch_object();
                                                if ($result != NULL) {
                                                    echo <<<HTML
                                                            <script>
                                                                console.log("{$result->id}");
                                                                console.log("{$result->last_name}");
                                                                console.log("{$result->role}");
                                                            </script>
                                                        HTML;

                                                    $emp_id = $result->id;
                                                    $name = $result->last_name;

                                                    if ($result->role == "Cashier") {
                                                        $daily = 500.00;
                                                    } else if ($result->role == "Delivery") {
                                                        $daily = 600.00;
                                                    }

                                                    $sql = "INSERT INTO `payroll` (`employee_id`, `employee_name`, `max_day_pay`, `month_year`) VALUES (?, ?, ?, ?)";
                                                    $stmt = $conn->prepare($sql);
                                                    $stmt->bind_param("isds", $emp_id, $name, $daily, $month_year);
                                                    if ($stmt->execute()) {
                                                        echo <<<HTML
                                                                    <script>
                                                                        $(document).ready(function() {
                                                                            Swal.fire({
                                                                                icon: 'success',
                                                                                title: 'Employee Added to Payroll Database!',
                                                                                background: '#112240',
                                                                                color: '#CCD6F6',
                                                                                confirmButtonColor: '#00E676',
                                                                                heightAuto: false
                                                                            }).then((result) => {
                                                                                if(result.isConfirmed) {
                                                                                    location.assign('payroll.php');
                                                                                }});
                                                                        })
                                                                    </script> 
                                                                HTML;
                                                    }
                                                } else {
                                                    echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Employee Does Not Exist!',
                                                                    text: 'Enter a new Employee ID',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addPayrollModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                                }
                                            } else {
                                                echo <<<HTML
                                                        <script>
                                                            $(document).ready(function() {
                                                                Swal.fire({
                                                                    icon: 'error',
                                                                    title: 'Employee Already Present in Payroll Database!',
                                                                    text: 'Enter a new Employee ID',
                                                                    background: '#112240',
                                                                    color: '#CCD6F6',
                                                                    confirmButtonColor: '#e60000',
                                                                    heightAuto: false
                                                                }).then((result) => {
                                                                    if(result.isConfirmed) {
                                                                        $('#addPayrollModal').modal('show');
                                                                    }});
                                                            })
                                                            </script> 
                                                    HTML;
                                            }
                                        }

                                        if (isset($_POST['view_slip'])) {

                                            $sql = "SELECT * FROM payroll WHERE id = '" . $_POST['view_slip'] . "'";
                                            $query = $conn->query($sql);
                                            $pay = $query->fetch_object();
                                            echo <<<HTML
                                                    <script>
                                                        $(document).ready(function() {
                                                            $('#payslipModal').modal('show');
                                                        })
                                                    </script>
                                                HTML;
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>


    <!-- Add Employee Modal -->
    <div class="modal fade" id="addPayrollModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add New Employee to the Payroll</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <form id="addEmployeeForm" method="POST">
                        <div class="mb-1">
                            <label for="newEmployeeName" class="form-label">Employee ID</label>
                            <input type="text" class="form-control" id="newEmployeeName" placeholder="e.g. 45" name="emp_id" required>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary w-auto" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Cancel</button>
                            <button type="submit" form="addEmployeeForm" class="btn btn-add w-auto px-4" name="adder"><i class="bi bi-check2-circle me-1"></i>Add Employee</button>
                        </div>
                    </form>
                </div>



            </div>
        </div>
    </div>

    <!-- View Payslip Modal -->
    <div class="modal fade" id="payslipModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-receipt-cutoff me-2"></i>Employee Pay Slip</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="payslip-box p-3" id="payslipContent">

                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 pb-3 payslip-header-border">
                            <div class="d-flex align-items-center gap-3">
                                <img src="../Images/logo.png" alt="Logo" class="header-logo">
                                <div>
                                    <h4 class="mb-0"><span class="green-text">ECO</span> HYDRATE HUB</h4>
                                    <small class="text-muted">Official Pay Slip</small>
                                </div>
                            </div>
                            <div class="payroll-tag" id="ps-monthyear"><?php echo $pay->month_year; ?></div>
                        </div>

                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <div class="payroll-controls-label">Employee ID</div>
                                <div class="fw-bold fs-5"><?php echo $pay->employee_id; ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="payroll-controls-label">Employee Name</div>
                                <div class="fw-bold fs-5"><?php echo $pay->employee_name; ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="payroll-controls-label">Status</div>
                                <div><?php echo $pay->status; ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="payroll-controls-label">Last Updated</div>
                                <div class="fw-bold green-text" id="lastUpdated"><?php echo $pay->last_updated; ?></div>
                            </div>
                        </div>

                        <div class="table-responsive mb-3">
                            <table class="table table-dark table-borderless mb-0">
                                <thead>
                                    <tr class="border-bottom">
                                        <th>Earnings</th>
                                        <th class="text-end">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Maximum Daily Pay</td>
                                        <td class="text-end">₱<?php echo $pay->max_day_pay; ?></td>
                                    </tr>
                                    <tr class="border-top">
                                        <td class="fw-bold">Gross Pay</td>
                                        <td class="text-end fw-bold green-text">₱<?php echo $pay->gross_pay; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="table-responsive mb-3">
                            <table class="table table-dark table-borderless mb-0">
                                <thead>
                                    <tr class="border-bottom">
                                        <th>Deductions</th>
                                        <th class="text-end">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>SSS</td>
                                        <td class="text-end">₱<?php echo $pay->sss; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Phil Health</td>
                                        <td class="text-end">₱<?php echo $pay->phil_health; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pag-Ibig</td>
                                        <td class="text-end">₱<?php echo $pay->pag_ibig; ?></td>
                                    </tr>
                                    <tr class="border-top">
                                        <td class="fw-bold">Total Deductions</td>
                                        <td class="text-end fw-bold" style="color:#FF5252;">₱<?php echo ($pay->sss + $pay->phil_health + $pay->pag_ibig); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="payslip-net-box d-flex justify-content-between align-items-center p-3 rounded">
                            <span class="fw-bold fs-5">NET PAY</span>
                            <span class="fw-bold fs-4 green-text" id="ps-net">₱<?php echo $pay->net_pay; ?></span>
                        </div>

                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary w-auto" data-bs-dismiss="modal"><i class="bi bi-x-lg me-1"></i>Close</button>
                    <button type="button" class="btn btn-add w-auto px-4" id="btn-print-payslip" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
                </div>

            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#payrollFilterTabs .nav-link').on('click', function() {
                $('#payrollFilterTabs .nav-link').removeClass('active');
                $(this).addClass('active');

                var filter = $(this).data('filter');
                $('#payroll_list tbody tr').hide();
                $('#payroll_list tbody tr[data-status="' + filter + '"]').show();
            });
        });

        $(document).ready(function() {
            $("#logout").click(function(e) {
                e.preventDefault();

                Swal.fire({
                    showConfirmButton: false,
                    icon: "question",
                    background: '#112240',
                    color: '#CCD6F6',
                    title: "Log out of HR Panel?",
                    html: "<a href='../logout.php' class='btn btn-outline-danger me-2' id='confirmLogout'><i class='bi bi-box-arrow-right me-1'></i>Log Out</a> <button onclick='Swal.close()' class='btn btn-outline-light'><i class='bi bi-x-lg me-1'></i>Cancel</button>",
                    heightAuto: false
                });

                $(document).off('click', '#confirmLogout').on('click', '#confirmLogout', function() {
                    window.location.href = this.href;
                });
            });
        });
    </script>

</body>