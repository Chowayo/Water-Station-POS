-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2026 at 02:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'Admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first_name`, `last_name`, `email`, `password`, `role`) VALUES
(1, 'Keith', 'Vernom', 'adminNuqui@gmail.com', '$2y$10$q326Lu5CeiU2iEPG34SQ6eSyTDsx8VbF8XJ0FXRVC1C7VJ2y27YE.', 'Admin'),
(2, 'NUQUI', 'B.', 'set@gmail.com', '$2y$10$yMl/DeXDDV6nwaiYz6pkKeEF1k0TbjgVU4g5cl18kCPZyVyzMIgJC', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `init_in` time NOT NULL,
  `last_out` time NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `employee_name`, `employee_id`, `role`, `init_in`, `last_out`, `status`, `date`) VALUES
(1, 'chow', 1, 'cashier', '14:38:02', '15:38:02', 'late', '2026-07-06'),
(2, 'lu', 1, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-07'),
(3, 'lu', 2, 'Delivery Driver', '15:10:14', '00:00:00', 'Late', '2026-07-07'),
(4, 'lu', 1, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-08'),
(5, 'lu', 2, 'Delivery Driver', '00:00:00', '00:00:00', 'Absent', '2026-07-08'),
(6, 'lu', 6, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-12'),
(7, 'lu', 8, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-12'),
(8, 'lu', 6, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-17'),
(9, 'lu', 8, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-17'),
(10, 'lu', 9, 'Financer', '12:10:50', '12:10:59', 'Late', '2026-07-17'),
(11, 'lu', 6, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-19'),
(12, 'lu', 8, 'Cashier', '10:55:08', '10:55:46', 'Late', '2026-07-19'),
(13, 'lu', 9, 'Financer', '08:27:36', '08:38:54', 'Late', '2026-07-19'),
(14, 'lu', 1, 'Cashier', '15:15:45', '15:15:53', 'Late', '2026-07-21'),
(15, 'lu', 3, 'Delivery', '15:29:33', '15:30:48', 'Late', '2026-07-21'),
(16, 'gon', 4, 'Financer', '15:34:57', '15:50:17', 'Late', '2026-07-21'),
(17, 'chow lu', 1, 'Cashier', '19:08:05', '19:08:23', 'Late', '2026-07-23'),
(18, 'sha lu', 2, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-07-23'),
(19, 'cho lu', 3, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-23'),
(20, 'sha gon', 4, 'Financer', '18:57:22', '19:07:24', 'Late', '2026-07-23'),
(21, 'chow lu', 1, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(22, 'sha lu', 2, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(23, 'cho lu', 3, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(24, 'sha gon', 4, 'Financer', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(132, 'John Micheal  Nuqui', 44, 'Financer', '15:56:55', '15:59:59', 'Absent', '2026-07-25'),
(133, 'Maybelle Dellamas', 46, 'Cashier', '15:45:45', '15:56:50', 'Absent', '2026-07-25'),
(134, 'Andrew Lanojan', 47, 'HR', '19:43:57', '19:45:14', 'Late', '2026-07-21'),
(135, 'Chow Lu', 48, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-21'),
(136, 'Luz Vivian Cantos', 51, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-21'),
(137, 'John Micheal  Nuqui', 44, 'Financer', '21:30:14', '21:50:46', 'Absent', '2026-07-26'),
(138, 'Maybelle Dellamas', 46, 'Cashier', '19:17:49', '20:07:00', 'Absent', '2026-07-26'),
(139, 'Andrew Lanojan', 47, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-07-23'),
(140, 'Chow Lu', 48, 'Cashier', '20:07:06', '20:07:20', 'Late', '2026-07-23'),
(141, 'Luz Vivian Cantos', 51, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-07-23'),
(142, 'John Micheal  Nuqui', 44, 'Financer', '19:01:25', '19:01:30', 'Absent', '2026-07-27'),
(143, 'Maybelle Dellamas', 46, 'Cashier', '18:44:15', '18:44:21', 'Absent', '2026-07-27'),
(144, 'Andrew Lanojan', 47, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-07-27'),
(145, 'Chow Lu', 48, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-07-27'),
(146, 'Luz Vivian Cantos', 51, 'Delivery', '00:00:00', '19:36:49', 'Absent', '2026-07-27'),
(150, 'John Micheal Nuqui', 44, 'Financer', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(151, 'Maybelle Dellamas', 46, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(152, 'Andrew Lanojan', 47, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(153, 'Chow Lu', 48, 'Cashier', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(154, 'Luz Vivian Cantos', 51, 'Delivery', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(155, 'NUQUI B.', 63, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(156, 'NUQUI B.', 64, 'HR', '00:00:00', '00:00:00', 'Absent', '2026-08-04'),
(157, 'NUQUI B.', 65, 'Financer', '00:00:00', '00:00:00', 'Absent', '2026-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `id` int(11) NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `due_date` date NOT NULL,
  `amount` double(11,2) NOT NULL,
  `payment_term` varchar(255) NOT NULL,
  `interval_month` int(11) NOT NULL,
  `installment` double(11,2) NOT NULL,
  `interest` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`id`, `supplier`, `due_date`, `amount`, `payment_term`, `interval_month`, `installment`, `interest`, `status`) VALUES
(47, 'SAMPLE1', '2026-07-30', 7.97, 'Quarterly', 3, 3.00, 0, 'Paid'),
(48, 'SAMPLE1', '2026-10-30', 7.97, 'Quarterly', 3, 3.00, 0, 'Paid'),
(49, 'SAMPLE1', '2027-01-30', 7.97, 'Quarterly', 3, 3.00, 0, 'Paid'),
(50, 'nuqui', '2026-07-24', 5.61, 'Monthly', 1, 4.00, 0, 'Unpaid'),
(51, 'nuqui', '2026-07-19', 5.61, 'Monthly', 1, 4.00, 0, 'Unpaid'),
(52, 'nuqui', '2027-04-02', 5.61, 'Monthly', 1, 4.00, 0, 'Unpaid'),
(53, 'nuqui', '2027-05-02', 5.61, 'Monthly', 1, 4.00, 0, 'Unpaid'),
(115, 'Aqua', '2026-07-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Paid'),
(116, 'Aqua', '2026-08-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(117, 'Aqua', '2026-09-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(118, 'Aqua', '2026-10-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(119, 'Aqua', '2026-11-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(120, 'Aqua', '2026-12-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(121, 'Aqua', '2027-01-30', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(122, 'Aqua', '2027-03-02', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(123, 'Aqua', '2027-04-02', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(124, 'Aqua', '2027-05-02', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(125, 'Aqua', '2027-06-02', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid'),
(126, 'Aqua', '2027-07-02', 1010.00, 'Monthly', 1, 12.00, 10, 'Unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `deleted` varchar(255) NOT NULL DEFAULT 'False'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `contact`, `address`, `deleted`) VALUES
(1, 'John Michael Nuqui', '09873531265', 'Blk 5 Lot 31 Ks 22', 'True'),
(14, 'NUQUI JOHN MICHEAeL B.e', '09348357293', 'eeee', 'True'),
(15, 'NUQUI JOHN MICHEAL B.24124', '09333483572', '1234213', 'True'),
(16, 'NUQUI JO324234HN MICHEAL B.', '09333483572', '23123', 'True'),
(17, 'NUQUI JOHN MICHEAL B.33', '09333483572', '21432134', 'False'),
(18, 'NUQUI JOHN MICHEAL 22B.', '09333483572', '5467457', 'True'),
(19, '23423423', '09333483572', '42342', 'False'),
(20, 'NUQUI JOHN MICHEAL B.325235', '09333483572', '24312421341', 'False');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Active',
  `clocked` varchar(255) NOT NULL DEFAULT 'in',
  `role` varchar(255) NOT NULL DEFAULT 'Employee',
  `deleted` varchar(255) NOT NULL DEFAULT 'False'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `first_name`, `last_name`, `email`, `password`, `status`, `clocked`, `role`, `deleted`) VALUES
(1, 'chow', 'lu', 'cashierlu@gmail.com', '$2y$10$MtDN6dLP/zCVH89tB4Q4peksEDjjlIR.x7ls4Lh1iOOexEmX0DZaG', 'Active', 'in', 'Cashier', 'False'),
(2, 'sha', 'lu', 'hrlu@gmail.com', '$2y$10$TQkeVpvWovSQB0KBYv4juu4gtAszvW2UZaim.kKl6pA/H.oGDqQUK', 'Active', 'in', 'HR', 'False'),
(3, 'cho', 'lu', 'deliverylu@gmail.com', '$2y$10$2shTJkExIKC4s8/a4fi8yukRI2GPBhm0aX1.qus5eTvnJ4pnEYC9O', 'Active', 'in', 'Delivery', 'False'),
(4, 'sha', 'gon', 'financelu@gmail.com', '$2y$10$lFcjbaShdl6ZNkmij/X4D.w6kLxtyj28Q2jLeYMirpuEjt7k413a2', 'Active', 'in', 'Financer', 'False'),
(44, 'John Micheal', 'Nuqui', 'Micheal@gmail.com', '$2y$10$eThGgqNLj1mYbhHuqw7tsuFIEeJAD5wI.Ckte78dEE23VaV3nDYIe', 'Active', 'in', 'Financer', 'False'),
(46, 'Maybelle', 'Dellamas', 'maybelle@gmail.com', '$2y$10$jerUR.qSzdlizTJgc/5BsOWNAYfeH1uw7wfo7ty9cRX.cETHnSsmq', 'Active', 'in', 'Cashier', 'False'),
(47, 'Andrew', 'Lanojan', 'dummy@gmail.com', '$2y$10$QPEBGWhgk2DLoc6gC5fzauGmZFzxNVBQoS1UUurx4dDyiQrUfR6Dq', 'Active', 'in', 'HR', 'False'),
(48, 'Chow', 'Lu', 'chow@gmail.com', '$2y$10$IcZCuxWjVtFVqFUgzof/K.Iv60EyC9pentquSls.1LTgFc2XdkIS.', 'Active', 'in', 'Cashier', 'False'),
(51, 'Luz Vivian', 'Cantos', 'cantos@gmail.com', '$2y$10$FKvc8DNsLdVMg.zXYKCrlOcWZffZoUUEomE8Lhk/i9X.bm.5jQ3lu', 'Active', 'in', 'Delivery', 'False'),
(63, 'NUQUI', 'B.', 'jm233nuqui2006@gmail.com', '$2y$10$KvZBZXNhNdj/dGWIYaikcuw5q3usZzcOFW.i7EHSrzqz2sy1S8Hi.', 'Active', 'in', 'HR', 'False'),
(64, 'NUQUI', 'B.', 'jmnuqu234263457i2006@gmail.com', '$2y$10$JvLiyvdaNNFcdDaJTTYJmufgYoKkhO3RZUyuxHRWITTcOKAmME7ie', 'Active', 'in', 'HR', 'False'),
(65, 'NUQUI', 'B.', '232231@gmail.com', '$2y$10$uS86CVLV2RolGGk1ST7ZD.j8QZu0sEumxVqAFYIiBm8Sr2AHIlbyi', 'Active', 'in', 'Financer', 'False');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `supplier` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `amount` double(11,2) NOT NULL,
  `receipt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `date`, `supplier`, `category`, `amount`, `receipt`) VALUES
(1, '2026-07-15', 'dsagdssdf', 'Maintenance', 1234.00, 'receipt_6a5f2151a91aa2.84407561.png'),
(2, '2026-07-16', 'bchgdfggh', 'Transport/Fuel', 1234.00, 'receipt_6a5f215d2be323.98487501.png'),
(3, '2026-07-17', 'qqqqqqqqqqqqqqq', 'Maintenance', 1000.00, 'receipt_6a5f2171ac99c6.41799864.png'),
(4, '2026-07-17', 'qszxcfasdasqweqweqwe', 'Transport/Fuel', 20000.00, 'receipt_6a5f2164a294e1.39108631.png'),
(5, '2026-07-21', 'Aqua', 'Supplies', 1000.00, 'receipt_6a5f51d3886563.65903446.png'),
(6, '2026-07-21', 'Delivery', 'Transport/Fuel', 100.00, 'receipt_6a5f57ab166b28.64317907.png'),
(7, '2026-07-22', 'Fuel', 'Transport/Fuel', 100.00, 'receipt_6a5f59561d0ad0.58665508.png'),
(8, '2026-07-23', 'Supplies', 'Supplies', 1000.00, 'receipt_6a5f5ac7207ba3.31187410.png'),
(9, '2026-07-21', 'Aqua', 'Supplies', 1000.00, 'receipt_6a5f621b670e38.23089446.png'),
(12, '2026-07-17', 'Smaple', 'Supplies', 300.00, 'receipt_6a599bb28c25a2.43509646.png'),
(13, '2026-07-23', 'nuqui', 'Transport/Fuel', 500.00, 'receipt_6a5f585e3cfad9.28302019.png'),
(14, '2026-07-23', 'nuqui', 'Transport/Fuel', 500.00, 'receipt_6a5f58984a3848.14787959.png'),
(15, '2026-07-23', 'nuqui', 'Transport/Fuel', 500.00, 'receipt_6a5f58cc64df88.54344267.png'),
(16, '2026-07-17', 'nuqui', 'Supplies', 500.00, 'receipt_6a623a3628f727.16511914.png'),
(17, '2026-07-08', 'SAMPLE1', 'Maintenance', 500.00, 'receipt_6a623bb7888b82.39893897.png');

-- --------------------------------------------------------

--
-- Table structure for table `leave_request`
--

CREATE TABLE `leave_request` (
  `id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_role` varchar(255) NOT NULL,
  `leave_type` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` mediumtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `submission_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_request`
--

INSERT INTO `leave_request` (`id`, `employee_name`, `employee_id`, `employee_role`, `leave_type`, `start_date`, `end_date`, `reason`, `status`, `submission_date`) VALUES
(1, 'lu', 8, 'Cashier', 'Sick leave', '2026-07-20', '2026-07-21', 'adasdasd', 'Approved', '2026-07-19'),
(2, 'lu', 1, 'Cashier', 'Sick leave', '2026-07-22', '2026-07-24', 'flu', 'Pending', '2026-07-21'),
(3, 'lu', 1, 'Cashier', 'Sick leave', '2026-07-22', '2026-07-23', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'Pending', '2026-07-21'),
(48, 'Dellamas', 46, 'Cashier', 'Sick leave', '2026-07-28', '2026-07-31', 'SAMPLE 1', 'Approved', '2026-07-27'),
(49, 'Cantos', 51, 'Delivery', 'Sick leave', '2026-07-27', '2026-08-05', '222', 'Approved', '2026-07-27');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Unread',
  `date` varchar(255) DEFAULT NULL,
  `deleted` varchar(255) NOT NULL DEFAULT 'False'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `emp_id`, `role`, `category`, `message`, `status`, `date`, `deleted`) VALUES
(1, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(2, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(3, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(4, 3, 'Delivery', 'Customer Information Added', 'New Customer information has been added on customer list ', 'Unread', '2026-07-21 15:25:38', 'False'),
(5, 3, 'Delivery', 'Customer Information Added', 'New Customer information has been added on customer list ', 'Unread', '2026-07-21 15:26:00', 'False'),
(6, 1, 'Cashier', 'Order Confirmed', 'Order #1 has been Confirmed for Delivery', 'read', '2026-07-21', 'False'),
(7, 3, 'Delivery', 'Order Confirmed', 'Order #1 has been Confirmed for Delivery', 'Unread', '2026-07-21', 'False'),
(8, 2, 'HR', 'Leave Request Submitted', 'Employee lu has submitted a leave request', 'read', '2026-07-21 15:27:47', 'False'),
(9, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(10, 2, 'HR', 'Employee Logged In', 'Employee #3 has logged in their account ', 'read', '2026-07-21', 'False'),
(11, 2, 'HR', 'Employee Logged Out', 'Employee #3 has logged out of their account ', 'read', '2026-07-21', 'False'),
(12, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(13, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(14, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(15, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(16, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(17, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(18, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(19, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(20, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(21, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(22, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(23, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(24, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(25, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(26, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(27, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(28, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(29, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(30, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(31, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(32, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(33, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(34, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(35, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-21', 'False'),
(36, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(37, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(38, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-21', 'False'),
(39, 2, 'HR', 'Leave Request Submitted', 'Employee lu has submitted a leave request', 'read', '2026-07-21 19:52:33', 'False'),
(40, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-21', 'False'),
(41, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-21', 'False'),
(42, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-23', 'False'),
(43, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-23', 'False'),
(44, 2, 'HR', 'Employee Logged Out', 'Employee #4 has logged out of their account ', 'read', '2026-07-23', 'False'),
(45, 2, 'HR', 'Employee Logged In', 'Employee #1 has logged in their account ', 'read', '2026-07-23', 'False'),
(46, 1, 'Cashier', 'Order Pending', 'Order #2 has been Pending for Delivery', 'Unread', '2026-07-23', 'False'),
(47, 3, 'Delivery', 'Order Pending', 'Order #2 has been Pending for Delivery', 'Unread', '2026-07-23', 'False'),
(48, 1, 'Cashier', 'Order Confirmed', 'Order #2 has been confirmed for Delivery', 'Unread', '2026-07-23', 'False'),
(49, 3, 'Delivery', 'Order Confirmed', 'Order #2 has been confirmed for Delivery', 'Unread', '2026-07-23', 'False'),
(50, 2, 'HR', 'Employee Logged Out', 'Employee #1 has logged out of their account ', 'read', '2026-07-23', 'False'),
(51, 2, 'HR', 'Employee Logged In', 'Employee #4 has logged in their account ', 'read', '2026-07-23', 'False'),
(52, 4, 'Financer', 'Net Money For Today', 'Todays net money is ₱0', 'Unread', '2026-08-04', 'False'),
(53, 2, 'HR', 'Absent Employee', 'Employee 1 is absent today', 'read', '2026-08-04', 'False'),
(54, 2, 'HR', 'Absent Employee', 'Employee 3 is absent today', 'read', '2026-08-04', 'False'),
(55, 2, 'HR', 'Absent Employee', 'Employee 4 is absent today', 'read', '2026-08-04', 'False'),
(539, 47, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-07-27', 'False'),
(540, 63, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-07-27', 'False'),
(541, 64, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-07-27', 'False'),
(542, 47, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-07-27', 'False'),
(543, 63, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-07-27', 'False'),
(544, 64, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-07-27', 'False'),
(545, 47, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-07-27', 'False'),
(546, 63, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-07-27', 'False'),
(547, 64, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-07-27', 'False'),
(548, 1, 'Admin', 'Absent Employee in the Last 3 days', 'Employee John Micheal  Nuqui has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(549, 2, 'Admin', 'Absent Employee in the Last 3 days', 'Employee John Micheal  Nuqui has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(550, 47, 'HR', 'Absent Employee in the Last 3 days', 'Employee John Micheal  Nuqui has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(551, 63, 'HR', 'Absent Employee in the Last 3 days', 'Employee John Micheal  Nuqui has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(552, 64, 'HR', 'Absent Employee in the Last 3 days', 'Employee John Micheal  Nuqui has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(553, 1, 'Admin', 'Absent Employee in the Last 3 days', 'Employee Maybelle Dellamas has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(554, 2, 'Admin', 'Absent Employee in the Last 3 days', 'Employee Maybelle Dellamas has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(555, 47, 'HR', 'Absent Employee in the Last 3 days', 'Employee Maybelle Dellamas has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(556, 63, 'HR', 'Absent Employee in the Last 3 days', 'Employee Maybelle Dellamas has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(557, 64, 'HR', 'Absent Employee in the Last 3 days', 'Employee Maybelle Dellamas has been absent for 3 condecutive days', 'Unread', '2026-07-27', 'False'),
(558, 47, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-08-04', 'False'),
(559, 63, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-08-04', 'False'),
(560, 64, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-08-04', 'False'),
(561, 47, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-08-04', 'False'),
(562, 63, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-08-04', 'False'),
(563, 64, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-08-04', 'False'),
(564, 47, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-08-04', 'False'),
(565, 63, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-08-04', 'False'),
(566, 64, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-08-04', 'False'),
(567, 47, 'HR', 'Absent Employee', 'Employee 65 is absent today', 'Unread', '2026-08-04', 'False'),
(568, 63, 'HR', 'Absent Employee', 'Employee 65 is absent today', 'Unread', '2026-08-04', 'False'),
(569, 64, 'HR', 'Absent Employee', 'Employee 65 is absent today', 'Unread', '2026-08-04', 'False'),
(570, 1, 'Admin', 'Product Low on Stock', 'LOW STOCK Only has 2 stock left', 'Unread', '2026-08-04', 'False'),
(571, 2, 'Admin', 'Product Low on Stock', 'LOW STOCK Only has 2 stock left', 'Unread', '2026-08-04', 'False'),
(572, 1, 'Admin', 'Product Out of Stock', 'NO STOCK is currently out of stock', 'Unread', '2026-08-04', 'False'),
(573, 2, 'Admin', 'Product Out of Stock', 'NO STOCK is currently out of stock', 'Unread', '2026-08-04', 'False'),
(574, 47, 'HR', 'Absent Employee', 'Employee 1 is absent today', 'Unread', '2026-08-04', 'False'),
(575, 63, 'HR', 'Absent Employee', 'Employee 1 is absent today', 'Unread', '2026-08-04', 'False'),
(576, 64, 'HR', 'Absent Employee', 'Employee 1 is absent today', 'Unread', '2026-08-04', 'False'),
(577, 47, 'HR', 'Absent Employee', 'Employee 3 is absent today', 'Unread', '2026-08-04', 'False'),
(578, 63, 'HR', 'Absent Employee', 'Employee 3 is absent today', 'Unread', '2026-08-04', 'False'),
(579, 64, 'HR', 'Absent Employee', 'Employee 3 is absent today', 'Unread', '2026-08-04', 'False'),
(580, 47, 'HR', 'Absent Employee', 'Employee 4 is absent today', 'Unread', '2026-08-04', 'False'),
(581, 63, 'HR', 'Absent Employee', 'Employee 4 is absent today', 'Unread', '2026-08-04', 'False'),
(582, 64, 'HR', 'Absent Employee', 'Employee 4 is absent today', 'Unread', '2026-08-04', 'False'),
(583, 2, 'HR', 'Absent Employee', 'Employee 44 is absent today', 'Unread', '2026-08-04', 'False'),
(584, 2, 'HR', 'Absent Employee', 'Employee 46 is absent today', 'Unread', '2026-08-04', 'False'),
(585, 2, 'HR', 'Absent Employee', 'Employee 48 is absent today', 'Unread', '2026-08-04', 'False'),
(586, 2, 'HR', 'Absent Employee', 'Employee 65 is absent today', 'Unread', '2026-08-04', 'False');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `order_content` varchar(999) NOT NULL,
  `total_price` double(11,1) DEFAULT NULL,
  `total_vat` float(11,2) NOT NULL,
  `order_type` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Not received',
  `time` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `cashier` varchar(255) NOT NULL,
  `deleted` varchar(255) NOT NULL DEFAULT 'False'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `customer_contact`, `customer_address`, `order_content`, `total_price`, `total_vat`, `order_type`, `payment_method`, `status`, `time`, `date`, `cashier`, `deleted`) VALUES
(1, 'Chowxinn Lu', '09123123123', 'Dasma Cavite', '2x Round Gallon 18L(Refill)₱70.00 VAT:0.12,1x Small slim gallon 10L(Refill)₱10.00 VAT:0.12', 80.0, 9.60, 'Delivery', 'Cash', 'Received', '03:27PM', '2026/07/21', 'chow', 'False'),
(2, 'Chowxinn Lu', '09123123123', 'Dasma Cavite', '5x Round Gallon 18.00L(Refill)₱175.00 VAT:0.12', 175.0, 21.00, 'Delivery', 'Cash', 'Received', '07:08PM', '2026/07/23', 'chow', 'False'),
(687, 'NUQUI JOHN MICHEAL B.', 'NO INFO', 'NO INFO', '1x Round Gallon 7ML(Refill)₱1.00 VAT:0.66,1x Round Gallon 7L(New Container)₱250.00 VAT:0.12,1x Slim Gallon with Faucet 7L(New Container)₱300.00 VAT:0.12', 551.0, 66.66, 'Pickup', 'Cash', 'Received', '02:23PM', '2026/07/19', 'Maybelle', 'True'),
(688, '23423423', '09333483572', '42342', '1x Slim Gallon with Faucet 7L(New Container)₱300.00 VAT:0.12', 300.0, 36.00, 'Delivery', 'Cash', 'Not received', '03:51PM', '2026/07/21', 'Maybelle', 'False'),
(689, '23423423', '09333483572', '42342', '1x Slim Gallon with Faucet 7.00L(New Container)₱300.00 VAT:0.12', 300.0, 36.00, 'Delivery', 'Cash', 'Received', '04:12PM', '2026/07/21', 'Maybelle', 'False'),
(690, 'NUQUI JOHN MICHEAL B.', 'NO INFO', 'NO INFO', '1x Slim Gallon with Faucet 7.00L(New Container)₱300.00 VAT:0.12', 300.0, 36.00, 'Pickup', 'Cash', 'Received', '04:12PM', '2026/07/21', 'Maybelle', 'False');

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_role` varchar(255) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `max_day_pay` double(11,2) NOT NULL,
  `gross_pay` double(11,2) NOT NULL DEFAULT 0.00,
  `phil_health` double(11,2) NOT NULL DEFAULT 0.00,
  `sss` double(11,2) NOT NULL DEFAULT 0.00,
  `pag_ibig` double(11,2) NOT NULL DEFAULT 0.00,
  `net_pay` double(11,2) NOT NULL DEFAULT 0.00,
  `last_updated` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(255) NOT NULL DEFAULT 'Unpaid',
  `month_year` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `employee_id`, `employee_role`, `employee_name`, `max_day_pay`, `gross_pay`, `phil_health`, `sss`, `pag_ibig`, `net_pay`, `last_updated`, `status`, `month_year`) VALUES
(137, 44, 'Financer', 'Nuqui', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2026-07-27', 'Unpaid', 'July 2026'),
(138, 46, 'Cashier', 'Dellamas', 500.00, 3785.20, 94.63, 75.70, 189.26, 3425.60, '2026-07-27', 'Unpaid', 'July 2026'),
(139, 48, 'Cashier', 'Lu', 500.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2026-07-23', 'Unpaid', 'July 2026'),
(140, 51, 'Delivery', 'Cantos', 600.00, 600.00, 15.00, 12.00, 30.00, 543.00, '2026-07-27', 'Unpaid', 'July 2026'),
(141, 65, 'Financer', 'B.', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '2026-07-23', 'Unpaid', 'July 2026');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `measurement` float(11,2) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` float(11,2) NOT NULL,
  `tax_percentage` float(11,2) NOT NULL,
  `deleted` varchar(255) NOT NULL DEFAULT 'False'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `image`, `product_name`, `category`, `measurement`, `unit`, `stock`, `price`, `tax_percentage`, `deleted`) VALUES
(1, '18.9L.png', 'Round Gallon', 'Refill', 7.00, 'ML', 42, 1.00, 66.00, 'False'),
(2, '18.9L.png', 'Round Gallon', 'New Container', 7.00, 'L', 42, 250.00, 12.00, 'False'),
(15, '10L.png', 'Slim Gallon with Faucet', 'New Container', 7.00, 'L', 38, 300.00, 12.00, 'False'),
(16, '7L.png', 'Water Bottle', 'Refill', 7.00, 'L', 62, 50.00, 12.00, 'False'),
(19, '7L.png', 'Water Bottle', 'New Container', 7.00, 'ML', 50, 345.00, 12.00, 'False'),
(25, '3L.png', 'Slim Gallon with Faucet', 'Refill', 5.00, 'L', 48, 10.00, 12.00, 'False'),
(26, '18.9L.png', 'Michael', 'Refill', 5.00, 'L', 48, 10.00, 12.00, 'False'),
(27, '10L.png', 'Gallon With Faucet', 'Refill', 10.00, 'L', 45, 35.00, 12.00, 'True'),
(29, '10L.png', 'Michael2', 'Refill', 22.00, 'L', 223, 22.00, 2.00, 'True'),
(30, 'resetpass.png', 'LOW STOCK', 'Refill', 2.00, 'L', 2, 22.00, 23.00, 'False'),
(31, '10L.png', 'NO STOCK', 'Refill', 22.80, 'L', 0, 22.00, 23.00, 'False');

-- --------------------------------------------------------

--
-- Table structure for table `settlement_records`
--

CREATE TABLE `settlement_records` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `system_cash` double(11,2) NOT NULL,
  `physical_cash` double(11,2) NOT NULL,
  `variance` double(11,2) NOT NULL,
  `note` mediumtext NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settlement_records`
--

INSERT INTO `settlement_records` (`id`, `date`, `system_cash`, `physical_cash`, `variance`, `note`, `status`) VALUES
(1, '2026-07-11', 5000.00, 4500.00, 500.00, 'SAMPLEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE', 'Confirmed'),
(2, '2026-07-12', 333.33, 23.00, 310.33, '213', 'Cash Over'),
(5, '2026-07-21', 80.00, 80.00, 0.00, 'Balanced', 'Balance'),
(6, '2026-07-23', 175.00, 175.00, 0.00, 'qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq', 'Balance'),
(7, '2026-07-21', 600.00, 222.00, 378.00, '222', 'Cash Over'),
(8, '2026-07-21', 600.00, 222.00, 378.00, '222', 'Cash Over'),
(13, '2026-07-23', 0.00, 44.00, -44.00, '3', 'Cash Short');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `amount` double(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `time`, `date`, `description`, `category`, `type`, `payment_method`, `amount`) VALUES
(2, '10:37:10', '2026-07-17', 'Order #5 Payment', 'Sales', 'Income', 'Cash', 10.00),
(3, '08:21:34', '2026-07-19', 'Order #7 Payment', 'Sales', 'Income', 'Cash', 20.00),
(4, '08:21:56', '2026-07-19', 'Order #4 Payment', 'Sales', 'Income', 'Cash', 30.00),
(5, '15:50:28', '2026-07-21', 'Order #1 Payment', 'Sales', 'Income', 'Cash', 80.00),
(6, '19:34:46', '2026-07-21', 'Paid Expense', 'Transport/Fuel', 'Expense', 'Cash', 100.00),
(7, '19:40:55', '2026-07-21', 'Paid Expense', 'Supplies', 'Expense', 'Cash', 1000.00),
(8, '20:12:11', '2026-07-21', 'Paid Expense', 'Supplies', 'Expense', 'Cash', 1000.00),
(9, '20:13:34', '2026-07-21', 'Paid Invoice Bill', 'Invoice', 'Expense', 'Cash', 1010.00),
(10, '19:08:20', '2026-07-23', 'Order #2 Payment', 'Sales', 'Income', 'Cash', 175.00),
(47, '01:04:21', '2026-07-24', 'Paid Invoice Bill', 'Invoice', 'Expense', 'Cash', 7.97);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_request`
--
ALTER TABLE `leave_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settlement_records`
--
ALTER TABLE `settlement_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `leave_request`
--
ALTER TABLE `leave_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=587;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=691;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `settlement_records`
--
ALTER TABLE `settlement_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
